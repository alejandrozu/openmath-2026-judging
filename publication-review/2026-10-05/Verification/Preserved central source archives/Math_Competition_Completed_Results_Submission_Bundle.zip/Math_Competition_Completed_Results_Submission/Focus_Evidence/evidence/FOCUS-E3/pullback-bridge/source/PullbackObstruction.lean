import Fugu3PullbackCore
import CombinedObstruction

/-!
A supplemental source-faithful bridge for the finite modulus-13 obstruction.
The original diagonal convention is `SA A = {(x,y) : x - y ∈ A}`. The original
curried AP-free/L-free predicates and the existing certificate's conjunction
predicates are explicitly identified below. This is not a claim to solve the
Erdős–Turán conjecture or to establish the optimum among all strong-L-free sets.
-/

namespace Erdos3PullbackBridge

theorem apFree4_iff_cyclic4Free (A : Finset (ZMod 13)) :
    Fugu3Lshape.APFree4 A ↔ Cyclic13Kernel.Cyclic4Free A := by
  constructor
  · intro h a d hd hm
    exact h a d hd hm.1 hm.2.1 hm.2.2.1 hm.2.2.2
  · intro h a d hd h0 h1 h2 h3
    exact h a d hd ⟨h0, h1, h2, h3⟩

theorem lFree_iff_strongLFree (S : Finset (ZMod 13 × ZMod 13)) :
    Fugu3Lshape.LFree S ↔ Erdos3Completion.StrongLFree S := by
  constructor
  · intro h x y d hd hm
    exact h x y d hd hm.1 hm.2.1 hm.2.2.1 hm.2.2.2
  · intro h x y d hd h0 h1 h2 h3
    exact h x y d hd ⟨h0, h1, h2, h3⟩

/-- The actual source-defined diagonal pullback has at most 78 points. -/
theorem card_diagonal_pullback_le_78 (A : Finset (ZMod 13))
    (hA : Fugu3Lshape.APFree4 A) : (Fugu3Lshape.SA A).card ≤ 78 := by
  rw [Fugu3Lshape.card_SA]
  exact Nat.mul_le_mul_left 13
    (Cyclic13Kernel.cyclic4Free_card_le_six A ((apFree4_iff_cyclic4Free A).mp hA))

/-- The retained 79-point witness exceeds every actual diagonal pullback. -/
theorem retained_witness_beats_every_diagonal_pullback :
    Erdos3R17.B.card = 79 ∧ Fugu3Lshape.LFree Erdos3R17.B ∧
    ∀ A : Finset (ZMod 13), Fugu3Lshape.APFree4 A →
      Fugu3Lshape.LFree (Fugu3Lshape.SA A) ∧
      (Fugu3Lshape.SA A).card = 13 * A.card ∧
      (Fugu3Lshape.SA A).card ≤ 78 ∧
      (Fugu3Lshape.SA A).card < Erdos3R17.B.card := by
  refine ⟨Erdos3R17.B_card, (lFree_iff_strongLFree _).mpr Erdos3R17.B_Lfree, ?_⟩
  intro A hA
  have hcard := card_diagonal_pullback_le_78 A hA
  refine ⟨Fugu3Lshape.lfree_of_apfree hA, Fugu3Lshape.card_SA A, hcard, ?_⟩
  rw [Erdos3R17.B_card]
  exact lt_of_le_of_lt hcard (by decide)

#print axioms apFree4_iff_cyclic4Free
#print axioms lFree_iff_strongLFree
#print axioms card_diagonal_pullback_le_78
#print axioms retained_witness_beats_every_diagonal_pullback

end Erdos3PullbackBridge
