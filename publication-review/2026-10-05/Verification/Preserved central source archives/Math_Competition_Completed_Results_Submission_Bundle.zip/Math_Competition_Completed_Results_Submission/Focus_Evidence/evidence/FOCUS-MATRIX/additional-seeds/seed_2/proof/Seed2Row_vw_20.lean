import Seed2KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed2
open Matrix
theorem row_vw_20 : (L_vw * M_vw) (20 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 20 := by decide
#print axioms row_vw_20
end RecoveredMMTKernelSeed2
