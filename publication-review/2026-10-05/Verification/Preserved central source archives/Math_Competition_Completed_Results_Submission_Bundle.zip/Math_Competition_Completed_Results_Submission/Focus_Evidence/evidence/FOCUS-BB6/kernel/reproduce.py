"""Recheck every delivered source, in dependency order, using standard Lean."""
import argparse,hashlib,json,os,pathlib,subprocess,time
p=pathlib.Path(__file__).resolve().parent
arg=argparse.ArgumentParser();arg.add_argument('--lean',default='lean');args=arg.parse_args()
out=p/'reproduction';out.mkdir(exist_ok=True)
env=os.environ.copy();env['LEAN_PATH']=str(out)
manifest=json.loads((p/'source-manifest.json').read_text())
for file,sha in manifest.items():
 assert hashlib.sha256((p/file).read_bytes()).hexdigest()==sha, 'Changed source: '+file
receipt=[]
for mod in json.loads((p/'modules.json').read_text()):
 start=time.monotonic();peak=0
 with (out/(mod+'.log')).open('w') as log:
  proc=subprocess.Popen([args.lean,'-j1','-M1536','-o',str(out/(mod+'.olean')),str(p/(mod+'.lean'))],env=env,stdout=log,stderr=subprocess.STDOUT)
  while proc.poll() is None:
   try:
    lines=pathlib.Path(f'/proc/{proc.pid}/status').read_text().splitlines();rss=int(next(x for x in lines if x.startswith('VmRSS:')).split()[1]);peak=max(peak,rss)
   except (FileNotFoundError,StopIteration):pass
   if peak>2*1024*1024 or time.monotonic()-start>180:
    proc.kill();proc.wait();log.write('\nRESOURCE LIMIT EXCEEDED\n');break
   time.sleep(.05)
 rec={'module':mod,'exit':proc.returncode,'seconds':time.monotonic()-start,'maxrss_kib':peak};receipt.append(rec)
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(rec),flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
