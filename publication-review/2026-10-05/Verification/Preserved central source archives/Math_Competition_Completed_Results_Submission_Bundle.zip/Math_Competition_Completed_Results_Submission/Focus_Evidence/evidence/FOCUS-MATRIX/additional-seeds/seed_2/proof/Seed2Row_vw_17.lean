import Seed2KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed2
open Matrix
theorem row_vw_17 : (L_vw * M_vw) (17 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 17 := by decide
#print axioms row_vw_17
end RecoveredMMTKernelSeed2
