import Init
import Lean.Elab.Tactic.Omega
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace BB6Kernel
-- left stores cells -1,-2,... from its least significant bit.
-- right stores the current cell, then cells +1,+2,... from its least significant bit.
structure Cfg where
  state : Nat
  left : Nat
  right : Nat
  deriving DecidableEq, Repr

def moveR (s w : Nat) (c : Cfg) : Cfg := ⟨s, c.left * 2 + w, c.right / 2⟩
def moveL (s w : Nat) (c : Cfg) : Cfg := ⟨s, c.left / 2, (c.right / 2 * 2 + w) * 2 + c.left % 2⟩
-- States A through F are 0 through 5. H is 6.
-- none means no transition exists from an already halted state.
def step (c : Cfg) : Option Cfg :=
  match c.state, c.right % 2 with
  | 0, 0 => some (moveR 1 1 c)
  | 0, 1 => some (moveL 2 0 c)
  | 1, 0 => some (moveR 3 1 c)
  | 1, 1 => some (moveR 1 1 c)
  | 2, 0 => some (moveL 6 0 c)
  | 2, 1 => some (moveL 4 1 c)
  | 3, 0 => some (moveL 0 1 c)
  | 3, 1 => some (moveL 3 1 c)
  | 4, 0 => some (moveL 0 0 c)
  | 4, 1 => some (moveL 5 1 c)
  | 5, 0 => some (moveL 4 0 c)
  | 5, 1 => some (moveR 3 0 c)
  | _, _ => none

def run : Nat → Cfg → Option Cfg
  | 0, c => some c
  | n+1, c => (step c).bind (run n)

def blank : Cfg := ⟨0, 0, 0⟩


def block : Nat → Nat → Nat
 | 0, x => x
 | n+1, x => 2 * block n x + 1
 theorem block_push (n x : Nat) : block n (2*x+1) = 2*block n x+1 := by
  induction n with
  | zero => rfl
  | succ n ih => simp only [block, ih]
 theorem odd (x : Nat) : (2*x+1)%2 = 1 := by omega
 theorem half (x : Nat) : (2*x+1)/2 = x := by omega
 theorem run_add (a b : Nat) (c : Cfg) : run (a+b) c = (run a c).bind (run b) := by
  induction a generalizing c with
  | zero => simp only [Nat.zero_add, run, Option.bind_some]
  | succ a ih =>
    simp only [Nat.succ_add, run]
    cases h : step c with
    | none => rfl
    | some d => exact ih d
 theorem run_B (n l r : Nat) :
     run n ⟨1,l,block n r⟩ = some ⟨1,block n l,r⟩ := by
  induction n generalizing l r with
  | zero => rfl
  | succ n ih =>
    simp only [run, block, step, odd, moveR, half, Option.bind_some]
    rw [Nat.mul_comm l 2, ih, block_push]
 theorem run_D (n l r : Nat) :
     run n ⟨3,block n l,2*r+1⟩ = some ⟨3,l,block n (2*r+1)⟩ := by
  induction n generalizing l r with
  | zero => rfl
  | succ n ih =>
    simp only [run, block, step, odd, moveL, half, Option.bind_some]
    rw [Nat.mul_comm r 2, Nat.mul_comm (2*r+1) 2, ih, block_push]
theorem block_eq (n x : Nat) : block n x + 1 = 2^n * (x+1) := by
  induction n with
  | zero => simp [block]
  | succ n ih =>
    simp only [block, Nat.pow_succ]
    rw [Nat.mul_comm (2^n) 2, Nat.mul_assoc, ← ih]
    omega
 theorem block_closed (n x : Nat) : block n x = 2^n * (x+1)-1 := by
  have := block_eq n x
  omega
 theorem run_B_fast (n l r : Nat) :
     run n ⟨1,l,2^n*(r+1)-1⟩ = some ⟨1,2^n*(l+1)-1,r⟩ := by
  simpa only [block_closed] using run_B n l r
 theorem run_D_fast (n l r : Nat) :
     run n ⟨3,2^n*(l+1)-1,2*r+1⟩ = some ⟨3,l,2^n*(2*r+2)-1⟩ := by
  simpa only [block_closed] using run_D n l r
theorem join {a b : Nat} {c d e : Cfg}
 (h₁ : run a c = some d) (h₂ : run b d = some e) :
 run (a+b) c = some e := by
 rw [run_add, h₁]
 exact h₂
#print axioms run_B_fast
#print axioms run_D_fast
end BB6Kernel
