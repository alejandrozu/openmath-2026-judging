#!/usr/bin/env python3
"""Fresh, complete, source-only replay; writes evidence and never imports prior seed oleans."""
from pathlib import Path
import argparse, concurrent.futures, datetime, hashlib, json, os, re, shutil, subprocess, sys, time
R=Path(__file__).resolve().parent
ROOT=R.parents[1]
EXPECTED_MATHLIB='0df444a360eaa60ab8c11dca51a86af692955474'
ALLOWED={'propext','Classical.choice','Quot.sound'}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,obj): p.write_text(json.dumps(obj,indent=2)+'\n')
def dependency_environment():
    lean=ROOT/'lean-cloud/.elan/toolchains/leanprover--lean4---v4.33.1/bin/lean'
    packages=ROOT/'lean-cloud/fc4331/.lake/packages'
    paths=sorted(packages.glob('*/.lake/build/lib/lean'))
    pins=[]
    for p in sorted(packages.iterdir()):
        if (p/'.git').exists():
            commit=subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
            pins.append({'package':p.name,'git_revision':commit})
    assert next(x['git_revision'] for x in pins if x['package']=='mathlib')==EXPECTED_MATHLIB
    version=subprocess.check_output([str(lean),'--version'],text=True).strip()
    assert 'version 4.33.1,' in version
    return lean,paths,{'lean_version':version,'lean_binary_sha256':sha(lean),'dependency_pins':pins,
                       'dependency_search_paths':[str(p) for p in paths]}

def run(seed, lean, paths, environment):
    r=R/f'seed_{seed}'; prefix=f'Seed{seed}'; timestamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    replay=r/'replay'/timestamp; replay.mkdir(parents=True)  # Fails if any previous outputs exist.
    modules=[f'{prefix}KernelData']+[f'{prefix}Row_{n}_{i:02d}' for n in ('uv','uw','vw') for i in range(23)]+[f'{prefix}KernelFinal']
    sources=[]
    for mod in modules:
        p=r/'proof'/f'{mod}.lean'
        assert not re.search(r'\b(sorry|admit|axiom|native_decide|unsafe)\b',p.read_text())
        q=replay/p.name; shutil.copyfile(p,q); sources.append({'file':p.name,'sha256':sha(p)})
    assert not list(replay.glob('*.olean'))
    env=dict(os.environ); env['LEAN_PATH']=os.pathsep.join([str(replay)]+[str(p) for p in paths])
    receipt={'schema':'matrix-additional-seeds-standard-kernel-v1','seed':seed,'namespace':f'RecoveredMMTKernelSeed{seed}',
        'started_utc':now(),'original_sha256':sha(r/'original'/f'hks139_{seed}.json'), 'fresh_replay_directory':str(replay.relative_to(R)),
        'fresh_directory_initial_olean_count':0,'source_modules':sources,'memory_limit_MiB':4096,'per_module_timeout_seconds':120,
        'environment':environment,'modules':[],'status':'running','axiom_whitelist':sorted(ALLOWED)}
    receipt_path=r/'kernel-check-receipt.json'; save(receipt_path,receipt)
    for mod in modules:
        p=replay/f'{mod}.lean'; command=[str(lean),'-M','4096','-o',f'{mod}.olean',p.name]; start=time.monotonic()
        try:
            cp=subprocess.run(command,cwd=replay,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120,text=True)
            code,out=cp.returncode,cp.stdout
        except subprocess.TimeoutExpired as e:
            code=124; out=e.stdout or ''; out=out.decode() if isinstance(out,bytes) else out
        (replay/f'{mod}.log').write_text(out)
        declarations=[]
        for name,axioms in re.findall(r"'([^']+)' depends on axioms: \[([^]]*)\]",out,re.S):
            ax=[x.strip() for x in axioms.split(',') if x.strip()]; assert set(ax)<=ALLOWED,(name,ax)
            declarations.append({'declaration':name,'axioms':ax})
        for name in re.findall(r"'([^']+)' does not depend on any axioms",out):
            declarations.append({'declaration':name,'axioms':[]})
        entry={'module':mod,'exit_code':code,'seconds':round(time.monotonic()-start,3),'source_sha256':sha(p),
            'log':str((replay/f'{mod}.log').relative_to(R)),'log_sha256':sha(replay/f'{mod}.log'),'completed_utc':now(),
            'axiom_reports':declarations,'command':command}
        if code==0:
            assert (replay/f'{mod}.olean').is_file(); entry['olean_sha256']=sha(replay/f'{mod}.olean')
        receipt['modules'].append(entry); save(receipt_path,receipt)
        print(json.dumps({'seed':seed,**entry}),flush=True)
        if code:
            receipt['status']='failed'; receipt['completed_utc']=now(); save(receipt_path,receipt)
            return False
    row_reports=[d for m in receipt['modules'][1:-1] for d in m['axiom_reports']]
    final_reports=receipt['modules'][-1]['axiom_reports']
    required={f'RecoveredMMTKernelSeed{seed}.{kind}_{n}' for kind in ('left_inverse','rational_injective','remaining_factor_unique') for n in ('uv','uw','vw')}
    assert len(row_reports)==69 and {d['declaration'] for d in final_reports}==required
    receipt.update(status='passed',completed_utc=now(),total_modules=71,total_row_modules=69,
        rational_injectivity_endpoints=3,remaining_factor_uniqueness_endpoints=3,
        only_standard_axioms=True,all_modules_freshly_compiled=True,
        total_module_seconds=round(sum(m['seconds'] for m in receipt['modules']),3))
    save(receipt_path,receipt); return True

if __name__=='__main__':
    lean,paths,environment=dependency_environment(); save(R/'environment-receipt.json',environment)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        outcomes=list(pool.map(lambda seed:run(seed,lean,paths,environment),(1,2)))
    sys.exit(0 if all(outcomes) else 1)
