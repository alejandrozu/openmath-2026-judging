import BooleanTree
import CardBridge

-- NEW supplemental proof, 2026-10-02; not part of the supplied submission.
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
namespace Cyclic13Kernel
def Cyclic4Free (A : Finset (ZMod 13)) : Prop :=
  ∀ a d : ZMod 13, d ≠ 0 → ¬ (a ∈ A ∧ a+d ∈ A ∧ a+2*d ∈ A ∧ a+3*d ∈ A)

theorem cyclic4Free_card_le_six (A : Finset (ZMod 13)) (hf : Cyclic4Free A) : A.card ≤ 6 := by
  have h := boolean_certificate (decide ((0 : ZMod 13) ∈ A)) (decide ((1 : ZMod 13) ∈ A)) (decide ((2 : ZMod 13) ∈ A)) (decide ((3 : ZMod 13) ∈ A)) (decide ((4 : ZMod 13) ∈ A)) (decide ((5 : ZMod 13) ∈ A)) (decide ((6 : ZMod 13) ∈ A)) (decide ((7 : ZMod 13) ∈ A)) (decide ((8 : ZMod 13) ∈ A)) (decide ((9 : ZMod 13) ∈ A)) (decide ((10 : ZMod 13) ∈ A)) (decide ((11 : ZMod 13) ∈ A)) (decide ((12 : ZMod 13) ∈ A))
  unfold Good at h
  simp only [decide_eq_true_eq] at h
  rcases h with h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h | h
  · rw [card_eq]; exact h
  · exfalso
    have bad := hf 0 1 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 0 2 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 0 3 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 0 4 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 0 5 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.2.2, h.2.1⟩
  · exfalso
    have bad := hf 0 6 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.2.2, h.2.1⟩
  · exfalso
    have bad := hf 0 7 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 0 8 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 0 9 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 0 10 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 0 11 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 0 12 (by decide)
    apply bad
    change (0 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 1 1 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 1 2 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 1 3 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 1 5 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.2.2, h.2.1⟩
  · exfalso
    have bad := hf 1 6 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 1 7 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 1 8 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 1 9 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 1 10 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 1 11 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 1 12 (by decide)
    apply bad
    change (1 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 2 1 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 2 2 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 2 3 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 2 5 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.2.2, h.2.1⟩
  · exfalso
    have bad := hf 2 6 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 2 7 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 2 9 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 2 10 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 2 11 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 2 12 (by decide)
    apply bad
    change (2 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 3 1 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 3 2 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 3 3 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 3 5 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 3 6 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 3 7 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 3 9 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.2, h.2.2.1, h.2.1⟩
  · exfalso
    have bad := hf 3 10 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 3 11 (by decide)
    apply bad
    change (3 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 4 1 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 4 2 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 4 5 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 4 6 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 4 7 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.2.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 4 9 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 4 10 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 4 11 (by decide)
    apply bad
    change (4 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 5 1 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 5 2 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 5 5 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 5 6 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 5 9 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 5 10 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 5 11 (by decide)
    apply bad
    change (5 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 6 1 (by decide)
    apply bad
    change (6 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 6 2 (by decide)
    apply bad
    change (6 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 6 5 (by decide)
    apply bad
    change (6 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 6 6 (by decide)
    apply bad
    change (6 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 6 9 (by decide)
    apply bad
    change (6 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 6 10 (by decide)
    apply bad
    change (6 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 7 1 (by decide)
    apply bad
    change (7 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 7 5 (by decide)
    apply bad
    change (7 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.2.2.2, h.1, h.2.2.1⟩
  · exfalso
    have bad := hf 7 6 (by decide)
    apply bad
    change (7 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 7 9 (by decide)
    apply bad
    change (7 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A ∧ (8 : ZMod 13) ∈ A
    exact ⟨h.2.1, h.1, h.2.2.2, h.2.2.1⟩
  · exfalso
    have bad := hf 7 10 (by decide)
    apply bad
    change (7 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 8 1 (by decide)
    apply bad
    change (8 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 8 5 (by decide)
    apply bad
    change (8 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 8 9 (by decide)
    apply bad
    change (8 : ZMod 13) ∈ A ∧ (4 : ZMod 13) ∈ A ∧ (0 : ZMod 13) ∈ A ∧ (9 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 8 10 (by decide)
    apply bad
    change (8 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 9 1 (by decide)
    apply bad
    change (9 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.1, h.2.1, h.2.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 9 5 (by decide)
    apply bad
    change (9 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 9 9 (by decide)
    apply bad
    change (9 : ZMod 13) ∈ A ∧ (5 : ZMod 13) ∈ A ∧ (1 : ZMod 13) ∈ A ∧ (10 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 10 5 (by decide)
    apply bad
    change (10 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.1, h.2.1, h.2.2.2⟩
  · exfalso
    have bad := hf 10 9 (by decide)
    apply bad
    change (10 : ZMod 13) ∈ A ∧ (6 : ZMod 13) ∈ A ∧ (2 : ZMod 13) ∈ A ∧ (11 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩
  · exfalso
    have bad := hf 11 9 (by decide)
    apply bad
    change (11 : ZMod 13) ∈ A ∧ (7 : ZMod 13) ∈ A ∧ (3 : ZMod 13) ∈ A ∧ (12 : ZMod 13) ∈ A
    exact ⟨h.2.2.1, h.2.1, h.1, h.2.2.2⟩

#print axioms cyclic4Free_card_le_six
end Cyclic13Kernel
