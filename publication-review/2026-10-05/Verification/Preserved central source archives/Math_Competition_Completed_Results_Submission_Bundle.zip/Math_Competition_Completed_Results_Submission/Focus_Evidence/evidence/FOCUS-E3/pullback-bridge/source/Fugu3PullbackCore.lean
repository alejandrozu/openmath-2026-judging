import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Finset.Prod
import Mathlib.Tactic.Ring

/-! Exact original core, through `card_SA`, retained verbatim from Fugu3_Lshape.lean.
Only the broad import is replaced, and the original namespace is closed here. -/

namespace Fugu3Lshape

variable {M : ℕ} [NeZero M]

/-- No `a, d` with `d ≠ 0` and `a, a+d, a+2d, a+3d ∈ A`. -/
def APFree4 (A : Finset (ZMod M)) : Prop :=
  ∀ a d : ZMod M, d ≠ 0 → a ∈ A → a + d ∈ A → a + 2 * d ∈ A → a + 3 * d ∈ A → False

/-- No L-shape `(x,y),(x,y+d),(x,y+2d),(x+d,y)` with `d ≠ 0`. -/
def LFree (S : Finset (ZMod M × ZMod M)) : Prop :=
  ∀ x y d : ZMod M, d ≠ 0 → (x, y) ∈ S → (x, y + d) ∈ S → (x, y + 2 * d) ∈ S →
    (x + d, y) ∈ S → False

/-- `S_A = {(x,y) : x - y ∈ A}`. -/
def SA (A : Finset (ZMod M)) : Finset (ZMod M × ZMod M) :=
  Finset.univ.filter (fun p => p.1 - p.2 ∈ A)

theorem mem_SA {A : Finset (ZMod M)} {p : ZMod M × ZMod M} :
    p ∈ SA A ↔ p.1 - p.2 ∈ A := by
  simp [SA]

/-- An L-shape in `S_A` projects to the 4-AP `s-2d, s-d, s, s+d`. -/
theorem lfree_of_apfree {A : Finset (ZMod M)} (hA : APFree4 A) : LFree (SA A) := by
  intro x y d hd h0 h1 h2 h3
  have e0 : x - y - 2 * d = x - (y + 2 * d) := by ring
  have e1 : x - y - 2 * d + d = x - (y + d) := by ring
  have e2 : x - y - 2 * d + 2 * d = x - y := by ring
  have e3 : x - y - 2 * d + 3 * d = x + d - y := by ring
  have m0 : x - (y + 2 * d) ∈ A := mem_SA.mp h2
  have m1 : x - (y + d) ∈ A := mem_SA.mp h1
  have m2 : x - y ∈ A := mem_SA.mp h0
  have m3 : x + d - y ∈ A := mem_SA.mp h3
  refine hA (x - y - 2 * d) d hd ?_ ?_ ?_ ?_
  · rw [e0]; exact m0
  · rw [e1]; exact m1
  · rw [e2]; exact m2
  · rw [e3]; exact m3

theorem SA_eq_image (A : Finset (ZMod M)) :
    SA A = (A ×ˢ (Finset.univ : Finset (ZMod M))).image (fun q => (q.1 + q.2, q.2)) := by
  ext p
  rw [mem_SA, Finset.mem_image]
  constructor
  · intro hp
    refine ⟨(p.1 - p.2, p.2), ?_, ?_⟩
    · rw [Finset.mem_product]
      exact ⟨hp, Finset.mem_univ _⟩
    · ext
      · simp
      · simp
  · rintro ⟨q, hq, rfl⟩
    rw [Finset.mem_product] at hq
    simpa using hq.1

/-- Fibre count: `|S_A| = M * |A|`. -/
theorem card_SA (A : Finset (ZMod M)) : (SA A).card = M * A.card := by
  have hinj : Function.Injective (fun q : ZMod M × ZMod M => (q.1 + q.2, q.2)) := by
    intro q r hqr
    have hqrEq : (q.1 + q.2, q.2) = (r.1 + r.2, r.2) := hqr
    rw [Prod.mk.injEq] at hqrEq
    obtain ⟨h1, h2⟩ := hqrEq
    refine Prod.ext ?_ h2
    rw [h2] at h1
    exact add_right_cancel h1
  rw [SA_eq_image, Finset.card_image_of_injective _ hinj, Finset.card_product,
    Finset.card_univ, ZMod.card, mul_comm]

end Fugu3Lshape

#print axioms Fugu3Lshape.lfree_of_apfree
#print axioms Fugu3Lshape.SA_eq_image
#print axioms Fugu3Lshape.card_SA
