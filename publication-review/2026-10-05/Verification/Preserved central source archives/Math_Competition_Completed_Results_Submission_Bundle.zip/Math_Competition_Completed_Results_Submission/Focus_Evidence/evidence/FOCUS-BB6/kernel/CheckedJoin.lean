import Kernel
namespace BB6Kernel
theorem join_checked {a b total : Nat} {c d e : Cfg}
 (ht : a+b=total) (h₁ : run a c = some d) (h₂ : run b d = some e) :
 run total c = some e := by
 rw [←ht]
 exact join h₁ h₂
end BB6Kernel
