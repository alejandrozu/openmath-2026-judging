#!/usr/bin/env python3
"""Check all recorded proof-module/log hashes and the permitted axiom boundary."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parent
ALLOWED={'propext','Classical.choice','Quot.sound'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for seed in (1,2):
 r=R/f'seed_{seed}'; c=json.loads((r/'kernel-check-receipt.json').read_text()); assert c['status']=='passed'
 assert c['fresh_directory_initial_olean_count']==0 and len(c['modules'])==71
 assert c['total_row_modules']==69 and c['rational_injectivity_endpoints']==3 and c['remaining_factor_uniqueness_endpoints']==3
 expected=[f'Seed{seed}KernelData']+[f'Seed{seed}Row_{n}_{i:02d}' for n in ('uv','uw','vw') for i in range(23)]+[f'Seed{seed}KernelFinal']
 assert [m['module'] for m in c['modules']]==expected
 reports=[]
 for m in c['modules']:
  assert m['exit_code']==0
  source=r/'proof'/f'{m["module"]}.lean'; copied=R/c['fresh_replay_directory']/source.name
  assert source.read_bytes()==copied.read_bytes() and sha(source)==m['source_sha256']
  assert not re.search(r'\b(sorry|admit|axiom|native_decide|unsafe)\b',source.read_text())
  log=R/m['log']; assert sha(log)==m['log_sha256']
  for e in m['axiom_reports']:
   assert set(e['axioms'])==ALLOWED; reports.append(e['declaration'])
 assert len(reports)==78
 correspondence=json.loads((r/'source-data-correspondence.json').read_text())
 assert correspondence['original_factor_sha256']==c['original_sha256']
 assert correspondence['KernelData_sha256']==c['modules'][0]['source_sha256']
 assert correspondence['factor_arrays_exact_match'] and correspondence['Brent_identities_checked']==729 and not correspondence['Brent_identities_failures']
 results.append({'seed':seed,'source_modules_checked':71,'compiler_logs_checked':71,'axiom_declarations_checked':len(reports),'status':'passed','completed_utc':c['completed_utc']})
summary={'schema':'matrix-additional-seeds-final-audit-v1','audited_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','seeds':results,
 'total_source_modules':142,'total_inverse_row_proofs':138,'rational_injectivity_endpoints':6,'remaining_factor_uniqueness_endpoints':6,
 'only_standard_axioms':sorted(ALLOWED),'original_inputs_preserved':True,'no_existing_report_changes':True}
(R/'final-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
