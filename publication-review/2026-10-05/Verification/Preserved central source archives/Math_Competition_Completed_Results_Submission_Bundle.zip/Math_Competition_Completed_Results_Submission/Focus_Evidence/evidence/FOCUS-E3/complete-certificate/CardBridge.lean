import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Tactic.NormNum
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
open scoped BigOperators
namespace Cyclic13Kernel
lemma indicator (p : Prop) [Decidable p] : (if p then 1 else 0 : ℕ) = (decide p).toNat := by split <;> simp_all
lemma card_eq (A : Finset (ZMod 13)) : A.card =
 (decide (0∈A)).toNat + (decide (1∈A)).toNat + (decide (2∈A)).toNat + (decide (3∈A)).toNat + (decide (4∈A)).toNat + (decide (5∈A)).toNat + (decide (6∈A)).toNat + (decide (7∈A)).toNat + (decide (8∈A)).toNat + (decide (9∈A)).toNat + (decide (10∈A)).toNat + (decide (11∈A)).toNat + (decide (12∈A)).toNat := by
 have hu : (Finset.univ : Finset (ZMod 13)) = {0,1,2,3,4,5,6,7,8,9,10,11,12} := by decide +kernel
 have he : Finset.univ.filter (fun x : ZMod 13 => x ∈ A) = A := by ext; simp
 have h := Finset.sum_boole (R := ℕ) (fun x : ZMod 13 => x ∈ A) (Finset.univ)
 rw [he, hu] at h
 have hn0 : (0 : ZMod 13) ∉ ({1,2,3,4,5,6,7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn1 : (1 : ZMod 13) ∉ ({2,3,4,5,6,7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn2 : (2 : ZMod 13) ∉ ({3,4,5,6,7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn3 : (3 : ZMod 13) ∉ ({4,5,6,7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn4 : (4 : ZMod 13) ∉ ({5,6,7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn5 : (5 : ZMod 13) ∉ ({6,7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn6 : (6 : ZMod 13) ∉ ({7,8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn7 : (7 : ZMod 13) ∉ ({8,9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn8 : (8 : ZMod 13) ∉ ({9,10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn9 : (9 : ZMod 13) ∉ ({10,11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn10 : (10 : ZMod 13) ∉ ({11,12} : Finset (ZMod 13)) := by decide +kernel
 have hn11 : (11 : ZMod 13) ∉ ({12} : Finset (ZMod 13)) := by decide +kernel
 simp only [Finset.sum_insert hn0, Finset.sum_insert hn1, Finset.sum_insert hn2, Finset.sum_insert hn3, Finset.sum_insert hn4, Finset.sum_insert hn5, Finset.sum_insert hn6, Finset.sum_insert hn7, Finset.sum_insert hn8, Finset.sum_insert hn9, Finset.sum_insert hn10, Finset.sum_insert hn11, Finset.sum_singleton, indicator, Nat.cast_id] at h
 simp only [Nat.add_assoc] at h ⊢
 exact h.symm
end Cyclic13Kernel
