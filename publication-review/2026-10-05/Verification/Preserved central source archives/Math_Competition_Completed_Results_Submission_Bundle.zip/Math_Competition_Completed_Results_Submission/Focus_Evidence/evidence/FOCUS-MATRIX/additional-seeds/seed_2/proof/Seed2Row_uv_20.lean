import Seed2KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed2
open Matrix
theorem row_uv_20 : (L_uv * M_uv) (20 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 20 := by decide
#print axioms row_uv_20
end RecoveredMMTKernelSeed2
