import R17SplitReplay
import CyclicUpper

/-!
New combination proof, 2 October 2026. The 79-point witness is the unchanged
supplied witness. Its row-partitioned proof and the cyclic upper certificate are
explicitly labelled reconstructions. This theorem concerns only the finite
strong-L/cyclic-four-AP extremal comparison at modulus 13. It does not claim
optimality of the L-free set or prove/refute the Erdős–Turán conjecture.
-/

namespace Erdos3Completion

def StrongLFree (B : Finset (ZMod 13 × ZMod 13)) : Prop :=
  ∀ x y d : ZMod 13, d ≠ 0 →
    ¬ ((x, y) ∈ B ∧ (x, y + d) ∈ B ∧
      (x, y + 2 * d) ∈ B ∧ (x + d, y) ∈ B)

theorem explicit_L_witness_beats_every_cyclic_AP_free_set :
    ∃ B : Finset (ZMod 13 × ZMod 13),
      B.card = 79 ∧ StrongLFree B ∧
      ∀ A : Finset (ZMod 13), Cyclic13Kernel.Cyclic4Free A →
        13 * A.card < B.card := by
  refine ⟨Erdos3R17.B, Erdos3R17.B_card, Erdos3R17.B_Lfree, ?_⟩
  intro A hA
  have h := Cyclic13Kernel.cyclic4Free_card_le_six A hA
  have hmul : 13 * A.card ≤ 78 := Nat.mul_le_mul_left 13 h
  rw [Erdos3R17.B_card]
  exact lt_of_le_of_lt hmul (by decide)

#print axioms explicit_L_witness_beats_every_cyclic_AP_free_set

end Erdos3Completion
