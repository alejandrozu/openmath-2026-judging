import Kernel
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace BB6Kernel
-- bit x k is the cell k places from the least-significant end.
def bit : Nat → Nat → Nat
 | x, 0 => x % 2
 | x, k+1 => bit (x/2) k
-- The following six cell identities specify writing w and moving one cell.
-- They give a representation-level soundness bridge to the ordinary tape rule.
theorem moveR_written (s w : Nat) (c : Cfg) (hw : w < 2) :
 bit (moveR s w c).left 0 = w := by
 simp only [moveR, bit]
 omega
theorem moveR_left_tail (s w k : Nat) (c : Cfg) (hw : w < 2) :
 bit (moveR s w c).left (k+1) = bit c.left k := by
 simp only [moveR, bit]
 have h : (c.left*2+w)/2 = c.left := by omega
 rw [h]
theorem moveR_right (s w k : Nat) (c : Cfg) :
 bit (moveR s w c).right k = bit c.right (k+1) := by rfl
theorem moveL_left (s w k : Nat) (c : Cfg) :
 bit (moveL s w c).left k = bit c.left (k+1) := by rfl
theorem moveL_current (s w : Nat) (c : Cfg) :
 bit (moveL s w c).right 0 = bit c.left 0 := by
 simp only [moveL, bit]
 omega
theorem moveL_written (s w : Nat) (c : Cfg) (hw : w < 2) :
 bit (moveL s w c).right 1 = w := by
 simp only [moveL, bit]
 omega
theorem moveL_right_tail (s w k : Nat) (c : Cfg) (hw : w < 2) :
 bit (moveL s w c).right (k+2) = bit c.right (k+1) := by
 simp only [moveL, bit]
 have h : ((c.right/2*2+w)*2+c.left%2)/2/2 = c.right/2 := by omega
 rw [h]
theorem halted_no_transition (c : Cfg) (h : c.state = 6) : step c = none := by
 simp only [step, h]
theorem run_halted (n : Nat) (c : Cfg) (h : c.state = 6) (hn : n ≠ 0) : run n c = none := by
 cases n with
 | zero => contradiction
 | succ n => simp only [run, halted_no_transition c h, Option.bind_none]
theorem no_earlier_halt {m : Nat} {a e : Cfg} (h : run m a = some e) :
 ∀ k, k < m → ∀ c, run k a = some c → c.state ≠ 6 := by
 intro k hk c hc hs
 have heq : m = k + (m-k) := by omega
 have hn : m-k ≠ 0 := by omega
 rw [heq, run_add, hc, Option.bind_some, run_halted (m-k) c hs hn] at h
 contradiction
-- Counts all 1 cells of a natural-number half-tape, not a truncated prefix.
def ones (n : Nat) : Nat :=
 if h : n = 0 then 0 else n%2 + ones (n/2)
 termination_by n
 decreasing_by exact Nat.div_lt_self (Nat.pos_of_ne_zero h) (by decide)
def count : Nat → Nat → Nat
 | 0, _ => 0
 | k+1, n => n%2 + count k (n/2)
def strip : Nat → Nat → Nat
 | 0, n => n
 | k+1, n => strip k (n/2)
theorem ones_unfold (n : Nat) : ones n = n%2 + ones (n/2) := by
 by_cases h : n = 0
 · subst n
   simp [ones]
 · rw [ones]
   simp only [h, ↓reduceDIte]
theorem ones_decompose (k n : Nat) : ones n = count k n + ones (strip k n) := by
 induction k generalizing n with
 | zero => simp only [count, strip, Nat.zero_add]
 | succ k ih =>
   rw [ones_unfold n, ih (n/2)]
   simp only [count, strip]
   omega
theorem ones_eq_count_of_strip_zero (k n : Nat) (h : strip k n = 0) :
 ones n = count k n := by
 rw [ones_decompose k n, h]
 simp only [ones, ↓reduceDIte, Nat.add_zero]
#print axioms moveR_left_tail
#print axioms moveL_right_tail
#print axioms no_earlier_halt
end BB6Kernel
