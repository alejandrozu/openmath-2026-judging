#!/usr/bin/env bash
set -euo pipefail
# Use an existing pinned Lean4.33.1/mathlib project; this script installs nothing.
# Usage: PATH=/path/to/lean4.33.1/bin:$PATH bash reproduce.sh /path/to/pinned/project
PROJECT=${1:?Supply the existing pinned mathlib project directory}
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
CERT="$HERE/complete-certificate"
LIBPATH=$(cd -- "$PROJECT" && lake env printenv LEAN_PATH)
export LEAN_PATH="$CERT:$LIBPATH"
export LEAN_NUM_THREADS=1
lean --version
for MODULE in BooleanTree CardBridge CyclicUpper CyclicSharpness R17SplitReplay CombinedObstruction; do
  lean -j1 -M4096 -R "$CERT" -o "$CERT/$MODULE.olean" "$CERT/$MODULE.lean" \
    > "$CERT/$MODULE.reproduced.log" 2>&1
  cat "$CERT/$MODULE.reproduced.log"
done
