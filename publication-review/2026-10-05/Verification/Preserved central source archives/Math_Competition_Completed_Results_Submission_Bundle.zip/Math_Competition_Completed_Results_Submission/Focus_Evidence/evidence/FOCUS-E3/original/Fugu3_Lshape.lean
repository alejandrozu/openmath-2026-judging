import Mathlib

/-!
# Fugu3 L-shape transfer (Round 6, b29)

`A ⊆ ZMod M` with no 4-AP of nonzero difference gives `S_A = {(x,y) : x - y ∈ A}` with no
L-shape of nonzero step, and `|S_A| = M * |A|`.  A general-`k` version is included.
-/

namespace Fugu3Lshape

variable {M : ℕ} [NeZero M]

/-- No `a, d` with `d ≠ 0` and `a, a+d, a+2d, a+3d ∈ A`. -/
def APFree4 (A : Finset (ZMod M)) : Prop :=
  ∀ a d : ZMod M, d ≠ 0 → a ∈ A → a + d ∈ A → a + 2 * d ∈ A → a + 3 * d ∈ A → False

/-- No L-shape `(x,y),(x,y+d),(x,y+2d),(x+d,y)` with `d ≠ 0`. -/
def LFree (S : Finset (ZMod M × ZMod M)) : Prop :=
  ∀ x y d : ZMod M, d ≠ 0 → (x, y) ∈ S → (x, y + d) ∈ S → (x, y + 2 * d) ∈ S →
    (x + d, y) ∈ S → False

/-- `S_A = {(x,y) : x - y ∈ A}`. -/
def SA (A : Finset (ZMod M)) : Finset (ZMod M × ZMod M) :=
  Finset.univ.filter (fun p => p.1 - p.2 ∈ A)

theorem mem_SA {A : Finset (ZMod M)} {p : ZMod M × ZMod M} :
    p ∈ SA A ↔ p.1 - p.2 ∈ A := by
  simp [SA]

/-- An L-shape in `S_A` projects to the 4-AP `s-2d, s-d, s, s+d`. -/
theorem lfree_of_apfree {A : Finset (ZMod M)} (hA : APFree4 A) : LFree (SA A) := by
  intro x y d hd h0 h1 h2 h3
  have e0 : x - y - 2 * d = x - (y + 2 * d) := by ring
  have e1 : x - y - 2 * d + d = x - (y + d) := by ring
  have e2 : x - y - 2 * d + 2 * d = x - y := by ring
  have e3 : x - y - 2 * d + 3 * d = x + d - y := by ring
  have m0 : x - (y + 2 * d) ∈ A := mem_SA.mp h2
  have m1 : x - (y + d) ∈ A := mem_SA.mp h1
  have m2 : x - y ∈ A := mem_SA.mp h0
  have m3 : x + d - y ∈ A := mem_SA.mp h3
  refine hA (x - y - 2 * d) d hd ?_ ?_ ?_ ?_
  · rw [e0]; exact m0
  · rw [e1]; exact m1
  · rw [e2]; exact m2
  · rw [e3]; exact m3

theorem SA_eq_image (A : Finset (ZMod M)) :
    SA A = (A ×ˢ (Finset.univ : Finset (ZMod M))).image (fun q => (q.1 + q.2, q.2)) := by
  ext p
  rw [mem_SA, Finset.mem_image]
  constructor
  · intro hp
    refine ⟨(p.1 - p.2, p.2), ?_, ?_⟩
    · rw [Finset.mem_product]
      exact ⟨hp, Finset.mem_univ _⟩
    · ext
      · simp
      · simp
  · rintro ⟨q, hq, rfl⟩
    rw [Finset.mem_product] at hq
    simpa using hq.1

/-- Fibre count: `|S_A| = M * |A|`. -/
theorem card_SA (A : Finset (ZMod M)) : (SA A).card = M * A.card := by
  have hinj : Function.Injective (fun q : ZMod M × ZMod M => (q.1 + q.2, q.2)) := by
    intro q r hqr
    have hqrEq : (q.1 + q.2, q.2) = (r.1 + r.2, r.2) := hqr
    rw [Prod.mk.injEq] at hqrEq
    obtain ⟨h1, h2⟩ := hqrEq
    refine Prod.ext ?_ h2
    rw [h2] at h1
    exact add_right_cancel h1
  rw [SA_eq_image, Finset.card_image_of_injective _ hinj, Finset.card_product,
    Finset.card_univ, ZMod.card, mul_comm]

/-- Transfer: an L-free bound `B` gives `M * |A| ≤ B` for every 4-AP-free `A`. -/
theorem transfer (B : ℕ) (hB : ∀ S : Finset (ZMod M × ZMod M), LFree S → S.card ≤ B)
    (A : Finset (ZMod M)) (hA : APFree4 A) : M * A.card ≤ B := by
  have h := hB (SA A) (lfree_of_apfree hA)
  rwa [card_SA] at h

/-! ## General `k` -/

/-- No `a, d` with `d ≠ 0` and `a + j d ∈ A` for all `j < k`. -/
def APFreeK (k : ℕ) (A : Finset (ZMod M)) : Prop :=
  ∀ a d : ZMod M, d ≠ 0 → (∀ j : ℕ, j < k → a + (j : ZMod M) * d ∈ A) → False

/-- No `k`-L: `(x, y - i d)` for `i + 1 < k` together with `(x - d, y)`, `d ≠ 0`. -/
def LFreeK (k : ℕ) (S : Finset (ZMod M × ZMod M)) : Prop :=
  ∀ x y d : ZMod M, d ≠ 0 → (∀ i : ℕ, i + 1 < k → (x, y - (i : ZMod M) * d) ∈ S) →
    (x - d, y) ∈ S → False

theorem lfreeK_of_apfreeK {k : ℕ} {A : Finset (ZMod M)} (hA : APFreeK k A) :
    LFreeK k (SA A) := by
  intro x y d hd hv hh
  refine hA (x - y - d) d hd ?_
  intro j hj
  rcases j with _ | i
  · have h : x - d - y ∈ A := mem_SA.mp hh
    convert h using 1
    push_cast
    ring
  · have h : x - (y - (i : ZMod M) * d) ∈ A := mem_SA.mp (hv i (by omega))
    convert h using 1
    push_cast
    ring

theorem transferK (k B : ℕ) (hB : ∀ S : Finset (ZMod M × ZMod M), LFreeK k S → S.card ≤ B)
    (A : Finset (ZMod M)) (hA : APFreeK k A) : M * A.card ≤ B := by
  have h := hB (SA A) (lfreeK_of_apfreeK hA)
  rwa [card_SA] at h

/-- Maximum cardinality of a strongly 4-AP-free set in `ZMod M`. -/
noncomputable def r4StrongCyclic (M : ℕ) [NeZero M] : ℕ := by
  classical
  exact (Finset.univ.filter (fun A : Finset (ZMod M) => APFree4 A)).sup Finset.card

/-- The extremal transfer stated as `r₄^strong(M) ≤ B/M`. -/
theorem r4Strong_le_div (B : ℕ)
    (hB : ∀ S : Finset (ZMod M × ZMod M), LFree S → S.card ≤ B) :
    r4StrongCyclic M ≤ B / M := by
  classical
  unfold r4StrongCyclic
  apply Finset.sup_le
  intro A hA
  have hfree : APFree4 A := (Finset.mem_filter.mp hA).2
  apply (Nat.le_div_iff_mul_le (NeZero.pos M)).2
  simpa [Nat.mul_comm] using transfer B hB A hfree

/-- Maximum cardinality of a strongly k-AP-free set in `ZMod M`. -/
noncomputable def rKStrongCyclic (k M : ℕ) [NeZero M] : ℕ := by
  classical
  exact (Finset.univ.filter (fun A : Finset (ZMod M) => APFreeK k A)).sup Finset.card

theorem rKStrong_le_div (k B : ℕ)
    (hB : ∀ S : Finset (ZMod M × ZMod M), LFreeK k S → S.card ≤ B) :
    rKStrongCyclic k M ≤ B / M := by
  classical
  unfold rKStrongCyclic
  apply Finset.sup_le
  intro A hA
  have hfree : APFreeK k A := (Finset.mem_filter.mp hA).2
  apply (Nat.le_div_iff_mul_le (NeZero.pos M)).2
  simpa [Nat.mul_comm] using transferK k B hB A hfree

/-! ## Distinct-term interpretation for arbitrary composite moduli -/

/-- Exactly the nondegenerate four-term differences: `d, 2d, 3d` are nonzero. -/
def Step4Distinct (d : ZMod M) : Prop := d ≠ 0 ∧ 2 * d ≠ 0 ∧ 3 * d ≠ 0

/-- Four-term progression free in the usual four-distinct-terms sense. -/
def APFree4Distinct (A : Finset (ZMod M)) : Prop :=
  ∀ a d : ZMod M, Step4Distinct d → a ∈ A → a + d ∈ A →
    a + 2 * d ∈ A → a + 3 * d ∈ A → False

/-- L-free at precisely those steps whose projection consists of four distinct points. -/
def LFree4Admissible (S : Finset (ZMod M × ZMod M)) : Prop :=
  ∀ x y d : ZMod M, Step4Distinct d → (x, y) ∈ S → (x, y + d) ∈ S →
    (x, y + 2 * d) ∈ S → (x + d, y) ∈ S → False

theorem lfreeAdmissible_of_apfreeDistinct {A : Finset (ZMod M)}
    (hA : APFree4Distinct A) : LFree4Admissible (SA A) := by
  intro x y d hd h0 h1 h2 h3
  have e0 : x - y - 2 * d = x - (y + 2 * d) := by ring
  have e1 : x - y - 2 * d + d = x - (y + d) := by ring
  have e2 : x - y - 2 * d + 2 * d = x - y := by ring
  have e3 : x - y - 2 * d + 3 * d = x + d - y := by ring
  have m0 : x - (y + 2 * d) ∈ A := mem_SA.mp h2
  have m1 : x - (y + d) ∈ A := mem_SA.mp h1
  have m2 : x - y ∈ A := mem_SA.mp h0
  have m3 : x + d - y ∈ A := mem_SA.mp h3
  refine hA (x - y - 2 * d) d hd ?_ ?_ ?_ ?_
  · rw [e0]; exact m0
  · rw [e1]; exact m1
  · rw [e2]; exact m2
  · rw [e3]; exact m3

/-- Maximum size with the usual four-distinct-term convention. -/
noncomputable def r4DistinctCyclic (M : ℕ) [NeZero M] : ℕ := by
  classical
  exact (Finset.univ.filter (fun A : Finset (ZMod M) => APFree4Distinct A)).sup Finset.card

theorem r4Distinct_le_div (B : ℕ)
    (hB : ∀ S : Finset (ZMod M × ZMod M), LFree4Admissible S → S.card ≤ B) :
    r4DistinctCyclic M ≤ B / M := by
  classical
  unfold r4DistinctCyclic
  apply Finset.sup_le
  intro A hA
  have hfree : APFree4Distinct A := (Finset.mem_filter.mp hA).2
  apply (Nat.le_div_iff_mul_le (NeZero.pos M)).2
  have h := hB (SA A) (lfreeAdmissible_of_apfreeDistinct hfree)
  rw [card_SA] at h
  simpa [Nat.mul_comm] using h

/-- In groups where every nonzero step yields four distinct terms, an ordinary L-free
    bound gives the ordinary 4-AP extremal bound. E.g. `M` prime and `M > 3`. -/
theorem r4Distinct_le_div_of_allSteps
    (hstep : ∀ d : ZMod M, d ≠ 0 → Step4Distinct d)
    (B : ℕ) (hB : ∀ S : Finset (ZMod M × ZMod M), LFree S → S.card ≤ B) :
    r4DistinctCyclic M ≤ B / M := by
  apply r4Distinct_le_div B
  intro S hS
  apply hB S
  intro x y d hd h0 h1 h2 h3
  exact hS x y d (hstep d hd) h0 h1 h2 h3

end Fugu3Lshape

#print axioms Fugu3Lshape.r4Distinct_le_div_of_allSteps
#print axioms Fugu3Lshape.r4Distinct_le_div
#print axioms Fugu3Lshape.lfreeAdmissible_of_apfreeDistinct
#print axioms Fugu3Lshape.r4Strong_le_div
#print axioms Fugu3Lshape.rKStrong_le_div
#print axioms Fugu3Lshape.lfree_of_apfree
#print axioms Fugu3Lshape.card_SA
#print axioms Fugu3Lshape.transfer
#print axioms Fugu3Lshape.lfreeK_of_apfreeK
#print axioms Fugu3Lshape.transferK

