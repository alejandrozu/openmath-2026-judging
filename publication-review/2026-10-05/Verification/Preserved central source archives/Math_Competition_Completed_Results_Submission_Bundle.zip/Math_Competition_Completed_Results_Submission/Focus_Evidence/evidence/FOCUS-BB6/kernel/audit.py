import json,re,hashlib
from pathlib import Path
p=Path(__file__).parent
src=Path('recovery-20261002/autolab-inputs/openmath_other_hills_source/submission/openmath_20261002_other_hills/official-autolab100/busy-beaver-6-certificates/candidates/verified_1235211_1519.json')
if not src.exists(): src=p/'machine.json'
t=json.loads(src.read_text())['transitions'];kernel=(p/'Kernel.lean').read_text()
parsed={}
for s,b,d,n,w in re.findall(r'\| (\d), (\d) => some \(move([RL]) (\d) (\d) c\)',kernel):
 parsed.setdefault(chr(65+int(s)),{})[b]=[int(w),d,'H' if int(n)==6 else chr(65+int(n))]
assert parsed==t
ones=set();s='A';h=steps=lo=hi=0;states=set()
while s!='H':
 assert steps<2_000_000
 states.add(s);b=int(h in ones);w,d,s=t[s][str(b)]
 if w:ones.add(h)
 else:ones.discard(h)
 h+=1 if d=='R' else -1;steps+=1;lo=min(lo,h);hi=max(hi,h)
l=sum(1<<(h-x-1) for x in ones if x<h);r=sum(1<<(x-h) for x in ones if x>=h)
end=json.loads((p/'macro-trace.json').read_text())[-1][3]
assert end==[6,l,r]
assert steps==1235211 and len(ones)==1519 and states==set('ABCDEF')
receipt={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'kernel_table_matches_source_json':True,'machine':'_'.join(''.join(str(w)+d+n for w,d,n in t[s].values()) for s in t),'steps':steps,'ones':len(ones),'head':h,'min_position':lo,'max_position':hi,'span':hi-lo+1,'visited_states':sorted(states),'blank_initial_configuration':True,'count_includes_transition_into_H':True,'exact_integer_endpoint_matches_macro_trace':True,'head_and_span_status':'independent exact Python replay; not claimed as Lean theorem'}
(p/'independent-audit.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
