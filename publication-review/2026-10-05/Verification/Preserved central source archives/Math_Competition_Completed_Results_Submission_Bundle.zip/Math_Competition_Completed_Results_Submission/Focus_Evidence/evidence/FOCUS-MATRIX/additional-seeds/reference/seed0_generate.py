from pathlib import Path
import json
r=Path(__file__).parent; src=r.parent; d=json.load(open(src/'matrix-source/solution.json'))
s='''import Mathlib.Data.Matrix.Basic
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
/- New 2026-10-02 standard-kernel reconstruction. Original fixed seed0 data.
No compiled evaluation; row certificates are separate modules. -/
set_option maxRecDepth 100000
namespace RecoveredMMTKernel
open Matrix
'''
def lists(x):return '['+', '.join(lists(v) if isinstance(v,list) else str(v) for v in x)+']'
for a in ['u','v','w']:
 s+=f'def data_{a} : List (List ℤ) := {lists(d[a])}\n'
 s+=f'def factor_{a} (t : Fin 23) (i : Fin 9) : ℤ := (data_{a}.getD t.val []).getD i.val 0\n'
for a,b in [('u','v'),('u','w'),('v','w')]:
 n=a+b;j=json.load(open(src/f'{n}_minor.json'))
 s+=f'def pivData_{n} : List ℕ := {lists(j["selected_rows"])}\n'
 s+=f'def piv_{n} (i : Fin 23) : Fin 81 := ⟨(pivData_{n}.getD i.val 0)%81, Nat.mod_lt _ (by decide)⟩\n'
 s+=f'def B_{n} : Matrix (Fin 81) (Fin 23) ℤ := fun i t => factor_{a} t ⟨i.val/9, by omega⟩ * factor_{b} t ⟨i.val%9, Nat.mod_lt _ (by decide)⟩\n'
 s+=f'def M_{n} : Matrix (Fin 23) (Fin 23) ℤ := fun i t => B_{n} (piv_{n} i) t\n'
 s+=f'def LData_{n} : List (List ℤ) := {lists(j["left_inverse"])}\n'
 s+=f'def L_{n} : Matrix (Fin 23) (Fin 23) ℤ := fun i j => (LData_{n}.getD i.val []).getD j.val 0\n'
s+='end RecoveredMMTKernel\n';(r/'KernelData.lean').write_text(s)
mods=[]
for n in ['uv','uw','vw']:
 for i in range(23):
  mod=f'Row_{n}_{i:02d}';mods.append(mod)
  s=f'''import KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernel
open Matrix
theorem row_{n}_{i} : (L_{n} * M_{n}) ({i} : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) {i} := by decide
#print axioms row_{n}_{i}
end RecoveredMMTKernel
''';(r/(mod+'.lean')).write_text(s)
s='\n'.join('import '+m for m in mods)+'\nimport Mathlib.Tactic.FinCases\nnamespace RecoveredMMTKernel\nopen Matrix\n'
for n in ['uv','uw','vw']:
 s+=f'theorem left_inverse_{n} : L_{n} * M_{n} = 1 := by\n  funext i\n  fin_cases i\n'+''.join(f'  · exact row_{n}_{i}\n' for i in range(23))
 s+=f'''theorem rational_left_inverse_{n} :
    (L_{n}.map (Int.castRingHom ℚ)) * (M_{n}.map (Int.castRingHom ℚ)) = 1 := by
  rw [← Matrix.map_mul, left_inverse_{n}]
  exact Matrix.map_one _ (map_zero _) (map_one _)
theorem rational_injective_{n} : Function.Injective ((B_{n}.map (Int.castRingHom ℚ)).mulVec) := by
  intro x y h
  have hm : (M_{n}.map (Int.castRingHom ℚ)).mulVec x = (M_{n}.map (Int.castRingHom ℚ)).mulVec y := by
    funext i
    exact congrFun h (piv_{n} i)
  have hh := congrArg ((L_{n}.map (Int.castRingHom ℚ)).mulVec) hm
  simpa only [Matrix.mulVec_mulVec, rational_left_inverse_{n}, Matrix.one_mulVec] using hh
#print axioms left_inverse_{n}
#print axioms rational_injective_{n}
'''
s+='\n/-- Fixing these two original legs uniquely determines every column of the third. -/\ntheorem remaining_factor_unique_uv {p : Type*}\n    (X Y : Matrix (Fin 23) p ℚ)\n    (h : (B_uv.map (Int.castRingHom ℚ)) * X = (B_uv.map (Int.castRingHom ℚ)) * Y) : X = Y := by\n  funext i j\n  have hc : (B_uv.map (Int.castRingHom ℚ)).mulVec (fun t => X t j) =\n      (B_uv.map (Int.castRingHom ℚ)).mulVec (fun t => Y t j) := by\n    funext k\n    exact congrFun (congrFun h k) j\n  exact congrFun (rational_injective_uv hc) i\n#print axioms remaining_factor_unique_uv\n\n/-- Fixing these two original legs uniquely determines every column of the third. -/\ntheorem remaining_factor_unique_uw {p : Type*}\n    (X Y : Matrix (Fin 23) p ℚ)\n    (h : (B_uw.map (Int.castRingHom ℚ)) * X = (B_uw.map (Int.castRingHom ℚ)) * Y) : X = Y := by\n  funext i j\n  have hc : (B_uw.map (Int.castRingHom ℚ)).mulVec (fun t => X t j) =\n      (B_uw.map (Int.castRingHom ℚ)).mulVec (fun t => Y t j) := by\n    funext k\n    exact congrFun (congrFun h k) j\n  exact congrFun (rational_injective_uw hc) i\n#print axioms remaining_factor_unique_uw\n\n/-- Fixing these two original legs uniquely determines every column of the third. -/\ntheorem remaining_factor_unique_vw {p : Type*}\n    (X Y : Matrix (Fin 23) p ℚ)\n    (h : (B_vw.map (Int.castRingHom ℚ)) * X = (B_vw.map (Int.castRingHom ℚ)) * Y) : X = Y := by\n  funext i j\n  have hc : (B_vw.map (Int.castRingHom ℚ)).mulVec (fun t => X t j) =\n      (B_vw.map (Int.castRingHom ℚ)).mulVec (fun t => Y t j) := by\n    funext k\n    exact congrFun (congrFun h k) j\n  exact congrFun (rational_injective_vw hc) i\n#print axioms remaining_factor_unique_vw\n\n'
s+='end RecoveredMMTKernel\n';(r/'KernelFinal.lean').write_text(s)
