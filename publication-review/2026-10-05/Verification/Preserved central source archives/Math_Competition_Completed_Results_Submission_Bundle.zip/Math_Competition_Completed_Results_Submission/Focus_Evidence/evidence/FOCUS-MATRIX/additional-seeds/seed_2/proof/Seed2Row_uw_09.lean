import Seed2KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed2
open Matrix
theorem row_uw_9 : (L_uw * M_uw) (9 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 9 := by decide
#print axioms row_uw_9
end RecoveredMMTKernelSeed2
