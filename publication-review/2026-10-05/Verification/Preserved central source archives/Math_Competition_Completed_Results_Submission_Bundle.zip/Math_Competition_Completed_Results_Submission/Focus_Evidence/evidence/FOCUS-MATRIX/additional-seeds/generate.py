#!/usr/bin/env python3
"""Reconstruct additional fixed-seed one-leg certificates; no input is mutated.

SymPy chooses minors and computes candidate inverse tables. The independent
Fraction checker verifies these and Lean's ordinary kernel checks every row.
This generator is not part of the trusted proof base.
"""
from pathlib import Path
import argparse, hashlib, json, re, shutil
import sympy as sp

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
ORIGINAL = WORKSPACE / 'recovery-20261002/m1-rereview/matrix-source'
TEMPLATE = ROOT / 'reference'
PAIRS = ('uv', 'uw', 'vw')

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(p, obj): p.write_text(json.dumps(obj, indent=2) + '\n')
def lists(x): return '[' + ', '.join(lists(v) if isinstance(v,list) else str(v) for v in x) + ']'

def generate(seed):
    r=ROOT / f'seed_{seed}'; (r/'original').mkdir(parents=True, exist_ok=True); (r/'proof').mkdir(exist_ok=True)
    src=ORIGINAL/'schemes'/f'hks139_{seed}.json'
    copied=r/'original'/src.name
    assert copied.exists(), 'The preserved original input must be included with this package.'
    if src.exists(): assert copied.read_bytes()==src.read_bytes()
    expected={1:'de78500d31eb4cae85a16fb20b94cc13205e955fecbddaa76c70b98b1588670d', 2:'e0a3573cfacb2f9713bdfaca5deff5181f3e5aec74427a9e8a82db08087a7a5c'}
    assert sha(copied)==expected[seed]
    d=json.loads(copied.read_text())
    assert set(d)==set('uvw') and all(len(d[a])==23 and all(len(row)==9 and all(type(x)==int for x in row) for row in d[a]) for a in 'uvw')
    for a,b in PAIRS:
        n=a+b
        B=sp.Matrix([[d[a][t][i]*d[b][t][j] for t in range(23)] for i in range(9) for j in range(9)])
        indices=list(B.T.rref()[1]); assert len(indices)==23
        M=B[indices,:]; inv=M.inv()
        assert all(x.q==1 for x in inv)  # Never silently truncate rational coefficients.
        cert={'source':str(src.relative_to(WORKSPACE)), 'source_sha256':sha(copied), 'seed':seed,
              'pairing':n, 'flattening':'row = 9*i+j, column = term t', 'selected_rows':indices,
              'matrix':[[int(x) for x in M.row(i)] for i in range(23)],
              'left_inverse':[[int(x) for x in inv.row(i)] for i in range(23)], 'determinant':int(M.det())}
        write_json(r/f'{n}_minor.json',cert)
    namespace=f'RecoveredMMTKernelSeed{seed}'; prefix=f'Seed{seed}'
    s='''import Mathlib.Data.Matrix.Basic
import Mathlib.LinearAlgebra.Matrix.NonsingularInverse
/- New 2026-10-03 standard-kernel reconstruction for an original HKS139 seed.
Smirnov/HKS receives algorithm attribution. Only fixed-seed one-leg rigidity
is certified here. No compiled evaluation is used. -/
set_option maxRecDepth 100000
'''+f'namespace {namespace}\nopen Matrix\n'
    for a in 'uvw':
        s+=f'def data_{a} : List (List ℤ) := {lists(d[a])}\n'
        s+=f'def factor_{a} (t : Fin 23) (i : Fin 9) : ℤ := (data_{a}.getD t.val []).getD i.val 0\n'
    for n in PAIRS:
        a,b=n; j=json.loads((r/f'{n}_minor.json').read_text())
        s+=f'def pivData_{n} : List ℕ := {lists(j["selected_rows"])}\n'
        s+=f'def piv_{n} (i : Fin 23) : Fin 81 := ⟨(pivData_{n}.getD i.val 0)%81, Nat.mod_lt _ (by decide)⟩\n'
        s+=f'def B_{n} : Matrix (Fin 81) (Fin 23) ℤ := fun i t => factor_{a} t ⟨i.val/9, by omega⟩ * factor_{b} t ⟨i.val%9, Nat.mod_lt _ (by decide)⟩\n'
        s+=f'def M_{n} : Matrix (Fin 23) (Fin 23) ℤ := fun i t => B_{n} (piv_{n} i) t\n'
        s+=f'def LData_{n} : List (List ℤ) := {lists(j["left_inverse"])}\n'
        s+=f'def L_{n} : Matrix (Fin 23) (Fin 23) ℤ := fun i j => (LData_{n}.getD i.val []).getD j.val 0\n'
    s+=f'end {namespace}\n'; (r/'proof'/f'{prefix}KernelData.lean').write_text(s)
    for n in PAIRS:
        for i in range(23):
            mod=f'{prefix}Row_{n}_{i:02d}'
            s=f'''import {prefix}KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace {namespace}
open Matrix
theorem row_{n}_{i} : (L_{n} * M_{n}) ({i} : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) {i} := by decide
#print axioms row_{n}_{i}
end {namespace}
'''
            (r/'proof'/f'{mod}.lean').write_text(s)
    # Reuse the successful complete generic proof, changing module/namespace names only.
    final=(TEMPLATE/'Seed0KernelFinal.lean').read_text().replace('RecoveredMMTKernel',namespace)
    final=re.sub(r'^import Row_',f'import {prefix}Row_',final,flags=re.M)
    (r/'proof'/f'{prefix}KernelFinal.lean').write_text(final)
    write_json(r/'generation-provenance.json',{'seed':seed,'original_source':str(src.relative_to(WORKSPACE)),
        'original_source_sha256':sha(copied),'copied_original_sha256':sha(copied),
        'prior_generator_sha256':sha(TEMPLATE/'seed0_generate.py'), 'generic_final_template_sha256':sha(TEMPLATE/'Seed0KernelFinal.lean'),
        'namespace':namespace,'proof_source_count':len(list((r/'proof').glob('*.lean'))),
        'all_inverses_integral':True})
    print(f'Generated seed {seed}: 71 modules, original SHA256 {sha(copied)}')

if __name__=='__main__':
    for seed in (1,2): generate(seed)
