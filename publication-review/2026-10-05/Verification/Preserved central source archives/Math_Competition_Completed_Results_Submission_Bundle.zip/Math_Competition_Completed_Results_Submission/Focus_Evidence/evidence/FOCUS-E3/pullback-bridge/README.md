# Source-faithful Erdős 3 diagonal-pullback bridge

This isolated supplement closes the formal cardinality/comparison gap in the
modulus-13 finite obstruction. It adds no new mathematical discovery or priority
claim, and does not solve/refute the Erdős–Turán conjecture. It does not determine
the maximum size among all strong-L-free subsets.

## Exact checked claim

`Erdos3PullbackBridge.retained_witness_beats_every_diagonal_pullback` states:

- The retained witness `Erdos3R17.B` has cardinality 79 and satisfies the original
  `Fugu3Lshape.LFree` predicate.
- For every `A : Finset (ZMod 13)` satisfying the original `Fugu3Lshape.APFree4`,
  the source-defined `Fugu3Lshape.SA A` is L-free, its cardinality equals
  `13 * A.card`, its cardinality is at most 78, and its cardinality is strictly
  smaller than that of `Erdos3R17.B`.

The diagonal is exactly the original convention, `x - y ∈ A`. The forbidden L
is exactly `(x,y), (x,y+d), (x,y+2*d), (x+d,y)` with `d ≠ 0`. The four-AP
predicate excludes `a, a+d, a+2*d, a+3*d` with `d ≠ 0`. Explicit equivalence
lemmas identify the original curried predicates with the conjunction predicates
used in the existing certificate; no convention has been silently changed.

## Source provenance

`original/Fugu3_Lshape.lean` is a byte-for-byte copy of the retained original at
`output/math-report-submission/Focus_Evidence/evidence/FOCUS-E3/original/`.
`source/Fugu3PullbackCore.lean` keeps the complete original namespace block from
its opening through `card_SA`, verbatim. Only the broad `import Mathlib` is
replaced by three narrow imports, the namespace is closed after that core, and
three axiom-report commands are added. It retains the original image bijection
`(a,y) ↦ (a+y,y)` with inverse `(x,y) ↦ (x-y,y)`, cardinality proof and L-free
transfer proof. This is a replayed original core, not a new cardinality argument.

The five copied dependencies in `source/` are byte-identical to
`output/math-report-submission/Focus_Evidence/evidence/FOCUS-E3/complete-certificate/`:
`BooleanTree`, `CardBridge`, `CyclicUpper`, `R17SplitReplay`, `CombinedObstruction`.
They are also byte-identical to the corresponding checked modules in
`recovery-20261002/erdos3-completion/complete-certificate/`.
No existing checked source, log, receipt or report was modified.

Only `source/PullbackObstruction.lean` supplies new logical bridges: equivalence
of the two predicate presentations, then the actual finite-set comparison.
`SOURCE_CORRESPONDENCE.json` records the precise source hashes and line ranges.

## Portable reproduction

Requirements: Python 3; Lean 4.33.1 (commit
`819816b2e0a3bf405af45ae5c7af2491d8f5bee6`); an already prepared mathlib project at
commit `0df444a360eaa60ab8c11dca51a86af692955474`, including its pinned dependencies
and built/cache-restored imported modules. The included `environment/` files
specify this project pin. No environment installation or network fetch is
performed by the replay script.

Run from any directory, with the correct Lean/Lake tools on PATH:

```sh
python3 /path/to/erdos3-pullback-bridge/reproduce.py /path/to/pinned/project /path/to/NEW-build-directory
```

The build directory must not already exist. The script refuses a different Lean
version or mathlib commit. It prepends the newly created empty build directory
to `LEAN_PATH`, then recompiles all seven own modules in dependency order. No
own `.olean` is copied or reused. Existing pinned mathlib/dependency artifacts
are used; this is not a rebuild of mathlib or the original source's Docker image.
Each Lean invocation uses `-j1 -M4096`; the largest Boolean/witness certificate
steps can require several GiB RAM. The script records exit codes, commands,
source hashes, log hashes, elapsed times and axiom output in `build-receipt.json`.

The delivered `fresh-replay/` directory contains the successful clean replay.
Every bridge theorem and the retained cardinality/L-free core have axiom reports
limited to `propext`, `Classical.choice`, and `Quot.sound`. There is no `sorry`,
`native_decide`, or custom axiom in the successful source chain. The finite
certificates use kernel `decide`, not native decision results.

## Integration

Copy `Fugu3PullbackCore.lean` and `PullbackObstruction.lean` beside the five
existing own modules (or use the complete self-contained `source/` directory).
Add the new modules at the end of the reproduction order. Keep the clean replay
logs, receipt and source correspondence with the evidence. The claim may then
accurately refer to a kernel-checked finite diagonal-pullback obstruction with
actual set cardinality. This does not broaden its mathematical or competition
classification.
