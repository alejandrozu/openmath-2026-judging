import Certificate
import Semantics
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace BB6Kernel

theorem endpoint_halted : endpoint.state = 6 := rfl

theorem endpoint_ones : ones endpoint.left + ones endpoint.right = 1519 := by
 rw [ones_eq_count_of_strip_zero 0 endpoint.left (by rfl),
     ones_eq_count_of_strip_zero 2028 endpoint.right (by rfl)]
 rfl

theorem exact_halting_witness :
 run 1235211 blank = some endpoint ∧
 endpoint.state = 6 ∧
 ones endpoint.left + ones endpoint.right = 1519 ∧
 (∀ k, k < 1235211 → ∀ c, run k blank = some c → c.state ≠ 6) :=
 ⟨exact_run, endpoint_halted, endpoint_ones, no_earlier_halt exact_run⟩

-- The six states occur by step 40, well before halting.
theorem visits_all_six_states : ∀ s, s < 6 →
 ∃ k, k ≤ 40 ∧ ∃ c, run k blank = some c ∧ c.state = s := by
 intro s hs
 have cases : s=0 ∨ s=1 ∨ s=2 ∨ s=3 ∨ s=4 ∨ s=5 := by omega
 rcases cases with h | h | h | h | h | h <;> subst s
 · exact ⟨0, by decide, ⟨0,0,0⟩, rfl, rfl⟩
 · exact ⟨1, by decide, ⟨1,1,0⟩, rfl, rfl⟩
 · exact ⟨4, by decide, ⟨2,0,5⟩, rfl, rfl⟩
 · exact ⟨2, by decide, ⟨3,3,0⟩, rfl, rfl⟩
 · exact ⟨5, by decide, ⟨4,0,10⟩, rfl, rfl⟩
 · exact ⟨40, by decide, ⟨5,63,23⟩, rfl, rfl⟩

#print axioms exact_run
#print axioms endpoint_ones
#print axioms exact_halting_witness
#print axioms visits_all_six_states
end BB6Kernel
