import Seed2KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed2
open Matrix
theorem row_uw_12 : (L_uw * M_uw) (12 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 12 := by decide
#print axioms row_uw_12
end RecoveredMMTKernelSeed2
