#!/usr/bin/env python3
"""Fresh own-module replay; requires an existing pinned Lean/mathlib project."""
import datetime, hashlib, json, os, pathlib, re, subprocess, sys, time
HERE = pathlib.Path(__file__).resolve().parent
PROJECT = pathlib.Path(sys.argv[1]).resolve()
OUT = pathlib.Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else HERE / 'fresh-replay'
OUT.mkdir(parents=True, exist_ok=False)
SOURCE = HERE / 'source'
MODULES = ['BooleanTree', 'CardBridge', 'CyclicUpper', 'R17SplitReplay',
           'CombinedObstruction', 'Fugu3PullbackCore', 'PullbackObstruction']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
env = os.environ.copy()
env['LEAN_NUM_THREADS'] = '1'
version = subprocess.check_output(['lean', '--version'], env=env, text=True).strip()
if 'version 4.33.1,' not in version:
    raise SystemExit('Lean 4.33.1 is required: ' + version)
mathlib = PROJECT / '.lake/packages/mathlib'
rev = subprocess.check_output(['git', '-C', str(mathlib), 'rev-parse', 'HEAD'], text=True).strip()
if rev != '0df444a360eaa60ab8c11dca51a86af692955474':
    raise SystemExit('Unexpected mathlib revision: ' + rev)
libpath = subprocess.check_output(['lake', 'env', 'printenv', 'LEAN_PATH'],
                                  cwd=PROJECT, env=env, text=True).strip()
libpath = os.pathsep.join(str((PROJECT / p).resolve()) for p in libpath.split(os.pathsep) if p)
env['LEAN_PATH'] = str(OUT) + os.pathsep + libpath
receipt = {'verification_date_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'lean': version, 'mathlib': rev, 'fresh_own_modules': True,
           'fresh_build_directory': str(OUT), 'project': str(PROJECT),
           'own_modules_preexisting': [], 'source_dir': str(SOURCE),
           'lean_path': env['LEAN_PATH'], 'modules': [], 'all_pass': False}
for name in MODULES:
    src = SOURCE / (name + '.lean')
    cmd = ['lean', '-j1', '-M4096', '-R', str(SOURCE), '-o', str(OUT / (name + '.olean')), str(src)]
    started = time.monotonic()
    result = subprocess.run(cmd, cwd=OUT, env=env, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=600)
    log = OUT / (name + '.log')
    log.write_text(result.stdout)
    entry = {'module': name, 'exit_code': result.returncode,
             'seconds': time.monotonic() - started, 'source_sha256': sha(src),
             'command': cmd, 'log_sha256': sha(log), 'axiom_output': result.stdout.strip()}
    receipt['modules'].append(entry)
    receipt['all_pass'] = len(receipt['modules']) == len(MODULES) and all(
        e['exit_code'] == 0 for e in receipt['modules'])
    (OUT / 'build-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(entry), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
print('PASS: all seven own modules freshly rebuilt from source.', flush=True)
