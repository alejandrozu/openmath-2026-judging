import Kernel
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace BB6Kernel
theorem segment0 : run 8 ⟨0, 0, 0⟩ = some ⟨3, 3, 5⟩ := by rfl
theorem segment1 : run 2 ⟨3, 3, 5⟩ = some ⟨3, 0, 23⟩ := run_D_fast 2 0 2
theorem segment2 : run 3 ⟨3, 0, 23⟩ = some ⟨1, 1, 47⟩ := by rfl
theorem segment3 : run 4 ⟨1, 1, 47⟩ = some ⟨1, 31, 2⟩ := run_B_fast 4 1 2
theorem segment4 : run 1 ⟨1, 31, 2⟩ = some ⟨3, 63, 1⟩ := by rfl
theorem segment5 : run 6 ⟨3, 63, 1⟩ = some ⟨3, 0, 127⟩ := run_D_fast 6 0 0
theorem segment6 : run 3 ⟨3, 0, 127⟩ = some ⟨1, 1, 255⟩ := by rfl
theorem segment7 : run 8 ⟨1, 1, 255⟩ = some ⟨1, 511, 0⟩ := run_B_fast 8 1 0
theorem segment8 : run 19 ⟨1, 511, 0⟩ = some ⟨3, 3, 1501⟩ := by rfl
theorem segment9 : run 2 ⟨3, 3, 1501⟩ = some ⟨3, 0, 6007⟩ := run_D_fast 2 0 750
theorem segment10 : run 3 ⟨3, 0, 6007⟩ = some ⟨1, 1, 12015⟩ := by rfl
theorem segment11 : run 4 ⟨1, 1, 12015⟩ = some ⟨1, 31, 750⟩ := run_B_fast 4 1 750
theorem segment12 : run 1 ⟨1, 31, 750⟩ = some ⟨3, 63, 375⟩ := by rfl
theorem segment13 : run 6 ⟨3, 63, 375⟩ = some ⟨3, 0, 24063⟩ := run_D_fast 6 0 187
theorem segment14 : run 3 ⟨3, 0, 24063⟩ = some ⟨1, 1, 48127⟩ := by rfl
theorem segment15 : run 10 ⟨1, 1, 48127⟩ = some ⟨1, 2047, 46⟩ := run_B_fast 10 1 46
theorem segment16 : run 1 ⟨1, 2047, 46⟩ = some ⟨3, 4095, 23⟩ := by rfl
theorem segment17 : run 12 ⟨3, 4095, 23⟩ = some ⟨3, 0, 98303⟩ := run_D_fast 12 0 11
theorem segment18 : run 3 ⟨3, 0, 98303⟩ = some ⟨1, 1, 196607⟩ := by rfl
theorem segment19 : run 16 ⟨1, 1, 196607⟩ = some ⟨1, 131071, 2⟩ := run_B_fast 16 1 2
theorem segment20 : run 1 ⟨1, 131071, 2⟩ = some ⟨3, 262143, 1⟩ := by rfl
theorem segment21 : run 18 ⟨3, 262143, 1⟩ = some ⟨3, 0, 524287⟩ := run_D_fast 18 0 0
theorem segment22 : run 3 ⟨3, 0, 524287⟩ = some ⟨1, 1, 1048575⟩ := by rfl
theorem segment23 : run 20 ⟨1, 1, 1048575⟩ = some ⟨1, 2097151, 0⟩ := run_B_fast 20 1 0
theorem segment24 : run 37 ⟨1, 2097151, 0⟩ = some ⟨3, 3, 6151645⟩ := by rfl
theorem segment25 : run 2 ⟨3, 3, 6151645⟩ = some ⟨3, 0, 24606583⟩ := run_D_fast 2 0 3075822
theorem segment26 : run 3 ⟨3, 0, 24606583⟩ = some ⟨1, 1, 49213167⟩ := by rfl
theorem segment27 : run 4 ⟨1, 1, 49213167⟩ = some ⟨1, 31, 3075822⟩ := run_B_fast 4 1 3075822
theorem segment28 : run 1 ⟨1, 31, 3075822⟩ = some ⟨3, 63, 1537911⟩ := by rfl
theorem segment29 : run 6 ⟨3, 63, 1537911⟩ = some ⟨3, 0, 98426367⟩ := run_D_fast 6 0 768955
theorem segment30 : run 3 ⟨3, 0, 98426367⟩ = some ⟨1, 1, 196852735⟩ := by rfl
theorem segment31 : run 10 ⟨1, 1, 196852735⟩ = some ⟨1, 2047, 192238⟩ := run_B_fast 10 1 192238
theorem chunk0 : run 223 ⟨0, 0, 0⟩ = some ⟨1, 2047, 192238⟩ := (join (join (join (join (join segment0 segment1) (join segment2 segment3)) (join (join segment4 segment5) (join segment6 segment7))) (join (join (join segment8 segment9) (join segment10 segment11)) (join (join segment12 segment13) (join segment14 segment15)))) (join (join (join (join segment16 segment17) (join segment18 segment19)) (join (join segment20 segment21) (join segment22 segment23))) (join (join (join segment24 segment25) (join segment26 segment27)) (join (join segment28 segment29) (join segment30 segment31)))))
end BB6Kernel
