import Seed1KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed1
open Matrix
theorem row_vw_3 : (L_vw * M_vw) (3 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 3 := by decide
#print axioms row_vw_3
end RecoveredMMTKernelSeed1
