import FormalConjecturesUtil

/-! Verified finite lower witness only: a 79-point 4-point-L-free subset of (ZMod 13)^2.
This does NOT prove r4_cyclic(13) ≤ 6 or the Erdős #3 hill. -/

set_option synthInstance.maxSize 100000
set_option synthInstance.maxHeartbeats 4000000
set_option maxRecDepth 100000
set_option maxHeartbeats 16000000

namespace Erdos3R17

def B : Finset (ZMod 13 × ZMod 13) := {(0, 0), (0, 2), (0, 3), (0, 5), (0, 6), (0, 7), (0, 9), (1, 0), (1, 1), (1, 3), (1, 4), (1, 7), (1, 12), (2, 1), (2, 2), (2, 6), (2, 7), (2, 9), (3, 1), (3, 4), (3, 6), (3, 8), (3, 10), (3, 11), (4, 0), (4, 3), (4, 4), (4, 7), (4, 8), (4, 11), (5, 0), (5, 1), (5, 3), (5, 5), (5, 7), (5, 10), (5, 11), (6, 1), (6, 2), (6, 4), (6, 5), (6, 10), (6, 12), (7, 4), (7, 5), (7, 7), (7, 8), (7, 10), (7, 12), (8, 2), (8, 6), (8, 8), (8, 9), (8, 11), (8, 12), (9, 1), (9, 2), (9, 5), (9, 6), (9, 7), (9, 9), (10, 1), (10, 2), (10, 3), (10, 8), (10, 11), (10, 12), (11, 0), (11, 2), (11, 3), (11, 8), (11, 10), (11, 12), (12, 2), (12, 4), (12, 5), (12, 6), (12, 9), (12, 10)}

theorem B_card : B.card = 79 := by decide +kernel

theorem B_Lfree : ∀ x y d : ZMod 13, d ≠ 0 →
    ¬ ((x, y) ∈ B ∧ (x, y + d) ∈ B ∧ (x, y + 2 * d) ∈ B ∧ (x + d, y) ∈ B) := by
  decide +kernel

end Erdos3R17

#print axioms Erdos3R17.B_card
#print axioms Erdos3R17.B_Lfree
