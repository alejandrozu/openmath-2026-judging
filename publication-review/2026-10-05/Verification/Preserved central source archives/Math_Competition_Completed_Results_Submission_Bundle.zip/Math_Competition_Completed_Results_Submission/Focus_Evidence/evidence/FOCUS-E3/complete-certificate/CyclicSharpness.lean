import CyclicUpper
-- New supplemental kernel certificate of sharpness, 2 October 2026.
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000
namespace Cyclic13Kernel
def sixPointWitness : Finset (ZMod 13) := {0,1,2,4,5,7}
theorem sixPointWitness_card : sixPointWitness.card = 6 := by decide +kernel
theorem sixPointWitness_free : Cyclic4Free sixPointWitness := by
  unfold Cyclic4Free
  decide +kernel

theorem cyclic_four_AP_extremum_is_six :
    (∃ A : Finset (ZMod 13), Cyclic4Free A ∧ A.card = 6) ∧
    (∀ A : Finset (ZMod 13), Cyclic4Free A → A.card ≤ 6) := by
  exact ⟨⟨sixPointWitness, sixPointWitness_free, sixPointWitness_card⟩,
    cyclic4Free_card_le_six⟩
#print axioms sixPointWitness_free
#print axioms cyclic_four_AP_extremum_is_six
end Cyclic13Kernel
