import Mathlib

/-!
# SemanticTest

Per-survivor semantic theorems `Q (V := V) A ≤ √2 * C A`, each chaining an
exact outward-rounded LDLᵀ dual certificate, the exact threshold test
U² ≤ 2·C², and an explicit sign-witness anchor C ≤ C A through
`Q_le_sqrt_two_mul_C_of_cert`.  Q and C are the sSup-defined optima.

Cases in this file: 4.
-/

/-!
# Semantic core: per-survivor `Q ≤ √2 · C` from an exact dual certificate

Assembled from two independently checker-verified files:
* `formal/branches/api_bridge/Bridge.lean` — weak duality in an arbitrary real
  inner-product space (via the finite-dimensional span and an orthonormal
  basis) and the generic theorem `Q_le_sqrt_two_mul_C_of_cert`;
* `formal/branches/anchor/Anchor.lean` — the scalar sign-witness anchor
  `signValue_le_C`.

`Q` and `C` are the sSup-defined optima of `formal/Symmetry.lean`, repeated
verbatim so the isolated checker needs only `import Mathlib`.

No `sorry`, no `axiom`, no `native_decide`.
-/

open scoped InnerProductSpace

namespace GrothSemantic

abbrev Sign := ℤˣ
abbrev SignMat (m n : ℕ) := Fin m → Fin n → Sign

/-- Real coefficient corresponding to an integer sign. -/
def coeff (s : Sign) : ℝ := ((s : ℤ) : ℝ)

@[simp] theorem abs_coeff (s : Sign) : |coeff s| = 1 := by
  rcases Int.units_eq_one_or s with h | h <;> simp [coeff, h]

@[simp] theorem norm_coeff (s : Sign) : ‖coeff s‖ = 1 := by
  simp [Real.norm_eq_abs]

variable {m n : ℕ}

/-- Dual slack quadratic form `Σ aᵢxᵢ² + Σ bⱼzⱼ² − Σ Aᵢⱼxᵢzⱼ` (as in `formal/Dual.lean`). -/
def slack (a : Fin m → ℝ) (b : Fin n → ℝ) (A : Fin m → Fin n → ℝ)
    (x : Fin m → ℝ) (z : Fin n → ℝ) : ℝ :=
  (∑ i, a i * x i ^ 2) + (∑ j, b j * z j ^ 2) - ∑ i, ∑ j, A i j * x i * z j

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The finite bilinear vector objective `Σᵢⱼ Aᵢⱼ ⟨uᵢ, vⱼ⟩`. -/
def objective (A : SignMat m n) (u : Fin m → V) (v : Fin n → V) : ℝ :=
  ∑ i, ∑ j, coeff (A i j) * ⟪u i, v j⟫_ℝ

/-- Supremum of all objectives attained by two families of unit vectors. -/
noncomputable def Q (A : SignMat m n) : ℝ :=
  sSup {z : ℝ | ∃ (u : Fin m → V) (v : Fin n → V),
    (∀ i, ‖u i‖ = 1) ∧ (∀ j, ‖v j‖ = 1) ∧ z = objective A u v}

/-- Sign optimum: in the one-dimensional real space, unit vectors are signs. -/
noncomputable def C (A : SignMat m n) : ℝ := Q (V := ℝ) A

theorem objective_le_card (A : SignMat m n) (u : Fin m → V) (v : Fin n → V)
    (hu : ∀ i, ‖u i‖ = 1) (hv : ∀ j, ‖v j‖ = 1) :
    objective A u v ≤ (m * n : ℕ) := by
  unfold objective
  calc
    (∑ i, ∑ j, coeff (A i j) * ⟪u i, v j⟫_ℝ)
        ≤ ∑ _i : Fin m, ∑ _j : Fin n, (1 : ℝ) := by
          apply Finset.sum_le_sum; intro i _
          apply Finset.sum_le_sum; intro j _
          calc
            coeff (A i j) * ⟪u i, v j⟫_ℝ
                ≤ |coeff (A i j) * ⟪u i, v j⟫_ℝ| := le_abs_self _
            _ = |⟪u i, v j⟫_ℝ| := by rw [abs_mul, abs_coeff, one_mul]
            _ ≤ ‖u i‖ * ‖v j‖ := abs_real_inner_le_norm _ _
            _ = 1 := by rw [hu i, hv j, one_mul]
    _ = (m * n : ℕ) := by simp

theorem objectiveSet_bddAbove (A : SignMat m n) :
    BddAbove {z : ℝ | ∃ (u : Fin m → V) (v : Fin n → V),
      (∀ i, ‖u i‖ = 1) ∧ (∀ j, ‖v j‖ = 1) ∧ z = objective A u v} := by
  refine ⟨(m * n : ℕ), ?_⟩
  rintro z ⟨u, v, hu, hv, rfl⟩
  exact objective_le_card A u v hu hv

/-- **Weak duality in an arbitrary real inner-product space.** -/
theorem weak_duality_V (a : Fin m → ℝ) (b : Fin n → ℝ) (A : SignMat m n)
    (hpsd : ∀ (x : Fin m → ℝ) (z : Fin n → ℝ),
      0 ≤ slack a b (fun i j => coeff (A i j)) x z)
    (u : Fin m → V) (v : Fin n → V)
    (hu : ∀ i, ‖u i‖ = 1) (hv : ∀ j, ‖v j‖ = 1) :
    objective A u v ≤ (∑ i, a i) + (∑ j, b j) := by
  let S : Submodule ℝ V := Submodule.span ℝ (Set.range u ∪ Set.range v)
  haveI : FiniteDimensional ℝ S :=
    FiniteDimensional.span_of_finite ℝ ((Set.finite_range u).union (Set.finite_range v))
  let e := stdOrthonormalBasis ℝ S
  have huS : ∀ i, u i ∈ S := fun i =>
    Submodule.subset_span (Set.mem_union_left _ (Set.mem_range_self i))
  have hvS : ∀ j, v j ∈ S := fun j =>
    Submodule.subset_span (Set.mem_union_right _ (Set.mem_range_self j))
  let U : Fin m → S := fun i => ⟨u i, huS i⟩
  let W : Fin n → S := fun j => ⟨v j, hvS j⟩
  have parse : ∀ x y : S,
      ∑ t, ⟪x, e t⟫_ℝ * ⟪e t, y⟫_ℝ = ⟪(x : V), (y : V)⟫_ℝ := by
    intro x y
    rw [e.sum_inner_mul_inner x y]
    rfl
  have parseUV : ∀ i j, ∑ t, ⟪U i, e t⟫_ℝ * ⟪e t, W j⟫_ℝ = ⟪u i, v j⟫_ℝ :=
    fun i j => parse (U i) (W j)
  have hUU : ∀ i, ∑ t, ⟪U i, e t⟫_ℝ ^ 2 = 1 := by
    intro i
    have hp : ∑ t, ⟪U i, e t⟫_ℝ * ⟪e t, U i⟫_ℝ = ⟪u i, u i⟫_ℝ := parse (U i) (U i)
    rw [real_inner_self_eq_norm_sq, hu i, one_pow] at hp
    rw [← hp]
    apply Finset.sum_congr rfl
    intro t _
    rw [real_inner_comm (U i) (e t)]
    ring
  have hWW : ∀ j, ∑ t, ⟪e t, W j⟫_ℝ ^ 2 = 1 := by
    intro j
    have hp : ∑ t, ⟪W j, e t⟫_ℝ * ⟪e t, W j⟫_ℝ = ⟪v j, v j⟫_ℝ := parse (W j) (W j)
    rw [real_inner_self_eq_norm_sq, hv j, one_pow] at hp
    rw [← hp]
    apply Finset.sum_congr rfl
    intro t _
    rw [real_inner_comm (e t) (W j)]
    ring
  have hsum : 0 ≤ ∑ t, slack a b (fun i j => coeff (A i j))
      (fun i => ⟪U i, e t⟫_ℝ) (fun j => ⟪e t, W j⟫_ℝ) :=
    Finset.sum_nonneg fun t _ => hpsd _ _
  have h1 : (∑ t, ∑ i, a i * ⟪U i, e t⟫_ℝ ^ 2) = ∑ i, a i := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    rw [← Finset.mul_sum, hUU i, mul_one]
  have h2 : (∑ t, ∑ j, b j * ⟪e t, W j⟫_ℝ ^ 2) = ∑ j, b j := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro j _
    rw [← Finset.mul_sum, hWW j, mul_one]
  have h3 : (∑ t, ∑ i, ∑ j, coeff (A i j) * ⟪U i, e t⟫_ℝ * ⟪e t, W j⟫_ℝ)
      = objective A u v := by
    unfold objective
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro i _
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro j _
    rw [← parseUV i j, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro t _
    ring
  have hexp : (∑ t, slack a b (fun i j => coeff (A i j))
      (fun i => ⟪U i, e t⟫_ℝ) (fun j => ⟪e t, W j⟫_ℝ))
      = (∑ i, a i) + (∑ j, b j) - objective A u v := by
    unfold slack
    simp only [Finset.sum_sub_distrib, Finset.sum_add_distrib]
    rw [h1, h2, h3]
  rw [hexp] at hsum
  linarith

/-- **Generic semantic bridge.**  PSD dual certificate + threshold `U² ≤ 2·Cnum²`
+ lower anchor `Cnum ≤ C A` give `Q A ≤ √2 · C A` in every real inner-product space. -/
theorem Q_le_sqrt_two_mul_C_of_cert (A : SignMat m n)
    (a : Fin m → ℝ) (b : Fin n → ℝ) (Cnum : ℝ)
    (hpsd : ∀ (x : Fin m → ℝ) (z : Fin n → ℝ),
      0 ≤ slack a b (fun i j => coeff (A i j)) x z)
    (hU : 0 ≤ (∑ i, a i) + (∑ j, b j)) (hC : 0 ≤ Cnum)
    (hcert : ((∑ i, a i) + (∑ j, b j)) ^ 2 ≤ 2 * Cnum ^ 2)
    (hanchor : Cnum ≤ C A) :
    Q (V := V) A ≤ Real.sqrt 2 * C A := by
  have hroot : 0 ≤ Real.sqrt 2 := Real.sqrt_nonneg _
  have hUc : (∑ i, a i) + (∑ j, b j) ≤ Real.sqrt 2 * Cnum := by
    have hsq : ((∑ i, a i) + (∑ j, b j)) ^ 2 ≤ (Real.sqrt 2 * Cnum) ^ 2 := by
      rw [mul_pow, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
      exact hcert
    exact (sq_le_sq₀ hU (mul_nonneg hroot hC)).mp hsq
  have hB : Real.sqrt 2 * Cnum ≤ Real.sqrt 2 * C A :=
    mul_le_mul_of_nonneg_left hanchor hroot
  have hCA : 0 ≤ C A := hC.trans hanchor
  let S : Set ℝ := {z : ℝ | ∃ (u : Fin m → V) (v : Fin n → V),
    (∀ i, ‖u i‖ = 1) ∧ (∀ j, ‖v j‖ = 1) ∧ z = objective A u v}
  by_cases hS : S.Nonempty
  · unfold Q
    apply csSup_le hS
    rintro z ⟨u, v, hu, hv, rfl⟩
    exact ((weak_duality_V a b A hpsd u v hu hv).trans hUc).trans hB
  · have hEmpty : S = ∅ := Set.not_nonempty_iff_eq_empty.mp hS
    unfold Q
    change sSup S ≤ Real.sqrt 2 * C A
    rw [hEmpty, Real.sSup_empty]
    exact mul_nonneg hroot hCA

/-! ## Scalar sign-witness anchor -/

/-- Value of the explicit scalar sign configuration `(s, t)`. -/
def signValue (A : SignMat m n) (s : Fin m → Sign) (t : Fin n → Sign) : ℝ :=
  ∑ i, ∑ j, coeff (A i j) * coeff (s i) * coeff (t j)

theorem objective_signWitness (A : SignMat m n) (s : Fin m → Sign)
    (t : Fin n → Sign) :
    objective (V := ℝ) A (fun i => coeff (s i)) (fun j => coeff (t j)) =
      signValue A s t := by
  unfold objective signValue
  refine Finset.sum_congr rfl ?_
  intro i _
  refine Finset.sum_congr rfl ?_
  intro j _
  rw [Real.inner_apply]
  ring

/-- Every explicit scalar sign witness lower-bounds `C A`. -/
theorem signValue_le_C (A : SignMat m n) (s : Fin m → Sign) (t : Fin n → Sign) :
    signValue A s t ≤ C A := by
  unfold C Q
  apply le_csSup (objectiveSet_bddAbove (V := ℝ) A)
  refine ⟨(fun i => coeff (s i)), (fun j => coeff (t j)), ?_, ?_, ?_⟩
  · intro i; exact norm_coeff (s i)
  · intro j; exact norm_coeff (t j)
  · exact (objective_signWitness A s t).symm

theorem anchor_of_signValue (A : SignMat m n) (s : Fin m → Sign)
    (t : Fin n → Sign) (c : ℝ) (hval : signValue A s t = c) :
    c ≤ C A := hval ▸ signValue_le_C A s t

/-- `+1` as a sign. -/
def sp : Sign := 1

/-- `-1` as a sign. -/
def sm : Sign := -1

@[simp] theorem coeff_sp : coeff sp = 1 := by simp [coeff, sp]

@[simp] theorem coeff_sm : coeff sm = -1 := by simp [coeff, sm]

/-- Survivor `6x6_106` (6x6, bank `other_survivors_certs.json`): C = 14, dual grid 1/4, U = 19, exact test 361 ≤ 392. -/
def A_6x6_106 : SignMat 6 6 :=
  ![![sp, sp, sp, sp, sp, sp], ![sp, sm, sm, sm, sp, sm], ![sp, sm, sp, sm, sp, sm], ![sp, sm, sp, sp, sm, sm], ![sp, sp, sm, sp, sp, sm], ![sp, sp, sp, sm, sp, sp]]

def s_6x6_106 : Fin 6 → Sign := ![sm, sm, sm, sm, sm, sm]

def t_6x6_106 : Fin 6 → Sign := ![sm, sp, sm, sp, sm, sp]

theorem signValue_6x6_106 : signValue A_6x6_106 s_6x6_106 t_6x6_106 = 14 := by
  unfold signValue A_6x6_106 s_6x6_106 t_6x6_106
  simp [Fin.sum_univ_six]
  norm_num

theorem anchor_6x6_106 : (14 : ℝ) ≤ C A_6x6_106 :=
  anchor_of_signValue A_6x6_106 s_6x6_106 t_6x6_106 14 signValue_6x6_106

noncomputable def a_6x6_106 : Fin 6 → ℝ := ![7/4, 7/4, 7/4, 5/4, 5/4, 7/4]

noncomputable def b_6x6_106 : Fin 6 → ℝ := ![7/4, 7/4, 5/4, 5/4, 7/4, 7/4]

theorem cert_6x6_106 (x : Fin 6 → ℝ) (z : Fin 6 → ℝ) :
    0 ≤ slack a_6x6_106 b_6x6_106 (fun i j => coeff (A_6x6_106 i j)) x z := by
  have key : slack a_6x6_106 b_6x6_106 (fun i j => coeff (A_6x6_106 i j)) x z =
      7/4 * (x 0 - 2/7 * z 0 - 2/7 * z 1 - 2/7 * z 2 - 2/7 * z 3 - 2/7 * z 4 - 2/7 * z 5) ^ 2 + 7/4 * (x 1 - 2/7 * z 0 + 2/7 * z 1 + 2/7 * z 2 + 2/7 * z 3 - 2/7 * z 4 + 2/7 * z 5) ^ 2 + 7/4 * (x 2 - 2/7 * z 0 + 2/7 * z 1 - 2/7 * z 2 + 2/7 * z 3 - 2/7 * z 4 + 2/7 * z 5) ^ 2 + 5/4 * (x 3 - 2/5 * z 0 + 2/5 * z 1 - 2/5 * z 2 - 2/5 * z 3 + 2/5 * z 4 + 2/5 * z 5) ^ 2 + 5/4 * (x 4 - 2/5 * z 0 - 2/5 * z 1 + 2/5 * z 2 - 2/5 * z 3 - 2/5 * z 4 + 2/5 * z 5) ^ 2 + 7/4 * (x 5 - 2/7 * z 0 - 2/7 * z 1 - 2/7 * z 2 + 2/7 * z 3 - 2/7 * z 4 - 2/7 * z 5) ^ 2 + 109/140 * (z 0 - 40/109 * z 2 - 16/109 * z 3 - 80/109 * z 4 + 56/109 * z 5) ^ 2 + 109/140 * (z 1 + 16/109 * z 2 - 40/109 * z 3 - 56/109 * z 4 - 80/109 * z 5) ^ 2 + 479/3052 * (z 2 - 112/479 * z 4 - 168/479 * z 5) ^ 2 + 479/3052 * (z 3 + 168/479 * z 4 - 112/479 * z 5) ^ 2 + 241/1916 * (z 4) ^ 2 + 241/1916 * (z 5) ^ 2 := by
    simp [slack, a_6x6_106, b_6x6_106, A_6x6_106, Fin.sum_univ_six]
    ring
  rw [key]
  positivity

/-- **Semantic bound for `6x6_106`**, in every real inner-product space. -/
theorem semantic_6x6_106 : Q (V := V) A_6x6_106 ≤ Real.sqrt 2 * C A_6x6_106 :=
  Q_le_sqrt_two_mul_C_of_cert A_6x6_106 a_6x6_106 b_6x6_106 14 cert_6x6_106
    (by norm_num [a_6x6_106, b_6x6_106, Fin.sum_univ_six]) (by norm_num)
    (by norm_num [a_6x6_106, b_6x6_106, Fin.sum_univ_six]) anchor_6x6_106

/-- Survivor `6x8_690` (6x8, bank `other_survivors_certs.json`): C = 20, dual grid 1/4, U = 27, exact test 729 ≤ 800. -/
def A_6x8_690 : SignMat 6 8 :=
  ![![sp, sp, sp, sp, sp, sp, sp, sp], ![sp, sm, sm, sm, sp, sp, sm, sm], ![sp, sm, sp, sm, sp, sm, sp, sm], ![sp, sm, sp, sp, sm, sp, sm, sm], ![sp, sp, sm, sp, sp, sp, sp, sp], ![sp, sp, sp, sm, sp, sp, sm, sp]]

def s_6x8_690 : Fin 6 → Sign := ![sm, sp, sm, sm, sm, sm]

def t_6x8_690 : Fin 8 → Sign := ![sm, sm, sm, sm, sm, sm, sm, sm]

theorem signValue_6x8_690 : signValue A_6x8_690 s_6x8_690 t_6x8_690 = 20 := by
  unfold signValue A_6x8_690 s_6x8_690 t_6x8_690
  simp [Fin.sum_univ_six, Fin.sum_univ_eight]
  norm_num

theorem anchor_6x8_690 : (20 : ℝ) ≤ C A_6x8_690 :=
  anchor_of_signValue A_6x8_690 s_6x8_690 t_6x8_690 20 signValue_6x8_690

noncomputable def a_6x8_690 : Fin 6 → ℝ := ![11/4, 2, 7/4, 7/4, 11/4, 9/4]

noncomputable def b_6x8_690 : Fin 8 → ℝ := ![2, 9/4, 5/4, 3/2, 3/2, 3/2, 3/2, 9/4]

theorem cert_6x8_690 (x : Fin 6 → ℝ) (z : Fin 8 → ℝ) :
    0 ≤ slack a_6x8_690 b_6x8_690 (fun i j => coeff (A_6x8_690 i j)) x z := by
  have key : slack a_6x8_690 b_6x8_690 (fun i j => coeff (A_6x8_690 i j)) x z =
      11/4 * (x 0 - 2/11 * z 0 - 2/11 * z 1 - 2/11 * z 2 - 2/11 * z 3 - 2/11 * z 4 - 2/11 * z 5 - 2/11 * z 6 - 2/11 * z 7) ^ 2 + 2 * (x 1 - 1/4 * z 0 + 1/4 * z 1 + 1/4 * z 2 + 1/4 * z 3 - 1/4 * z 4 - 1/4 * z 5 + 1/4 * z 6 + 1/4 * z 7) ^ 2 + 7/4 * (x 2 - 2/7 * z 0 + 2/7 * z 1 - 2/7 * z 2 + 2/7 * z 3 - 2/7 * z 4 + 2/7 * z 5 - 2/7 * z 6 + 2/7 * z 7) ^ 2 + 7/4 * (x 3 - 2/7 * z 0 + 2/7 * z 1 - 2/7 * z 2 - 2/7 * z 3 + 2/7 * z 4 - 2/7 * z 5 + 2/7 * z 6 + 2/7 * z 7) ^ 2 + 11/4 * (x 4 - 2/11 * z 0 - 2/11 * z 1 + 2/11 * z 2 - 2/11 * z 3 - 2/11 * z 4 - 2/11 * z 5 - 2/11 * z 6 - 2/11 * z 7) ^ 2 + 9/4 * (x 5 - 2/9 * z 0 - 2/9 * z 1 - 2/9 * z 2 + 2/9 * z 3 - 2/9 * z 4 - 2/9 * z 5 + 2/9 * z 6 - 2/9 * z 7) ^ 2 + 7187/5544 * (z 0 + 653/7187 * z 1 - 1507/7187 * z 2 + 301/7187 * z 3 - 2317/7187 * z 4 - 2317/7187 * z 5 + 301/7187 * z 6 + 653/7187 * z 7) ^ 2 + 44147/28748 * (z 1 + 2136/44147 * z 2 - 5768/44147 * z 3 - 3736/44147 * z 4 - 3736/44147 * z 5 - 5768/44147 * z 6 - 20536/44147 * z 7) ^ 2 + 943581/1942468 * (z 2 + 4664/314527 * z 3 - 131032/943581 * z 4 - 131032/943581 * z 5 + 4664/314527 * z 6 + 70488/314527 * z 7) ^ 2 + 3380743/4403378 * (z 3 + 1503892/3380743 * z 4 - 1012324/3380743 * z 5 - 708108/3380743 * z 6 - 1301580/3380743 * z 7) ^ 2 + 9925771/20284458 * (z 4 - 3753596/9925771 * z 5 - 169068/522409 * z 6 - 46764/522409 * z 7) ^ 2 + 9974149/19851542 * (z 5 + 4635164/9974149 * z 6 - 5565708/9974149 * z 7) ^ 2 + 11456715/19948298 * (z 6 - 321012/763781 * z 7) ^ 2 + 2454309/3055124 * (z 7) ^ 2 := by
    simp [slack, a_6x8_690, b_6x8_690, A_6x8_690, Fin.sum_univ_six, Fin.sum_univ_eight]
    ring
  rw [key]
  positivity

/-- **Semantic bound for `6x8_690`**, in every real inner-product space. -/
theorem semantic_6x8_690 : Q (V := V) A_6x8_690 ≤ Real.sqrt 2 * C A_6x8_690 :=
  Q_le_sqrt_two_mul_C_of_cert A_6x8_690 a_6x8_690 b_6x8_690 20 cert_6x8_690
    (by norm_num [a_6x8_690, b_6x8_690, Fin.sum_univ_six, Fin.sum_univ_eight]) (by norm_num)
    (by norm_num [a_6x8_690, b_6x8_690, Fin.sum_univ_six, Fin.sum_univ_eight]) anchor_6x8_690

/-- Survivor `7x8_53110` (7x8, bank `other_survivors_certs.json`): C = 22, dual grid 1/2, U = 31, exact test 961 ≤ 968. -/
def A_7x8_53110 : SignMat 7 8 :=
  ![![sp, sp, sp, sp, sp, sp, sp, sp], ![sp, sm, sm, sp, sp, sm, sp, sm], ![sp, sm, sp, sm, sm, sp, sm, sm], ![sp, sm, sp, sm, sm, sp, sp, sp], ![sp, sp, sm, sp, sm, sp, sm, sm], ![sp, sp, sp, sm, sp, sm, sm, sm], ![sp, sp, sp, sp, sp, sp, sp, sp]]

def s_7x8_53110 : Fin 7 → Sign := ![sm, sp, sm, sm, sm, sm, sm]

def t_7x8_53110 : Fin 8 → Sign := ![sm, sm, sm, sp, sp, sm, sp, sm]

theorem signValue_7x8_53110 : signValue A_7x8_53110 s_7x8_53110 t_7x8_53110 = 22 := by
  unfold signValue A_7x8_53110 s_7x8_53110 t_7x8_53110
  simp [Fin.sum_univ_seven, Fin.sum_univ_eight]
  norm_num

theorem anchor_7x8_53110 : (22 : ℝ) ≤ C A_7x8_53110 :=
  anchor_of_signValue A_7x8_53110 s_7x8_53110 t_7x8_53110 22 signValue_7x8_53110

noncomputable def a_7x8_53110 : Fin 7 → ℝ := ![3, 2, 5/2, 5/2, 3/2, 3/2, 3]

noncomputable def b_7x8_53110 : Fin 8 → ℝ := ![3/2, 3/2, 2, 2, 2, 2, 2, 2]

theorem cert_7x8_53110 (x : Fin 7 → ℝ) (z : Fin 8 → ℝ) :
    0 ≤ slack a_7x8_53110 b_7x8_53110 (fun i j => coeff (A_7x8_53110 i j)) x z := by
  have key : slack a_7x8_53110 b_7x8_53110 (fun i j => coeff (A_7x8_53110 i j)) x z =
      3 * (x 0 - 1/6 * z 0 - 1/6 * z 1 - 1/6 * z 2 - 1/6 * z 3 - 1/6 * z 4 - 1/6 * z 5 - 1/6 * z 6 - 1/6 * z 7) ^ 2 + 2 * (x 1 - 1/4 * z 0 + 1/4 * z 1 + 1/4 * z 2 - 1/4 * z 3 - 1/4 * z 4 + 1/4 * z 5 - 1/4 * z 6 + 1/4 * z 7) ^ 2 + 5/2 * (x 2 - 1/5 * z 0 + 1/5 * z 1 - 1/5 * z 2 + 1/5 * z 3 + 1/5 * z 4 - 1/5 * z 5 + 1/5 * z 6 + 1/5 * z 7) ^ 2 + 5/2 * (x 3 - 1/5 * z 0 + 1/5 * z 1 - 1/5 * z 2 + 1/5 * z 3 + 1/5 * z 4 - 1/5 * z 5 - 1/5 * z 6 - 1/5 * z 7) ^ 2 + 3/2 * (x 4 - 1/3 * z 0 - 1/3 * z 1 + 1/3 * z 2 - 1/3 * z 3 + 1/3 * z 4 - 1/3 * z 5 + 1/3 * z 6 + 1/3 * z 7) ^ 2 + 3/2 * (x 5 - 1/3 * z 0 - 1/3 * z 1 - 1/3 * z 2 + 1/3 * z 3 - 1/3 * z 4 + 1/3 * z 5 + 1/3 * z 6 + 1/3 * z 7) ^ 2 + 3 * (x 6 - 1/6 * z 0 - 1/6 * z 1 - 1/6 * z 2 - 1/6 * z 3 - 1/6 * z 4 - 1/6 * z 5 - 1/6 * z 6 - 1/6 * z 7) ^ 2 + 27/40 * (z 0 - 7/27 * z 1 - 29/81 * z 2 - 11/81 * z 3 - 11/81 * z 4 - 29/81 * z 5 + 5/81 * z 6 + 35/81 * z 7) ^ 2 + 17/27 * (z 1 - 25/102 * z 2 - 43/102 * z 3 - 43/102 * z 4 - 25/102 * z 5 + 49/102 * z 6 + 19/102 * z 7) ^ 2 + 643/612 * (z 2 + 241/643 * z 3 - 167/643 * z 4 - 173/643 * z 5 + 29/643 * z 6 - 97/643 * z 7) ^ 2 + 1742/1929 * (z 3 - 174/871 * z 4 - 161/871 * z 5 - 170/871 * z 6 + 103/871 * z 7) ^ 2 + 822/871 * (z 4 + 125/411 * z 5 - 79/411 * z 6 + 4/137 * z 7) ^ 2 + 352/411 * (z 5 + 17/176 * z 6 - 39/176 * z 7) ^ 2 + 417/440 * (z 6 - 263/417 * z 7) ^ 2 + 238/417 * (z 7) ^ 2 := by
    simp [slack, a_7x8_53110, b_7x8_53110, A_7x8_53110, Fin.sum_univ_seven, Fin.sum_univ_eight]
    ring
  rw [key]
  positivity

/-- **Semantic bound for `7x8_53110`**, in every real inner-product space. -/
theorem semantic_7x8_53110 : Q (V := V) A_7x8_53110 ≤ Real.sqrt 2 * C A_7x8_53110 :=
  Q_le_sqrt_two_mul_C_of_cert A_7x8_53110 a_7x8_53110 b_7x8_53110 22 cert_7x8_53110
    (by norm_num [a_7x8_53110, b_7x8_53110, Fin.sum_univ_seven, Fin.sum_univ_eight]) (by norm_num)
    (by norm_num [a_7x8_53110, b_7x8_53110, Fin.sum_univ_seven, Fin.sum_univ_eight]) anchor_7x8_53110

/-- Survivor `s8x8_1705` (8x8, bank `survivors_8x8_certs.json`): C = 28, dual grid 1/2, U = 77/2, exact test 5929 ≤ 6272. -/
def A_s8x8_1705 : SignMat 8 8 :=
  ![![sp, sp, sp, sp, sp, sp, sp, sp], ![sp, sm, sp, sm, sm, sm, sm, sm], ![sp, sm, sp, sm, sm, sp, sm, sp], ![sp, sm, sp, sp, sm, sp, sm, sm], ![sp, sm, sp, sp, sm, sp, sm, sp], ![sp, sp, sp, sm, sp, sm, sp, sm], ![sp, sp, sp, sp, sp, sm, sp, sp], ![sp, sp, sp, sp, sp, sp, sp, sm]]

def s_s8x8_1705 : Fin 8 → Sign := ![sm, sp, sm, sm, sm, sm, sm, sm]

def t_s8x8_1705 : Fin 8 → Sign := ![sm, sm, sm, sm, sm, sm, sm, sm]

theorem signValue_s8x8_1705 : signValue A_s8x8_1705 s_s8x8_1705 t_s8x8_1705 = 28 := by
  unfold signValue A_s8x8_1705 s_s8x8_1705 t_s8x8_1705
  simp [Fin.sum_univ_eight]
  norm_num

theorem anchor_s8x8_1705 : (28 : ℝ) ≤ C A_s8x8_1705 :=
  anchor_of_signValue A_s8x8_1705 s_s8x8_1705 t_s8x8_1705 28 signValue_s8x8_1705

noncomputable def a_s8x8_1705 : Fin 8 → ℝ := ![3, 2, 5/2, 5/2, 3, 2, 5/2, 5/2]

noncomputable def b_s8x8_1705 : Fin 8 → ℝ := ![2, 3, 2, 2, 3, 2, 3, 3/2]

theorem cert_s8x8_1705 (x : Fin 8 → ℝ) (z : Fin 8 → ℝ) :
    0 ≤ slack a_s8x8_1705 b_s8x8_1705 (fun i j => coeff (A_s8x8_1705 i j)) x z := by
  have key : slack a_s8x8_1705 b_s8x8_1705 (fun i j => coeff (A_s8x8_1705 i j)) x z =
      3 * (x 0 - 1/6 * z 0 - 1/6 * z 1 - 1/6 * z 2 - 1/6 * z 3 - 1/6 * z 4 - 1/6 * z 5 - 1/6 * z 6 - 1/6 * z 7) ^ 2 + 2 * (x 1 - 1/4 * z 0 + 1/4 * z 1 - 1/4 * z 2 + 1/4 * z 3 + 1/4 * z 4 + 1/4 * z 5 + 1/4 * z 6 + 1/4 * z 7) ^ 2 + 5/2 * (x 2 - 1/5 * z 0 + 1/5 * z 1 - 1/5 * z 2 + 1/5 * z 3 + 1/5 * z 4 - 1/5 * z 5 + 1/5 * z 6 - 1/5 * z 7) ^ 2 + 5/2 * (x 3 - 1/5 * z 0 + 1/5 * z 1 - 1/5 * z 2 - 1/5 * z 3 + 1/5 * z 4 - 1/5 * z 5 + 1/5 * z 6 + 1/5 * z 7) ^ 2 + 3 * (x 4 - 1/6 * z 0 + 1/6 * z 1 - 1/6 * z 2 - 1/6 * z 3 + 1/6 * z 4 - 1/6 * z 5 + 1/6 * z 6 - 1/6 * z 7) ^ 2 + 2 * (x 5 - 1/4 * z 0 - 1/4 * z 1 - 1/4 * z 2 + 1/4 * z 3 - 1/4 * z 4 + 1/4 * z 5 - 1/4 * z 6 + 1/4 * z 7) ^ 2 + 5/2 * (x 6 - 1/5 * z 0 - 1/5 * z 1 - 1/5 * z 2 - 1/5 * z 3 - 1/5 * z 4 + 1/5 * z 5 - 1/5 * z 6 - 1/5 * z 7) ^ 2 + 5/2 * (x 7 - 1/5 * z 0 - 1/5 * z 1 - 1/5 * z 2 - 1/5 * z 3 - 1/5 * z 4 - 1/5 * z 5 - 1/5 * z 6 + 1/5 * z 7) ^ 2 + 71/60 * (z 0 - 49/71 * z 2 - 7/71 * z 3 - 7/71 * z 5 + 5/71 * z 7) ^ 2 + 131/60 * (z 1 - 12/131 * z 3 - 49/131 * z 4 + 12/131 * z 5 - 49/131 * z 6) ^ 2 + 44/71 * (z 2 - 7/22 * z 3 - 7/22 * z 5 + 5/22 * z 7) ^ 2 + 7859/7205 * (z 3 - 1980/7859 * z 4 - 3405/7859 * z 5 - 1980/7859 * z 6 - 1179/7859 * z 7) ^ 2 + 14214/7859 * (z 4 + 204/2369 * z 5 - 3121/4738 * z 6 - 54/2369 * z 7) ^ 2 + 10336/11845 * (z 5 + 45/152 * z 6 - 9/34 * z 7) ^ 2 + 18/19 * (z 6) ^ 2 + 19/34 * (z 7) ^ 2 := by
    simp [slack, a_s8x8_1705, b_s8x8_1705, A_s8x8_1705, Fin.sum_univ_eight]
    ring
  rw [key]
  positivity

/-- **Semantic bound for `s8x8_1705`**, in every real inner-product space. -/
theorem semantic_s8x8_1705 : Q (V := V) A_s8x8_1705 ≤ Real.sqrt 2 * C A_s8x8_1705 :=
  Q_le_sqrt_two_mul_C_of_cert A_s8x8_1705 a_s8x8_1705 b_s8x8_1705 28 cert_s8x8_1705
    (by norm_num [a_s8x8_1705, b_s8x8_1705, Fin.sum_univ_eight]) (by norm_num)
    (by norm_num [a_s8x8_1705, b_s8x8_1705, Fin.sum_univ_eight]) anchor_s8x8_1705

end GrothSemantic
