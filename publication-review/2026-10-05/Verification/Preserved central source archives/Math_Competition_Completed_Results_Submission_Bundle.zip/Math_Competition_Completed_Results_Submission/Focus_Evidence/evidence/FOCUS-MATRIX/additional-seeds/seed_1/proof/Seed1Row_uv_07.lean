import Seed1KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed1
open Matrix
theorem row_uv_7 : (L_uv * M_uv) (7 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 7 := by decide
#print axioms row_uv_7
end RecoveredMMTKernelSeed1
