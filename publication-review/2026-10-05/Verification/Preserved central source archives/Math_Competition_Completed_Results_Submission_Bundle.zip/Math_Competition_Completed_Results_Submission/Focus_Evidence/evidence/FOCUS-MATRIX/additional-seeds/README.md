# Additional HKS139 fixed-seed one-leg rigidity certificates

Prepared 3 October 2026. Both additional original seeds, `hks139_1.json` and
`hks139_2.json`, now have completed standard-kernel proofs for all three paired
factor maps. Seed 1 completed at 01:08:07 UTC and seed 2 at 01:08:15 UTC.
Each fresh replay compiled 71 modules: the exact data definitions, 69 inverse-row
proofs, and the final injectivity and remaining-factor uniqueness proofs.

## Exact result

For either stored seed, and each pair UV, UW or VW, let
`B[9*i+j,t] = a[t,i] * b[t,j]`, with `t < 23` and `i,j < 9`.
The rational map `x ↦ B*x` is injective. For every index type `p` and every
pair of rational matrices `X,Y : Fin 23 × p → Q`, `B*X = B*Y` implies `X = Y`.
Thus fixing either pair of the original factor lists uniquely determines the
remaining factor list through the coefficient equations. This gives the same
fixed-seed one-leg support obstruction as the existing seed-0 certificate.

The construction/algorithm remains attributed to Smirnov via the
Heule–Kauers–Seidl catalogue. The team's supplied result is the specific
fixed-seed obstruction and its certificates. This package does not assert a
new matrix-multiplication algorithm, global tensor-rank lower bound,
rank-22 impossibility, support-139 optimality, novelty/priority, or M1 admission.
It adds no new seed: `solution.json` is the existing seed 0.

## Proof trust and correspondence

All finite inverse identities are proved by ordinary Lean `decide`, then used
by generic matrix proofs. No `native_decide`, `sorry`, `admit`, custom axiom or
unsafe declaration occurs in the 142 generated Lean source modules. The 138
row theorems and 18 printed final declarations have only the standard axioms
`propext`, `Classical.choice`, and `Quot.sound`. The six injectivity and six
remaining-factor uniqueness endpoints are included among those declarations.

Each minor is 23×23 with determinant ±1 and a 0/±1 integer inverse. The Lean
data definitions use exactly the original JSON factor arrays. The independent
stdlib-only checker parses the generated Lean literals and checks those arrays,
the selected rows, and the integer inverse tables. It separately checks exact
rational rank 23 for all six 81×23 matrices, both inverse products, and all 729
Brent identities for each seed under the original README's column-major W
convention. The last tensor checks are computational source/target audits,
not additional formal Lean theorems.

Each replay directory was newly created with zero `.olean` files. Only `.lean`
source was copied into it before compiling all 71 modules. Previously built
seed-0 or seed-1/2 certificate objects were absent from its import path. The
matching Mathlib dependency cache was used normally.

Environment: Lean 4.33.1 (commit
`819816b2e0a3bf405af45ae5c7af2491d8f5bee6`), Mathlib
`0df444a360eaa60ab8c11dca51a86af692955474`. The full dependency revisions,
commands, source hashes, output hashes, timings and logs are in the receipts.

## Navigation

For `N = 1` or `2`:

- `seed_N/proof/SeedNKernelData.lean`: actual original factor arrays and minors
- `seed_N/proof/SeedNKernelFinal.lean`: generic final proof
- `seed_N/kernel-check-receipt.json`: completed fresh replay status and every module
- `seed_N/replay/<timestamp>/*.log`: original compiler logs
- `seed_N/source-data-correspondence.json`: independent data/target audit
- `seed_N/original/hks139_N.json`: byte-identical preserved input
- `seed_N/{uv,uw,vw}_minor.json`: selected rows, minor and inverse certificates

Both final proof files have the same theorem line numbers:

- 103: `rational_injective_uv`
- 142: `rational_injective_uw`
- 181: `rational_injective_vw`
- 192: `remaining_factor_unique_uv`
- 204: `remaining_factor_unique_uw`
- 216: `remaining_factor_unique_vw`

The namespaces are `RecoveredMMTKernelSeed1` and `RecoveredMMTKernelSeed2`.
`preservation-check.json` confirms that all 149 archived seed-0 files still
match the earlier standard-kernel ZIP, and all four original JSON input paths
match their prior recorded hashes. That older certificate/archive is not
modified or superseded; it covers seed 0, while this package covers seeds 1–2.

`reference/original-matrix-README.md` is preserved source material, not a new
endorsement of every historical search, leaderboard, or optimality statement.
`reference/Seed0KernelFinal.lean` and `reference/seed0_generate.py` are
unchanged references to the successful prior construction. The former is not
compiled by either new proof chain.

## Replay

Use an initialized project with the matching pinned Lean/Mathlib environment.
The `environment` directory provides the toolchain, Lake configuration and
pinned dependency manifest. Once its dependencies are available, run from that
project:

```sh
lake env bash /absolute/path/to/matrix-additional-seeds/build.sh
```

The portable build creates new replay directories and leaves existing receipts
and compiler evidence intact. It compiles all sources and prints the final
axiom reports. The independent data checker can also run by itself:

```sh
python3 check_correspondence.py
```

`generate.py` deterministically regenerates the certificate sources from the
included preserved originals and seed-0 proof template (requires SymPy).
It rejects non-integral inverses rather than truncating them. Generation is
not part of the trusted base: Lean checks every resulting inverse identity.
`run_checks.py` is the exact workspace-specific runner used for the recorded
fresh replay; `build.sh` is the portable equivalent.

The source/log archive intentionally omits `.olean` objects; these are rebuilt
from source. No upload, publication or report/card mutation was performed.
