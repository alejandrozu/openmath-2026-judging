#!/usr/bin/env python3
"""Independent stdlib-only data audit, exact rational rank, and integer products."""
from pathlib import Path
from fractions import Fraction
import ast,datetime,hashlib,json,re
R=Path(__file__).resolve().parent
EXPECTED={1:'de78500d31eb4cae85a16fb20b94cc13205e955fecbddaa76c70b98b1588670d',2:'e0a3573cfacb2f9713bdfaca5deff5181f3e5aec74427a9e8a82db08087a7a5c'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def matmul(A,B): return [[sum(x*y for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def rank(A):
    M=[[Fraction(x) for x in row] for row in A]; h=0
    for j in range(len(M[0])):
        piv=next((i for i in range(h,len(M)) if M[i][j]),None)
        if piv is None: continue
        M[h],M[piv]=M[piv],M[h]; a=M[h][j]; M[h]=[x/a for x in M[h]]
        for i in range(h+1,len(M)):
            if M[i][j]:
                a=M[i][j]; M[i]=[x-a*y for x,y in zip(M[i],M[h])]
        h+=1
    return h

def check(seed):
    r=R/f'seed_{seed}'; original=r/'original'/f'hks139_{seed}.json'
    assert sha(original)==EXPECTED[seed]
    d=json.loads(original.read_text()); source=r/'proof'/f'Seed{seed}KernelData.lean'; text=source.read_text()
    def literal(name):
        matches=re.findall(r'^def '+name+r' : [^\n]* := (\[.*\])$',text,re.M)
        assert len(matches)==1,name
        return ast.literal_eval(matches[0])
    assert all(literal('data_'+a)==d[a] for a in 'uvw')
    for a in 'uvw':
        assert f'def factor_{a} (t : Fin 23) (i : Fin 9) : ℤ := (data_{a}.getD t.val []).getD i.val 0' in text
        assert len(d[a])==23 and all(len(row)==9 for row in d[a])
    pairs=[]
    for a,b in ('uv','uw','vw'):
        n=a+b; c=json.loads((r/f'{n}_minor.json').read_text()); inds=c['selected_rows']; L=c['left_inverse']
        B=[[d[a][t][i]*d[b][t][j] for t in range(23)] for i in range(9) for j in range(9)]
        assert len(inds)==23 and len(set(inds))==23 and all(0<=i<81 for i in inds)
        M=[B[i] for i in inds]
        assert c['matrix']==M and c['source_sha256']==EXPECTED[seed]
        assert literal('pivData_'+n)==inds and literal('LData_'+n)==L
        assert f'def B_{n} : Matrix (Fin 81) (Fin 23) ℤ := fun i t => factor_{a} t ⟨i.val/9, by omega⟩ * factor_{b} t ⟨i.val%9, Nat.mod_lt _ (by decide)⟩' in text
        assert f'def M_{n} : Matrix (Fin 23) (Fin 23) ℤ := fun i t => B_{n} (piv_{n} i) t' in text
        assert f'def L_{n} : Matrix (Fin 23) (Fin 23) ℤ := fun i j => (LData_{n}.getD i.val []).getD j.val 0' in text
        I=[[int(i==j) for j in range(23)] for i in range(23)]
        assert matmul(L,M)==I and matmul(M,L)==I
        rk=rank(B); assert rk==23
        pairs.append({'pairing':n,'shape':[81,23],'exact_Fraction_rank':rk,'minor_shape':[23,23],
            'selected_rows_exact_match':True,'selected_minor_exact_match':True,'integer_inverse_tables_exact_match':True,
            'L_times_M_identity':True,'M_times_L_identity':True,'minor_certificate_sha256':sha(r/f'{n}_minor.json')})
    support=sum(bool(x) for a in 'uvw' for row in d[a] for x in row); assert support==139
    failed=[]
    for i in range(9):
        for j in range(9):
            for k in range(9):
                actual=sum(d['u'][t][i]*d['v'][t][j]*d['w'][t][k] for t in range(23))
                expected=int(i%3==j//3 and k%3==i//3 and k//3==j%3)
                if actual!=expected: failed.append([i,j,k,actual,expected])
    assert not failed
    template=(R/'reference/Seed0KernelFinal.lean').read_text()
    expected_final=re.sub(r'^import Row_',f'import Seed{seed}Row_',template.replace('RecoveredMMTKernel',f'RecoveredMMTKernelSeed{seed}'),flags=re.M)
    assert (r/'proof'/f'Seed{seed}KernelFinal.lean').read_text()==expected_final
    final={'schema':'matrix-additional-seeds-correspondence-v1','seed':seed,'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_factor_sha256':sha(original),'expected_original_hash_match':True,'KernelData_sha256':sha(source),
        'factor_arrays_exact_match':True,'factor_dimensions':[23,9],'support_nonzero_entries':support,
        'target_tensor':'T[I,J,K] = 1 iff I%3=J//3 and K%3=I//3 and K//3=J%3; W is column-major',
        'Brent_identities_checked':729,'Brent_identities_failures':0,'pairings':pairs,
        'generic_proof_is_seed0_proof_with_only_import_and_namespace_renaming':True,
        'method':'Parse emitted Lean list literals independently; exact stdlib Fraction Gaussian elimination; exact integer matrix multiplication; exhaustive 729 tensor coefficients. No project checker or SymPy imported.'}
    (r/'source-data-correspondence.json').write_text(json.dumps(final,indent=2)+'\n')
    print(json.dumps(final))
if __name__=='__main__':
    for seed in (1,2):check(seed)
