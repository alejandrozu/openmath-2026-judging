import Mathlib

/-!
# The semantic three-row Grothendieck bound

For every `3 × n` sign matrix `A`, every family of unit vectors in every real
inner-product space satisfies `objective A u v ≤ √(3/2) · C A`; hence
`Q A ≤ √(3/2) · C A ≤ √2 · C A`.

The file repeats the public definitions of `formal/Symmetry.lean` (`Sign`,
`SignMat`, `coeff`, `objective`, `Q`, `C`) so the isolated checker needs only
`import Mathlib`.

Outline.
* Column normalisation: `Σᵢ Aᵢⱼ uᵢ = A₀ⱼ • (u₀ + r₁ⱼ u₁ + r₂ⱼ u₂)` with
  `r₁ⱼ = A₀ⱼA₁ⱼ` and `r₂ⱼ = A₀ⱼA₂ⱼ` in `{±1}`.
* Walsh weights `wt a b = Σⱼ ((1 + a r₁ⱼ)/2)((1 + b r₂ⱼ)/2)` are the real
  multiplicities of the four projective column types; nothing is counted.
* Four lower anchors `n + 2·wt a b ≤ C A`, one per row-sign vector `(1,a,b)`,
  from the general anchor `absScore_le_C`.  Exact optimality of `C` is unused.
* Parseval `Σ ‖u₀ + a u₁ + b u₂‖² = 12` from the parallelogram law.
* Cauchy–Schwarz plus `(K − 2N)² ≥ 0` closes at `√(3/2)`.
-/

open scoped InnerProductSpace

namespace GrothSymmetry

abbrev Sign := ℤˣ
abbrev SignMat (m n : ℕ) := Fin m → Fin n → Sign

/-- Real coefficient corresponding to an integer sign. -/
def coeff (s : Sign) : ℝ := ((s : ℤ) : ℝ)

@[simp] theorem coeff_mul (s t : Sign) : coeff (s * t) = coeff s * coeff t := by
  simp [coeff]

@[simp] theorem coeff_one : coeff 1 = 1 := by simp [coeff]

@[simp] theorem coeff_mul_self (s : Sign) : coeff s * coeff s = 1 := by
  rw [← coeff_mul, Int.units_mul_self, coeff_one]

@[simp] theorem abs_coeff (s : Sign) : |coeff s| = 1 := by
  rcases Int.units_eq_one_or s with h | h <;> simp [coeff, h]

@[simp] theorem norm_coeff (s : Sign) : ‖coeff s‖ = 1 := by
  simp [Real.norm_eq_abs]

theorem coeff_cases (s : Sign) : coeff s = 1 ∨ coeff s = -1 := by
  rcases Int.units_eq_one_or s with h | h <;> simp [coeff, h]

variable {m n : ℕ} {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The finite bilinear vector objective `Σᵢⱼ Aᵢⱼ ⟨uᵢ, vⱼ⟩`. -/
def objective (A : SignMat m n) (u : Fin m → V) (v : Fin n → V) : ℝ :=
  ∑ i, ∑ j, coeff (A i j) * ⟪u i, v j⟫_ℝ

/-- Supremum of all objectives attained by two families of unit vectors. -/
noncomputable def Q (A : SignMat m n) : ℝ :=
  sSup {z : ℝ | ∃ (u : Fin m → V) (v : Fin n → V),
    (∀ i, ‖u i‖ = 1) ∧ (∀ j, ‖v j‖ = 1) ∧ z = objective A u v}

/-- Sign optimum: in the one-dimensional real space, unit vectors are signs. -/
noncomputable def C (A : SignMat m n) : ℝ := Q (V := ℝ) A

theorem objective_le_card (A : SignMat m n) (u : Fin m → V) (v : Fin n → V)
    (hu : ∀ i, ‖u i‖ = 1) (hv : ∀ j, ‖v j‖ = 1) :
    objective A u v ≤ (m * n : ℕ) := by
  unfold objective
  calc
    (∑ i, ∑ j, coeff (A i j) * ⟪u i, v j⟫_ℝ)
        ≤ ∑ _i : Fin m, ∑ _j : Fin n, (1 : ℝ) := by
          apply Finset.sum_le_sum; intro i _
          apply Finset.sum_le_sum; intro j _
          calc
            coeff (A i j) * ⟪u i, v j⟫_ℝ
                ≤ |coeff (A i j) * ⟪u i, v j⟫_ℝ| := le_abs_self _
            _ = |⟪u i, v j⟫_ℝ| := by rw [abs_mul, abs_coeff, one_mul]
            _ ≤ ‖u i‖ * ‖v j‖ := abs_real_inner_le_norm _ _
            _ = 1 := by rw [hu i, hv j, one_mul]
    _ = (m * n : ℕ) := by simp

theorem objectiveSet_bddAbove (A : SignMat m n) :
    BddAbove {z : ℝ | ∃ (u : Fin m → V) (v : Fin n → V),
      (∀ i, ‖u i‖ = 1) ∧ (∀ j, ‖v j‖ = 1) ∧ z = objective A u v} := by
  refine ⟨(m * n : ℕ), ?_⟩
  rintro z ⟨u, v, hu, hv, rfl⟩
  exact objective_le_card A u v hu hv

/-! ## A general scalar anchor, valid for every number of rows -/

/-- A `±1`-valued sign of a real number (total: `usign 0 = 1`). -/
noncomputable def usign (x : ℝ) : ℝ := if 0 ≤ x then 1 else -1

@[simp] theorem norm_usign (x : ℝ) : ‖usign x‖ = 1 := by
  unfold usign; split_ifs <;> simp

theorem mul_usign (x : ℝ) : x * usign x = |x| := by
  unfold usign
  split_ifs with h
  · rw [abs_of_nonneg h]; ring
  · rw [abs_of_neg (not_le.mp h)]; ring

/-- Value attained by the row-sign vector `s`, answering each column optimally. -/
def absScore (A : SignMat m n) (s : Fin m → Sign) : ℝ :=
  ∑ j, |∑ i, coeff (A i j) * coeff (s i)|

/-- Every row-sign vector lower-bounds the sign optimum. -/
theorem absScore_le_C (A : SignMat m n) (s : Fin m → Sign) :
    absScore A s ≤ C A := by
  unfold C Q
  apply le_csSup (objectiveSet_bddAbove (V := ℝ) A)
  refine ⟨(fun i => coeff (s i)),
    (fun j => usign (∑ i, coeff (A i j) * coeff (s i))), ?_, ?_, ?_⟩
  · intro i; exact norm_coeff (s i)
  · intro j; exact norm_usign _
  · unfold objective absScore
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro j _
    simp only [Real.inner_apply, ← mul_assoc]
    rw [← Finset.sum_mul]
    exact (mul_usign _).symm

/-! ## Elementary facts about `±1` reals -/

theorem pm_mul {x y : ℝ} (hx : x = 1 ∨ x = -1) (hy : y = 1 ∨ y = -1) :
    x * y = 1 ∨ x * y = -1 := by
  rcases hx with rfl | rfl <;> rcases hy with rfl | rfl <;> norm_num

theorem half_nonneg_of_pm {z : ℝ} (hz : z = 1 ∨ z = -1) : 0 ≤ (1 + z) / 2 := by
  rcases hz with rfl | rfl <;> norm_num

theorem abs_three {x y : ℝ} (hx : x = 1 ∨ x = -1) (hy : y = 1 ∨ y = -1) :
    |1 + x + y| = 1 + 2 * (((1 + x) / 2) * ((1 + y) / 2)) := by
  rcases hx with rfl | rfl <;> rcases hy with rfl | rfl
  · rw [abs_of_nonneg (show (0 : ℝ) ≤ 1 + 1 + 1 by norm_num)]; norm_num
  · rw [abs_of_nonneg (show (0 : ℝ) ≤ 1 + 1 + -1 by norm_num)]; norm_num
  · rw [abs_of_nonneg (show (0 : ℝ) ≤ 1 + -1 + 1 by norm_num)]; norm_num
  · rw [abs_of_nonpos (show (1 : ℝ) + -1 + -1 ≤ 0 by norm_num)]; norm_num

/-! ## The four-type aggregation inequality -/

/-- Four nonnegative weights with lower anchors `N + 2 pₖ ≤ K`, against four
nonnegative reals whose squares total `12`, are bounded by `√(3/2) · K`. -/
theorem agg4 (p1 p2 p3 p4 x1 x2 x3 x4 N K : ℝ)
    (h1 : 0 ≤ p1) (h2 : 0 ≤ p2) (h3 : 0 ≤ p3) (h4 : 0 ≤ p4)
    (hx1 : 0 ≤ x1) (hx2 : 0 ≤ x2) (hx3 : 0 ≤ x3) (hx4 : 0 ≤ x4)
    (hN : p1 + p2 + p3 + p4 = N)
    (hx : x1 ^ 2 + x2 ^ 2 + x3 ^ 2 + x4 ^ 2 = 12)
    (a1 : N + 2 * p1 ≤ K) (a2 : N + 2 * p2 ≤ K)
    (a3 : N + 2 * p3 ≤ K) (a4 : N + 2 * p4 ≤ K) :
    p1 * x1 + p2 * x2 + p3 * x3 + p4 * x4 ≤ Real.sqrt (3 / 2) * K := by
  have hN0 : 0 ≤ N := by linarith
  have hK0 : 0 ≤ K := by linarith
  have hS0 : 0 ≤ p1 * x1 + p2 * x2 + p3 * x3 + p4 * x4 := by
    have := mul_nonneg h1 hx1
    have := mul_nonneg h2 hx2
    have := mul_nonneg h3 hx3
    have := mul_nonneg h4 hx4
    linarith
  have hCS : (p1 * x1 + p2 * x2 + p3 * x3 + p4 * x4) ^ 2
      ≤ (p1 ^ 2 + p2 ^ 2 + p3 ^ 2 + p4 ^ 2) * (x1 ^ 2 + x2 ^ 2 + x3 ^ 2 + x4 ^ 2) := by
    nlinarith [sq_nonneg (p1 * x2 - p2 * x1), sq_nonneg (p1 * x3 - p3 * x1),
      sq_nonneg (p1 * x4 - p4 * x1), sq_nonneg (p2 * x3 - p3 * x2),
      sq_nonneg (p2 * x4 - p4 * x2), sq_nonneg (p3 * x4 - p4 * x3)]
  have e1 : p1 ^ 2 ≤ (K - N) / 2 * p1 := by
    nlinarith [mul_nonneg h1 (show (0 : ℝ) ≤ (K - N) / 2 - p1 by linarith)]
  have e2 : p2 ^ 2 ≤ (K - N) / 2 * p2 := by
    nlinarith [mul_nonneg h2 (show (0 : ℝ) ≤ (K - N) / 2 - p2 by linarith)]
  have e3 : p3 ^ 2 ≤ (K - N) / 2 * p3 := by
    nlinarith [mul_nonneg h3 (show (0 : ℝ) ≤ (K - N) / 2 - p3 by linarith)]
  have e4 : p4 ^ 2 ≤ (K - N) / 2 * p4 := by
    nlinarith [mul_nonneg h4 (show (0 : ℝ) ≤ (K - N) / 2 - p4 by linarith)]
  have hsum : (K - N) / 2 * p1 + (K - N) / 2 * p2 + (K - N) / 2 * p3
      + (K - N) / 2 * p4 = (K - N) / 2 * N := by
    rw [← hN]; ring
  have hP : p1 ^ 2 + p2 ^ 2 + p3 ^ 2 + p4 ^ 2 ≤ (K - N) / 2 * N := by linarith
  have hS2 : (p1 * x1 + p2 * x2 + p3 * x3 + p4 * x4) ^ 2 ≤ 3 / 2 * K ^ 2 := by
    rw [hx] at hCS
    nlinarith [sq_nonneg (K - 2 * N), hP, hCS]
  have key : Real.sqrt (3 / 2) * K = Real.sqrt (3 / 2 * K ^ 2) := by
    rw [Real.sqrt_mul (by norm_num : (0 : ℝ) ≤ 3 / 2), Real.sqrt_sq hK0]
  rw [key]
  calc p1 * x1 + p2 * x2 + p3 * x3 + p4 * x4
      = Real.sqrt ((p1 * x1 + p2 * x2 + p3 * x3 + p4 * x4) ^ 2) :=
        (Real.sqrt_sq hS0).symm
    _ ≤ Real.sqrt (3 / 2 * K ^ 2) := Real.sqrt_le_sqrt hS2

/-! ## The four projective pattern vectors -/

/-- `tv u a b = u₀ + a u₁ + b u₂`. -/
def tv (u : Fin 3 → V) (a b : ℝ) : V := u 0 + a • u 1 + b • u 2

theorem tv_11 (u : Fin 3 → V) : tv u 1 1 = u 0 + u 1 + u 2 := by
  simp only [tv, one_smul]

theorem tv_1m (u : Fin 3 → V) : tv u 1 (-1) = u 0 + u 1 - u 2 := by
  simp only [tv, one_smul, neg_smul]; abel

theorem tv_m1 (u : Fin 3 → V) : tv u (-1) 1 = u 0 - u 1 + u 2 := by
  simp only [tv, one_smul, neg_smul]; abel

theorem tv_mm (u : Fin 3 → V) : tv u (-1) (-1) = u 0 - u 1 - u 2 := by
  simp only [tv, one_smul, neg_smul]; abel

/-- **Parseval.** The four patterns have squared norms summing to `12`. -/
theorem tv_parseval (u : Fin 3 → V) (hu : ∀ i, ‖u i‖ = 1) :
    ‖tv u 1 1‖ ^ 2 + ‖tv u 1 (-1)‖ ^ 2 + ‖tv u (-1) 1‖ ^ 2
      + ‖tv u (-1) (-1)‖ ^ 2 = 12 := by
  rw [tv_11, tv_1m, tv_m1, tv_mm]
  have h1 := parallelogram_law_with_norm ℝ (u 0 + u 1) (u 2)
  have h2 := parallelogram_law_with_norm ℝ (u 0 - u 1) (u 2)
  have h3 := parallelogram_law_with_norm ℝ (u 0) (u 1)
  rw [hu 2] at h1 h2
  rw [hu 0, hu 1] at h3
  nlinarith [h1, h2, h3]

/-- Walsh decomposition: a pattern with `±1` coefficients equals exactly one of
the four basic patterns, selected by the indicator products. -/
theorem four_decomp (u : Fin 3 → V) {x y : ℝ}
    (hx : x = 1 ∨ x = -1) (hy : y = 1 ∨ y = -1) :
    ‖tv u x y‖ =
      ((1 + 1 * x) / 2) * ((1 + 1 * y) / 2) * ‖tv u 1 1‖
      + ((1 + 1 * x) / 2) * ((1 + (-1) * y) / 2) * ‖tv u 1 (-1)‖
      + ((1 + (-1) * x) / 2) * ((1 + 1 * y) / 2) * ‖tv u (-1) 1‖
      + ((1 + (-1) * x) / 2) * ((1 + (-1) * y) / 2) * ‖tv u (-1) (-1)‖ := by
  rcases hx with rfl | rfl <;> rcases hy with rfl | rfl <;> norm_num

/-! ## Three-row sign matrices -/

section ThreeRows

variable (A : SignMat 3 n)

/-- Normalised correlation of rows `0,1` in column `j`. -/
def r1 (j : Fin n) : ℝ := coeff (A 0 j) * coeff (A 1 j)

/-- Normalised correlation of rows `0,2` in column `j`. -/
def r2 (j : Fin n) : ℝ := coeff (A 0 j) * coeff (A 2 j)

/-- Walsh indicator: `1` iff column `j` has projective type `(1,a,b)`, else `0`. -/
noncomputable def ind (a b : ℝ) (j : Fin n) : ℝ := ((1 + a * r1 A j) / 2) * ((1 + b * r2 A j) / 2)

/-- Real multiplicity of the projective column type `(1,a,b)`. -/
noncomputable def wt (a b : ℝ) : ℝ := ∑ j, ind A a b j

theorem r1_cases (j : Fin n) : r1 A j = 1 ∨ r1 A j = -1 := by
  unfold r1; exact pm_mul (coeff_cases _) (coeff_cases _)

theorem r2_cases (j : Fin n) : r2 A j = 1 ∨ r2 A j = -1 := by
  unfold r2; exact pm_mul (coeff_cases _) (coeff_cases _)

theorem ind_nonneg {a b : ℝ} (ha : a = 1 ∨ a = -1) (hb : b = 1 ∨ b = -1) (j : Fin n) :
    0 ≤ ind A a b j := by
  unfold ind
  exact mul_nonneg (half_nonneg_of_pm (pm_mul ha (r1_cases A j)))
    (half_nonneg_of_pm (pm_mul hb (r2_cases A j)))

theorem wt_nonneg {a b : ℝ} (ha : a = 1 ∨ a = -1) (hb : b = 1 ∨ b = -1) :
    0 ≤ wt A a b := by
  unfold wt
  exact Finset.sum_nonneg fun j _ => ind_nonneg A ha hb j

/-- The four real multiplicities sum to the number of columns. -/
theorem wt_sum :
    wt A 1 1 + wt A 1 (-1) + wt A (-1) 1 + wt A (-1) (-1) = (n : ℝ) := by
  unfold wt
  rw [← Finset.sum_add_distrib, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  have h : ∀ j, ind A 1 1 j + ind A 1 (-1) j + ind A (-1) 1 j
      + ind A (-1) (-1) j = 1 := by
    intro j; unfold ind; ring
  simp [h]

/-- Column normalisation by the first-row sign. -/
theorem col_vec_eq (u : Fin 3 → V) (j : Fin n) :
    ∑ i, coeff (A i j) • u i = coeff (A 0 j) • tv u (r1 A j) (r2 A j) := by
  have h1 : coeff (A 0 j) * r1 A j = coeff (A 1 j) := by
    unfold r1; rw [← mul_assoc, coeff_mul_self, one_mul]
  have h2 : coeff (A 0 j) * r2 A j = coeff (A 2 j) := by
    unfold r2; rw [← mul_assoc, coeff_mul_self, one_mul]
  simp only [tv, Fin.sum_univ_three, smul_add, smul_smul, h1, h2]

theorem col_decomp (u : Fin 3 → V) (j : Fin n) :
    ‖∑ i, coeff (A i j) • u i‖ =
      ind A 1 1 j * ‖tv u 1 1‖ + ind A 1 (-1) j * ‖tv u 1 (-1)‖
      + ind A (-1) 1 j * ‖tv u (-1) 1‖ + ind A (-1) (-1) j * ‖tv u (-1) (-1)‖ := by
  rw [col_vec_eq A u j, norm_smul, norm_coeff, one_mul]
  unfold ind
  exact four_decomp u (r1_cases A j) (r2_cases A j)

theorem sum_col_decomp (u : Fin 3 → V) :
    ∑ j, ‖∑ i, coeff (A i j) • u i‖ =
      wt A 1 1 * ‖tv u 1 1‖ + wt A 1 (-1) * ‖tv u 1 (-1)‖
      + wt A (-1) 1 * ‖tv u (-1) 1‖ + wt A (-1) (-1) * ‖tv u (-1) (-1)‖ := by
  simp only [col_decomp A u, Finset.sum_add_distrib, wt, Finset.sum_mul]

theorem objective_eq_sum_col (u : Fin 3 → V) (v : Fin n → V) :
    objective A u v = ∑ j, ⟪∑ i, coeff (A i j) • u i, v j⟫_ℝ := by
  unfold objective
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro j _
  rw [Fin.sum_univ_three, Fin.sum_univ_three]
  simp only [inner_add_left, real_inner_smul_left]

theorem objective_le_sum_norm (u : Fin 3 → V) (v : Fin n → V)
    (hv : ∀ j, ‖v j‖ = 1) :
    objective A u v ≤ ∑ j, ‖∑ i, coeff (A i j) • u i‖ := by
  rw [objective_eq_sum_col A u v]
  apply Finset.sum_le_sum
  intro j _
  have h := real_inner_le_norm (∑ i, coeff (A i j) • u i) (v j)
  rw [hv j, mul_one] at h
  exact h

/-- One scalar column term for the row-sign vector `(1,a,b)`. -/
theorem col_abs (s : Fin 3 → Sign) (a b : ℝ) (hs0 : s 0 = 1)
    (ha : coeff (s 1) = a) (hb : coeff (s 2) = b) (j : Fin n) :
    |∑ i, coeff (A i j) * coeff (s i)| = |1 + a * r1 A j + b * r2 A j| := by
  have hinner : ∑ i, coeff (A i j) * coeff (s i)
      = coeff (A 0 j) * (1 + a * r1 A j + b * r2 A j) := by
    rw [Fin.sum_univ_three, hs0, coeff_one, ha, hb]
    unfold r1 r2
    have h00 := coeff_mul_self (A 0 j)
    linear_combination (-(coeff (A 1 j) * a + coeff (A 2 j) * b)) * h00
  rw [hinner, abs_mul, abs_coeff, one_mul]

/-- The scalar value of the row-sign vector `(1,a,b)` is `n + 2·wt a b`. -/
theorem absScore_eq (s : Fin 3 → Sign) (a b : ℝ) (hs0 : s 0 = 1)
    (ha : coeff (s 1) = a) (hb : coeff (s 2) = b)
    (ha' : a = 1 ∨ a = -1) (hb' : b = 1 ∨ b = -1) :
    absScore A s = (n : ℝ) + 2 * wt A a b := by
  unfold absScore wt
  rw [Finset.mul_sum]
  have hn : (n : ℝ) = ∑ _j : Fin n, (1 : ℝ) := by simp
  rw [hn, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro j _
  rw [col_abs A s a b hs0 ha hb j]
  unfold ind
  exact abs_three (pm_mul ha' (r1_cases A j)) (pm_mul hb' (r2_cases A j))

/-- Lower anchor from the row-sign vector `(1,a,b)`. -/
theorem anchor_ab (s : Fin 3 → Sign) (a b : ℝ) (hs0 : s 0 = 1)
    (ha : coeff (s 1) = a) (hb : coeff (s 2) = b)
    (ha' : a = 1 ∨ a = -1) (hb' : b = 1 ∨ b = -1) :
    (n : ℝ) + 2 * wt A a b ≤ C A := by
  rw [← absScore_eq A s a b hs0 ha hb ha' hb']
  exact absScore_le_C A s

theorem anchor11 : (n : ℝ) + 2 * wt A 1 1 ≤ C A :=
  anchor_ab A ![1, 1, 1] 1 1 (by simp) (by simp [coeff]) (by simp [coeff])
    (Or.inl rfl) (Or.inl rfl)

theorem anchor1m : (n : ℝ) + 2 * wt A 1 (-1) ≤ C A :=
  anchor_ab A ![1, 1, -1] 1 (-1) (by simp) (by simp [coeff]) (by simp [coeff])
    (Or.inl rfl) (Or.inr rfl)

theorem anchorm1 : (n : ℝ) + 2 * wt A (-1) 1 ≤ C A :=
  anchor_ab A ![1, -1, 1] (-1) 1 (by simp) (by simp [coeff]) (by simp [coeff])
    (Or.inr rfl) (Or.inl rfl)

theorem anchormm : (n : ℝ) + 2 * wt A (-1) (-1) ≤ C A :=
  anchor_ab A ![1, -1, -1] (-1) (-1) (by simp) (by simp [coeff]) (by simp [coeff])
    (Or.inr rfl) (Or.inr rfl)

theorem C_nonneg : 0 ≤ C A := by
  have h := anchor11 A
  have hw := wt_nonneg A (a := 1) (b := 1) (Or.inl rfl) (Or.inl rfl)
  have hn : (0 : ℝ) ≤ n := Nat.cast_nonneg n
  linarith

/-- Pointwise semantic bound for every pair of unit-vector families. -/
theorem objective_le_sqrt_three_halves_mul_C (u : Fin 3 → V) (v : Fin n → V)
    (hu : ∀ i, ‖u i‖ = 1) (hv : ∀ j, ‖v j‖ = 1) :
    objective A u v ≤ Real.sqrt (3 / 2) * C A := by
  have hle := objective_le_sum_norm A u v hv
  rw [sum_col_decomp A u] at hle
  refine hle.trans ?_
  exact agg4 (wt A 1 1) (wt A 1 (-1)) (wt A (-1) 1) (wt A (-1) (-1))
    ‖tv u 1 1‖ ‖tv u 1 (-1)‖ ‖tv u (-1) 1‖ ‖tv u (-1) (-1)‖ (n : ℝ) (C A)
    (wt_nonneg A (a := 1) (b := 1) (Or.inl rfl) (Or.inl rfl))
    (wt_nonneg A (a := 1) (b := -1) (Or.inl rfl) (Or.inr rfl))
    (wt_nonneg A (a := -1) (b := 1) (Or.inr rfl) (Or.inl rfl))
    (wt_nonneg A (a := -1) (b := -1) (Or.inr rfl) (Or.inr rfl))
    (norm_nonneg _) (norm_nonneg _) (norm_nonneg _) (norm_nonneg _)
    (wt_sum A) (tv_parseval u hu)
    (anchor11 A) (anchor1m A) (anchorm1 A) (anchormm A)

/-- **Every `3 × n` sign matrix obeys the semantic `√(3/2)` bound**, in every
real inner-product space (the empty feasible set is handled explicitly). -/
theorem row3_Q_le_sqrt_three_halves_mul_C :
    Q (V := V) A ≤ Real.sqrt (3 / 2) * C A := by
  let S : Set ℝ := {z : ℝ | ∃ (u : Fin 3 → V) (v : Fin n → V),
    (∀ i, ‖u i‖ = 1) ∧ (∀ j, ‖v j‖ = 1) ∧ z = objective A u v}
  by_cases hS : S.Nonempty
  · unfold Q
    apply csSup_le hS
    rintro z ⟨u, v, hu, hv, rfl⟩
    exact objective_le_sqrt_three_halves_mul_C A u v hu hv
  · have hEmpty : S = ∅ := Set.not_nonempty_iff_eq_empty.mp hS
    have hC : 0 ≤ C A := C_nonneg A
    unfold Q
    change sSup S ≤ Real.sqrt (3 / 2) * C A
    rw [hEmpty, Real.sSup_empty]
    exact mul_nonneg (Real.sqrt_nonneg _) hC

/-- Consequently every `3 × n` sign matrix obeys the project's `√2` bound. -/
theorem row3_Q_le_sqrt_two_mul_C : Q (V := V) A ≤ Real.sqrt 2 * C A := by
  have h32 : Real.sqrt (3 / 2) ≤ Real.sqrt 2 := Real.sqrt_le_sqrt (by norm_num)
  calc Q (V := V) A ≤ Real.sqrt (3 / 2) * C A := row3_Q_le_sqrt_three_halves_mul_C A
    _ ≤ Real.sqrt 2 * C A := mul_le_mul_of_nonneg_right h32 (C_nonneg A)

end ThreeRows

end GrothSymmetry
