import Kernel
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace BB6Kernel
theorem segment64 : run 3 ⟨3, 0, 51603745800191⟩ = some ⟨1, 1, 103207491600383⟩ := by rfl
theorem segment65 : run 21 ⟨1, 1, 103207491600383⟩ = some ⟨1, 4194303, 49213166⟩ := run_B_fast 21 1 49213166
theorem segment66 : run 1 ⟨1, 4194303, 49213166⟩ = some ⟨3, 8388607, 24606583⟩ := by rfl
theorem segment67 : run 23 ⟨3, 8388607, 24606583⟩ = some ⟨3, 0, 206414987395071⟩ := run_D_fast 23 0 12303291
theorem segment68 : run 3 ⟨3, 0, 206414987395071⟩ = some ⟨1, 1, 412829974790143⟩ := by rfl
theorem segment69 : run 27 ⟨1, 1, 412829974790143⟩ = some ⟨1, 268435455, 3075822⟩ := run_B_fast 27 1 3075822
theorem segment70 : run 1 ⟨1, 268435455, 3075822⟩ = some ⟨3, 536870911, 1537911⟩ := by rfl
theorem segment71 : run 29 ⟨3, 536870911, 1537911⟩ = some ⟨3, 0, 825660218015743⟩ := run_D_fast 29 0 768955
theorem segment72 : run 3 ⟨3, 0, 825660218015743⟩ = some ⟨1, 1, 1651320436031487⟩ := by rfl
theorem segment73 : run 33 ⟨1, 1, 1651320436031487⟩ = some ⟨1, 17179869183, 192238⟩ := run_B_fast 33 1 192238
theorem segment74 : run 1 ⟨1, 17179869183, 192238⟩ = some ⟨3, 34359738367, 96119⟩ := by rfl
theorem segment75 : run 35 ⟨3, 34359738367, 96119⟩ = some ⟨3, 0, 3302658051932159⟩ := run_D_fast 35 0 48059
theorem segment76 : run 3 ⟨3, 0, 3302658051932159⟩ = some ⟨1, 1, 6605316103864319⟩ := by rfl
theorem segment77 : run 39 ⟨1, 1, 6605316103864319⟩ = some ⟨1, 1099511627775, 12014⟩ := run_B_fast 39 1 12014
theorem segment78 : run 1 ⟨1, 1099511627775, 12014⟩ = some ⟨3, 2199023255551, 6007⟩ := by rfl
theorem segment79 : run 41 ⟨3, 2199023255551, 6007⟩ = some ⟨3, 0, 13211731719356415⟩ := run_D_fast 41 0 3003
theorem segment80 : run 3 ⟨3, 0, 13211731719356415⟩ = some ⟨1, 1, 26423463438712831⟩ := by rfl
theorem segment81 : run 45 ⟨1, 1, 26423463438712831⟩ = some ⟨1, 70368744177663, 750⟩ := run_B_fast 45 1 750
theorem segment82 : run 1 ⟨1, 70368744177663, 750⟩ = some ⟨3, 140737488355327, 375⟩ := by rfl
theorem segment83 : run 47 ⟨3, 140737488355327, 375⟩ = some ⟨3, 0, 52917295621603327⟩ := run_D_fast 47 0 187
theorem segment84 : run 3 ⟨3, 0, 52917295621603327⟩ = some ⟨1, 1, 105834591243206655⟩ := by rfl
theorem segment85 : run 51 ⟨1, 1, 105834591243206655⟩ = some ⟨1, 4503599627370495, 46⟩ := run_B_fast 51 1 46
theorem segment86 : run 1 ⟨1, 4503599627370495, 46⟩ = some ⟨3, 9007199254740991, 23⟩ := by rfl
theorem segment87 : run 53 ⟨3, 9007199254740991, 23⟩ = some ⟨3, 0, 216172782113783807⟩ := run_D_fast 53 0 11
theorem segment88 : run 3 ⟨3, 0, 216172782113783807⟩ = some ⟨1, 1, 432345564227567615⟩ := by rfl
theorem segment89 : run 57 ⟨1, 1, 432345564227567615⟩ = some ⟨1, 288230376151711743, 2⟩ := run_B_fast 57 1 2
theorem segment90 : run 1 ⟨1, 288230376151711743, 2⟩ = some ⟨3, 576460752303423487, 1⟩ := by rfl
theorem segment91 : run 59 ⟨3, 576460752303423487, 1⟩ = some ⟨3, 0, 1152921504606846975⟩ := run_D_fast 59 0 0
theorem segment92 : run 3 ⟨3, 0, 1152921504606846975⟩ = some ⟨1, 1, 2305843009213693951⟩ := by rfl
theorem segment93 : run 61 ⟨1, 1, 2305843009213693951⟩ = some ⟨1, 4611686018427387903, 0⟩ := run_B_fast 61 1 0
theorem segment94 : run 105 ⟨1, 4611686018427387903, 0⟩ = some ⟨3, 3, 108220898565762702813⟩ := by rfl
theorem segment95 : run 2 ⟨3, 3, 108220898565762702813⟩ = some ⟨3, 0, 432883594263050811255⟩ := run_D_fast 2 0 54110449282881351406
theorem chunk2 : run 759 ⟨3, 0, 51603745800191⟩ = some ⟨3, 0, 432883594263050811255⟩ := (join (join (join (join (join segment64 segment65) (join segment66 segment67)) (join (join segment68 segment69) (join segment70 segment71))) (join (join (join segment72 segment73) (join segment74 segment75)) (join (join segment76 segment77) (join segment78 segment79)))) (join (join (join (join segment80 segment81) (join segment82 segment83)) (join (join segment84 segment85) (join segment86 segment87))) (join (join (join segment88 segment89) (join segment90 segment91)) (join (join segment92 segment93) (join segment94 segment95)))))
end BB6Kernel
