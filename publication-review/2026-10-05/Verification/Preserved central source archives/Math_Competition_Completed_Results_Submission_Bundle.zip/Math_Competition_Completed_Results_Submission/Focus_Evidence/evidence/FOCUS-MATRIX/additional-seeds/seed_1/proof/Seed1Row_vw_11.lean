import Seed1KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed1
open Matrix
theorem row_vw_11 : (L_vw * M_vw) (11 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 11 := by decide
#print axioms row_vw_11
end RecoveredMMTKernelSeed1
