# BB6 finite halting witness: new standard-kernel certificate

**Verified 2 October 2026.** This is a new, separately labelled certificate for an existing supplied machine. Original sources and reports were not edited. The certificate does not establish mathematical novelty, event eligibility, a new Busy Beaver frontier, or acceptance by a verification chair.

## Exact result

For the supplied six-state, two-symbol table

`1RB0LC_1RD1RB_0LH1LE_1LA1LD_0LA1LF_0LE0RD`

starting in state A on the all-zero bi-infinite tape:

- The run reaches H after exactly **1,235,211 transitions**.
- Its final tape contains exactly **1,519 ones**.
- No shorter successful prefix is in H.
- Every state A–F is visited by step **40**.

`Claims.lean` contains the final theorems `BB6Kernel.exact_halting_witness` and `BB6Kernel.visits_all_six_states`. `Claims.log` records a successful check and the printed axiom sets. `final-certificate-receipt.json` summarizes all 129 checked source modules; `source-manifest.json` identifies their exact contents. The final axiom sets are **[propext, Quot.sound]**. There is no `sorry`, custom axiom, `native_decide`, or native-evaluation trust extension in these sources.

## Semantics and exact step convention

`Kernel.lean` numbers A–F as 0–5 and H as 6. A configuration contains two nonnegative integers. The right integer's least-significant bit is the current cell, followed by the cells to its right; the left integer's least-significant bit is the immediate left neighbor, followed by farther-left cells. Missing high bits are zero. Together these encode a finite-support binary tape relative to its head. `blank` is state A with both integers zero.

All twelve transition branches are spelled out in `step`. `machine.json` is a byte-preserving copy of the supplied table. `independent-audit.json` records its SHA-256 and a programmatic equality check between its twelve branches and the Lean definition. The representation is not a surrogate machine: seven theorems in `Semantics.lean` give the exact cell equations for writing and moving left/right, including preservation of every farther cell.

`run n` executes exactly n transitions and returns `none` if it tries to execute from an already halted state. A transition into H is executed and counted. Thus the final C/0 → 0,L,H transition is included in 1,235,211. The theorem `no_earlier_halt` derives the absence of an earlier halted prefix from the successful exact run; this is not a larger fuel-bound claim.

`ones` is a well-founded binary population count over the entire natural-number half-tape, not a truncated count. The proof relates it to a structurally recursive finite count and proves the stripped remainder is zero. The numeral 2028 used in that counting proof is a sufficient bit-count bound, not a formal visited-span theorem.

Absolute head position −2001 and visited span 2028 are confirmed separately by the exact set-tape Python replay in `independent-audit.json`. **They are not claimed as Lean-certified properties.**

## Proof construction and trust

The certificate uses 3,949 segments in 124 chunk modules. Ordinary short segments are checked by kernel definitional reduction (`rfl`). Two inductively proved macro lemmas cover consecutive-one traversals in states B and D. Every concrete macro application and every join is checked by Lean. A generator supplies numerical endpoints, but incorrect endpoints or counts cannot satisfy the checked propositions; the generator and Python simulation are not trusted proof oracles.

The successful chain was checked with Lean **4.33.1**, commit **819816b2e0a3bf405af45ae5c7af2491d8f5bee6**, using only Lean's bundled `Init` and `Lean.Elab.Tactic.Omega` imports. Mathlib is not required. All final proof terms are accepted by the standard kernel under the two ordinary axioms above.

The initial 256-segment partition exceeded the configured Lean memory limit. The successful build used 32-segment partitions. A checked-count composition lemma prevents unnecessary full-run normalization in the later chunks and final assembly. Earlier successfully checked modules were preserved rather than rerun for speculative optimization. Source/log receipts record the completed chain and final rechecks. Failed exploratory files are not included in the source archive.

Maximum observed RSS among the successful module checks was 1,222,644 KiB. The final Claims check took about 1.1 seconds, after its dependencies were checked. This is not the time for rebuilding the entire proof.

## Reproduce from the source archive

Install the exact Lean release above. Extract the archive and run:

```sh
python3 reproduce.py --lean /absolute/path/to/lean
```

The script verifies source hashes and compiles all 129 modules in dependency order into a separate `reproduction/` directory. It uses one Lean thread, a 1536 MiB Lean allocation cap, a 2 GiB observed-RSS cap, and a 180-second cap for each module. Rebuilding the entire preserved source set can take several minutes; the early modules retain the less efficient checked composition.

Inspect `reproduction/Claims.log` for all four axiom reports and `reproduction/receipt.json` for per-module exit codes. Merely importing a prebuilt `.olean` is not offered as a substitute for this source rebuild. The source archive does not include prebuilt `.olean` files.

The original build's `build-receipt.json` plus `final-check-receipt.json` establish the performed checks. Final rechecks cover semantic/count proofs, composition helper, the affected boundary chunks, certificate assembly, and final claims. `final-certificate-receipt.json` reconciles those records against the delivered source manifest.

## Scope for M1 review

This closes the previously missing formal finite-execution/ones certificate for the supplied machine and adds a formal all-six-states witness. It does not show that this exact machine/result was new, establish its discovery date, authenticate a missing organizer receipt, recover the search-family exhaustion proof, prove an improved S(6) lower-bound frontier, or determine M1 credit. Those remain separate review questions.
