import Seed1Row_uv_00
import Seed1Row_uv_01
import Seed1Row_uv_02
import Seed1Row_uv_03
import Seed1Row_uv_04
import Seed1Row_uv_05
import Seed1Row_uv_06
import Seed1Row_uv_07
import Seed1Row_uv_08
import Seed1Row_uv_09
import Seed1Row_uv_10
import Seed1Row_uv_11
import Seed1Row_uv_12
import Seed1Row_uv_13
import Seed1Row_uv_14
import Seed1Row_uv_15
import Seed1Row_uv_16
import Seed1Row_uv_17
import Seed1Row_uv_18
import Seed1Row_uv_19
import Seed1Row_uv_20
import Seed1Row_uv_21
import Seed1Row_uv_22
import Seed1Row_uw_00
import Seed1Row_uw_01
import Seed1Row_uw_02
import Seed1Row_uw_03
import Seed1Row_uw_04
import Seed1Row_uw_05
import Seed1Row_uw_06
import Seed1Row_uw_07
import Seed1Row_uw_08
import Seed1Row_uw_09
import Seed1Row_uw_10
import Seed1Row_uw_11
import Seed1Row_uw_12
import Seed1Row_uw_13
import Seed1Row_uw_14
import Seed1Row_uw_15
import Seed1Row_uw_16
import Seed1Row_uw_17
import Seed1Row_uw_18
import Seed1Row_uw_19
import Seed1Row_uw_20
import Seed1Row_uw_21
import Seed1Row_uw_22
import Seed1Row_vw_00
import Seed1Row_vw_01
import Seed1Row_vw_02
import Seed1Row_vw_03
import Seed1Row_vw_04
import Seed1Row_vw_05
import Seed1Row_vw_06
import Seed1Row_vw_07
import Seed1Row_vw_08
import Seed1Row_vw_09
import Seed1Row_vw_10
import Seed1Row_vw_11
import Seed1Row_vw_12
import Seed1Row_vw_13
import Seed1Row_vw_14
import Seed1Row_vw_15
import Seed1Row_vw_16
import Seed1Row_vw_17
import Seed1Row_vw_18
import Seed1Row_vw_19
import Seed1Row_vw_20
import Seed1Row_vw_21
import Seed1Row_vw_22
import Mathlib.Tactic.FinCases
namespace RecoveredMMTKernelSeed1
open Matrix
theorem left_inverse_uv : L_uv * M_uv = 1 := by
  funext i
  fin_cases i
  · exact row_uv_0
  · exact row_uv_1
  · exact row_uv_2
  · exact row_uv_3
  · exact row_uv_4
  · exact row_uv_5
  · exact row_uv_6
  · exact row_uv_7
  · exact row_uv_8
  · exact row_uv_9
  · exact row_uv_10
  · exact row_uv_11
  · exact row_uv_12
  · exact row_uv_13
  · exact row_uv_14
  · exact row_uv_15
  · exact row_uv_16
  · exact row_uv_17
  · exact row_uv_18
  · exact row_uv_19
  · exact row_uv_20
  · exact row_uv_21
  · exact row_uv_22
theorem rational_left_inverse_uv :
    (L_uv.map (Int.castRingHom ℚ)) * (M_uv.map (Int.castRingHom ℚ)) = 1 := by
  rw [← Matrix.map_mul, left_inverse_uv]
  exact Matrix.map_one _ (map_zero _) (map_one _)
theorem rational_injective_uv : Function.Injective ((B_uv.map (Int.castRingHom ℚ)).mulVec) := by
  intro x y h
  have hm : (M_uv.map (Int.castRingHom ℚ)).mulVec x = (M_uv.map (Int.castRingHom ℚ)).mulVec y := by
    funext i
    exact congrFun h (piv_uv i)
  have hh := congrArg ((L_uv.map (Int.castRingHom ℚ)).mulVec) hm
  simpa only [Matrix.mulVec_mulVec, rational_left_inverse_uv, Matrix.one_mulVec] using hh
#print axioms left_inverse_uv
#print axioms rational_injective_uv
theorem left_inverse_uw : L_uw * M_uw = 1 := by
  funext i
  fin_cases i
  · exact row_uw_0
  · exact row_uw_1
  · exact row_uw_2
  · exact row_uw_3
  · exact row_uw_4
  · exact row_uw_5
  · exact row_uw_6
  · exact row_uw_7
  · exact row_uw_8
  · exact row_uw_9
  · exact row_uw_10
  · exact row_uw_11
  · exact row_uw_12
  · exact row_uw_13
  · exact row_uw_14
  · exact row_uw_15
  · exact row_uw_16
  · exact row_uw_17
  · exact row_uw_18
  · exact row_uw_19
  · exact row_uw_20
  · exact row_uw_21
  · exact row_uw_22
theorem rational_left_inverse_uw :
    (L_uw.map (Int.castRingHom ℚ)) * (M_uw.map (Int.castRingHom ℚ)) = 1 := by
  rw [← Matrix.map_mul, left_inverse_uw]
  exact Matrix.map_one _ (map_zero _) (map_one _)
theorem rational_injective_uw : Function.Injective ((B_uw.map (Int.castRingHom ℚ)).mulVec) := by
  intro x y h
  have hm : (M_uw.map (Int.castRingHom ℚ)).mulVec x = (M_uw.map (Int.castRingHom ℚ)).mulVec y := by
    funext i
    exact congrFun h (piv_uw i)
  have hh := congrArg ((L_uw.map (Int.castRingHom ℚ)).mulVec) hm
  simpa only [Matrix.mulVec_mulVec, rational_left_inverse_uw, Matrix.one_mulVec] using hh
#print axioms left_inverse_uw
#print axioms rational_injective_uw
theorem left_inverse_vw : L_vw * M_vw = 1 := by
  funext i
  fin_cases i
  · exact row_vw_0
  · exact row_vw_1
  · exact row_vw_2
  · exact row_vw_3
  · exact row_vw_4
  · exact row_vw_5
  · exact row_vw_6
  · exact row_vw_7
  · exact row_vw_8
  · exact row_vw_9
  · exact row_vw_10
  · exact row_vw_11
  · exact row_vw_12
  · exact row_vw_13
  · exact row_vw_14
  · exact row_vw_15
  · exact row_vw_16
  · exact row_vw_17
  · exact row_vw_18
  · exact row_vw_19
  · exact row_vw_20
  · exact row_vw_21
  · exact row_vw_22
theorem rational_left_inverse_vw :
    (L_vw.map (Int.castRingHom ℚ)) * (M_vw.map (Int.castRingHom ℚ)) = 1 := by
  rw [← Matrix.map_mul, left_inverse_vw]
  exact Matrix.map_one _ (map_zero _) (map_one _)
theorem rational_injective_vw : Function.Injective ((B_vw.map (Int.castRingHom ℚ)).mulVec) := by
  intro x y h
  have hm : (M_vw.map (Int.castRingHom ℚ)).mulVec x = (M_vw.map (Int.castRingHom ℚ)).mulVec y := by
    funext i
    exact congrFun h (piv_vw i)
  have hh := congrArg ((L_vw.map (Int.castRingHom ℚ)).mulVec) hm
  simpa only [Matrix.mulVec_mulVec, rational_left_inverse_vw, Matrix.one_mulVec] using hh
#print axioms left_inverse_vw
#print axioms rational_injective_vw

/-- Fixing these two original legs uniquely determines every column of the third. -/
theorem remaining_factor_unique_uv {p : Type*}
    (X Y : Matrix (Fin 23) p ℚ)
    (h : (B_uv.map (Int.castRingHom ℚ)) * X = (B_uv.map (Int.castRingHom ℚ)) * Y) : X = Y := by
  funext i j
  have hc : (B_uv.map (Int.castRingHom ℚ)).mulVec (fun t => X t j) =
      (B_uv.map (Int.castRingHom ℚ)).mulVec (fun t => Y t j) := by
    funext k
    exact congrFun (congrFun h k) j
  exact congrFun (rational_injective_uv hc) i
#print axioms remaining_factor_unique_uv

/-- Fixing these two original legs uniquely determines every column of the third. -/
theorem remaining_factor_unique_uw {p : Type*}
    (X Y : Matrix (Fin 23) p ℚ)
    (h : (B_uw.map (Int.castRingHom ℚ)) * X = (B_uw.map (Int.castRingHom ℚ)) * Y) : X = Y := by
  funext i j
  have hc : (B_uw.map (Int.castRingHom ℚ)).mulVec (fun t => X t j) =
      (B_uw.map (Int.castRingHom ℚ)).mulVec (fun t => Y t j) := by
    funext k
    exact congrFun (congrFun h k) j
  exact congrFun (rational_injective_uw hc) i
#print axioms remaining_factor_unique_uw

/-- Fixing these two original legs uniquely determines every column of the third. -/
theorem remaining_factor_unique_vw {p : Type*}
    (X Y : Matrix (Fin 23) p ℚ)
    (h : (B_vw.map (Int.castRingHom ℚ)) * X = (B_vw.map (Int.castRingHom ℚ)) * Y) : X = Y := by
  funext i j
  have hc : (B_vw.map (Int.castRingHom ℚ)).mulVec (fun t => X t j) =
      (B_vw.map (Int.castRingHom ℚ)).mulVec (fun t => Y t j) := by
    funext k
    exact congrFun (congrFun h k) j
  exact congrFun (rational_injective_vw hc) i
#print axioms remaining_factor_unique_vw

end RecoveredMMTKernelSeed1
