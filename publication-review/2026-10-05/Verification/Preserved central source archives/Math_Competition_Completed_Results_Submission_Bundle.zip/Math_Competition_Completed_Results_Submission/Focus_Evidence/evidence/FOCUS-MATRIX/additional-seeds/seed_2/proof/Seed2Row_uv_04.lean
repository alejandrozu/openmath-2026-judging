import Seed2KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed2
open Matrix
theorem row_uv_4 : (L_uv * M_uv) (4 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 4 := by decide
#print axioms row_uv_4
end RecoveredMMTKernelSeed2
