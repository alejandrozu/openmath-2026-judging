# Verbatim dictionary-simulator excerpt; OFF and out are supplied by the original audit.
bb=[]
for p in sorted((OFF/'busy-beaver-6-certificates').rglob('*.json')):
    d=json.loads(p.read_text())
    if set(d)!={'transitions'}: continue
    tr=d['transitions'];assert set(tr)==set('ABCDEF')
    for k in tr:
        assert set(tr[k])=={'0','1'}
        assert all(w in [0,1] and m in ['L','R'] and s in 'ABCDEFH' for w,m,s in tr[k].values())
    tape={};state='A';head=lo=hi=0;seen=set()
    for steps in range(1,2000001):
        seen.add(state);w,move,state=tr[state][str(tape.get(head,0))]
        tape[head]=w;head+=1 if move=='R' else -1;lo=min(lo,head);hi=max(hi,head)
        if state=='H': break
    bb.append({'file':str(p.relative_to(ROOT)),'halted':state=='H','steps':steps,'ones':sum(tape.values()),'tape_span':hi-lo+1,'all_six_states':seen==set('ABCDEF')})
out['busy_beaver']=bb
