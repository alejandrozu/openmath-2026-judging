import Kernel
set_option maxRecDepth 200000
set_option maxHeartbeats 0
namespace BB6Kernel
theorem segment32 : run 1 ⟨1, 2047, 192238⟩ = some ⟨3, 4095, 96119⟩ := by rfl
theorem segment33 : run 12 ⟨3, 4095, 96119⟩ = some ⟨3, 0, 393707519⟩ := run_D_fast 12 0 48059
theorem segment34 : run 3 ⟨3, 0, 393707519⟩ = some ⟨1, 1, 787415039⟩ := by rfl
theorem segment35 : run 16 ⟨1, 1, 787415039⟩ = some ⟨1, 131071, 12014⟩ := run_B_fast 16 1 12014
theorem segment36 : run 1 ⟨1, 131071, 12014⟩ = some ⟨3, 262143, 6007⟩ := by rfl
theorem segment37 : run 18 ⟨3, 262143, 6007⟩ = some ⟨3, 0, 1574961151⟩ := run_D_fast 18 0 3003
theorem segment38 : run 3 ⟨3, 0, 1574961151⟩ = some ⟨1, 1, 3149922303⟩ := by rfl
theorem segment39 : run 22 ⟨1, 1, 3149922303⟩ = some ⟨1, 8388607, 750⟩ := run_B_fast 22 1 750
theorem segment40 : run 1 ⟨1, 8388607, 750⟩ = some ⟨3, 16777215, 375⟩ := by rfl
theorem segment41 : run 24 ⟨3, 16777215, 375⟩ = some ⟨3, 0, 6308233215⟩ := run_D_fast 24 0 187
theorem segment42 : run 3 ⟨3, 0, 6308233215⟩ = some ⟨1, 1, 12616466431⟩ := by rfl
theorem segment43 : run 28 ⟨1, 1, 12616466431⟩ = some ⟨1, 536870911, 46⟩ := run_B_fast 28 1 46
theorem segment44 : run 1 ⟨1, 536870911, 46⟩ = some ⟨3, 1073741823, 23⟩ := by rfl
theorem segment45 : run 30 ⟨3, 1073741823, 23⟩ = some ⟨3, 0, 25769803775⟩ := run_D_fast 30 0 11
theorem segment46 : run 3 ⟨3, 0, 25769803775⟩ = some ⟨1, 1, 51539607551⟩ := by rfl
theorem segment47 : run 34 ⟨1, 1, 51539607551⟩ = some ⟨1, 34359738367, 2⟩ := run_B_fast 34 1 2
theorem segment48 : run 1 ⟨1, 34359738367, 2⟩ = some ⟨3, 68719476735, 1⟩ := by rfl
theorem segment49 : run 36 ⟨3, 68719476735, 1⟩ = some ⟨3, 0, 137438953471⟩ := run_D_fast 36 0 0
theorem segment50 : run 3 ⟨3, 0, 137438953471⟩ = some ⟨1, 1, 274877906943⟩ := by rfl
theorem segment51 : run 38 ⟨1, 1, 274877906943⟩ = some ⟨1, 549755813887, 0⟩ := run_B_fast 38 1 0
theorem segment52 : run 63 ⟨1, 549755813887, 0⟩ = some ⟨1, 1, 1612617054071⟩ := by rfl
theorem segment53 : run 3 ⟨1, 1, 1612617054071⟩ = some ⟨1, 15, 201577131758⟩ := run_B_fast 3 1 201577131758
theorem segment54 : run 1 ⟨1, 15, 201577131758⟩ = some ⟨3, 31, 100788565879⟩ := by rfl
theorem segment55 : run 5 ⟨3, 31, 100788565879⟩ = some ⟨3, 0, 3225234108159⟩ := run_D_fast 5 0 50394282939
theorem segment56 : run 3 ⟨3, 0, 3225234108159⟩ = some ⟨1, 1, 6450468216319⟩ := by rfl
theorem segment57 : run 9 ⟨1, 1, 6450468216319⟩ = some ⟨1, 1023, 12598570734⟩ := run_B_fast 9 1 12598570734
theorem segment58 : run 1 ⟨1, 1023, 12598570734⟩ = some ⟨3, 2047, 6299285367⟩ := by rfl
theorem segment59 : run 11 ⟨3, 2047, 6299285367⟩ = some ⟨3, 0, 12900936433663⟩ := run_D_fast 11 0 3149642683
theorem segment60 : run 3 ⟨3, 0, 12900936433663⟩ = some ⟨1, 1, 25801872867327⟩ := by rfl
theorem segment61 : run 15 ⟨1, 1, 25801872867327⟩ = some ⟨1, 65535, 787410670⟩ := run_B_fast 15 1 787410670
theorem segment62 : run 1 ⟨1, 65535, 787410670⟩ = some ⟨3, 131071, 393705335⟩ := by rfl
theorem segment63 : run 17 ⟨3, 131071, 393705335⟩ = some ⟨3, 0, 51603745800191⟩ := run_D_fast 17 0 196852667
theorem chunk1 : run 410 ⟨1, 2047, 192238⟩ = some ⟨3, 0, 51603745800191⟩ := (join (join (join (join (join segment32 segment33) (join segment34 segment35)) (join (join segment36 segment37) (join segment38 segment39))) (join (join (join segment40 segment41) (join segment42 segment43)) (join (join segment44 segment45) (join segment46 segment47)))) (join (join (join (join segment48 segment49) (join segment50 segment51)) (join (join segment52 segment53) (join segment54 segment55))) (join (join (join segment56 segment57) (join segment58 segment59)) (join (join segment60 segment61) (join segment62 segment63)))))
end BB6Kernel
