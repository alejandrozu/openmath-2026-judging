# matrix-multiplication-tensor-3x3

Owner: **Hamdi Abderrahmene** · branch `hamdi-abderrahmene`
All computation was performed on the Sakana AI server (`gcp_eu_ide`).

## Task
Find an exact low-rank decomposition of the tensor for general **3×3 matrix multiplication
over the rationals**. A submission is three factor matrices `u`, `v`, `w`; term *t* computes
`M_t = (Σ_i u[t][i]·A[i]) · (Σ_j v[t][j]·B[j])` and the output is `C[k] = Σ_t w[t][k]·M_t`.

Conventions (fixed by the hill): `A`, `B` are **row-major** (`A[3r+c]`); the `W` coordinate
for `C[row][col]` is `3·col + row` (**column-major**). Equivalently the target tensor is
`T[i·3+j, j·3+k, k·3+i] = 1`, i.e. `target(I,J,K)=1 ⇔ (I%3==J//3) ∧ (K%3==I//3) ∧ (K//3==J%3)`.

## Metric
Lexicographic: **rank** (rows of `u,v,w`; minimize), then **support** (total nonzero
coefficients in `u,v,w`; minimize). Correctness = all **729 Brent identities**.
Rank 23 is known (Laderman/Smirnov); **rank ≤ 22 is a famous open problem**.

## Result (this branch)
**rank 23, support 139** — verified by two independent exact checkers (729/729 identities)
plus 100/100 random concrete `A·B` replays. This **ties the current #1** on the leaderboard
(`1c1jp5dhwy`, 23/139) and beats #2/#3 (23/153). The scheme is Smirnov's, recovered from the
Heule–Kauers–Seidl catalogue and converted to the hill convention.

```sh
# reproduce the check:
cd matrix-multiplication-tensor-3x3
cp code/mmt3.py . && python3 mmt3.py verify solution.json   # -> rank= 23 support= 139 fails= 0
```

## Techniques tried (all verified on-server)

| method | best exact | outcome |
|---|---|---|
| AlphaTensor `factorizations_r` 3,3,3 → hill coords | 23 / 165 | valid baseline |
| Integer flip-graph SA from AlphaTensor | 23 / 150 | local min |
| 2026 "52-addition" paper (arXiv 2609.06588), flattened | 23 / 149 | additions ≠ flat support |
| 2026 "55-addition" (arXiv 2607.28676), flattened | 23 / ~165 | additions ≠ flat support |
| **HKS catalogue scan (17,376 schemes)** | **23 / 139** | **corpus minimum = 139 (Smirnov, ×3), 0 fractional** |
| Greedy GL₃×GL₃×GL₃ isotropy descent | 149→148; 139→139 | 139 is a strict local min |
| Isotropy+flip+reduction SA + basin-hopping (45 workers) | — | never < 139, never rank < 23 |
| Exhaustive bounded-GL₃ (bound-1 full; bound-2 partial) | ≥ 148 off other orbits | — |
| CP-SAT exact neighborhoods (coef domains {−1,0,1} and [−2,2]) | — | **all 276 single-row bilinear neighborhoods UNSAT; 197/253 two-row pairs UNSAT in {−1,0,1}** |
| ALS + exact rationalization (rank 23 and 22) | — | refinds 139; rank-22 residual ≈ 0.075, no exact |
| Finite-field rank-22 (ℤ/2,3,5,7) + Hensel lift | — | no exact rank-22 on any field |

## Key findings
- **"Additions" ≠ flat support.** The 2026 low-addition SLPs reuse shared subexpressions; when
  expanded to flat factor matrices they have 149–165 nonzeros, worse than 139.
- **Block-coordinate rigidity.** For every support-139 seed, fixing any two legs leaves the third
  as an 81×23 linear system of rank 23 (nullity 0) — a single leg cannot be re-sparsified;
  improvement requires changing ≥2 legs jointly.
- **139 is the frontier.** The exhaustive HKS corpus minimum, the leaderboard best, the CP-SAT
  UNSAT proofs, and all local/orbit/ALS/finite-field searches agree: no exact rank-23 with
  support < 139 and no exact rank-22 was found. Beating 139 needs a genuinely new construction.

## Layout
```
solution.json         # the submission (rank 23, support 139)
code/                 # exact 729-Brent checker + all search engines
schemes/              # verified schemes at 139 (×3), 149, 165, and rank-27 schoolbook
logs/
  coordinator/        # my HKS scan + flip/isotropy run logs
  agents/             # the six parallel search agents (audit, cpsat, breathing, als, orbit, mine, rank22)
campaign_summary.md   # full narrative + numbers
```

## Provenance
- Target/scoring: Autolab hill `matrix-multiplication-tensor-3x3`.
- Baseline rank-23: AlphaTensor `factorizations_r.npz` (`google-deepmind/alphatensor`).
- 139 scheme: Smirnov, via the Heule–Kauers–Seidl "shortest linear program / new ways to
  multiply 3×3 matrices" catalogue (`schemes-tab.tgz`).
- 2026 low-addition schemes: arXiv 2607.28676 (55 adds) and arXiv 2609.06588 (52 adds).
