import Seed1KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed1
open Matrix
theorem row_vw_21 : (L_vw * M_vw) (21 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 21 := by decide
#print axioms row_vw_21
end RecoveredMMTKernelSeed1
