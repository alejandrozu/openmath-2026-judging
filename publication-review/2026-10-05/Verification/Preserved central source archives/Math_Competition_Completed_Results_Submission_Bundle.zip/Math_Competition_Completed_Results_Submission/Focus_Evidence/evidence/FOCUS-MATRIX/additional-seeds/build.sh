#!/usr/bin/env bash
# Run from a matching initialized project: lake env bash /path/to/build.sh
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for seed in 1 2; do
  replay="$(mktemp -d "$root/seed_${seed}/portable-replay-XXXXXXXX")"
  cp "$root/seed_${seed}/proof/"*.lean "$replay/"
  (
    cd "$replay"
    export LEAN_PATH="$replay:${LEAN_PATH:-}"
    lean --version | tee environment.log
    [[ "$(lean --version)" == *"version 4.33.1,"* ]]
    lean -M 4096 -o "Seed${seed}KernelData.olean" "Seed${seed}KernelData.lean" > "Seed${seed}KernelData.log" 2>&1
    for leg in uv uw vw; do
      for i in $(seq -w 0 22); do
        module="Seed${seed}Row_${leg}_${i}"
        lean -M 4096 -o "$module.olean" "$module.lean" > "$module.log" 2>&1
      done
    done
    lean -M 4096 -o "Seed${seed}KernelFinal.olean" "Seed${seed}KernelFinal.lean" > "Seed${seed}KernelFinal.log" 2>&1
    cat "Seed${seed}KernelFinal.log"
    printf 'All 71 modules for seed %s passed in %s\n' "$seed" "$replay"
  )
done
python3 "$root/check_correspondence.py"
