#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path

STATES = "ABCDEF"
NEXT = set(STATES + "H")

def load_machine(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    if set(data) != {"transitions"}:
        raise ValueError("top level must contain exactly transitions")
    tr = data["transitions"]
    if set(tr) != set(STATES):
        raise ValueError("states must be exactly A..F")
    table = []
    for s in STATES:
        row = tr[s]
        if set(row) != {"0", "1"}:
            raise ValueError(f"{s} must have exactly symbols 0 and 1")
        out = []
        for bit in ("0", "1"):
            e = row[bit]
            if not isinstance(e, list) or len(e) != 3:
                raise ValueError(f"{s}/{bit}: entry must be length-3 list")
            w, move, nxt = e
            if type(w) is not int or w not in (0, 1):
                raise ValueError(f"{s}/{bit}: invalid write")
            if move not in ("L", "R"):
                raise ValueError(f"{s}/{bit}: invalid move")
            if nxt not in NEXT:
                raise ValueError(f"{s}/{bit}: invalid next state")
            out.append((w, -1 if move == "L" else 1, 6 if nxt == "H" else STATES.index(nxt)))
        table.append(tuple(out))
    return tuple(table)

def simulate(table, max_steps):
    ones = set()
    state = 0
    head = 0
    lo = hi = 0
    seen_states = 0
    for step in range(1, max_steps + 1):
        seen_states |= 1 << state
        sym = 1 if head in ones else 0
        w, d, nxt = table[state][sym]
        if w:
            ones.add(head)
        else:
            ones.discard(head)
        head += d
        if head < lo: lo = head
        if head > hi: hi = head
        if nxt == 6:
            return {
                "halted": True,
                "steps": step,
                "ones": len(ones),
                "tape_span": hi - lo + 1,
                "visited_states": [STATES[i] for i in range(6) if seen_states >> i & 1],
                "all_states_visited": seen_states == 0b111111,
                "head": head,
                "min_pos": lo,
                "max_pos": hi,
            }
        state = nxt
    return {
        "halted": False,
        "steps": max_steps,
        "ones": len(ones),
        "tape_span": hi - lo + 1,
        "visited_states": [STATES[i] for i in range(6) if seen_states >> i & 1],
        "all_states_visited": seen_states == 0b111111,
        "head": head,
        "min_pos": lo,
        "max_pos": hi,
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("machine", type=Path)
    ap.add_argument("--max-steps", type=int, default=100_000_000)
    args = ap.parse_args()
    try:
        t = load_machine(args.machine)
        print(json.dumps(simulate(t, args.max_steps), sort_keys=True))
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        raise SystemExit(2)

if __name__ == "__main__":
    main()
