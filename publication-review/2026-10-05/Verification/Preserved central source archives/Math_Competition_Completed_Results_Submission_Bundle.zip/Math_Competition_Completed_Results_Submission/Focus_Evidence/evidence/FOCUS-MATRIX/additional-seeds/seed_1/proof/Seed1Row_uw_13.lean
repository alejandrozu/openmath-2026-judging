import Seed1KernelData
set_option maxRecDepth 100000
set_option maxHeartbeats 0
namespace RecoveredMMTKernelSeed1
open Matrix
theorem row_uw_13 : (L_uw * M_uw) (13 : Fin 23) = (1 : Matrix (Fin 23) (Fin 23) ℤ) 13 := by decide
#print axioms row_uw_13
end RecoveredMMTKernelSeed1
