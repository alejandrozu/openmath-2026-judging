# FOCUS-MATRIX — Matrix multiplication: one-leg rigidity

Stable report locator: C03. Completed result candidate, evidence snapshot 3 October 2026. Classification remains provisional.

## Our contribution

Our team contributes the fixed-seed one-leg obstruction: exact rank certificates for all nine paired-factor systems across three seeds, together with standard-kernel proofs of the injectivity and remaining-factor uniqueness statements for all three seeds. The contribution certifies rigidity of these known decompositions under one-leg changes.

## Exact statement and scope

For each of the three stored 139-support HKS seeds, every 81-by-23 rational matrix formed from columnwise products of two 23-by-9 factor lists has column rank 23. Thus fixing any two factor lists uniquely determines the third through the coefficient equations; changing only that list cannot reduce support while retaining the same tensor. The standard-kernel formal certificates prove all three pairings and remaining-factor uniqueness for each of the three stored seeds.

## Proof or computational evidence

All three stored HKS139 seeds have standard-kernel certificates for the UV, UW and VW rational injectivity and remaining-factor uniqueness statements. Seed 0 retains its recorded certificate; the two additional seeds passed fresh 71-module Lean 4.33.1 replays on 3 October 2026. Endpoint axioms are only propext, Classical.choice and Quot.sound. The original factors, selected minors, integer inverse tables and all 729 tensor coefficients match their source data. The independent exact rank checks are also retained.

## Proof outline and semantic bridge

All three stored HKS139 seeds have standard-kernel certificates for the UV, UW and VW rational injectivity and remaining-factor uniqueness statements. Seed 0 retains its recorded certificate; the two additional seeds passed fresh 71-module Lean 4.33.1 replays on 3 October 2026. Endpoint axioms are only propext, Classical.choice and Quot.sound. The original factors, selected minors, integer inverse tables and all 729 tensor coefficients match their source data. The independent exact rank checks are also retained.

## Prior work and novelty assessment

The rank-23/support-139 construction is explicitly attributed to Smirnov/HKS; standard linear algebra supplies the injectivity argument. The team's contribution is the specific fixed-seed one-leg obstruction and its certificates. Its prior occurrence and meaningful mathematical novelty are not established. The result is not a new matrix-multiplication algorithm or global tensor-rank bound.

## Original attribution and contribution history

Source owner Hamdi Abderrahmene; original scheme attributed in its README to Smirnov, recovered from HKS. The exact-rank review and current standard-kernel partitioned proof are dated reconstruction artifacts; competition-period production is entrant-declared. An earlier compiled/native certificate is retained as historical evidence and is superseded for seed-0 proof trust by the successful kernel certificate. Team ownership is confirmed by the user.

## Review route and remaining uncertainty

One narrow method-obstruction candidate. All three seed certificates now establish the stated endpoints with standard kernel axioms. M1 still requires accepted novelty and relevance; M2 may apply to genuinely new useful formal infrastructure. Organizer admission is not implied by successful checking.

## Limits of the claim

No rank-22 impossibility, no global tensor-rank lower bound or support-139 optimality. Seed 0 is not a fourth seed under the name solution.json. All three stored seeds have standard-kernel three-pairing injectivity and remaining-factor uniqueness certificates.

## Exact evidence and navigation

All paths below are relative to the extracted Focus_Evidence directory. The manifest records original paths and SHA-256 hashes; preserved evidence is distinguished from newly prepared excerpts.

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.lean:103` — `rational_injective_uv`.

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.lean:142` — `rational_injective_uw`.

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.lean:181` — `rational_injective_vw`.

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.lean:192` — `remaining_factor_unique_uv`.

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.lean:204` — `remaining_factor_unique_uw`.

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.lean:216` — `remaining_factor_unique_vw`.

- `evidence/FOCUS-MATRIX/MatrixRigidityCompiled.log`

- `evidence/FOCUS-MATRIX/kernel/KernelData.log`

- `evidence/FOCUS-MATRIX/kernel/KernelFinal.log`

- `evidence/FOCUS-MATRIX/kernel/kernel-check-receipt.json`

- `evidence/FOCUS-MATRIX/kernel/progress.log`

- `evidence/FOCUS-MATRIX/kernel/source-data-correspondence.json`

- `evidence/FOCUS-MATRIX/matrix-compiled-receipt.json`

- `evidence/FOCUS-MATRIX/matrix-rigidity-exact-recheck.json`

- `evidence/FOCUS-MATRIX/original/schemes/hks139_0.json`

- `evidence/FOCUS-MATRIX/original/schemes/hks139_1.json`

- `evidence/FOCUS-MATRIX/original/schemes/hks139_2.json`

- `evidence/FOCUS-MATRIX/original/solution.json`

- `evidence/FOCUS-MATRIX/uv_minor.json`

- `evidence/FOCUS-MATRIX/uw_minor.json`

- `evidence/FOCUS-MATRIX/vw_minor.json`

## Prior sources

- [HKS prior schemes](https://arxiv.org/abs/1903.11391)

- [HKS further prior schemes](https://arxiv.org/abs/1905.10192)

## Common review rule

Handbook sections 1, 5 and 7 permit narrow certified computations and obstructions through approved certificate protocols; Lean is not mandatory. The entrants declare team ownership and competition-period production for all supplied results. Mathematical novelty, formalization novelty, target correspondence and protocol approval remain separate review questions.

The prior-work comparison is bounded; it does not establish publication priority or authenticate archive dates.

## Additional seed certificates

- `evidence/FOCUS-MATRIX/additional-seeds/seed_1/proof/Seed1KernelFinal.lean:103`: `rational_injective_uv`; SHA-256 `c3e50cc5b7cfae9880b802e9ba2af987f2504cf6d1e9c39ece761d14b80af3e1`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_1/proof/Seed1KernelFinal.lean:142`: `rational_injective_uw`; SHA-256 `c3e50cc5b7cfae9880b802e9ba2af987f2504cf6d1e9c39ece761d14b80af3e1`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_1/proof/Seed1KernelFinal.lean:181`: `rational_injective_vw`; SHA-256 `c3e50cc5b7cfae9880b802e9ba2af987f2504cf6d1e9c39ece761d14b80af3e1`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_1/proof/Seed1KernelFinal.lean:192`: `remaining_factor_unique_uv`; SHA-256 `c3e50cc5b7cfae9880b802e9ba2af987f2504cf6d1e9c39ece761d14b80af3e1`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_1/proof/Seed1KernelFinal.lean:204`: `remaining_factor_unique_uw`; SHA-256 `c3e50cc5b7cfae9880b802e9ba2af987f2504cf6d1e9c39ece761d14b80af3e1`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_1/proof/Seed1KernelFinal.lean:216`: `remaining_factor_unique_vw`; SHA-256 `c3e50cc5b7cfae9880b802e9ba2af987f2504cf6d1e9c39ece761d14b80af3e1`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_2/proof/Seed2KernelFinal.lean:103`: `rational_injective_uv`; SHA-256 `edf0277c1191d282ca7259e8000c26029e89795902d6a42fb78de4e34c66fa26`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_2/proof/Seed2KernelFinal.lean:142`: `rational_injective_uw`; SHA-256 `edf0277c1191d282ca7259e8000c26029e89795902d6a42fb78de4e34c66fa26`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_2/proof/Seed2KernelFinal.lean:181`: `rational_injective_vw`; SHA-256 `edf0277c1191d282ca7259e8000c26029e89795902d6a42fb78de4e34c66fa26`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_2/proof/Seed2KernelFinal.lean:192`: `remaining_factor_unique_uv`; SHA-256 `edf0277c1191d282ca7259e8000c26029e89795902d6a42fb78de4e34c66fa26`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_2/proof/Seed2KernelFinal.lean:204`: `remaining_factor_unique_uw`; SHA-256 `edf0277c1191d282ca7259e8000c26029e89795902d6a42fb78de4e34c66fa26`.
- `evidence/FOCUS-MATRIX/additional-seeds/seed_2/proof/Seed2KernelFinal.lean:216`: `remaining_factor_unique_vw`; SHA-256 `edf0277c1191d282ca7259e8000c26029e89795902d6a42fb78de4e34c66fa26`.

Final audit: `evidence/FOCUS-MATRIX/additional-seeds/final-audit.json`. Both seed source-data correspondence and kernel-check receipts are included.


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
