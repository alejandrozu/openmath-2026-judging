# FOCUS-BB6 — Busy Beaver 6: exact halting witness

Stable report locator: C05. Completed result candidate, evidence snapshot 2 October 2026. Classification remains provisional.

## Our contribution

Our team contributes the explicit six-state transition table and a complete Lean kernel certificate for its exact 1,235,211-step blank-tape run, final 1,519 ones, and absence of any earlier halt. A separate endpoint proves that every nonhalting state is visited by step 40; two exact simulators supply independent computational evidence.

## Exact statement and scope

Starting on a bi-infinite blank tape in state A, the six-state two-symbol machine 1RB0LC_1RD1RB_0LH1LE_1LA1LD_0LA1LF_0LE0RD executes exactly 1,235,211 transitions to H with 1,519 ones on its final tape and no earlier halted prefix. Every state A–F is visited by step 40. Separate exact simulators give final head -2001 and visited span 2,028 (minimum -2001, maximum 26, including the post-halting head); head and span are not kernel-certified claims.

## Proof or computational evidence

A new standard-kernel certificate in Lean 4.33.1 successfully checks the literal machine, exact run, final ones count, absence of an earlier halt and all-six-states visitation. Claims.lean endpoints exact_halting_witness and visits_all_six_states have only propext and Quot.sound in their printed axiom sets. The 129-source-module closure uses no native_decide, custom axiom or admission, and requires no Mathlib. Semantics.lean proves the tape-cell equations for both move directions. Original dictionary- and set-tape simulator records are preserved as independent evidence.

## Proof outline and semantic bridge

The Lean configuration encodes the two finite-support binary half-tapes as natural numbers relative to the head. Kernel.lean spells out the twelve transition branches, and Semantics.lean proves writing/movement equations for the current, neighboring and all farther cells. The run is assembled from 3,949 segments in 124 chunk modules; ordinary segments reduce in the kernel, while checked macro lemmas handle consecutive-one traversals. A transition into H is counted. The successful exact run rules out any earlier halted prefix. A well-founded population count covers the entire half-tapes; a zero stripped remainder proves the finite counting endpoint. The number 2028 in that counting proof is a sufficient bit bound, not a formal span statement.

## Prior work and novelty assessment

The weak consequence S(6)>=1,235,211 is below older known lower bounds, including Schult's 4,208,824; this does not identify the exact table with earlier work. Team ownership is attested by the user. Exact-table priority/equivalence remains unverified; a bounded search finding no match does not prove first discovery. Runtime alone does not establish a higher significance band.

## Original attribution and contribution history

Recovered SakanaAI/autolab-100 packet on hamdi-abderrahmene. The verified_1235211_1519 filename is an artifact label, not authenticated discovery provenance. The dated passing organizer receipt belongs to a different 177,725-step machine. The newly completed 2 October 2026 kernel certificate verifies the retained machine; team ownership and competition-period production are entrant-declared.

## Review route and remaining uncertainty

One provisional finite halter candidate. The completed standard-kernel certificate closes the earlier formal finite-execution/ones proof gap for this exact table. Mathematical novelty, exact focus correspondence and verification-chair protocol acceptance remain unresolved; successful checking does not establish accepted M1 status or numerical credit.

## Limits of the claim

No global S(6) improvement or exact value, nonhalting theorem or exhaustive search-family exclusion. Exact run length, final ones and all-six-state visitation are kernel-certified; absolute head position and visited span remain simulator-only. No matching final organizer acceptance receipt or certificate-protocol approval is established.

## Exact evidence and navigation

All paths below are relative to the extracted Focus_Evidence directory. The manifest records original paths and SHA-256 hashes; preserved evidence is distinguished from newly prepared excerpts.

- `evidence/FOCUS-BB6/kernel/Claims.lean:14` — `exact_halting_witness`.

- `evidence/FOCUS-BB6/kernel/Claims.lean:22` — `visits_all_six_states`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:11` — `moveR_written`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:15` — `moveR_left_tail`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:20` — `moveR_right`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:22` — `moveL_left`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:24` — `moveL_current`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:28` — `moveL_written`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:32` — `moveL_right_tail`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:43` — `no_earlier_halt`.

- `evidence/FOCUS-BB6/kernel/Semantics.lean:74` — `ones_eq_count_of_strip_zero`.

- `evidence/FOCUS-BB6/kernel/Claims.log`

- `evidence/FOCUS-BB6/kernel/final-certificate-receipt.json`

- `evidence/FOCUS-BB6/kernel/final-check-receipt.json`

- `evidence/FOCUS-BB6/kernel/build-receipt.json`

- `evidence/FOCUS-BB6/kernel/source-manifest.json`

- `evidence/FOCUS-BB6/kernel/independent-audit.json`

- `evidence/FOCUS-BB6/kernel/reproduce.py`

- `evidence/FOCUS-BB6/verified_1235211_1519.json`

- `evidence/FOCUS-BB6/bb6-strongest-replay.json`

- `evidence/FOCUS-BB6/dictionary-audit-excerpt.json`

- `evidence/FOCUS-BB6/dictionary-audit-source-excerpt.py`

- `evidence/FOCUS-BB6/sim.py`

- `evidence/FOCUS-BB6/different-machine-177725-validation.json`

## Prior sources

- [bbchallenge S(6) record and history](https://wiki.bbchallenge.org/wiki/S%286%29)

## Common review rule

Handbook sections 1, 5 and 7 permit narrow certified computations and obstructions through approved certificate protocols; Lean is not mandatory. The entrants declare team ownership and competition-period production for all supplied results. Mathematical novelty, formalization novelty, target correspondence and protocol approval remain separate review questions.

The prior-work comparison is bounded; it does not establish publication priority or authenticate archive dates.


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
