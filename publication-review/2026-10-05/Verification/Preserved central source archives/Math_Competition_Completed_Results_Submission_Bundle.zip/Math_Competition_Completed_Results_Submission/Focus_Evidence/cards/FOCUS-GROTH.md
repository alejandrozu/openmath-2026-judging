# FOCUS-GROTH — Grothendieck: restricted sign-matrix bounds

Stable report locator: C02. Completed result candidate, evidence snapshot 2 October 2026. Classification remains provisional.

## Our contribution

Our team contributes the restricted three-row sign-matrix bound and the four named finite-matrix applications, with their standard-axiom Lean proofs and source-linked checking records. These results provide precise certified cases within the broader sign-matrix problem.

## Exact statement and scope

For every n and every 3-by-n sign matrix A, Q_V(A)<=sqrt(3/2) C(A) in every real inner-product space V. Additionally Q_V(A)<=sqrt(2) C(A) for the four literal archived matrices A_6x6_106, A_6x8_690, A_7x8_53110 and A_s8x8_1705. Q_V is the unit-vector objective supremum, with Q_V(A)=0 for an empty feasible set, and C is its real scalar specialization. These supporting cases form one review family.

## Proof or computational evidence

Fresh Row3Granular and four-case SemanticTestGranular checks passed in Lean 4.33.1 with standard axioms only. Row3 mathematical body is byte-identical after import adjustment; the four-case file retains statements and certificate data with eight arithmetic tactic repairs and explicit imports.

## Proof outline and semantic bridge

Row3 normalizes each sign column to one of four projective types. Walsh multiplicities give four lower anchors for C; Parseval and Cauchy–Schwarz bound the vector objective by sqrt(3/2)C. Each of the four explicit semantic cases combines literal rational sum-of-squares dual data, a scalar sign witness and a generic finite-span bridge valid for arbitrary real inner-product spaces. Matrix dimensions are distinct from ambient vector dimension.

## Prior work and novelty assessment

Walsh/Cauchy and SDP duality methods are established mathematics. The bounded audit did not establish an exact prior occurrence of the stronger sign-only three-row bound or these particular certified instances; this is not a priority certificate. Ben Li's low-setting arbitrary-real-coefficient work is relevant prior, but is not the same restricted statement. Team ownership is user-confirmed. The September 25 internal record is team history, not independent prior publication; exact priority still requires comparison.

## Original attribution and contribution history

Original Row3 and semantic sources come from the recovered SakanaAI/autolab-100 Grothendieck packet on hamdi-abderrahmene. Archived source/check records label Row3 work 25 September 2026; those source bytes are preserved alongside the entrants' declaration of competition-period production. Fresh import/tactic adaptation is dated 2 October 2026. Team ownership is confirmed by the user.

## Review route and remaining uncertainty

One provisional restricted-bound focus candidate; assess M1 after novelty and exact-target review, or M2 for a genuinely new reusable formalization. No per-case or duplicate modality credit.

## Limits of the claim

Fresh checking covers Row3 and four named semantic matrices only. No fresh replay of all 555 semantic cases, no global orbit-coverage theorem, no unrestricted real Grothendieck constant result and no bit-minimality claim.

## Exact evidence and navigation

All paths below are relative to the extracted Focus_Evidence directory. The manifest records original paths and SHA-256 hashes; preserved evidence is distinguished from newly prepared excerpts.

- `evidence/FOCUS-GROTH/Row3Granular.lean:397` — `row3_Q_le_sqrt_three_halves_mul_C`.

- `evidence/FOCUS-GROTH/SemanticTestGranular.lean:276` — `semantic_6x6_106`.

- `evidence/FOCUS-GROTH/SemanticTestGranular.lean:311` — `semantic_6x8_690`.

- `evidence/FOCUS-GROTH/SemanticTestGranular.lean:346` — `semantic_7x8_53110`.

- `evidence/FOCUS-GROTH/SemanticTestGranular.lean:381` — `semantic_s8x8_1705`.

- `evidence/FOCUS-GROTH/Row3Granular.log`

- `evidence/FOCUS-GROTH/SemanticTestGranular.log`

- `evidence/FOCUS-GROTH/SemanticTestGranular.patch`

- `evidence/FOCUS-GROTH/row3-source-correspondence.json`

- `evidence/FOCUS-GROTH/semantic-source-correspondence.json`

## Prior sources

- [Ben Li, Exact values of quantum violations in low-dimensional Bell correlation inequalities](https://arxiv.org/abs/1712.08506)

## Common review rule

Handbook sections 1, 5 and 7 permit narrow certified computations and obstructions through approved certificate protocols; Lean is not mandatory. The entrants declare team ownership and competition-period production for all supplied results. Mathematical novelty, formalization novelty, target correspondence and protocol approval remain separate review questions.

The prior-work comparison is bounded; it does not establish publication priority or authenticate archive dates.


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
