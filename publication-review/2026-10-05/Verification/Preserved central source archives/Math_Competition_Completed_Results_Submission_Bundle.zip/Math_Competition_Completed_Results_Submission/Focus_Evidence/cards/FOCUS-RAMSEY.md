# FOCUS-RAMSEY — Ramsey: exact weighted construction and formal lifting

Stable report locator: C04. Completed result candidate, evidence snapshot 2 October 2026. Classification remains provisional.

## Our contribution

Our team contributes the exact weighted 1024-block construction and independently checked monochromatic count, together with the reusable Lean count-to-limit bridge. The bridge treats repeated block labels and diagonal colors, supplies the explicit collision-error bound, and proves the limiting upper-bound implication.

## Exact statement and scope

The literal symmetric 1024-block binary template has positive integer weights summing to Q=47,314,248 and ordered weighted monochromatic K4 probability P=75525646867723584998137743109/2505750190359427899123170347008. Exact computation gives P<20480989/679477248, the archived hill threshold. The general formal lifting theorem gives c4<=P; for t>0 and tQ>=4 the finite blow-up density differs from P by at most 6/(tQ).

## Proof or computational evidence

The numerator is independently checked by exact C++/Python arithmetic and matches a nonfinal validation receipt. The general count-to-limit development freshly compiled after four compatibility edits in Lean 4.33.1, with standard axioms only. The concrete 1024-block numerator is not evaluated in Lean; approved end-to-end computational acceptance is unestablished.

## Proof outline and semantic bridge

The exact count partitions ordered four-tuples by coincidence pattern, so repeated block labels and within-cluster diagonal colors are included. The independent counts are blue numerator 75,785,863,840,115,062,873,959,569,906 and red numerator 75,265,429,895,332,107,122,315,916,312 over Q^4=5,011,500,380,718,855,798,246,340,694,016. Their reduced sum is P. The generic Lean development controls collisions by 6/(tQ), proves blow-up convergence, and relates the limiting minimum c4 to P. The concrete numerator is verified by exact-integer computation outside Lean; the generic bridge is separately kernel checked.

## Prior work and novelty assessment

The Technion page for Noam Feinstein's January 21, 2026 talk announces c4<0.030139, a stronger numerical bound in the same normalization. It is a credible stronger prior announcement under review: a complete proof/certificate was not obtained, and the page's publication/version before the event has not been authenticated. The team's construction therefore remains a provisional M1 candidate pending that verification. Lifting, averaging and collision estimates are known mathematics. Mathlib edge/Turan density infrastructure and public lean-flag-algebras uniform blow-up and limit developments provide genuine formal overlap, while no matching complete weighted Ramsey interface was located in the bounded comparison. A useful formalization route is an alternative for this one family, without duplicate credit.

## Original attribution and contribution history

Recovered SakanaAI/autolab-100 branch rachtsy, archive-declared commit 39bd2b1d60056dd28765db45f072d4d2df70fb03; experiment 175cc10a. Team ownership is user-confirmed. Supplied codex-fugu/Lea labels record tool roles; competition-period production is entrant-declared, while the recorded tool roles and source chronology are retained.

## Review route and remaining uncertainty

Keep one provisional M1 exact-construction/formal-lifting family while the stronger public announcement and its timing are verified. M2 is a possible alternative formalization route, not a second counted contribution. Archived hill success is not final acceptance.

## Limits of the claim

No exact c4 value, no new global best bound, no concrete-numerator Lean evaluation and no authenticated final acceptance. The receipt's HMAC has not been independently authenticated. Weaker recovered templates belong to this same family.

## Exact evidence and navigation

All paths below are relative to the extracted Focus_Evidence directory. The manifest records original paths and SHA-256 hashes; preserved evidence is distinguished from newly prepared excerpts.

- `evidence/FOCUS-RAMSEY/formal/Lea/RamseyLifting/Lifting.lean:1018` — `density_sub_P_abs_le`.

- `evidence/FOCUS-RAMSEY/formal/Lea/RamseyLifting/Lifting.lean:1117` — `lifting_bound`.

- `evidence/FOCUS-RAMSEY/formal/Lea/RamseyLifting/Lifting.lean:1127` — `density_tendsto`.

- `evidence/FOCUS-RAMSEY/formal/Limit.lean:536` — `c4_le_Pval`.

- `evidence/FOCUS-RAMSEY/archive-provenance-excerpt.json`

- `evidence/FOCUS-RAMSEY/certificate/official_report_175cc10a.json`

- `evidence/FOCUS-RAMSEY/certificate/solution.json`

- `evidence/FOCUS-RAMSEY/exact-count/certificate_input.txt`

- `evidence/FOCUS-RAMSEY/exact-count/count_result.txt`

- `evidence/FOCUS-RAMSEY/exact-count/independent_validation.json`

- `evidence/FOCUS-RAMSEY/formal/AxiomAudit.log`

- `evidence/FOCUS-RAMSEY/formal/Lifting.lean.log`

- `evidence/FOCUS-RAMSEY/formal/Limit.lean.log`

- `evidence/FOCUS-RAMSEY/formal/compatibility.patch`

- `evidence/FOCUS-RAMSEY/formal/replay.json`

- `evidence/FOCUS-RAMSEY/original/LiftingCheck.out`

- `evidence/FOCUS-RAMSEY/original/LimitCheck.out`

## Prior sources

- [Noam Feinstein, January 21, 2026 Technion abstract](https://math.technion.ac.il/events/noam-feinstein/)

- [Mathlib edge-density infrastructure](https://github.com/leanprover-community/mathlib4/blob/0df444a360eaa60ab8c11dca51a86af692955474/Mathlib/Combinatorics/SimpleGraph/Density.lean)
- [Mathlib Turan-density infrastructure](https://github.com/leanprover-community/mathlib4/blob/0df444a360eaa60ab8c11dca51a86af692955474/Mathlib/Combinatorics/SimpleGraph/Extremal/TuranDensity.lean)
- [Public lean-flag-algebras uniform blow-up development](https://github.com/taeyool/lean-flag-algebras-release/blob/main/LeanFlagAlgebras/MetaTheory/BlowupSequence.lean)
- [Public lean-flag-algebras C5 blow-up application](https://github.com/taeyool/lean-flag-algebras-release/blob/main/LeanFlagAlgebras/ErdosPentagon/ErdosPentagon.lean)

The public flag-algebra sources were inspected at current main, not independently pinned to a pre-event commit; this is bounded semantic comparison, not exhaustive priority certification.

## Common review rule

Handbook sections 1, 5 and 7 permit narrow certified computations and obstructions through approved certificate protocols; Lean is not mandatory. The entrants declare team ownership and competition-period production for all supplied results. Mathematical novelty, formalization novelty, target correspondence and protocol approval remain separate review questions.

The prior-work comparison is bounded; it does not establish publication priority or authenticate archive dates.


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
