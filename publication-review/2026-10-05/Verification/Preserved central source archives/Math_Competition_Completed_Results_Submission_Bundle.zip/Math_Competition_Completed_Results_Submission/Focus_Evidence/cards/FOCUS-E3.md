# FOCUS-E3 — Erdős 3: finite diagonal-pullback nonoptimality

Stable report locator: C01. Completed result candidate, evidence snapshot 3 October 2026. Classification remains provisional.

## Our contribution

Our team supplies the 79-point strong-L-free witness at modulus 13, the finite separation 79>78, and the complete formal certificate that every source-defined diagonal pullback of a cyclic four-progression-free subset of Z/13Z has size at most 78 and is strictly smaller than the retained witness. The certificate also proves the sharp cyclic four-progression-free maximum of six, linking the witness and obstruction in one contribution.

## Exact statement and scope

At modulus 13, the supplied 79-point subset B of (Z/13Z)^2 avoids (x,y), (x,y+d), (x,y+2d), (x+d,y) for every nonzero d. The maximum size of a cyclic four-AP-free subset A of Z/13Z is exactly 6, attained by {0,1,2,4,5,7}. Hence |B|=79>78>=13|A| for every such A. In particular, every diagonal pullback S_A={(x,y):x-y belongs to A} has size 13|A|<=78 and is beaten by B. The source-faithful bridge kernel-checks the original pullback cardinality identity |S_A|=13|A|, the L-free transfer and its strict comparison with B.

## Proof or computational evidence

The cyclic sharpness certificate and source-faithful diagonal-pullback bridge passed Lean 4.33.1 / Mathlib 0df444a360eaa60ab8c11dca51a86af692955474 with standard axioms only. The bridge passed a fresh seven-module source-only replay on 3 October 2026, with no reused project-local compiled objects. It checks the actual pullback cardinality, its L-free transfer and the strict comparison with the retained 79-point witness. No native_decide or admitted theorem occurs in the successful chain.

## Proof outline and semantic bridge

The retained 79-point table is checked row by row. A finite Boolean case tree excludes cyclic four-AP-free sets of size seven; a proved bridge transfers that Boolean exclusion to Finset cardinality. A kernel-checked six-point witness supplies the matching lower endpoint. The combination theorem uses 13·6=78<79. The generator is outside the proof trust boundary because the generated propositions and proofs are checked by Lean.

## Prior work and novelty assessment

The 79-point witness, the separation 79>78 and its completed formal certificate are team work, as confirmed by the user. Peluse's L-configuration work provides relevant external context; the bounded review located no exact primary prior for this finite separation and does not establish world priority. Its relevance as a recognized obstacle for the parent conjecture remains a review question.

## Original attribution and contribution history

Retained SakanaAI/autolab-100 packet on branch hamdi-abderrahmene; archive-declared commit a59f286ca8965a46cb8c70deb9d01847bdaa70bb. The split proof, cyclic upper certificate, combination theorem and six-point sharpness certificate are explicitly dated reconstructions in this review.

## Review route and remaining uncertainty

One provisional finite-obstruction M1 review candidate combining the team witness, separation and complete certificate. Novelty and relevance require claim-specific review. M2 may be an alternative for a genuine useful formalization delta; no duplicate family or modality credit.

## Limits of the claim

No strong-L optimum, asymptotic improvement or solution/refutation of Erdős–Turán. The original Fugu3_Lshape one-way transfer remains valid and unchanged.

## Exact evidence and navigation

All paths below are relative to the extracted Focus_Evidence directory. The manifest records original paths and SHA-256 hashes; preserved evidence is distinguished from newly prepared excerpts.

- `evidence/FOCUS-E3/complete-certificate/CombinedObstruction.lean:19` — `explicit_L_witness_beats_every_cyclic_AP_free_set`.

- `evidence/FOCUS-E3/complete-certificate/CyclicSharpness.lean:12` — `cyclic_four_AP_extremum_is_six`.

- `evidence/FOCUS-E3/complete-certificate/CyclicUpper.lean:11` — `cyclic4Free_card_le_six`.

- `evidence/FOCUS-E3/complete-certificate/R17SplitReplay.lean:18` — `B_card`.

- `evidence/FOCUS-E3/complete-certificate/R17SplitReplay.lean:72` — `B_Lfree`.

- `evidence/FOCUS-E3/R17-source-correspondence.json`

- `evidence/FOCUS-E3/R17SplitReplay-receipt.json`

- `evidence/FOCUS-E3/complete-certificate/BooleanTree.log`

- `evidence/FOCUS-E3/complete-certificate/CardBridge.log`

- `evidence/FOCUS-E3/complete-certificate/CombinedObstruction.log`

- `evidence/FOCUS-E3/complete-certificate/CyclicSharpness-receipt.json`

- `evidence/FOCUS-E3/complete-certificate/CyclicSharpness.log`

- `evidence/FOCUS-E3/complete-certificate/CyclicUpper.log`

- `evidence/FOCUS-E3/complete-certificate/R17SplitReplay.log`

- `evidence/FOCUS-E3/complete-certificate/build-receipt.json`

- `evidence/FOCUS-E3/original/LEDGER-candidate-excerpt.txt`

- `evidence/FOCUS-E3/original/R17_lshape13_lower.check.txt`

- `evidence/FOCUS-E3/source-packet-manifest.json`

## Prior sources

- [Relevant L-configuration literature](https://arxiv.org/abs/2205.01295)

## Common review rule

Handbook sections 1, 5 and 7 permit narrow certified computations and obstructions through approved certificate protocols; Lean is not mandatory. The entrants declare team ownership and competition-period production for all supplied results. Mathematical novelty, formalization novelty, target correspondence and protocol approval remain separate review questions.

The prior-work comparison is bounded; it does not establish publication priority or authenticate archive dates.


## Source-faithful diagonal-pullback bridge

The source-faithful bridge kernel-checks the original pullback cardinality identity |S_A|=13|A|, the L-free transfer and its strict comparison with B.

- `evidence/FOCUS-E3/pullback-bridge/source/Fugu3PullbackCore.lean:63` — `card_SA`.
- `evidence/FOCUS-E3/pullback-bridge/source/PullbackObstruction.lean:31` — `card_diagonal_pullback_le_78`.
- `evidence/FOCUS-E3/pullback-bridge/source/PullbackObstruction.lean:38` — `retained_witness_beats_every_diagonal_pullback`.

Fresh source-only replay and axiom records: `evidence/FOCUS-E3/pullback-bridge/fresh-replay/build-receipt.json`. Exact source correspondence: `evidence/FOCUS-E3/pullback-bridge/SOURCE_CORRESPONDENCE.json`. Portable reproduction: `evidence/FOCUS-E3/pullback-bridge/README.md`.


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
