# Focus-hill evidence

This directory contains the five completed focus-hill result candidates, their source and computational data, and verification records. `focus-candidates.json` lists current theorem and evidence locators. Candidate novelty, eligible contribution and acceptance remain distinct from a successful check. All five are team work with independently credited inputs preserved.
