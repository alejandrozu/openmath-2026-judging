# Claim evidence

This directory contains the 22 completed original-family result cards, exact endpoint source files and preserved verification records. `claim-navigation-22.json` gives local paths and hashes. Cards state their precise scope and recorded checking environment. Raw records retain their original bytes and timestamps; those are evidence of the checked artifact, not publication priority. See the bundle README for the verification boundary.
