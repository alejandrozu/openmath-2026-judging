# Rights and attribution review

This is the selected competition submission packet. The user confirms on behalf of the team and Sakana AI authorization to represent the company, approval of attribution, and permission to release the selected competition material under the required competition publication terms. Preserve all included source notices and prior-work attribution. No blanket new license has been assigned. Team ownership is confirmed by the user. This declaration applies to the selected packet and preserves all third-party license conditions. AI tools are not human authors.

A185895’s retained third-party proof archive is excluded from this selection. Ordinary-only work, invalid constructions and duplicate result stages are excluded as score-bearing claims. Known prior formal results are disclosed in the review annex rather than presented as newly solved mathematics.

Historical source/license metadata are evidence, not a substitute for the entrant’s release authority. Official acceptance and adjudication remain organizer responsibilities.
## New mathematical source attribution

The Erdős 1060 addition attributes the unrestricted-core bound to Kominers and squarefree injectivity to Noppakaew–Pongsriiam and preserves the Apache-2.0 canonical-reference notice. The sharp residual-cover addition attributes Sivashankar paper and official ancillary source, preserves its original bytes and documented adapted prefix, and records the arXiv CC BY 4.0 display without inventing a file-specific software license. Known triangle sharpness is support only. The user has confirmed release authorization for this selected competition packet; no broader license grant is inferred.
## Later mathematical attribution

The Formal Conjectures copyright attribution and Apache-2.0 license for the reused criticality definitions accompany this packet. Original verified source bytes remain unchanged. The existing construction proof is not imported. Team ownership and release authorization for the selected packet are user-confirmed; no blanket license or third-party endorsement is inferred.

Local AI-assisted theorem development, formalization and review are disclosed. Team ownership is user-confirmed; individual contribution allocation, resources and any new-content license remain separate declaration fields. Classical mixture and RBM mathematics are attributed as prior work. No endorsement, publication priority or blanket license is inferred. Broader ordinary arguments remain separately labeled.
