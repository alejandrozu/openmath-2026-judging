# Reciprocal square numerator arithmetic

Completed result and evidence record.

Claim ID: `m2-research-wolstenholme`. Family: `research-wolstenholme`.
## Our contribution

We combine equal-minimum 3-adic noncancellation, the reciprocal-square 2-adic exclusion, and a rational-numerator bridge to the stated prime-index divisibility result. The two proof files have recorded standard-axiom Lean 4.33.1 checks; the package supplies these reciprocal-square results while using related ordinary-harmonic valuation infrastructure from Mathlib.

## Exact preserved statement and scope

For every m ≥ 1, the rational sum Σ from k=1 to m of 1/k² has nonpositive 2-adic and 3-adic valuations. The selected bridge excludes a prime from its numerator when the valuation is nonpositive; for every prime p>3, gcd(p,A007406(p−1))=p.

Four endpoint views in two independent proof files forming one coherent arithmetic family.

Not claimed:
- No full composite-n conjecture
- No full stronger classical Wolstenholme theorem
- No extra credit for two duplicate archived snapshots

## Contribution and prior overlap

Proposed classification: M2 conditional formalization/usefulness review. No acceptance or credit asserted.

- No newly solved open-problem claim asserted
- Coherent reciprocal-square arithmetic with genuine equal-minimum 3-adic noncancellation,2-adic exclusion and prime/numerator bridge; repeated snapshots deduplicated.

Recorded overlap:
- Pinned Mathlib has ordinary harmonic 2-adic valuation theory, not the same reciprocal-square result
- The equal-minimum 3-adic noncancellation and numerator/prime bridge are the principal selected formal content

Recorded bounded prior-art comparison:
- Pinned Mathlib has ordinary harmonic 2-adic valuation theory, not the same reciprocal-square result
- The equal-minimum 3-adic noncancellation and numerator/prime bridge are the principal selected formal content

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### a7406_padicValRat_three

Source: `proofs/m2-research/claims/proofs/30761d1c63ddf3a50fc6ee930e68dacb2cd63742913abfd9007567ec00f72c8e.lean`, line 766. SHA-256 `30761d1c63ddf3a50fc6ee930e68dacb2cd63742913abfd9007567ec00f72c8e`.

```lean
theorem a7406_padicValRat_three {m : Nat} (hm1 : 1 ≤ m) :
    padicValRat 3 (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0
```

### a7406_padicValRat_two

Source: `proofs/m2-research/claims/proofs/30761d1c63ddf3a50fc6ee930e68dacb2cd63742913abfd9007567ec00f72c8e.lean`, line 1001. SHA-256 `30761d1c63ddf3a50fc6ee930e68dacb2cd63742913abfd9007567ec00f72c8e`.

```lean
theorem a7406_padicValRat_two {m : Nat} (hm1 : 1 ≤ m) :
    padicValRat 2 (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0
```

### a7406_prime_case_gcd

Source: `proofs/m2-research/claims/proofs/87b6dd5bd86142923b09c0207d04800a82e423eff3fe4178f53bb2a873a8db5e.lean`, line 400. SHA-256 `87b6dd5bd86142923b09c0207d04800a82e423eff3fe4178f53bb2a873a8db5e`.

```lean
theorem a7406_prime_case_gcd :
  ∀ (p : Nat), Nat.Prime p → 3 < p →
    Nat.gcd p (OeisA7406.a (p - 1)) = p
```

### a7406_not_dvd_of_padicValRat_nonpos

Source: `proofs/m2-research/claims/proofs/87b6dd5bd86142923b09c0207d04800a82e423eff3fe4178f53bb2a873a8db5e.lean`, line 147. SHA-256 `87b6dd5bd86142923b09c0207d04800a82e423eff3fe4178f53bb2a873a8db5e`.

```lean
theorem a7406_not_dvd_of_padicValRat_nonpos
    {p m : Nat} [Fact (Nat.Prime p)] (hm : 1 ≤ m)
    (h : padicValRat p (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0) :
    ¬ p ∣ OeisA7406.a m
```

## Verification evidence

The additional exact-source Lean 4.33.1 replay passed all 235 own-source dependency modules and seven independent selected proof files. Individual source hashes and selected endpoint standard-axiom reports are retained. Original archival passes remain separate. The source replay continued across scheduling restarts using hash-matched successful dependency receipts and exact pinned external-library caches. Each proof ran in a separate process; no aggregate importability, independent compiler implementation or official checker acceptance is asserted.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'own_project_commit': 'e6fac203f1f66c8550969c93530ad6462e05fb7b'}

- `proofs/m2-research/claims/fresh-replays-v2/30761d1c63ddf3a50fc6.json` (existing retained artifact; SHA-256 `f70d12d738acd516e9935587ff0c5b9154b068fb76a23d1c664edae34b90b913`).
- `proofs/m2-research/claims/fresh-replays-v2/87b6dd5bd86142923b09.json` (existing retained artifact; SHA-256 `1d25ed1ed92e71617435c38eb604f8bebe9d655987a3ef9d0637a4d1cc0850ba`).
- `proofs/m2-research/verification/fresh-replay-status.json` (existing retained artifact; SHA-256 `4f39e77647711c02b261119dfce38305c90116f2615ea054d755c48a62041b48`).
- `proofs/m2-research/verification/research-fresh-endpoint-audit.json` (existing retained artifact; SHA-256 `612587872f1adde30054be09019f19a981f00bbc897378096bd24a7e92d3e3ba`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
