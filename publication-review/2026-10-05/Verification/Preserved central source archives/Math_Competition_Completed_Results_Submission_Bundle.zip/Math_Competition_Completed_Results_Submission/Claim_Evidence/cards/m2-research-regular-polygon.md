# Regular polygon chord and distance multiplicity

Completed result and evidence record.

Claim ID: `m2-research-regular-polygon`. Family: `research-regular_polygon`.
## Our contribution

We supply the coherent regular-polygon formalization linking the chord-length formula and geometric distance classes to the unordered-pair count. Recorded standard-axiom Lean 4.33.1 verification proves the bound by the number of vertices for the stated even polygons, using existing two-circle-intersection uniqueness as supporting infrastructure.

## Exact preserved statement and scope

For every even n ≥ 5 and every distance d occurring between distinct vertices of the regular n-gon, the number of unordered vertex pairs at distance d is at most n.

Exact even-n endpoint with chord, cardinality and distance-count infrastructure.

Not claimed:
- No general convex extremality or maximal-square-multiplicity theorem
- No audited odd-n endpoint
- No general Erdős94 solution

## Contribution and prior overlap

Proposed classification: M2 conditional formalization/usefulness review. No acceptance or credit asserted.

- No newly solved open-problem claim asserted
- Verified canonical unordered-distance convention, chord analysis, cardinality/convexity and distance-count infrastructure; generic circle-intersection library overlap disclosed.

Recorded overlap:
- Generic two-circle-intersection uniqueness is already in pinned Mathlib
- The selected case is the complete regular-polygon geometry/counting family; the final inequality or proof length alone does not certify novelty

Recorded bounded prior-art comparison:
- Generic two-circle-intersection uniqueness is already in pinned Mathlib
- The selected case is the complete regular-polygon geometry/counting family; the final inequality or proof length alone does not certify novelty

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### regularNGon_even_distanceMultiplicity_chord_bound

Source: `proofs/m2-research/claims/proofs/cc13704faafdd146113fbb944434a585102dde0dba7700cccacc9f194ba56777.lean`, line 982. SHA-256 `cc13704faafdd146113fbb944434a585102dde0dba7700cccacc9f194ba56777`.

```lean
theorem regularNGon_even_distanceMultiplicity_chord_bound
    (n : Nat)
    (hn : 5 ≤ n)
    (heven : Even n) :
    ∀ d ∈ distanceSet (Erdos94.regularNGon n),
      distanceMultiplicity (Erdos94.regularNGon n) d ≤ n
```

## Verification evidence

The additional exact-source Lean 4.33.1 replay passed all 235 own-source dependency modules and seven independent selected proof files. Individual source hashes and selected endpoint standard-axiom reports are retained. Original archival passes remain separate. The source replay continued across scheduling restarts using hash-matched successful dependency receipts and exact pinned external-library caches. Each proof ran in a separate process; no aggregate importability, independent compiler implementation or official checker acceptance is asserted.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'own_project_commit': 'e6fac203f1f66c8550969c93530ad6462e05fb7b'}

- `proofs/m2-research/claims/extended-research-fresh-replays/cc13704faafdd146113f.json` (existing retained artifact; SHA-256 `c121ba8e9b7b696ddac792cfefe3bc060cc680c8a9bfa0a9ce301fccc3b03bd2`).
- `proofs/m2-research/verification/fresh-replay-status.json` (existing retained artifact; SHA-256 `4f39e77647711c02b261119dfce38305c90116f2615ea054d755c48a62041b48`).
- `proofs/m2-research/verification/research-fresh-endpoint-audit.json` (existing retained artifact; SHA-256 `612587872f1adde30054be09019f19a981f00bbc897378096bd24a7e92d3e3ba`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
