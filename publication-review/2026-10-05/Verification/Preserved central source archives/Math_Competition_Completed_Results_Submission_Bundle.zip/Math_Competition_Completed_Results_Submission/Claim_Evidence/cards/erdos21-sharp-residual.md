# Erdős Lovász sharp residual cover bound

Completed result and evidence record.

Claim ID: `erdos21-sharp-residual`. Family: `erdos21-sharp-residual-cover`.
## Our contribution

We close the source paper's explicit +3 residual-cover question through refined colored-link budgets and equality-case exclusions, then derives the all-r bound with additive constant three. The isolated 18-module Lean 4.34.1 replay and separate triangle check certify the result and sharpness, building on the credited matching infrastructure and +4 theorem.

## Exact preserved statement and scope

For every finite intersecting r-uniform hypergraph J of maximum vertex degree at most 3, 4 tau(J) <= |J| + r + 3. Degree-four peeling yields the same inequality without a degree restriction and hence 3r <= |H| + 3 whenever tau(H)=r; for r=8 this gives |H|>=21. The additive constant 3 is optimal, with a separately checked known triangle example.

Complete proof of the explicit +3 refinement asked after Lemma 2 of arXiv 2606.24878v2; one provisional non-M2 new-target mathematical family.

Not claimed:
- No resolution of the original O(r) Erdős 21 question, already solved by Kahn
- No determination of g(r) or improvement of the source paper asymptotic coefficient (41-sqrt(19))/12
- No separate claim for lower_three_sub, r=8, triangle sharpness or infrastructure
- No certified first-publication priority

## Contribution and prior overlap

Proposed classification: Provisional non-M2 new-target mathematical claim. No acceptance or credit asserted.

- The source paper’s residual bound has +4 and explicitly asks for +3. Refined colored-link edge budgets and finite equality-case exclusions establish +3, and the same family improves its explicit all-r bound from 3r-4 to 3r-3.


Recorded overlap:
- Varun Sivashankar, An Improved Lower Bound for the Erdős–Lovász Cover Number Problem, arXiv 2606.24878v2, 29 July 2026 supplies the unconditional matching/witness infrastructure, +4 theorem and known sharpness examples.
- The paper’s stronger asymptotic coefficient about 3.053 is prior work and is not improved. Its ancillary source prefix is reused with explicit attribution and only the documented Lean 4.34.1 compatibility changes. The entire Kahn-dependent asymptotic section is excluded.

Recorded bounded prior-art comparison:
- Varun Sivashankar, An Improved Lower Bound for the Erdős–Lovász Cover Number Problem, arXiv 2606.24878v2, 29 July 2026 supplies the unconditional matching/witness infrastructure, +4 theorem and known sharpness examples.
- The paper’s stronger asymptotic coefficient about 3.053 is prior work and is not improved. Its ancillary source prefix is reused with explicit attribution and only the documented Lean 4.34.1 compatibility changes. The entire Kahn-dependent asymptotic section is excluded.

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### ErdosLovasz.residual_cover_bound_sharp

Source: `proofs/erdos21-sharp-residual/OpHack/Erdos21/Main.lean`, line 25. SHA-256 `9314ae7ba95b6fd9922ccfea882f1d33a6c11c9a40d750109014c8184ab7e414`.

```lean
theorem residual_cover_bound_sharp (r : ℕ) (J : Finset (Finset V))
    (huni : IsUniform r J) (hint : Intersecting J)
    (hdeg : ∀ v, edgeDeg J v ≤ 3) :
    4 * coverNum J ≤ J.card + r + 3
```

### ErdosLovasz.cover_bound_sharp

Source: `proofs/erdos21-sharp-residual/OpHack/Erdos21/Main.lean`, line 33. SHA-256 `9314ae7ba95b6fd9922ccfea882f1d33a6c11c9a40d750109014c8184ab7e414`.

```lean
theorem cover_bound_sharp (r : ℕ) (H : Finset (Finset V))
    (huni : IsUniform r H) (hint : Intersecting H) :
    4 * coverNum H ≤ H.card + r + 3
```

### ErdosLovasz.erdos_lovasz_lower_three

Source: `proofs/erdos21-sharp-residual/OpHack/Erdos21/Main.lean`, line 41. SHA-256 `9314ae7ba95b6fd9922ccfea882f1d33a6c11c9a40d750109014c8184ab7e414`.

```lean
theorem erdos_lovasz_lower_three (r : ℕ) (H : Finset (Finset V))
    (huni : IsUniform r H) (hint : Intersecting H) (hcover : coverNum H = r) :
    3 * r ≤ H.card + 3
```

### ErdosLovasz.erdos_lovasz_lower_three_sub

Source: `proofs/erdos21-sharp-residual/OpHack/Erdos21/Main.lean`, line 49. SHA-256 `9314ae7ba95b6fd9922ccfea882f1d33a6c11c9a40d750109014c8184ab7e414`.

```lean
theorem erdos_lovasz_lower_three_sub (r : ℕ) (H : Finset (Finset V))
    (huni : IsUniform r H) (hint : Intersecting H) (hcover : coverNum H = r) :
    3 * r - 3 ≤ H.card
```

### ErdosLovasz.erdos_lovasz_eight_lower

Source: `proofs/erdos21-sharp-residual/OpHack/Erdos21/Main.lean`, line 56. SHA-256 `9314ae7ba95b6fd9922ccfea882f1d33a6c11c9a40d750109014c8184ab7e414`.

```lean
theorem erdos_lovasz_eight_lower (H : Finset (Finset V))
    (huni : IsUniform 8 H) (hint : Intersecting H) (hcover : coverNum H = 8) :
    21 ≤ H.card
```

## Verification evidence

An independent isolated Lean 4.34.1 replay passed all 18 Main-closure modules. The proof-output directory began empty, source hashes stayed unchanged, nine external revisions were pinned and clean, and the separate endpoint-definition audit passed. Final endpoints use only propext, Classical.choice and Quot.sound; no Kahn hypothesis, hidden packing lemma or extra mathematical assumption is present. The known triangle witness was separately checked against the rebuilt core, outside the 18-module replay.

Recorded environments:
- {'lean': '4.34.1', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/erdos21-sharp-residual/replay-receipt/manifest.json` (existing retained artifact; SHA-256 `5dc4e129bd723dc0b914ec12a711d31ff63151dc1d56956fbab17f0098dfca2e`).
- `proofs/erdos21-sharp-residual/replay-receipt/Main.log` (existing retained artifact; SHA-256 `94d78809809af1486c48477b5dfb3166a48af05fa5597da2e872ac652ef0db42`).
- `proofs/erdos21-sharp-residual/replay-receipt/EndpointAudit.log` (existing retained artifact; SHA-256 `930313bcac1c89a8010b052ce64adfa6305e2d2579afdf6e6095bdd46c95a4d6`).
- `proofs/erdos21-sharp-residual/replay-receipt/TriangleSharpness.log` (existing retained artifact; SHA-256 `1433ba0035a9c0578b46db873b88a7b5bd275ed2e833700f4a3b3ca9c5f3e75e`).
- `proofs/erdos21-sharp-residual/verified-main-output.txt` (existing retained artifact; SHA-256 `94d78809809af1486c48477b5dfb3166a48af05fa5597da2e872ac652ef0db42`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
