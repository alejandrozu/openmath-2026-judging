# OPDP89 sharp four parity likelihood classification

Completed result and evidence record.

Claim ID: `opdp89-parity-local-maxima`. Family: `opdp89-parity-rbm`.
## Our contribution

We supply the sharp collapsed-fibre local-maximum threshold for the four-visible, one-hidden pure-parity RBM, including stationarity and both signs of variation at and beyond the boundary in every full parameter neighborhood. The fresh 17-module replay and semantic audit verify this higher-order classification with standard axioms, extending the known singular-stationarity setting.

## Exact preserved statement and scope

For pure four-parity data Q_rho(s)=(1+rho*s1*s2*s3*s4)/16 with 0<|rho|<=1, consider the normalized four-visible, one-hidden spin RBM P_(b,c,w)(s) proportional to exp(b dot s)*cosh(c+w dot s), and its expected log likelihood ell_rho. At every collapsed point (0,c0,0), with c0 any finite real, every affine parameter-direction derivative is zero. It is a local maximum in the full nine-dimensional parameter space if and only if tanh(c0)^2 < (3+2|rho|)/(3+6|rho|). At equality or beyond, every full parameter neighborhood has both a strictly higher and a strictly lower likelihood point. Every collapsed point has a strictly better finite RBM and distinct equal-likelihood points in every neighborhood; the local maxima are non-strict.

One provisional non-M2 mathematical family giving the exact finite collapsed-fiber classification for the four-visible, one-hidden parity RBM.

Not claimed:
- No higher-dimensional n>=5 or arbitrary four-wise-uniform-data formal endpoint
- Exactly one hidden unit and pure four-parity data
- No distribution-space local maximum, strict optimization trap, attraction basin, EM convergence or training-time theorem
- No complete resolution of the broad OPDP89 learning-structures prompt
- No extra family credit for the earlier strict region, balanced fallback, stationary fiber or ordinary extensions
- Historical sharp raw logs remain unavailable; the separate dated fresh post-recovery PASS receipt/logs are retained without altering historical snapshots
- Novelty, eligibility and accepted credit remain unestablished

## Contribution and prior overlap

Proposed classification: Provisional non-M2 mathematical partial. No acceptance or credit asserted.

- This upgrades the existing strict-region family to a sharp if-and-only-if threshold, with stationarity in every affine parameter direction and both signs of likelihood variation in every full neighborhood at and outside the boundary. Boundary passage is proved along the likelihood-flat collapsed fiber. It remains one family.


Recorded overlap:
- Collapsed stationarity, singular mixture critical lines and familiar RBM interaction formulas are prior mathematics. The bounded comparison with Fukumizu, Akaho and Amari (NIPS 2002) identifies a degenerate case where the second-derivative splitting matrix vanishes; the higher-order full-neighborhood result is the candidate contribution.
- Bounded primary-source review did not locate the exact parity threshold result; it does not certify novelty.
- The earlier strict-region proof and broader ordinary OPDP89 record remain same-family support. The exact 17-module sharp closure now also has fresh post-recovery verification; n>=5 and four-wise-uniform extensions remain ordinary-only.

Recorded bounded prior-art comparison:
- Collapsed stationarity, singular mixture critical lines and familiar RBM interaction formulas are prior mathematics. The bounded comparison with Fukumizu, Akaho and Amari (NIPS 2002) identifies a degenerate case where the second-derivative splitting matrix vanishes; the higher-order full-neighborhood result is the candidate contribution.
- Bounded primary-source review did not locate the exact parity threshold result; it does not certify novelty.
- The earlier strict-region proof and broader ordinary OPDP89 record remain same-family support. The exact 17-module sharp closure now also has fresh post-recovery verification; n>=5 and four-wise-uniform extensions remain ordinary-only.

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### ParityFour.sharp_parity_classification

Source: `proofs/opdp89-parity-sharp/SharpClassification.lean`, line 40. SHA-256 `15ef1ad86c585c87e7ac4fabdc3a58702c915e69dbf6aa80d701258bc9efc602`.

```lean
theorem sharp_parity_classification (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1) :
    (∀ (b : Fin 4 → ℝ) (d : ℝ) (w : Fin 4 → ℝ),
      HasDerivAt (fun t => objective ρ (affineParameterRay c₀ b d w t)) 0 0) ∧
    (IsLocalMax (objective ρ) (nullParameter c₀) ↔
      Real.tanh c₀ ^ 2 < (3+2*|ρ|)/(3+6*|ρ|)) ∧
    ((3+2*|ρ|)/(3+6*|ρ|) ≤ Real.tanh c₀ ^ 2 → ParameterSaddle ρ (nullParameter c₀)) ∧
    (∃ θ : Parameters, objective ρ (nullParameter c₀) < objective ρ θ) ∧
    (∀ U : Set Parameters, U ∈ nhds (nullParameter c₀) →
      ∃ θ : Parameters, θ ∈ U ∧ θ ≠ nullParameter c₀ ∧
        objective ρ θ = objective ρ (nullParameter c₀))
```

### ParityFour.collapsed_local_max_iff

Source: `proofs/opdp89-parity-sharp/SharpClassification.lean`, line 22. SHA-256 `15ef1ad86c585c87e7ac4fabdc3a58702c915e69dbf6aa80d701258bc9efc602`.

```lean
theorem collapsed_local_max_iff (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1) :
    IsLocalMax (objective ρ) (nullParameter c₀) ↔
      Real.tanh c₀ ^ 2 < (3+2*|ρ|)/(3+6*|ρ|)
```

### ParityFour.nonstable_parameter_saddle

Source: `proofs/opdp89-parity-sharp/SharpClassification.lean`, line 33. SHA-256 `15ef1ad86c585c87e7ac4fabdc3a58702c915e69dbf6aa80d701258bc9efc602`.

```lean
theorem nonstable_parameter_saddle (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1)
    (houtside : (3+2*|ρ|)/(3+6*|ρ|) ≤ Real.tanh c₀ ^ 2) :
    ParameterSaddle ρ (nullParameter c₀)
```

## Verification evidence

Fresh post-recovery source-only replay completed 2026-10-02T18:45:45.269248+00:00 in 108.552 seconds. All 17 frozen source modules passed with no warnings or errors; all original source SHA256 values and nine dependency pins were unchanged before/after. No old own-module oleans were reused. A supplemental semantic/type audit passed at 18:48:24 UTC. The final transitive axioms are only propext, Classical.choice and Quot.sound. Historical sharp raw logs remain unavailable; their absence is not filled with invented logs. The new dated PASS receipt and genuine fresh logs supersede historical pending status in byte-preserved recovery snapshots. Earlier strict-region proof and original raw evidence remain unchanged. This is internal AI-assisted formal/semantic review, not appointed jury or external peer review.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474'}

- `proofs/opdp89-parity-local-maxima/verification/independent-replay/REPLAY.json` (existing retained artifact; SHA-256 `4836e9b11a247d1cb1b4a83294167029245f75a0a396807b8a7b3031e9fe938b`).
- `proofs/opdp89-parity-local-maxima/verification/independent-replay/logs/Main.log` (existing retained artifact; SHA-256 `b7d002b1db5e7e5d5efb5939ff5e6dd40457478888e0bcb92ebdb14e6632d32f`).
- `proofs/opdp89-parity-local-maxima/verification/independent-replay/logs/AxiomAudit.log` (existing retained artifact; SHA-256 `147408b72d34539e1285a08e9419b4bf5d530480bc2d840cb037124e11ae0070`).
- `proofs/opdp89-parity-local-maxima/verification/author-replay/REPLAY.json` (existing retained artifact; SHA-256 `e8fece7b1d9b00b2e8e02f6b8110f6cfcdf3e107e3fa894ab5c8b5ded6e7736d`).
- `proofs/opdp89-parity-sharp/RESULT.json` (existing retained artifact; SHA-256 `e5ca9d67c3dd2b5ddb0674f6c57d8a5f653373f36cdd8fbbda651a39a369d89e`).
- `proofs/opdp89-parity-sharp/RECOVERY_PROVENANCE.json` (existing retained artifact; SHA-256 `e1153d2434c964477fd6260ef8cfaa540b5c2d0c96c5790317f20ca4bcb9a269`).
- `proofs/opdp89-parity-sharp/VERIFICATION.md` (existing retained artifact; SHA-256 `2bc11c186ec19b509cc78a6381fee2d4dfdab4a7847cf7ada2d599e29b147ded`).
- `proofs/opdp89-parity-sharp/SEMANTIC_SCOPE.md` (existing retained artifact; SHA-256 `776ffd82ffcc9fdc90a6ef8bfcbadd17cbbcef356584bd5bcc890544c3163b1f`).
- `proofs/opdp89-parity-sharp/SOURCE_MANIFEST.json` (existing retained artifact; SHA-256 `a9107e9c4c546451166108f1faab9e25cf4ac73926e766ef0659638d2463ae7b`).
- `evidence/opdp89-sharp-revalidation-20261002/VERIFICATION_RECEIPT.json` (existing retained artifact; SHA-256 `38ace5540df3a7684453c21e6558c35a773cba1c7dbdca87d92801acf6d19af1`).
- `evidence/opdp89-sharp-revalidation-20261002/fresh-replay/REPLAY.json` (existing retained artifact; SHA-256 `c469ec4e66869f015af4df1f91002d3dc933528d679dc78c3982eacf0c3e39b5`).
- `evidence/opdp89-sharp-revalidation-20261002/fresh-replay/logs/SharpClassification.log` (existing retained artifact; SHA-256 `c241e8d517f5f7a4f19fa62f3870e0b0dd598c10003fbf4a7597f727a6564bf5`).
- `evidence/opdp89-sharp-revalidation-20261002/fresh-replay/logs/SharpAxiomAudit.log` (existing retained artifact; SHA-256 `b53ee9c6349e2db9b8c73625f4be0a06b247b1c94e0074f1a811de21649a53df`).
- `evidence/opdp89-sharp-revalidation-20261002/supplemental-audit/SemanticTypeAudit.log` (existing retained artifact; SHA-256 `f4f44e7043de5b679f015f0eb1546b926edf9bc8369f038491be25cc6955b802`).
- `evidence/opdp89-sharp-revalidation-20261002/supplemental-audit/RESULT.json` (existing retained artifact; SHA-256 `96581517c38656d5e7e9077ae8354ef5767a321b40e71de411ee66c37e3f83d4`).
- `evidence/opdp89-sharp-revalidation-20261002/SEMANTIC_REVIEW.md` (existing retained artifact; SHA-256 `f28005106a7f99f674c4879830a59d63bfa94475483f43fbb65f82c4ee83fd06`).
- `evidence/opdp89-sharp-revalidation-20261002/PREFLIGHT.json` (existing retained artifact; SHA-256 `9309cdfc7e72e9ce3659cb7e9b8ce4365031706f76614277b51e6dd7d73ac284`).
- `evidence/opdp89-sharp-revalidation-20261002/POSTFLIGHT.json` (existing retained artifact; SHA-256 `35158f6261722db29ce897446ac4c34511d861086bd44504ca442609f1ed7db6`).
- `evidence/opdp89-sharp-revalidation-20261002/COMMANDS.sh` (existing retained artifact; SHA-256 `2c0d67b15679c0ebde012f739c33abe6754d1f29b1b6d530f8ffea7243ec5658`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
