# A005258 Apéry prime-power irreducibility

Completed result and evidence record.

Claim ID: `apery-odd-formalization`. Family: `partial-apery-a005258`.
## Our contribution

We supply a completed prime-power irreducibility formalization, including the general odd non-Wieferich family, its translation and congruence interfaces, and the exact upstream polynomial-definition bridge. The seven-module proofs pass on Lean 4.33.1 and 4.34.1 with standard axioms; the binary and ternary cases remain parts of this single family, alongside the known Eisenstein-based mathematical argument.

## Exact preserved statement and scope

For B_n(X)=Σ_(k=0)^n binom(n,k)^2 binom(n+k,k)X^k in Q[X], every odd prime p and r≥1 satisfying p² ∤ 2^(p−1)−1 has Irreducible(B_(p^r)). This card requests review only of any genuinely new useful formalization beyond the prior exposed mathematical sketch; it asserts no original-open novelty.

Formalized odd non-Wieferich prime-power sufficient family, with exact upstream definition bridge

Not claimed:
- New original-open odd-family mathematics
- New binary-power family, which already has a public complete formal helper
- Separate3^r credit
- General degrees, mixed prime factors, Wieferich prime powers
- Independent target/credit for squared-binomial companion

## Contribution and prior overlap

Proposed classification: M2/formalization-delta review only; withhold scored selection until defensible new reusable delta is documented. No acceptance or credit asserted.


- No prior named odd-family checked Lean endpoint found in the23 scored-source attempt audit. Potential delta is the completed generalized odd-family proof and reusable translation/congruence interfaces. A different port or wrapper alone is insufficient; exact code/library comparison and utility rationale remain pending.

Recorded overlap:
- Public pre-event binary-power completed Lean helper
- Public pre-event comments explicitly sketch n=p^a shifted Eisenstein and non-Wieferich success
- 3^r subset; standard Vandermonde/Euler/Eisenstein/Gauss ingredients

Recorded bounded prior-art comparison:
- Completed prior binary chain is not invalidated by the unresolved full theorem’s sorry
- Odd-family overlap is an informal sketch, not an earlier verified odd-family Lean endpoint
- The prior higher-valuation formula is incorrect/unjustified and is not adopted; valid non-Wieferich sufficient implication survives
- Earlier no-exact-prior reports are superseded by the2Oct positive overlap

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### OeisA5258.conjecture_odd_nonWieferich_prime_pow

Source: `proofs/apery-odd/OpHack/AperyPrimePower/Target5258.lean`, line 31. SHA-256 `b21b4c8241412e659cda575432d180b1714b306a314111d43c90066e9b88297b`.

```lean
theorem conjecture_odd_nonWieferich_prime_pow {p r : ℕ} (hp : p.Prime)
    (htwo : p ≠ 2) (hr : 1 ≤ r)
    (hWieferich : ¬ p ^ 2 ∣ 2 ^ (p - 1) - 1) :
    Irreducible (aperyPoly (p ^ r))
```

## Verification evidence

Seven modules checked successfully on both pins; retained successful first-five logs and patched final-two logs are stated honestly. Source hashes match both receipts; final target standard axioms.

Recorded environments:
- {'lean': '4.33.1', 'lean_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474'}
- {'lean': '4.34.1', 'lean_commit': '5045d0056413266e57c625dcd7c365b10e377c52', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/apery-odd/verification/4.33.1/replay.json` (existing retained artifact; SHA-256 `23fff957cd0c42387f8495bd3abcdecc0725b22ede2dff00c2dfa4c592aea548`).
- `proofs/apery-odd/verification/4.34.1/replay.json` (existing retained artifact; SHA-256 `0dca51c7e4a05b1a366c245ada70ce3d3ee23f3fb2f9235eb5d19412a7cac21f`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
