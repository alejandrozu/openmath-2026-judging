# Erdős and Rosenfeld four nearby divisors

Completed result and evidence record.

Claim ID: `m2-research-erdos887`. Family: `research-erdos887`.
## Our contribution

We supply the explicit eight-consecutive-factor construction proving infinitely many integers have four distinct divisors in the stated interval above their square roots, with constant 40. The construction, distinctness, and all interval inequalities are included in the recorded standard-axiom Lean 4.33.1 verification, yielding a closed proof of this precise lower-bound theorem.

## Exact preserved statement and scope

There are infinitely many natural n with at least four distinct divisors d in the open real interval (sqrt(n), sqrt(n)+40 n^(1/4)). The preserved statement uses equivalent floor/ceiling integer endpoints.

Known construction with constant 40 and infinitude.

Not claimed:
- No constant-16 endpoint
- No upper bound or maximality solution to the parent divisor problem

## Contribution and prior overlap

Proposed classification: M2 conditional formalization/usefulness review. No acceptance or credit asserted.

- No newly solved open-problem claim asserted
- Explicit infinite eight-consecutive-factor construction with four distinct divisors and all real interval inequalities; prior statements/axioms distinguished from closed proofs.

Recorded overlap:
- Eight-consecutive-factor construction with explicit divisors and interval inequalities
- Located prior constant-16 benchmark statement has a proof hole; located axiomatized work is not a closed prior proof; bounded search is not a universal novelty certificate

Recorded bounded prior-art comparison:
- Eight-consecutive-factor construction with explicit divisors and interval inequalities
- Located prior constant-16 benchmark statement has a proof hole; located axiomatized work is not a closed prior proof; bounded search is not a universal novelty certificate

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### ga_contains_4_infinite

Source: `proofs/m2-research/claims/proofs/269a2caa15a591595c54001b8cc5360c677ff25f63904e9017548e7492cf965f.lean`, line 123. SHA-256 `269a2caa15a591595c54001b8cc5360c677ff25f63904e9017548e7492cf965f`.

```lean
theorem ga_contains_4_infinite :
    Infinite {n : Nat | 4 ≤ (Finset.filter (fun d => d ∣ n)
      (Finset.Ioo (Nat.floor ((n : ℝ).sqrt))
        (Nat.ceil ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)))))).card}
```

## Verification evidence

The additional exact-source Lean 4.33.1 replay passed all 235 own-source dependency modules and seven independent selected proof files. Individual source hashes and selected endpoint standard-axiom reports are retained. Original archival passes remain separate. The source replay continued across scheduling restarts using hash-matched successful dependency receipts and exact pinned external-library caches. Each proof ran in a separate process; no aggregate importability, independent compiler implementation or official checker acceptance is asserted.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'own_project_commit': 'e6fac203f1f66c8550969c93530ad6462e05fb7b'}

- `proofs/m2-research/claims/fresh-replays-v2/269a2caa15a591595c54.json` (existing retained artifact; SHA-256 `c7f387bea3a3fec9fdb42e5bcca81eff33e1c3f4b7de56d5d8bda1898e3ad870`).
- `proofs/m2-research/verification/fresh-replay-status.json` (existing retained artifact; SHA-256 `4f39e77647711c02b261119dfce38305c90116f2615ea054d755c48a62041b48`).
- `proofs/m2-research/verification/research-fresh-endpoint-audit.json` (existing retained artifact; SHA-256 `612587872f1adde30054be09019f19a981f00bbc897378096bd24a7e92d3e3ba`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
