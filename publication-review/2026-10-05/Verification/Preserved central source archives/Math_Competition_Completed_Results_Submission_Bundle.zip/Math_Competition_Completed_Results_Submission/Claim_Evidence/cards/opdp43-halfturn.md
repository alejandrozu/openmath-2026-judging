# Sharp half-turn symmetry defect gap

Completed result and evidence record.

Claim ID: `opdp43-halfturn`. Family: `partial-opdp43-halfturn`.
## Our contribution

We prove that a no-three-in-line set of exactly 2n points in an n-by-n grid has half-turn miss count zero or at least four, and certifies a ten-point witness attaining four. The clean four-module build verifies the universal theorem and witness geometry with standard axioms, closing the historical miss-two question while crediting the known miss-four examples.

## Exact preserved statement and scope

For A⊆{0,…,n−1}² with |A|=2n and no three collinear, let R(x,y)=(n−1−x,n−1−y). The one-sided miss count |{p∈A:R(p)∉A}| is 0 or ≥4. An explicit ten-point 5×5 witness has miss exactly4, proving global sharpness. Symmetric-difference cardinality is twice the one-sided miss.

Complete sharp answer to the explicitly proposed subsidiary near-half-turn-symmetry question; structural partial relative to broad no-three-in-line

Not claimed:
- Main asymptotic no-three-in-line conjecture
- Miss4 at every n
- A valid n75 construction
- Symmetric-difference count4; one-sided miss4 corresponds to symmetric difference8

## Contribution and prior overlap

Proposed classification: M3A complete existing subsidiary target if organizer uses that exact source question; otherwise parent-linked partial/refinement for classification. No acceptance or credit asserted.

- No positive defect below4 for any full grid configuration; kernel-checked global sharp witness


Recorded overlap:
- Known miss4 examples and prior large-grid calibration configurations; no new general construction claimed

Recorded bounded prior-art comparison:
- Targeted checks found no matching obstruction, but elementary argument has material folklore risk
- The source already poses the subsidiary question, so new-target M3B is not the only possible route

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### NoThreeSymmetry.grid_half_turn_gap

Source: `proofs/opdp43/OpHack/NoThree/Main.lean`, line 8. SHA-256 `f8262d41b0933681b1db8dafb3d4302471dc28650b8ca950e3e1fc01f203c3d2`.

```lean
theorem grid_half_turn_gap {n : ℕ} (A : Finset (GridPoint n))
    (h : GridNoThree A) (hcard : A.card = 2*n) :
    (gridDefect A).card = 0 ∨ 4 ≤ (gridDefect A).card
```

### NoThreeSymmetry.sharp_half_turn_gap

Source: `proofs/opdp43/OpHack/NoThree/Main.lean`, line 56. SHA-256 `f8262d41b0933681b1db8dafb3d4302471dc28650b8ca950e3e1fc01f203c3d2`.

```lean
theorem sharp_half_turn_gap :
    (∀ (n : ℕ) (A : Finset (GridPoint n)), GridNoThree A → A.card = 2*n →
      (gridDefect A).card = 0 ∨ 4 ≤ (gridDefect A).card) ∧
    (∃ A : Finset (GridPoint 5), A.card = 10 ∧ GridNoThree A ∧ (gridDefect A).card = 4)
```

## Verification evidence

Clean4-module standalone release build completed3097jobs; source SHA entries match; final universal theorem includes n0,1,2 and exact witness geometry; standard axioms only.

Recorded environments:
- {'lean': '4.34.1', 'lean_commit': '5045d0056413266e57c625dcd7c365b10e377c52', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/opdp43/verification/clean-release-build.log` (existing retained artifact; SHA-256 `d723ce9924914dedd4fb96f7918496927ee737a90b565b28f7068d8a909dd6bc`).
- `proofs/opdp43/SHA256.json` (existing retained artifact; SHA-256 `4a5bff7200171e3caa8ad123d04d0dd5aaa090ca24225787bbaf92fbb5647a13`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
