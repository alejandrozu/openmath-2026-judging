# OPDP67 explicit two-witness quaternion scalar definition

Completed result and evidence record.

Claim ID: `opdp67-quaternion`. Family: `opdp67-quaternion-definability`.
## Our contribution

We supply the explicit single integer-coefficient equation with two unrestricted quaternion witnesses characterizing scalar elements over every stated ordered commutative ring. The recorded Lean 4.34.1 build and standard-axiom audits include rational and Lipschitz specializations; existing commutation APIs support the construction, while the existential equation provides the concrete formal result.

## Exact preserved statement and scope

For every linearly ordered commutative ring R satisfying CommRing, LinearOrder and IsStrictOrderedRing, a Hamilton quaternion q over R is scalar iff there exist unrestricted quaternions u,v with ((uv−vu)^2+4)^2−(qu−uq)^2−(qv−vq)^2=0. Specializations define scalar Z in the Lipschitz order and scalar Q in rational Hamilton quaternions.

Complete explicit scalar-definition theorem; a subquestion of the source decision-problem discussion

Not claimed:
- Mathematical novelty
- Formal polynomial compiler, DPRM or undecidability chain
- Solution of H10(Q)
- Separate credit for natural sampler/eight-witness variants, which are excluded from this selected card

## Contribution and prior overlap

Proposed classification: M2 new/useful formalization candidate only. No acceptance or credit asserted.


- Proposed reusable formal delta is a single integer-coefficient equation using only ring operations and constants, two unrestricted witnesses, and the general ordered-ring equivalence. A full-tree literal scan of all8 pinned Mathlib files containing Quaternion and scoped base-module inspection found scalar-commutation APIs but no matching existential/Diophantine scalar-definition theorem. This is a defensible M2 proposal with bounded external-library search, not a guarantee of award.

Recorded overlap:
- Known quaternion definability/centralizer mathematics and AIMQuestion7 discussion

Recorded bounded prior-art comparison:
- Known mathematical outcome; no original-open claim
- Useful formalization is plausible, not guaranteed by successful local compilation or absence of an exact name in a narrow search
- The latest8-file pinned Mathlib scan distinguishes preexisting algebra/norm/commutation APIs from the explicit existential equation. It is not an exhaustive semantic search of every proof assistant or repository.

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### OPDP67TwoWitness.scalar_ring_existentially_defined

Source: `proofs/opdp67/OpHack/Quaternion67TwoWitness.lean`, line 157. SHA-256 `200cc2be79f4ba4e52f69e738cd4314278f8ef01b9e780072cfec48f8c47d7f3`.

```lean
theorem scalar_ring_existentially_defined (q : Quaternion R) :
    (∃ u v : Quaternion R, centerPolynomial q u v = 0) ↔
      ∃ r : R, q = (r : Quaternion R)
```

### OPDP67TwoWitness.rationals_existentially_defined

Source: `proofs/opdp67/OpHack/Quaternion67TwoWitness.lean`, line 169. SHA-256 `200cc2be79f4ba4e52f69e738cd4314278f8ef01b9e780072cfec48f8c47d7f3`.

```lean
theorem rationals_existentially_defined (q : HQ) :
    (∃ u v : HQ, centerPolynomial q u v = 0) ↔ ∃ r : ℚ, q = (r : HQ)
```

### OPDP67TwoWitness.integers_defined_by_explicit_equation

Source: `proofs/opdp67/OpHack/Quaternion67TwoWitness.lean`, line 179. SHA-256 `200cc2be79f4ba4e52f69e738cd4314278f8ef01b9e780072cfec48f8c47d7f3`.

```lean
theorem integers_defined_by_explicit_equation (q : OZ) :
    (∃ u v : OZ,
      ((u * v - v * u) ^ 2 + 4) ^ 2 -
        (q * u - u * q) ^ 2 - (q * v - v * q) ^ 2 = 0) ↔
      ∃ z : ℤ, q = (z : OZ)
```

## Verification evidence

Recorded two-witness module build and explicit final generic/rational/integer axiom audit; only standard axioms. No independent clean second replay claimed.

Recorded environments:
- {'lean': '4.34.1', 'lean_commit': '5045d0056413266e57c625dcd7c365b10e377c52', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/opdp67/verification/build.log` (existing retained artifact; SHA-256 `1d5dc9496235758673881815d6c0be98cdc284236e5e32b760e0704035966955`).
- `proofs/opdp67/verification/axioms.log` (existing retained artifact; SHA-256 `73264553141ed26b62ca29ae5b9f4530949ebd24e3e8ef1d7df12cba1d206b3e`).
- `proofs/opdp67/MANIFEST.json` (existing retained artifact; SHA-256 `0cd9b573cec387a4472882312da0c41a1788d0b6988b8fae0ee772b8d739113c`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
