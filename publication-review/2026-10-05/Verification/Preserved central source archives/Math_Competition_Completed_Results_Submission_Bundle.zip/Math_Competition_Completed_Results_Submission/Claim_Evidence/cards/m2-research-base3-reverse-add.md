# Base three reverse and add carry obstruction

Completed result and evidence record.

Claim ID: `m2-research-base3-reverse-add`. Family: `research-base3_reverse_add`.
## Our contribution

We supply the uniform digit-length and carry proof that a palindromic base-three reverse-and-add output forces either palindromic input or carry-free mirrored digit sums. Recorded Lean 4.33.1 verification checks this reusable implication with standard axioms, building on classical carry and symmetry ideas and retaining its single-step scope.

## Exact preserved statement and scope

If x plus its canonical base-3 digit reversal has palindromic base-3 digits, then x already has palindromic base-3 digits or every pair of mirrored input digits sums to less than 3.

Uniform digit-length and carry implication.

Not claimed:
- No perpetual palindrome avoidance for the trajectory from 103
- No claim that MathPages states this exact implication

## Contribution and prior overlap

Proposed classification: M2 conditional formalization/usefulness review. No acceptance or credit asserted.

- No newly solved open-problem claim asserted
- Uniform digit-length/carry dichotomy and complete mirrored-pair implication; exact published source correspondence remains a reusable-target admission question.

Recorded overlap:
- Classical carry/symmetry context is known
- Potential reusable uniform digit/carry formalization; exact target admission and formal-library freshness remain review questions

Recorded bounded prior-art comparison:
- Classical carry/symmetry context is known
- Potential reusable uniform digit/carry formalization; exact target admission and formal-library freshness remain review questions

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### ga_addRevBase3_pal_imp_input_pal_or_carryFree

Source: `proofs/m2-research/claims/proofs/d8fefc50c50b01cf689691ca19ede76b3714975c8cc895d8a151a13ec01070c9.lean`, line 980. SHA-256 `d8fefc50c50b01cf689691ca19ede76b3714975c8cc895d8a151a13ec01070c9`.

```lean
theorem ga_addRevBase3_pal_imp_input_pal_or_carryFree {x : Nat}
    (h : (Nat.digits (3 : Nat) (x + OeisA77408.revBase (3 : Nat) x)).reverse =
           Nat.digits (3 : Nat) (x + OeisA77408.revBase (3 : Nat) x)) :
    (Nat.digits (3 : Nat) x).reverse = Nat.digits (3 : Nat) x ∨
      ga_addRevBase3_carryFree (Nat.digits (3 : Nat) x)
```

## Verification evidence

The additional exact-source Lean 4.33.1 replay passed all 235 own-source dependency modules and seven independent selected proof files. Individual source hashes and selected endpoint standard-axiom reports are retained. Original archival passes remain separate. The source replay continued across scheduling restarts using hash-matched successful dependency receipts and exact pinned external-library caches. Each proof ran in a separate process; no aggregate importability, independent compiler implementation or official checker acceptance is asserted.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'own_project_commit': 'e6fac203f1f66c8550969c93530ad6462e05fb7b'}

- `proofs/m2-research/claims/fresh-replays-v2/d8fefc50c50b01cf6896.json` (existing retained artifact; SHA-256 `a9125db1493ea4ad2b8bb748c9dad275ca13b11f7ccb3ab934a8984f7fa7e8cb`).
- `proofs/m2-research/verification/fresh-replay-status.json` (existing retained artifact; SHA-256 `4f39e77647711c02b261119dfce38305c90116f2615ea054d755c48a62041b48`).
- `proofs/m2-research/verification/research-fresh-endpoint-audit.json` (existing retained artifact; SHA-256 `612587872f1adde30054be09019f19a981f00bbc897378096bd24a7e92d3e3ba`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
