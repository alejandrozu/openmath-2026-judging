# Erdős 1060 uniform quantitative partial bound

Completed result and evidence record.

Claim ID: `erdos1060-uniform-partial`. Family: `erdos1060-weighted-core-bound`.
## Our contribution

We use the retained powerful-core size constraint and a weighted generating function to reduce the uniform counting coefficient below log(3)/3 to the stated constant C. The fresh ten-module Lean 4.33.1 replay verifies the canonical count, all asymptotic hypotheses, and the strict improvement with standard axioms, retaining the prior squarefree injection and unrestricted-core bound as inputs.

## Exact preserved statement and scope

Let sigma(k) be the sum of positive divisors of k, and let f(n) count positive integers k satisfying k sigma(k) = n. With C = log(2539/1000)/3 + log(10/9)/2, for every epsilon > 0 there is N such that every n >= N satisfies f(n) <= exp((C+epsilon) log(n)/log(log(n))). The formal count is exactly the finite set {k <= n : k sigma(k) = n}. The strict comparison C < log(3)/3 is also proved.

One provisional non-M2 mathematical partial toward Erdős 1060. The full zero-constant and polylogarithmic goals remain open.

Not claimed:
- No solution of either full Erdős 1060 goal
- No new claim for the known squarefree injection or unrestricted-core encoding
- No formalized explicit O(error-rate) refinement or optimized-majorant sharpness
- No lower bound for actual fiber counts, odd-target improvement or certified novelty

## Contribution and prior overlap

Proposed classification: Provisional non-M2 mathematical partial. No acceptance or credit asserted.

- The retained powerful core satisfies P^2 <= n. A weighted generating-function bound with x=9/10 improves the located general unrestricted-core constant from log(3)/3 to C = 0.363270358736427... . All arithmetic and asymptotic hypotheses are discharged in the final canonical-count declarations.


Recorded overlap:
- Scott Duke Kominers, On the Number of Solutions of k sigma(k)=n, 2026 working paper, presents the unrestricted-core bound with log(3)/3 and attributes squarefree injectivity to Noppakaew–Pongsriiam. Those arguments are prior mathematics.

Recorded bounded prior-art comparison:
- Scott Duke Kominers, On the Number of Solutions of k sigma(k)=n, 2026 working paper, presents the unrestricted-core bound with log(3)/3 and attributes squarefree injectivity to Noppakaew–Pongsriiam. Those arguments are prior mathematics.

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### Erdos1060.canonical_count_eventually_upper

Source: `proofs/erdos1060-uniform-partial/src/SigmaFiberAsymptotic.lean`, line 38. SHA-256 `440f2f6aaa1d5dd04611fe855077352a3b75171d6e1ec823939ede8609e2d45a`.

```lean
theorem canonical_count_eventually_upper {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ n : ℕ in atTop,
      (#{k ≤ n | k * ArithmeticFunction.sigma 1 k = n} : ℝ) ≤
        Real.exp (((Real.log (2539 / 1000) / 3 + Real.log (10 / 9) / 2) + ε) *
          Real.log (n : ℝ) / Real.log (Real.log (n : ℝ)))
```

### Erdos1060.canonical_count_upper

Source: `proofs/erdos1060-uniform-partial/src/SigmaFiberAsymptotic.lean`, line 49. SHA-256 `440f2f6aaa1d5dd04611fe855077352a3b75171d6e1ec823939ede8609e2d45a`.

```lean
theorem canonical_count_upper {ε : ℝ} (hε : 0 < ε) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n →
      (#{k ≤ n | k * ArithmeticFunction.sigma 1 k = n} : ℝ) ≤
        Real.exp (((Real.log (2539 / 1000) / 3 + Real.log (10 / 9) / 2) + ε) *
          Real.log (n : ℝ) / Real.log (Real.log (n : ℝ)))
```

### Erdos1060Partial.entropyConstant_lt_old

Source: `proofs/erdos1060-uniform-partial/src/EntropyConversion.lean`, line 45. SHA-256 `a9c629fe04c5f4252e92ebdef87ba5942f689fb64a0ca7e1fbc46f8f3957dc14`.

```lean
theorem entropyConstant_lt_old : entropyConstant < Real.log 3 / 3
```

## Verification evidence

Fresh isolated Lean 4.33.1 compilation passed all 10 own source modules, with no own olean reuse. Before/after source hashes agree and final canonical theorem types and axiom lists were printed. Only propext, Classical.choice and Quot.sound occur. Exact package evidence is retained; integration performs file-identity validation, not another replay.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474'}

- `proofs/erdos1060-uniform-partial/verification/RESULT.json` (existing retained artifact; SHA-256 `29bf72f15436677f0281c03d61fd6e4aa9bf4152d6704ac33a448264a6983d65`).
- `proofs/erdos1060-uniform-partial/verification/fresh-replay.log` (existing retained artifact; SHA-256 `7b01be04b6048f53669722c42e712ce80694e79fefef511dcf5d31808d161b46`).
- `proofs/erdos1060-uniform-partial/verification/source-hashes-before.json` (existing retained artifact; SHA-256 `85ef32af149718a85928eaaa89a91543664cf3413fb70e2020ce74e09c0fab1f`).
- `proofs/erdos1060-uniform-partial/verification/source-hashes-after.json` (existing retained artifact; SHA-256 `85ef32af149718a85928eaaa89a91543664cf3413fb70e2020ce74e09c0fab1f`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
