# Theta half sum negative inverse cancellation

Completed result and evidence record.

Claim ID: `m2-research-theta-half-sum`. Family: `research-theta_half_sum`.
## Our contribution

We supply the direct centered-residue permutation and parity proof of negative-inverse half-sum cancellation. Recorded Lean 4.33.1 verification checks the exact odd-prime, parity, range, and modular-inverse hypotheses with standard axioms, providing a concrete formal treatment of mathematics related to the classical Hardy and Dedekind identities.

## Exact preserved statement and scope

For an odd prime k and odd natural a,b with 1 ≤ a,b < k and ab mod k = k−1, define H(k,a)=Σ from j=1 to (k−1)/2 of (−1)^floor(aj/k). Then H(k,a)+H(k,b)=0.

Exact prime-modulus negative-inverse cancellation.

Not claimed:
- No positivity of all remaining terms
- No audited weakening of primality

## Contribution and prior overlap

Proposed classification: M2 conditional formalization/usefulness review. No acceptance or credit asserted.

- No newly solved open-problem claim asserted
- Direct centered-residue permutation and parity cancellation; classical Hardy/Dedekind mathematical correspondence documented.

Recorded overlap:
- Classical Hardy/Dedekind identities explain the mathematics; source-based derivation documented
- Direct centered-residue permutation and parity proof supplies the formalization under review

Recorded bounded prior-art comparison:
- Classical Hardy/Dedekind identities explain the mathematics; source-based derivation documented
- Direct centered-residue permutation and parity proof supplies the formalization under review

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### ga_half_sum_add_eq_zero_of_modEq_neg_one

Source: `proofs/m2-research/claims/proofs/1948663a1348321db557d85cd4e05e9b3b1ad9e03a8dc3f7a342c17afc215ca3.lean`, line 61. SHA-256 `1948663a1348321db557d85cd4e05e9b3b1ad9e03a8dc3f7a342c17afc215ca3`.

```lean
theorem ga_half_sum_add_eq_zero_of_modEq_neg_one (k a b : Nat) (hk : Nat.Prime k) (hodd : Odd k)
    (ha : 1 ≤ a) (ha' : a < k) (hb : 1 ≤ b) (hb' : b < k)
    (hoa : Odd a) (hob : Odd b) (hab : a * b % k = k - 1) :
    ga_half_sum k a + ga_half_sum k b = 0
```

## Verification evidence

The additional exact-source Lean 4.33.1 replay passed all 235 own-source dependency modules and seven independent selected proof files. Individual source hashes and selected endpoint standard-axiom reports are retained. Original archival passes remain separate. The source replay continued across scheduling restarts using hash-matched successful dependency receipts and exact pinned external-library caches. Each proof ran in a separate process; no aggregate importability, independent compiler implementation or official checker acceptance is asserted.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'own_project_commit': 'e6fac203f1f66c8550969c93530ad6462e05fb7b'}

- `proofs/m2-research/claims/fresh-replays-v2/1948663a1348321db557.json` (existing retained artifact; SHA-256 `496ad12077bd243cd742156f4111385228e294c65631274e5713dbbf42732efe`).
- `proofs/m2-research/verification/fresh-replay-status.json` (existing retained artifact; SHA-256 `4f39e77647711c02b261119dfce38305c90116f2615ea054d755c48a62041b48`).
- `proofs/m2-research/verification/research-fresh-endpoint-audit.json` (existing retained artifact; SHA-256 `612587872f1adde30054be09019f19a981f00bbc897378096bd24a7e92d3e3ba`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
