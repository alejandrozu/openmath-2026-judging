# Explicit four-AP-free reciprocal sum >111/25

Completed result and evidence record.

Claim ID: `erdos169-fourap`. Family: `partial-erdos169-fourap`.
## Our contribution

We supply the explicit six-residue augmentation of Walker's base-55 construction and the reciprocal-sum bound exceeding 4.44. The fresh full build and axiom audit verify positivity, absence of nonconstant four-term progressions, and the exact rational-sum inequality for the same finite set; Walker's digit alphabet and earlier bound remain the credited starting point.

## Exact preserved statement and scope

Let D={0,1,2,4,5,9,10,11,14,16,17,18,21,24,30,37,39,41,42,45,47}, M=55³=166375, U={26286,26726,26737,120061,120501,120512}, and T_j={Σ_(i=0)^(j−1) d_i55^i:d_i∈D}, T_0={0}. Let E=T_22 ∪ ⋃_(u∈U)(u+M T_21), A={e+1:e∈E}. Every a∈A is positive; A contains no nonconstant four-term arithmetic progression over Z; Σ_(a∈A)1/a>111/25=4.44, as an exact rational finite sum over distinct elements.

Quantitative partial lower-bound construction for Erdős169

Not claimed:
- Erdős3 reciprocal-divergence theorem
- Full estimation problem or exact optimum
- Global optimality of the six-residue augmentation
- Additional credit for finite certificate stages or fixed-seed saturation

## Contribution and prior overlap

Proposed classification: M3A original estimation-problem partial; M1 only if organizer assigns focus status. No acceptance or credit asserted.

- Explicit six-residue base55 augmentation and exact reciprocal sum strictly above4.44


Recorded overlap:
- Walker base55 alphabet and digit descent, prior4.43975 bound
- Exposed September2026 >4.439753474215620 construction, grouped levels and generic strict improvement

Recorded bounded prior-art comparison:
- No earlier exact4.44 bound found in recorded review; no absolute priority certification

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### Erdos3Candidate.explicit_four_ap_free_reciprocal_gt

Source: `proofs/erdos169-fourap/OpHack/MainResult.lean`, line 17. SHA-256 `cc686e49443c9f23ccbf715be6e9cf71c528736794df230771d33ec84df80ac5`.

```lean
theorem explicit_four_ap_free_reciprocal_gt :
    (∀ a ∈ sixAFinset, 0 < a) ∧
      APFree 4 (sixAFinset : Set ℤ) ∧
      (∑ a ∈ sixAFinset, (1 : ℚ) / (a : ℚ)) > 111 / 25
```

## Verification evidence

Fresh Linux full build completed8950jobs and final axiom audit. Exact same finite set appears in positivity, AP-free and rational-sum clauses. Mathematical source manifest matches; later README change is documentation only.

Recorded environments:
- {'lean': '4.34.1', 'lean_commit': '5045d0056413266e57c625dcd7c365b10e377c52', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/erdos169-fourap/verification/build-linux.log` (existing retained artifact; SHA-256 `2d78bf7fe8b1610192c5c266f27d933f80512c19c5c24c33d56f1a621b7bb181`).
- `proofs/erdos169-fourap/verification/final-axioms.log` (existing retained artifact; SHA-256 `be4399146b1c3f38a075d21f29bf9cc443471b4df55cc399b5e2916b8cf1f14a`).
- `proofs/erdos169-fourap/verification/final-dependencies.log` (existing retained artifact; SHA-256 `c3ba10d9a2c7e00bb80bbb095dad531bb9af23ef8fa5202f659c8c47c53526b2`).
- `proofs/erdos169-fourap/verification/final-toolchain.log` (existing retained artifact; SHA-256 `355a9a028f81641782d75d6e6b58dec70f29d2f61238a9e271690259d9bf5680`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
