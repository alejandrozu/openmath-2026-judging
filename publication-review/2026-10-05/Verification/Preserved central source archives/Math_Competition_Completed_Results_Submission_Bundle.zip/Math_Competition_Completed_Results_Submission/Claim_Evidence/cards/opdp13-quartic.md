# Quartic exact exponent classification and sharp boundary scale

Completed result and evidence record.

Claim ID: `opdp13-quartic`. Family: `partial-opdp13-quartic`.
## Our contribution

We supply the exact exceptional-exponent classification, cubic transition, and sharp logarithmic boundary scale with leading constant one for the least positive admissible exponent. The recorded 40-proof-module Lean 4.34.1 build verifies the function-level squared-norm statements with standard axioms, refining the known quartic family, radical threshold, and qualitative eventual positivity.

## Exact preserved statement and scope

For H_t(z)=(1+|z|²)^4−t|z|⁴ and 6<t≤7, H_t^N (N positive integer) is a finite sum of |holomorphic polynomial|² iff N=2, or N≥4, or N=3 and 924−210t+18t²−t³≥0. For 6<t<8 any such N obeys 12N(8−t)≥t(10−t). For 7≤t<8 it obeys 81N t^(4N)≤614656(16−t)^(4N), plus explicit logarithmic lower bound. Writing δ=8−t, for every ε>0 sufficiently small δ>0 forces all admissible N to satisfy δN≥(1−ε)log(1/δ), while every N≥(1+ε)log(1/δ)/δ has strictly positive coefficients in every degree 0,…,4N and gives a function-level squared-norm representation. The defined least positive admissible index exists and has normalized ratio δ index/log(1/δ) between 1−ε and 1+ε near 0.

Precise one-variable restricted refinement of Hermitian-power problem

Not claimed:
- Full OPDP13 or new t<8 radical threshold
- Binary homogeneous bridge as formally proved
- A separately defined eventual index or filter-limit theorem
- Separate credit for criterion, lower, upper and least-index modules

## Contribution and prior overlap

Proposed classification: M3A parent partial or M3B substantive parent-linked quartic refinement, for organizer classification. No acceptance or credit asserted.

- Exact exceptional exponents/cubic transition and uniform log(1/δ)/δ scale with leading constant1 for the least positive admissible index


Recorded overlap:
- Quartic family after rescaling, t<8 threshold, t7 square, qualitative eventual positivity and general saddle method
- Gram/coefficient and arbitrary-summand squared-norm criteria

Recorded bounded prior-art comparison:
- Known family/methods are removed from new-mathematics scope
- Tan–To accessible appendix studies R^m P_alpha with Θ(1/alpha) minimal exponent, a different operation/family; it does not itself supply this H_t^N logarithmic rate
- Unseen main Theorem2.1 may have a relevant specialization; no categorical clearance asserted

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### PowerSemigroup.function_exact_exponent_semigroup

Source: `proofs/opdp13/OpHack/PowerSemigroup/Evaluation.lean`, line 116. SHA-256 `9924251f0abcd263e38621ad0b96cadbd0a33f6c353d41ecf3e16e30a860ebfc`.

```lean
theorem function_exact_exponent_semigroup {t : ℝ} (ht6 : 6 < t) (ht7 : t ≤ 7)
    (n : ℕ) (hn : 0 < n) :
    FunctionSquaredNorm (fun z : ℂ =>
      (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ)) ↔
      n=2 ∨ 4≤n ∨ (n=3 ∧ 0≤924-210*t+18*t^2-t^3)
```

### PowerMoment.function_exponent_lower_bound

Source: `proofs/opdp13/OpHack/PowerMoment/Bound.lean`, line 86. SHA-256 `556b24cda4326f34d2b8e723b629b76a7930ff6a4c115f831942550fdd5fa830`.

```lean
theorem function_exponent_lower_bound (t : ℝ) (ht : 6 < t) (ht8 : t < 8)
    (n : ℕ) (hn : 0 < n)
    (h : PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
      (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ))) :
    t*(10-t) ≤ 12*(n : ℝ)*(8-t)
```

### PowerFourier.function_logarithmic_growth

Source: `proofs/opdp13/OpHack/PowerFourier/Growth.lean`, line 59. SHA-256 `dab12267b81d6895e9cfc646fedf3b3180a6ded6987210111863cd98c118e1be`.

```lean
theorem function_logarithmic_growth : ∀ ε : ℝ, 0 < ε → ∃ η : ℝ, 0 < η ∧
    ∀ (t : ℝ) (n : ℕ), 7 ≤ t → t < 8 → 0 < n →
      PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
        (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ)) → 8-t < η →
      (1-ε)*Real.log (1/(8-t)) ≤ (8-t)*(n : ℝ)
```

### PowerUpper.function_near_boundary_upper

Source: `proofs/opdp13/OpHack/PowerUpper/Function.lean`, line 9. SHA-256 `c0b278ad2bc4d2d0297a99649e208205dcbc4136c8a3bf89c75604995a7a8e90`.

```lean
theorem function_near_boundary_upper :
    ∀ ε : ℝ, 0 < ε → ∃ δ0 : ℝ, 0 < δ0 ∧ δ0 ≤ 1 ∧
      ∀ (δ : ℝ) (N : ℕ), 0 < δ → δ < δ0 →
        (1+ε)*Real.log (1/δ)/δ ≤ (N : ℝ) →
        PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
          (((1+Complex.normSq z)^4-(8-δ)*(Complex.normSq z)^2)^N : ℝ))
```

### PowerUpper.LeastIndex.leastPositiveIndex_squeeze

Source: `proofs/opdp13/OpHack/PowerUpper/LeastIndex.lean`, line 40. SHA-256 `41aa021b2f3b58b80de296aa22bf5ca917ffb9853bdaa740af8c9dcb36b442c0`.

```lean
theorem leastPositiveIndex_squeeze :
    ∀ ε : ℝ, 0 < ε → ∃ δ0 : ℝ, 0 < δ0 ∧ δ0 ≤ 1 ∧
      ∀ δ : ℝ, 0 < δ → δ < δ0 →
        IsLeastAdmissible δ (leastPositiveIndex δ) ∧
        1-ε ≤ δ*(leastPositiveIndex δ : ℝ)/Real.log (1/δ) ∧
        δ*(leastPositiveIndex δ : ℝ)/Real.log (1/δ) ≤ 1+ε
```

## Verification evidence

Final standalone40-proof-module and aggregate build completed3553jobs with exit0; source SHA records match; endpoint axioms standard. Earlier dependency-graph refresh and stale18-file README count are superseded by this evidence.

Recorded environments:
- {'lean': '4.34.1', 'lean_commit': '5045d0056413266e57c625dcd7c365b10e377c52', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/opdp13/verification/final-build.log` (existing retained artifact; SHA-256 `a44abbddab80c085f30679c43689b9abc80d0c3be678ee66df3c07ea28177c61`).
- `proofs/opdp13/verification/root-least-index-build.log` (existing retained artifact; SHA-256 `d92a7ec970fcbd3050429bc1a9ffbcaba1de62076ed1d490eb1bc5d6b2f22ebb`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
