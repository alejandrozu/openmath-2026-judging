# Ferrers general deficiency hierarchy (44-module dual replay)

Completed result and evidence record.

Claim ID: `ferrers-hierarchy`. Family: `partial-ferrers`.
## Our contribution

We supply the arbitrary-rank deficiency hierarchy that preserves every supplied optimal factor while adjoining the stated matching colors, with exact later ranks and balanced and one-defect realizations. The 44-source dual-version replays verify the graph/rank transport with standard axioms; known greedy boundary and existential cases remain credited within this broader preservation theorem.

## Exact preserved statement and scope

For 1≤r≤k and 0≤e<r, a finite Ferrers graph with matching-union ranks α_r=rk−e and α_(r+1)=(r+1)k−r−e has α_1=k. Every supplied optimal degree-r factor is retained while r−e disjoint matching colors of size k−r are appended. For 0≤h≤r−e, α_(r+h)=rk−e+h(k−r). Balanced e=0 yields simultaneous first 2r CDS colors; e=1 yields first 2r−1. For e>1 no individual first-r CDS-color realization is asserted for arbitrary supplied colorings.

General restricted hierarchy and factor-preserving extension; partial relative to unrestricted Latin Tableaux

Not claimed:
- Full Latin Tableau conjecture or unrestricted L5
- Individual first-r CDS colors for arbitrary supplied colorings when e>1
- Newness of greedy e=r−1 boundary or all small known existence cases
- Parameterized sharpness or rectangular missing-corner transport as Lean-checked in this44-module closure

## Contribution and prior overlap

Proposed classification: M3A parent partial or M3B explicit parent-linked refinement, for organizer classification. No acceptance or credit asserted.

- For arbitrary r and e<r, preserve every supplied optimal r-factor while adjoining r−e matching colors, together with exact later ranks and special balanced/one-defect realizations


Recorded overlap:
- Corner/min-cut formulas, capacitated Hall, bipartite edge coloring
- Greedy e=r−1 extension
- r=3,e=1 existential L5 scope overlaps September2026 McAuley claim; arbitrary supplied-factor preservation is stronger than that stated existence claim

Recorded bounded prior-art comparison:
- No inspected result found to entail the full arbitrary-r preservation hierarchy; bounded negative source audit
- Subtract the known boundary and old existence results explicitly

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### FerrersArm.TightDefectCorner.defect_preserves_factor

Source: `proofs/ferrers/OpHack/Ferrers/DefectExtension.lean`, line 104. SHA-256 `c17d8534968c3ac199813212046ba0da17c65fa46e2907460afeca99323b1e20`.

```lean
theorem defect_preserves_factor {n W : ℕ} (ℓ : Fin n → ℕ) (hℓ : Antitone ℓ)
    (r k e : ℕ) (hr : 1 ≤ r) (hk : r ≤ k) (he : e < r)
    (hR : factorRank (W := W) ℓ r = r*k-e)
    (hNext : factorRank (W := W) ℓ (r+1) = (r+1)*k-r-e)
    (F : Finset (Fin n × Fin W)) (hF : Feasible ℓ r F) (hcard : F.card = r*k-e) :
    ∃ G : Fin (r-e) → Finset (Fin n × Fin W),
      (∀ c, IsMatching (G c) ∧ (G c).card = k-r ∧
        ∀ p ∈ G c, Allowed ℓ p.1 p.2 ∧ p ∉ F) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) ∧
      (∀ h ≤ r-e, factorRank (W := W) ℓ (r+h) = (r+h)*k-h*r-e) ∧
      factorRank (W := W) ℓ 1 = k
```

### FerrersArm.YoungDiagramBridge.defect_indepNumK_later_ranks

Source: `proofs/ferrers/OpHack/Ferrers/YoungDiagramDefect.lean`, line 8. SHA-256 `c55685043c4b319f834184a218377c836af11200769eeae94fda76c4fc2c2dbc`.

```lean
theorem defect_indepNumK_later_ranks (μ : YoungDiagram) (r k e : ℕ)
    (hr : 1 ≤ r) (hk : r ≤ k) (he : e < r)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r*k-e)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+1) = (r+1)*k-r-e) :
    ∀ h ≤ r-e, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+h) = (r+h)*k-h*r-e
```

### FerrersArm.YoungDiagramBridge.one_defect_independent_sets

Source: `proofs/ferrers/OpHack/Ferrers/YoungDiagramDefect.lean`, line 42. SHA-256 `c55685043c4b319f834184a218377c836af11200769eeae94fda76c4fc2c2dbc`.

```lean
theorem one_defect_independent_sets (μ : YoungDiagram) (r k : ℕ)
    (hr : 2 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r*k-1)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+1) = (r+1)*k-r-1) :
    ∃ (R : Fin r → Finset (FCCompat.YoungDiagram.Cell μ))
      (G : Fin (r-1) → Finset (FCCompat.YoungDiagram.Cell μ)),
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (R c : Set (FCCompat.YoungDiagram.Cell μ)) ∧
        (R c).card = (if c.val < r-1 then k else k-1)) ∧
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (G c : Set (FCCompat.YoungDiagram.Cell μ)) ∧ (G c).card = k-r) ∧
      (∀ c d, c ≠ d → Disjoint (R c) (R d)) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) ∧
      (∀ c d, Disjoint (R c) (G d)) ∧
      (∀ t ≤ 2*r-1, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) t =
        if t < r then t*k else t*k-(t-r)*r-1)
```

### FerrersArm.YoungDiagramBridge.first_two_r_independent_sets

Source: `proofs/ferrers/OpHack/Ferrers/YoungDiagramRestrictedPrefix.lean`, line 158. SHA-256 `e5e0e0f73933f360a6fc87e96d2e6172b791acff5ba73aaa0ad0ff836e83654e`.

```lean
theorem first_two_r_independent_sets (μ : YoungDiagram) (r k : ℕ)
    (hr : 1 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r * k)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r + 1) = (r + 1) * k - r) :
    ∃ R G : Fin r → Finset (FCCompat.YoungDiagram.Cell μ),
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (R c : Set (FCCompat.YoungDiagram.Cell μ)) ∧ (R c).card = k) ∧
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (G c : Set (FCCompat.YoungDiagram.Cell μ)) ∧ (G c).card = k - r) ∧
      (∀ c d, c ≠ d → Disjoint (R c) (R d)) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) ∧
      (∀ c d, Disjoint (R c) (G d)) ∧
      (∀ t ≤ 2 * r,
        (firstCells R (min t r) ∪ firstCells G (t - r)).card =
          FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) t)
```

## Verification evidence

44-source strict replay receipts on both pins; source hashes match both recorded receipts. Actual YoungDiagram graph/rank transport and all selected final standard-axiom audits included.

Recorded environments:
- {'lean': '4.33.1', 'lean_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474'}
- {'lean': '4.34.1', 'lean_commit': '5045d0056413266e57c625dcd7c365b10e377c52', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/ferrers/verification/4.33.1/full-verification.json` (existing retained artifact; SHA-256 `139d8b50bafa2dd7b0d715eec830882a005b15a0d8c3e2feaf1077a56188acdb`).
- `proofs/ferrers/verification/4.34.1/full-verification.json` (existing retained artifact; SHA-256 `a44d60930c974cf27ee8b0e3a7763ea9af8c06c79053fd46645ee31b82dc6257`).
- `proofs/ferrers/verification/source-inventory.json` (existing retained artifact; SHA-256 `0f6d9be1e409b8c22aaec1c5fc8a352b9597aaadd777d61cb250f6bc1a2195e2`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
