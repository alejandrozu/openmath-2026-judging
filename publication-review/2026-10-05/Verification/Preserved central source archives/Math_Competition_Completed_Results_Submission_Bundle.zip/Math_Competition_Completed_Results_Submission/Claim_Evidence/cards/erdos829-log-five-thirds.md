# Erdős 829 verified log(5/3) partial bound

Completed result and evidence record.

Claim ID: `erdos829-log-five-thirds`. Family: `erdos829-weighted-code`.
## Our contribution

We combine the finite weighted-code certificate, all-target gcd transfer, and prime cutoff to prove the uniform log(5/3) bound for ordered nonnegative cube-sum representations. The fresh 33-proof-module replay and two audits verify the exact unrestricted target count with standard axioms, building on prior ratio-root, congruence, and coding methods.

## Exact preserved statement and scope

Let R(n) count ordered nonnegative integer pairs (x,y) satisfying x^3+y^3=n. For every real epsilon>0 there exists a natural N such that, for every natural n>=N, R(n) <= exp((log(5/3)+epsilon)*log(n)/log(log(n))). Zero coordinates are included and swapping unequal coordinates gives distinct representations. There is no primitive-pair or cubefree-target restriction. The existential threshold is not given numerically.

One conditional original-target mathematical partial-advance family; the polylogarithmic target remains open.

Not claimed:
- No proof or refutation of the original polylogarithmic Erdős 829 conjecture R(n)=O((log n)^C)
- No signed-integer representation bound
- No certified novelty, best-known status, official admission, accepted progress or points
- Competition-period production is entrant-declared; recovery/check dates do not establish independent publication priority

## Contribution and prior overlap

Proposed classification: Conditional non-M2 original-target mathematical partial. No acceptance or credit asserted.

- The selected endpoint proves the all-target ordered nonnegative count bound with coefficient log(5/3). The earlier log(7/4) endpoint belongs to this same family. Selection is conditional on target status, novelty and substantive mathematical review. If the mathematics is known, M2 requires a separate genuinely new and useful formalization delta.


Recorded overlap:
- Primitive ratio-root injection and determinant congruence are prior tools (including Merikoski, Lemma 8); Elias/Plotkin localization and entropy machinery are classical. The finite weighted-code certificate, all-target gcd transfer and prime cutoff support the proposed partial-advance comparison.
- The bounded literature comparison did not locate an all-target bound subsuming the stated coefficients. Its derived 0.5564773354 comparison applies only to cubefree targets; it is not an all-target theorem or a comprehensive priority certificate.

Recorded bounded prior-art comparison:
- Primitive ratio-root injection and determinant congruence are prior tools (including Merikoski, Lemma 8); Elias/Plotkin localization and entropy machinery are classical. The finite weighted-code certificate, all-target gcd transfer and prime cutoff support the proposed partial-advance comparison.
- The bounded literature comparison did not locate an all-target bound subsuming the stated coefficients. Its derived 0.5564773354 comparison applies only to cubefree targets; it is not an all-target theorem or a comprehensive priority certificate.

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### Erdos829FiveThirds.canonicalCubeCount_eventually_exp

Source: `proofs/erdos829-log-five-thirds/FiveThirdsCanonical.lean`, line 8. SHA-256 `51541747f8104588463d8b7b051d69692876cee605c68a2f50df9da132e6a006`.

```lean
theorem canonicalCubeCount_eventually_exp {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ n : ℕ in atTop, (canonicalCubeCount n : ℝ) ≤
      Real.exp ((Real.log (5/3 : ℝ)+ε)*Real.log (n : ℝ)/Real.log (Real.log (n : ℝ)))
```

### Erdos829FiveThirds.canonicalCubeCount_eventual_threshold

Source: `proofs/erdos829-log-five-thirds/FiveThirdsCanonical.lean`, line 14. SHA-256 `51541747f8104588463d8b7b051d69692876cee605c68a2f50df9da132e6a006`.

```lean
theorem canonicalCubeCount_eventual_threshold {ε : ℝ} (hε : 0<ε) :
    ∃ N : ℕ, ∀ n : ℕ, N≤n → (canonicalCubeCount n : ℝ) ≤
      Real.exp ((Real.log (5/3 : ℝ)+ε)*Real.log (n : ℝ)/Real.log (Real.log (n : ℝ)))
```

## Verification evidence

Fresh separately orchestrated source-only Lean 4.33.1 replay completed 2026-10-02T18:54:57.202016+00:00. All 33 proof modules and two semantic/axiom audit modules exited 0. The final active sources comprise 28 historical exact modules and five reconstructed/repaired variants, all freshly verified. No old own-module oleans were used; nine third-party dependency pins matched. Endpoint transitive axioms are only propext, Classical.choice and Quot.sound. The semantic audit checks the exact expanded catalog expression and ordered nonnegative coordinate count; it does not import the catalog conjecture. This is internal AI-assisted formal-check/semantic evidence, not appointed jury or external peer review.

Recorded environments:
- {'lean': '4.33.1', 'lean_commit': '819816b2e0a3bf405af45ae5c7af2491d8f5bee6', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'dependency_pins': {'plausible': 'b7eb3304aeae834b12dda98993a37f6a41f6f0bb', 'LeanSearchClient': '5f4d51b81cbd3f6b32b156bfad9056621a040404', 'importGraph': '16f02aa7642864af59f1ff0e384a015994db9118', 'proofwidgets': '4be2e3d5087eeb272cf5a8853b8f9dd025ef5957', 'aesop': '3448c0bcc5ce01b2d1546e483ec3620e32df3d0e', 'Qq': '92c15be17b7caf78c2ad767ec40f89052d908d81', 'batteries': '4488d40d070b9700d4d5a6aa342f0d40c31b2a2d', 'Cli': '6130a47896ce867c6a4a55373441e59e565bad0f', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474'}, 'dependency_pins_path': 'proofs/erdos829-log-five-thirds/dependency-pins.json'}

- `proofs/erdos829-log-five-thirds/verification/verification.json` (existing retained artifact; SHA-256 `ec3e17f4d76b50df8ff759480fbc65907309d5a2d715d3fc3b7e4013c472bfa9`).
- `proofs/erdos829-log-five-thirds/verification/independent-audit/independent-receipt.json` (existing retained artifact; SHA-256 `ac1635c2bac105208673a0e5f1554203ea39593c38f7639adad51953b1d7f034`).
- `proofs/erdos829-log-five-thirds/verification/logs/FiveThirdsCanonical.log` (existing retained artifact; SHA-256 `f093d3acdd665dd598fff8a4871d6d45570067958987651fd5ff5f4122521491`).
- `proofs/erdos829-log-five-thirds/verification/logs/FiveThirdsFinalTypeAudit.log` (existing retained artifact; SHA-256 `11c397a92e03c799fda8be31ee6562087a81e0b8cf79b0ef389f9ff0a2260533`).
- `proofs/erdos829-log-five-thirds/verification/logs/IndependentFiveThirdsSemanticAudit.log` (existing retained artifact; SHA-256 `d43f0952c0d72c5fb5276c21144ff08861221a5c7ff48c7a1b802265e872e0d1`).
- `proofs/erdos829-log-five-thirds/verification/logs/FreshSemanticAndAxiomAudit.log` (existing retained artifact; SHA-256 `3d62193131c9f0a6bb581f4c5206c8852b9cf2b0ee9a7c3952fea42217a2e613`).
- `proofs/erdos829-log-five-thirds/verification/source-hashes.json` (existing retained artifact; SHA-256 `126dffa9a2b6811fde754de26e3fd23020c594eeac730dab5321acd0bcdc0931`).
- `proofs/erdos829-log-five-thirds/dependency-pins.json` (existing retained artifact; SHA-256 `370768e89fbf1028eed2a6f5784734a9747c849b0f30e45b62f6f467d7330e7c`).
- `proofs/erdos829-log-five-thirds/PACKAGE_MANIFEST.json` (existing retained artifact; SHA-256 `72d23e3f383c5cf9b62ca60c80394360c5868fe35b57f2f7ba2d4ba13b26819f`).
- `proofs/erdos829-log-five-thirds/VERIFICATION.md` (existing retained artifact; SHA-256 `78067ed971757b61807f2dab2bf63d2186dbf965adf0f3077088c0da2f481678`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
