# A060841 reciprocal determinant integrality

Completed result and evidence record.

Claim ID: `m2-research-a060841`. Family: `research-a060841`.
## Our contribution

We supply the complete formal bridge from the reciprocal-lcm determinant to its product expression and the finite-and-infinite integrality classification. Recorded Lean 4.33.1 checks verify the exact list through 34 together with 36 and 38 using standard axioms, while the known mathematical classification and existing product/valuation helpers remain credited background.

## Exact preserved statement and scope

For n ≥ 1, the inverse determinant of the n by n matrix with entries 1/lcm(i+1,j+1) is an integer exactly when n belongs to {1,…,34,36,38}.

Complete integrality-classification endpoint; proposed as formalization of known mathematics.

Not claimed:
- No new open-problem solution
- No claim for the separate denominator conjecture

## Contribution and prior overlap

Proposed classification: M2 conditional formalization/usefulness review. No acceptance or credit asserted.

- No newly solved open-problem claim asserted
- Substantial determinant-to-product bridge and complete finite/infinite integrality classification; prior informal mathematics and product-helper overlap disclosed.

Recorded overlap:
- Substantive determinant-to-product and valuation bridge beyond located public product-only development
- Exact informal classification was already public; product/valuation helpers have prior formal overlap

Recorded bounded prior-art comparison:
- Substantive determinant-to-product and valuation bridge beyond located public product-only development
- Exact informal classification was already public; product/valuation helpers have prior formal overlap

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### ga_target_5e67b0763c763225

Source: `proofs/m2-research/claims/proofs/5e4bb2ede244d1de75b753bc0115a7173872d8b4ecb488d6e6e94828e2691d28.lean`, line 1426. SHA-256 `5e4bb2ede244d1de75b753bc0115a7173872d8b4ecb488d6e6e94828e2691d28`.

```lean
theorem ga_target_5e67b0763c763225 : ∀ (n : Nat),
  @LE.le.{0} Nat instLENat (@OfNat.ofNat.{0} Nat (nat_lit 1) (instOfNatNat (nat_lit 1))) n →
    Iff
      (@Eq.{1} Nat
        (@Inv.inv.{0} Rat Rat.instInv
            (@Matrix.det.{0, 0} (Fin n) (instDecidableEqFin n) (Fin.fintype n) Rat Rat.commRing
              (OeisA60841.lcmMatrix n))).den
        (@OfNat.ofNat.{0} Nat (nat_lit 1) (instOfNatNat (nat_lit 1))))
      (@Membership.mem.{0, 0} Nat (Set.{0} Nat) (@Set.instMembership.{0} Nat) OeisA60841.integerDetN n)
```

## Verification evidence

The additional exact-source Lean 4.33.1 replay passed all 235 own-source dependency modules and seven independent selected proof files. Individual source hashes and selected endpoint standard-axiom reports are retained. Original archival passes remain separate. The source replay continued across scheduling restarts using hash-matched successful dependency receipts and exact pinned external-library caches. Each proof ran in a separate process; no aggregate importability, independent compiler implementation or official checker acceptance is asserted.

Recorded environments:
- {'lean': '4.33.1', 'mathlib': '0df444a360eaa60ab8c11dca51a86af692955474', 'own_project_commit': 'e6fac203f1f66c8550969c93530ad6462e05fb7b'}

- `proofs/m2-research/claims/fresh-replays-v2/5e4bb2ede244d1de75b7.json` (existing retained artifact; SHA-256 `c6ae3eeaf57152cabaa3b8f383cfa7ce3b722a17394dc08532195ed231af1741`).
- `proofs/m2-research/verification/fresh-replay-status.json` (existing retained artifact; SHA-256 `4f39e77647711c02b261119dfce38305c90116f2615ea054d755c48a62041b48`).
- `proofs/m2-research/verification/research-fresh-endpoint-audit.json` (existing retained artifact; SHA-256 `612587872f1adde30054be09019f19a981f00bbc897378096bd24a7e92d3e3ba`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
