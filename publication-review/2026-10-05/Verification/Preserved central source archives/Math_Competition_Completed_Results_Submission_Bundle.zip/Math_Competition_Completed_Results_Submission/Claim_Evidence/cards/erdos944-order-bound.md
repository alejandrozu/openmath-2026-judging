# Erdős 944 finite order obstruction

Completed result and evidence record.

Claim ID: `erdos944-order-bound`. Family: `erdos944-finite-order-bound`.
## Our contribution

We supply the stronger finite order obstruction for vertex-critical four-chromatic graphs with the stated edge resilience, including the quadratic and integer independent-set filters. The isolated Lean 4.34.1 replay and target audit verify all three inequalities with standard axioms, improving the explicit finite comparison while preserving the prior stronger eventual asymptotic result.

## Exact preserved statement and scope

For a finite simple graph G with n vertices and an integer r >= 1, suppose its chromatic number is 4, deleting any vertex lowers that number, and deleting any set of at most r edges does not lower it. Then 27r+19 <= 4n. The same hypotheses give 27(r+1)(n-1) <= (2n+1)^2 and 9b(r+1) <= (2b+1)(n-b), where b=floor((n+1)/3). These necessary conditions form one family.

One provisional non-M2 mathematical partial for the finite k=4 case of Erdős 944.

Not claimed:
- No existence construction or full solution of Erdős 944
- No infinite-vertex or k>4 theorem
- No asymptotic improvement
- No new credit for the prior r=1 construction
- No certified novelty, first-publication priority, eligibility or accepted credit

## Contribution and prior overlap

Proposed classification: Provisional non-M2 mathematical partial. No acceptance or credit asserted.

- The clean inequality strengthens the explicit n >= 5r+6 finite obstruction in Skottova and Steiner, Proposition 5.1. Stronger quadratic and integral independent-set filters are also proved; for r=4, the integer filter requires n >= 33 rather than the linear bound alone requiring n >= 32.


Recorded overlap:
- Skottova and Steiner, Critical edge sets in vertex-critical graphs, arXiv:2508.08703, supply the explicit n >= 5r+6 bound and the separate r=O(n/(log n)^c) theorem for an absolute c>0. Their asymptotic theorem is stronger eventually and is not improved here.
- The public 48-vertex degree-6 r=1 construction and later 6-regular r=1 results are prior work. Target criticality definitions are reused; the construction proof is neither copied nor imported. Finite coding, Cauchy-Schwarz and Plotkin methods are classical background.

Recorded bounded prior-art comparison:
- Skottova and Steiner, Critical edge sets in vertex-critical graphs, arXiv:2508.08703, supply the explicit n >= 5r+6 bound and the separate r=O(n/(log n)^c) theorem for an absolute c>0. Their asymptotic theorem is stronger eventually and is not improved here.
- The public 48-vertex degree-6 r=1 construction and later 6-regular r=1 results are prior work. Target criticality definitions are reused; the construction proof is neither copied nor imported. Finite coding, Cauchy-Schwarz and Plotkin methods are classical background.

## Formal proof source

Paths below are relative to `Claim_Evidence/` in this bundle. Exact source bytes, declaration lines and verification evidence are preserved. Dependency versions and the inspection/build boundary are described in the bundle README.

### Erdos944Bounds.erdos944_order_linear

Source: `proofs/erdos944-order-bound/OpHack/Erdos944Bounds.lean`, line 42. SHA-256 `8f9e544d0e9f465f8d92d0c0b878ab2bd9b542c0c969eaa4e2d7c908acec27f4`.

```lean
theorem erdos944_order_linear {r : ℕ} (hr : 1 ≤ r)
    (hG : G.IsCritical 4)
    (hE : ∀ edges : Set (Sym2 V), G.IsCriticalEdges edges → r < edges.ncard) :
    27*r + 19 ≤ 4 * Fintype.card V
```

### Erdos944Bounds.erdos944_order_quadratic

Source: `proofs/erdos944-order-bound/OpHack/Erdos944Bounds.lean`, line 28. SHA-256 `8f9e544d0e9f465f8d92d0c0b878ab2bd9b542c0c969eaa4e2d7c908acec27f4`.

```lean
theorem erdos944_order_quadratic {r : ℕ} (hr : 1 ≤ r)
    (hG : G.IsCritical 4)
    (hE : ∀ edges : Set (Sym2 V), G.IsCriticalEdges edges → r < edges.ncard) :
    27 * (r+1) * (Fintype.card V - 1) ≤ (2 * Fintype.card V + 1)^2
```

### Erdos944Bounds.erdos944_order_exact

Source: `proofs/erdos944-order-bound/OpHack/Erdos944Bounds.lean`, line 54. SHA-256 `8f9e544d0e9f465f8d92d0c0b878ab2bd9b542c0c969eaa4e2d7c908acec27f4`.

```lean
theorem erdos944_order_exact {r : ℕ} (hr : 1 ≤ r)
    (hG : G.IsCritical 4)
    (hE : ∀ edges : Set (Sym2 V), G.IsCriticalEdges edges → r < edges.ncard) :
    9 * ((Fintype.card V + 1) / 3) * (r+1) ≤
      (2 * ((Fintype.card V + 1) / 3) + 1) *
        (Fintype.card V - (Fintype.card V + 1) / 3)
```

## Verification evidence

Independent isolated Lean 4.34.1 replay compiled three proof modules and the separate TargetAudit.lean from unchanged frozen sources. Its own output directory began empty and earlier project proof caches were excluded; pinned third-party caches were reused. Exact target definitions and conjunction were audited. Every final endpoint uses only propext, Classical.choice and Quot.sound. Packaging validates identities without claiming a further Lean replay.

Recorded environments:
- {'lean': '4.34.1', 'mathlib': 'd13f23b723b8a846827a245b89c10fc7d3f11612'}

- `proofs/erdos944-order-bound/verification/independent-replay-receipt.json` (existing retained artifact; SHA-256 `62e604c3e67cf6522b78d99c10eab4c6110cc2efd961bdaff8195902ad07446a`).
- `proofs/erdos944-order-bound/verification/Erdos944Graph.log` (existing retained artifact; SHA-256 `00d06e0489132de4a21fd55425f3f8f16f20bd5c587d1afdf16200def97a7d9f`).
- `proofs/erdos944-order-bound/verification/CriticalCodeBound.log` (existing retained artifact; SHA-256 `b1e3668d218324d6984ec262069df738d472b9fb721207e631132de5d6da0763`).
- `proofs/erdos944-order-bound/verification/Erdos944Bounds.log` (existing retained artifact; SHA-256 `41ae983a1ca6a332b804faa8df2861673c3147648732d2c2581c464c4a61f5b1`).
- `proofs/erdos944-order-bound/verification/TargetAudit.log` (existing retained artifact; SHA-256 `8521858d1ac7a1983fee4b1eb9ea0d7f363b5f91da05841265b2671bea0f83c4`).


## Entrant declaration

The entrants declare that all supplied results are their team's work produced during the competition. Original source and replay timestamps are preserved as artifact history.
