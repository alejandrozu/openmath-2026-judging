#!/usr/bin/env bash
set -euo pipefail
# Execute only with an empty/new fresh-replay directory.
export LEAN_JOBS=1
bash /workspace/scratch/06b291553089/output/opdp89-sharp-revalidation-20261002T1841Z/source/verify.sh --lean /workspace/scratch/06b291553089/output/opdp89-sharp-revalidation-20261002T1841Z/lean-bounded.sh --dependencies /workspace/scratch/06b291553089/lean-cloud/fc4331/.lake/packages --output-dir /workspace/scratch/06b291553089/output/opdp89-sharp-revalidation-20261002T1841Z/fresh-replay 2>&1 | tee /workspace/scratch/06b291553089/output/opdp89-sharp-revalidation-20261002T1841Z/replay-console.log
