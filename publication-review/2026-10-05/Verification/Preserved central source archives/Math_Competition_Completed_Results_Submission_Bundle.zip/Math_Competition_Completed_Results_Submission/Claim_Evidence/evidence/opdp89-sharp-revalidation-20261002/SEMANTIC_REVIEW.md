# Fresh semantic review of the sharp four-parity RBM theorem

Reviewed on 2026-10-02 against the frozen seventeen-source snapshot in `source/`. This internal AI-assisted source inspection is separate from the fresh compiler and transitive-axiom evidence in `fresh-replay/` and `supplemental-audit/`.

## Endpoint and genuine model

`ParityFour.sharp_parity_classification` (`SharpClassification.lean:40–52`) has only `ρ,c₀ : ℝ`, `0 < |ρ|`, and `|ρ| ≤ 1` as its outer parameters and assumptions. All real parameter values are finite in this model. The cases ρ=±1 are included.

`ParityWalsh.lean:22–43` uses sixteen four-spin states, data mass `(1+ρ parity(s))/16`, a positive exponential partition function, normalized model mass, and the exact data-weighted log normalized probability. `sum_dataMass`, `dataMass_nonneg`, `partition_pos`, `modelMass_pos`, and `sum_modelMass` prove the required probability properties (`:77–99`). Zero data cells are harmless: the logarithm is applied to the strictly positive model probability, not the data mass.

`rbmPotential`, `hiddenWeight`, and `rbmMass` (`:174–183`) use the true four-visible/one-hidden-spin RBM. `hiddenWeight_eq` and `rbmMass_eq_modelMass` (`:185–200`) prove equality to direct hidden-spin summation; the factor two cancels upon normalization. The objective is not a surrogate unconstrained distribution problem.

`LocalMaximum.lean:13–16` defines `Parameters = (Fin 4 → ℝ) × ℝ × (Fin 4 → ℝ)`, the collapsed point `(0,c₀,0)`, and the objective. There are nine unrestricted real parameters with their ordinary finite-product topology. There is no custom topology or replacement definition of `IsLocalMax`.

## Five conjuncts

1. `Stationarity.lean:31–32,56–83` proves zero `HasDerivAt` at zero along every affine parameter ray `(tb,c₀+td,tw)`. This is precisely all-affine-direction stationarity, not a separately asserted Fréchet-derivative theorem.
2. Full-parameter local maximality holds iff `tanh(c₀)^2 < (3+2|ρ|)/(3+6|ρ|)`. The sufficient direction is genuinely uniform over neighborhoods: centered-potential control depends on all nine parameters (`LocalMaximum.lean:20–29,80–87`; `StableRegion.lean:57–119`). Arbitrary visible biases and unequal, signed, or zero weights are included.
3. At equality or above the threshold, `ParameterSaddle` means strict ascent and strict descent points in every full parameter neighborhood (`SaddleTopology.lean:10–12`). It is not merely an indefinite Hessian, a selected-ray test, or absence of local maximality.
4. `Nonglobal.lean:101–148` constructs a positive improving uniform/product mixture and realizes it by finite `b=w=β/2`, `c=log(t)/2`, `t>0`. Thus a strictly better finite RBM exists at every collapsed point. No explicit numerical optimizer or uniform parameter bound is claimed.
5. `LocalMaximum.lean:134–158` proves a continuous injective constant-objective hidden-bias line and distinct equal-likelihood points in every neighborhood. The local maxima are non-strict.

## Analytic bridges and boundary

Finite-state Parseval and pair-energy bounds, a quantitative logarithmic Jensen bound, and the exact quartic inequality `6|w₁w₂w₃w₄| ≤ Σ(i<j) wᵢ²wⱼ²` support the full-neighborhood sufficient proof. Exact iterated mean-value estimates in `MixedDifference` cover unequal and zero steps; all intermediate bounds are discharged before the final endpoint. There is no assumed Taylor remainder.

`QuarticEscape.lean:9–14,73–82` uses a genuine RBM ray with signed equal-magnitude weights and compensating visible biases. Its first three objective derivatives vanish. The favorable fourth derivative is

`24(1−u)[(3+6|ρ|)u−(3+2|ρ|)]`, where `u=tanh(c₀)^2`.

`QuarticJets.lean:99–115,168–192` connects these jets to the exact objective and proves eventual strict ascent through four successive mean-value arguments. At the critical equality, relative openness of local maximality along the constant-objective collapsed fiber conflicts with nearby exterior points (`SaddleTopology.lean:96–150`). This validates the boundary conclusion without claiming a fixed-hidden-bias improving straight ray at the boundary. Exact visible-bias descent supplies the other strict sign.

## Inspection outcome and documentation caveats

No mathematical statement mismatch, hidden analytic assumption, or advertised-scope restriction was found. The textual source scan found no proof placeholders, custom axioms, `unsafe`, `native_decide`, `extern`, or `implemented_by` shortcuts; the compiler's transitive axiom reports remain the authoritative dependency check.

Frozen comments are preserved even where historically stale:

- `Main.lean:9–10` says no saddle converse is asserted in “this formal package”; this describes the inherited strict-region layer, not the combined sharp endpoint.
- `QuarticEscape.lean:26` calls `escapeJet` “centered”; its potential is constant-shifted from the collapsed potential, not generally cube-mean-zero. The actual normalization is correctly handled by `objectiveJet`.
- `source/VERIFICATION.md` retains the recovery-time “fresh replay pending” status. The new dated receipt and logs, once complete, supersede that historical status. None of these comments changes a theorem or proof term.

## Prior mathematics and bounded candidate contribution

Collapsed Bernoulli-mixture stationary fibers are established background: Carreira-Perpiñán and Renals, *Practical identifiability of finite mixtures of multivariate Bernoulli distributions*, §3 ([author PDF](https://faculty.ucmerced.edu/mcarreira-perpinan/papers/neco00.pdf)). Fukumizu, Akaho, and Amari, *Critical Lines in Symmetry of Mixture Models and its Application to Component Splitting*, Theorem 3/Corollary 4, give sufficient classifications through the splitting Hessian ([proceedings PDF](https://proceedings.neurips.cc/paper_files/paper/2002/file/2d3acd3e240c61820625fff66a19938f-Paper.pdf)). Specializing that matrix to this balanced pairwise-independent law makes it zero; this specialization is an inference from their formula. Thus their second-order criterion does not settle the present quartic threshold or its full-neighborhood boundary. Mixture representation, Walsh methods, and mean-value tools are credited as prior mathematics.

The candidate contribution is the exact full-nine-parameter classification of the finite collapsed fiber for pure four-parity data, including the critical boundary and faithful Lean verification. Earlier bounded literature checking is not a priority certificate; this revalidation does not establish originality, eligibility, or acceptance.

## Concise organizer-review nomination

Nominate one nontrivial, parent-linked four-parity/one-hidden-unit sharp-landscape variation, subject to the organizers' target-status, modality, admission, and prior-status decisions under the [official handbook](https://rsihouse.ai/openmath/handbook.pdf), especially §§3.2, 4.1, 5, 7.1–7.2, and 8. It is not a complete resolution of broad OPDP89/AIM-PROBABILITY-0006. The sharp theorem upgrades the existing strict-region family: balanced, strict, saddle, and derivative endpoints add no separate family credit. No difficulty, probability, or points are assigned here.

## Exclusions

No claim about general RBMs, extra hidden units, arbitrary data, distribution-local maximality, strict trapping, attraction basins, EM dynamics, or training-time bounds is proved. Higher-dimensional extensions are outside this sharp theorem and remain ordinary only.

This is internal AI-assisted review, not appointed jury review, unconflicted external review, or external peer review. Formal replay is formal-check evidence only. Prior-status, admission, modality, and any release/submission gates remain for authorized organizer review.
