/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/
import A46969Conclusion

/-!
Candidate solution of OEIS A046969 conjecture I.
The definition and final theorem match Formal Conjectures OEIS/46969.lean.
The stronger formula is a(p)=12(2p-1) for the qualifying primes.
Mathematical novelty and competition acceptance require separate review.
-/
namespace OeisA46969

def a (n : ℕ) : ℕ :=
  if n = 0 then 0
  else
    let m := 2 * n
    let k := m * (m - 1)
    (bernoulli m / (k : ℚ)).den

theorem a_prime (p : ℕ) (hp : p.Prime) (hq : (2 * p - 1).Prime) (h3 : 3 < p) :
    a p = 12 * (2 * p - 1) := by
  simpa only [a, if_neg hp.ne_zero] using A46969Conclusion.denominator_formula p hp hq h3

theorem conjecture1 (p : ℕ) (hp : p.Prime) (hp' : (2 * p - 1).Prime) (h3 : 3 < p) :
    (a p / 12).Prime := by
  rw [a_prime p hp hp' h3, Nat.mul_div_right _ (by decide : 0 < 12)]
  exact hp'

#print axioms a_prime
#print axioms conjecture1
end OeisA46969
