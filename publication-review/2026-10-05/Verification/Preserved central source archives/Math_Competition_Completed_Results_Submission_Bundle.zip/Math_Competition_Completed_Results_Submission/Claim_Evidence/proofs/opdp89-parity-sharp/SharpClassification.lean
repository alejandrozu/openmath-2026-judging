import QuarticEscape
import SaddleTopology
import Stationarity

/-! Exact classification of the entire finite collapsed hidden-bias fiber.
The old strict-region package is imported unchanged; the new converse is proved
by fourth-order ascent outside and flat-fiber accumulation on the boundary. -/
noncomputable section
open scoped Topology
namespace ParityFour

theorem nonstable_not_local_max (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1)
    (houtside : (3+2*|ρ|)/(3+6*|ρ|) ≤ Real.tanh c₀ ^ 2) :
    ¬ IsLocalMax (objective ρ) (nullParameter c₀) := by
  rcases eq_or_lt_of_le houtside with heq | hlt
  · exact boundary_not_local_max_of_exterior ρ c₀ hρ heq.symm
      (fun c hc => exterior_not_local_max ρ c hρ hρ1 hc)
  · exact exterior_not_local_max ρ c₀ hρ hρ1 hlt

/-- The displayed strict threshold is both necessary and sufficient for a local
maximum in the full nine-dimensional parameter space. -/
theorem collapsed_local_max_iff (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1) :
    IsLocalMax (objective ρ) (nullParameter c₀) ↔
      Real.tanh c₀ ^ 2 < (3+2*|ρ|)/(3+6*|ρ|) := by
  constructor
  · intro hmax
    by_contra hn
    exact nonstable_not_local_max ρ c₀ hρ hρ1 (le_of_not_gt hn) hmax
  · exact parameter_local_maximum_of_spin_threshold ρ c₀ hρ hρ1

/-- Every finite collapsed point at or beyond the threshold admits both strict
signs of likelihood variation in every parameter neighborhood. -/
theorem nonstable_parameter_saddle (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1)
    (houtside : (3+2*|ρ|)/(3+6*|ρ|) ≤ Real.tanh c₀ ^ 2) :
    ParameterSaddle ρ (nullParameter c₀) :=
  collapsed_saddle_of_not_local_max ρ c₀ (nonstable_not_local_max ρ c₀ hρ hρ1 houtside)

/-- Complete finite-fiber classification, with stationarity, nonglobality, and
non-strictness stated explicitly. -/
theorem sharp_parity_classification (ρ c₀ : ℝ) (hρ : 0 < |ρ|) (hρ1 : |ρ| ≤ 1) :
    (∀ (b : Fin 4 → ℝ) (d : ℝ) (w : Fin 4 → ℝ),
      HasDerivAt (fun t => objective ρ (affineParameterRay c₀ b d w t)) 0 0) ∧
    (IsLocalMax (objective ρ) (nullParameter c₀) ↔
      Real.tanh c₀ ^ 2 < (3+2*|ρ|)/(3+6*|ρ|)) ∧
    ((3+2*|ρ|)/(3+6*|ρ|) ≤ Real.tanh c₀ ^ 2 → ParameterSaddle ρ (nullParameter c₀)) ∧
    (∃ θ : Parameters, objective ρ (nullParameter c₀) < objective ρ θ) ∧
    (∀ U : Set Parameters, U ∈ nhds (nullParameter c₀) →
      ∃ θ : Parameters, θ ∈ U ∧ θ ≠ nullParameter c₀ ∧
        objective ρ θ = objective ρ (nullParameter c₀)) := by
  exact ⟨collapsed_directional_stationary ρ c₀, collapsed_local_max_iff ρ c₀ hρ hρ1,
    nonstable_parameter_saddle ρ c₀ hρ hρ1,
    collapsed_not_global ρ c₀ (abs_pos.mp hρ), collapsed_point_not_strict ρ c₀⟩

#print axioms collapsed_local_max_iff
#print axioms nonstable_parameter_saddle
#print axioms sharp_parity_classification
end ParityFour
