import Mathlib
import Lean
import FormalConjectures.Arxiv.«2501.03234».ArithmeticSumS

set_option google.answer "postpone"

-- Already imported, audited repository definitions (do not redeclare):
-- def Arxiv.«2501.03234».S : ℕ → ℤ := fun k => ∑ h ∈ Finset.Ico 1 k, Arxiv.«2501.03234».S' h k

namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit

def ga_half_range (k : Nat) : Finset Nat := Finset.Ico 1 ((k - 1) / 2 + 1)

def ga_half_sum (k j : Nat) : Int :=
  ∑ x ∈ ga_half_range k, (-1 : Int) ^ ((x * j) / k)

theorem ga_half_sum_add_eq_zero_of_modEq_neg_one (k a b : Nat) (hk : Nat.Prime k) (hodd : Odd k)
    (ha : 1 ≤ a) (ha' : a < k) (hb : 1 ≤ b) (hb' : b < k)
    (hoa : Odd a) (hob : Odd b) (hab : a * b % k = k - 1) :
    ga_half_sum k a + ga_half_sum k b = 0 := by
  have hk_ge2 : 2 ≤ k := Nat.Prime.two_le hk
  have hk2 : k % 2 = 1 := by
    obtain ⟨tt, htt⟩ := hodd
    omega
  have hd : 2 ∣ k - 1 := by
    rw [Nat.dvd_iff_mod_eq_zero]
    omega
  set m := (k - 1) / 2 with hm
  have h2m : k = 2 * m + 1 := by
    have h : (k - 1) / 2 * 2 = k - 1 := Nat.div_mul_cancel hd
    omega
  have lt2 : ∀ p q : Nat, (2 * p + q) % 2 = q % 2 := by
    intro p q
    omega
  let R : Finset Nat := ga_half_range k
  have memR : ∀ x : Nat, x ∈ R ↔ 1 ≤ x ∧ x ≤ m := by
    intro x
    show x ∈ Finset.Ico 1 ((k - 1) / 2 + 1) ↔ 1 ≤ x ∧ x ≤ m
    rw [Finset.mem_Ico]
    omega
  have hnz : ∀ (j x : Nat), 1 ≤ j → j < k → 1 ≤ x → x < k → (j * x) % k ≠ 0 := by
    intro j x hj1 hjk hx1 hxk h
    have h1 : k ∣ j * x := by
      rw [Nat.dvd_iff_mod_eq_zero]
      exact h
    cases (Nat.Prime.dvd_mul hk).mp h1 with
    | inl hka =>
      have hle := Nat.le_of_dvd hj1 hka
      omega
    | inr hkx =>
      have hle := Nat.le_of_dvd hx1 hkx
      omega
  have hres_bound :
      ∀ (j x : Nat), 1 ≤ j → j < k → x ∈ R → 1 ≤ (j * x) % k ∧ (j * x) % k ≤ k - 1 := by
    intro j x hj1 hjk hx
    obtain ⟨hx1, hxm⟩ := (memR x).mp hx
    have h1 : (j * x) % k < k := Nat.mod_lt _ (by omega)
    have h2 : (j * x) % k ≠ 0 := hnz j x hj1 hjk hx1 (by omega)
    exact ⟨by omega, by omega⟩
  let u (x : Nat) : Nat := (a * x) % k
  let s (x : Nat) : Nat := if u x ≤ m then u x else k - u x
  let v (y : Nat) : Nat := (b * y) % k
  let t (y : Nat) : Nat := if v y ≤ m then v y else k - v y
  have hs : ∀ x, s x = if u x ≤ m then u x else k - u x := fun _ => rfl
  have hu1 : ∀ x ∈ R, 1 ≤ u x ∧ u x ≤ k - 1 := by
    intro x hx
    show 1 ≤ (a * x) % k ∧ (a * x) % k ≤ k - 1
    exact hres_bound a x ha ha' hx
  have s_mem : ∀ x ∈ R, s x ∈ R := by
    intro x hx
    obtain ⟨h1, h2⟩ := hu1 x hx
    rw [memR, hs]
    split <;> omega
  have hab2 : (a * b : ℕ) = k * ((a * b) / k) + (k - 1) := by
    have h := Nat.div_add_mod (a * b) k
    rw [hab] at h
    exact h.symm
  have hk1 : ((k - 1 : ℕ) : ℤ) = (k : ℤ) - 1 := by
    rw [Nat.cast_sub (by omega : (1 : ℕ) ≤ k), Nat.cast_one]
  have hcongr : ∀ x ∈ R, ∃ C : ℤ, (b : ℤ) * ((u x : ℕ) : ℤ) + (x : ℤ) = (k : ℤ) * C := by
    intro x hx
    have hax_nat : a * x = k * ((a * x) / k) + u x := (Nat.div_add_mod (a * x) k).symm
    have haxI : (a : ℤ) * (x : ℤ) = (k : ℤ) * (((a * x) / k : ℕ) : ℤ) + ((u x : ℕ) : ℤ) := by
      exact_mod_cast hax_nat
    have hU : ((u x : ℕ) : ℤ) = (a : ℤ) * (x : ℤ) - (k : ℤ) * (((a * x) / k : ℕ) : ℤ) := by
      rw [haxI]
      ring
    have habI :
        (a : ℤ) * (b : ℤ) = (k : ℤ) * (((a * b) / k : ℕ) : ℤ) + ((k - 1 : ℕ) : ℤ) := by
      exact_mod_cast hab2
    have hab3 : (a : ℤ) * (b : ℤ) = (k : ℤ) * (((a * b) / k : ℕ) : ℤ) + ((k : ℤ) - 1) := by
      rw [habI, hk1]
    have key : (a : ℤ) * (b : ℤ) * (x : ℤ)
        = (k : ℤ) * (((a * b) / k : ℕ) : ℤ) * (x : ℤ) + ((k : ℤ) - 1) * (x : ℤ) := by
      rw [hab3]
      ring
    have hmain : (b : ℤ) * ((u x : ℕ) : ℤ) + (x : ℤ)
        = (k : ℤ) * ((((a * b) / k : ℕ) : ℤ) * (x : ℤ) + (x : ℤ)
            - (b : ℤ) * (((a * x) / k : ℕ) : ℤ)) := by
      rw [hU]
      calc (b : ℤ) * ((a : ℤ) * (x : ℤ) - (k : ℤ) * (((a * x) / k : ℕ) : ℤ)) + (x : ℤ)
          = (a : ℤ) * (b : ℤ) * (x : ℤ) - (b : ℤ) * ((k : ℤ) * (((a * x) / k : ℕ) : ℤ))
              + (x : ℤ) := by ring
        _ = ((k : ℤ) * (((a * b) / k : ℕ) : ℤ) * (x : ℤ) + ((k : ℤ) - 1) * (x : ℤ))
              - (b : ℤ) * ((k : ℤ) * (((a * x) / k : ℕ) : ℤ)) + (x : ℤ) := by rw [key]
        _ = (k : ℤ) * ((((a * b) / k : ℕ) : ℤ) * (x : ℤ) + (x : ℤ)
              - (b : ℤ) * (((a * x) / k : ℕ) : ℤ)) := by ring
    exact ⟨_, hmain⟩
  have hmul_mod : ∀ (c : ℤ) (r : ℕ),
      (0 : ℤ) ≤ (r : ℤ) → (r : ℤ) < (k : ℤ) → ((k : ℤ) * c + (r : ℤ)) % (k : ℤ) = (r : ℤ) := by
    intro c r h0 h1
    rw [Int.add_emod, Int.mul_emod, Int.emod_self, Int.zero_mul, Int.zero_emod, Int.zero_add,
      Int.emod_eq_of_lt h0 h1, Int.emod_eq_of_lt h0 h1]
  have hres1 : ∀ x ∈ R, (b * u x) % k = k - x := by
    intro x hx
    obtain ⟨hx1, hxm⟩ := (memR x).mp hx
    obtain ⟨C, hC⟩ := hcongr x hx
    have h2 : (b : ℤ) * ((u x : ℕ) : ℤ) = (k : ℤ) * C - (x : ℤ) := by
      rw [← hC]
      ring
    have hbU : ((b * u x : ℕ) : ℤ) = (k : ℤ) * (C - 1) + ((k : ℤ) - (x : ℤ)) := by
      rw [Nat.cast_mul, h2]
      ring
    have hkx : ((k : ℤ) - (x : ℤ)) = ((k - x : ℕ) : ℤ) :=
      (Nat.cast_sub (by omega : x ≤ k)).symm
    have hI : ((b * u x : ℕ) : ℤ) % (k : ℤ) = ((k - x : ℕ) : ℤ) := by
      rw [hbU, hkx]
      exact hmul_mod (C - 1) (k - x) (by omega) (by omega)
    have h3 : (((b * u x) % k : ℕ) : ℤ) = ((k - x : ℕ) : ℤ) := by
      rw [Int.natCast_emod, hI]
    exact Nat.cast_inj.mp h3
  have hres2 : ∀ x ∈ R, (b * (k - u x)) % k = x := by
    intro x hx
    obtain ⟨hx1, hxm⟩ := (memR x).mp hx
    obtain ⟨hU1, hU2⟩ := hu1 x hx
    obtain ⟨C, hC⟩ := hcongr x hx
    have hU : (b : ℤ) * ((u x : ℕ) : ℤ) = (k : ℤ) * C - (x : ℤ) := by
      rw [← hC]
      ring
    have hh :
        (b : ℤ) * ((k - u x : ℕ) : ℤ) = (b : ℤ) * (k : ℤ) - (b : ℤ) * ((u x : ℕ) : ℤ) := by
      rw [Nat.cast_sub (by omega)]
      ring
    have hEq : (b : ℤ) * ((k - u x : ℕ) : ℤ) = (k : ℤ) * ((b : ℤ) - C) + (x : ℤ) := by
      rw [hh, hU]
      ring
    have hI : ((b * (k - u x) : ℕ) : ℤ) % (k : ℤ) = (x : ℤ) := by
      calc ((b * (k - u x) : ℕ) : ℤ) % (k : ℤ)
          = ((b : ℤ) * ((k - u x : ℕ) : ℤ)) % (k : ℤ) := by rw [Nat.cast_mul]
        _ = ((k : ℤ) * ((b : ℤ) - C) + (x : ℤ)) % (k : ℤ) := by rw [hEq]
        _ = (x : ℤ) := hmul_mod ((b : ℤ) - C) x (by omega) (by omega)
    have h3 : (((b * (k - u x)) % k : ℕ) : ℤ) = ((x : ℕ) : ℤ) := by
      rw [Int.natCast_emod, hI]
    exact Nat.cast_inj.mp h3
  have tts : ∀ x ∈ R, t (s x) = x := by
    intro x hx
    obtain ⟨hx1, hxm⟩ := (memR x).mp hx
    by_cases hc : u x ≤ m
    · have hv : (b * s x) % k = k - x := by
        rw [hs, if_pos hc]
        exact hres1 x hx
      have hgt : ¬ ((b * s x) % k ≤ m) := by
        rw [hv]
        omega
      show (if (b * s x) % k ≤ m then (b * s x) % k else k - (b * s x) % k) = x
      rw [if_neg hgt, hv]
      omega
    · have hv : (b * s x) % k = x := by
        rw [hs, if_neg hc]
        exact hres2 x hx
      have hle : (b * s x) % k ≤ m := by
        rw [hv]
        omega
      show (if (b * s x) % k ≤ m then (b * s x) % k else k - (b * s x) % k) = x
      rw [if_pos hle, hv]
  have hinj : Set.InjOn s (R : Set Nat) := by
    intro x hx y hy hxy
    have h1 : t (s x) = x := tts x hx
    have h2 : t (s y) = y := tts y hy
    rw [← hxy] at h2
    exact h1.symm.trans h2
  have himage : R.image s = R := by
    refine Finset.eq_of_subset_of_card_le ?_ ?_
    · intro z hz
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hz
      exact s_mem x hx
    · rw [Finset.card_image_of_injOn hinj]
  have haodd : a % 2 = 1 := by
    obtain ⟨aa, haa⟩ := hoa
    omega
  have hbodd : b % 2 = 1 := by
    obtain ⟨bb, hbb⟩ := hob
    omega
  have parity_lemma : ∀ (j x q w : Nat), j % 2 = 1 → k * q + w = j * x → q % 2 = (x + w) % 2 := by
    intro j x q w hj h
    obtain ⟨aa, hj2⟩ : ∃ aa, j = 2 * aa + 1 := ⟨j / 2, by omega⟩
    rw [hj2] at h
    have h1 : (2 * aa + 1) * x = 2 * (aa * x) + x := by ring
    have e1 : ((2 * aa + 1) * x) % 2 = x % 2 := by
      rw [h1, lt2]
    have h2 : k * q + w = 2 * (m * q) + (q + w) := by
      rw [h2m]
      ring
    have e2 : (k * q + w) % 2 = (q + w) % 2 := by
      rw [h2, lt2]
    have e3 : x % 2 = (q + w) % 2 := by
      rw [← e1, ← e2, h]
    omega
  have cancel : ∀ (r s' : Nat), r % 2 ≠ s' % 2 → (-1 : Int) ^ r + (-1 : Int) ^ s' = 0 := by
    intro r s' hne
    rw [neg_one_pow_eq_pow_mod_two r, neg_one_pow_eq_pow_mod_two s']
    have h1 : r % 2 = 0 ∨ r % 2 = 1 := Nat.mod_two_eq_zero_or_one r
    have h2 : s' % 2 = 0 ∨ s' % 2 = 1 := Nat.mod_two_eq_zero_or_one s'
    rcases h1 with e | e
    · rcases h2 with f | f
      · exfalso
        apply hne
        rw [e, f]
      · rw [e, f]
        norm_num
    · rcases h2 with f | f
      · rw [e, f]
        norm_num
      · exfalso
        apply hne
        rw [e, f]
  have hreindex :
      ∑ x ∈ R, (-1 : Int) ^ ((x * b) / k) = ∑ x ∈ R, (-1 : Int) ^ ((b * s x) / k) := by
    calc
      ∑ x ∈ R, (-1 : Int) ^ ((x * b) / k)
        = ∑ z ∈ R.image s, (-1 : Int) ^ ((z * b) / k) := by rw [himage]
      _ = ∑ x ∈ R, (-1 : Int) ^ ((s x * b) / k) := by
          rw [Finset.sum_image hinj]
      _ = ∑ x ∈ R, (-1 : Int) ^ ((b * s x) / k) := by
          apply Finset.sum_congr rfl
          intro x _
          rw [Nat.mul_comm]
  have term : ∀ x ∈ R,
      (-1 : Int) ^ ((x * a) / k) + (-1 : Int) ^ ((b * s x) / k) = 0 := by
    intro x hx
    obtain ⟨hx1, hxm⟩ := (memR x).mp hx
    obtain ⟨hU1, hU2⟩ := hu1 x hx
    have hax : k * ((a * x) / k) + u x = a * x := Nat.div_add_mod (a * x) k
    have hq : ((a * x) / k) % 2 = (x + u x) % 2 :=
      parity_lemma a x ((a * x) / k) (u x) haodd hax
    apply cancel
    rw [Nat.mul_comm x a]
    by_cases hc : u x ≤ m
    · rw [hs, if_pos hc]
      have hby : k * ((b * u x) / k) + (k - x) = b * u x := by
        have h := Nat.div_add_mod (b * u x) k
        rw [hres1 x hx] at h
        exact h
      have hq' : ((b * u x) / k) % 2 = (u x + (k - x)) % 2 :=
        parity_lemma b (u x) ((b * u x) / k) (k - x) hbodd hby
      omega
    · rw [hs, if_neg hc]
      have hbkU : k * ((b * (k - u x)) / k) + x = b * (k - u x) := by
        have h := Nat.div_add_mod (b * (k - u x)) k
        rw [hres2 x hx] at h
        exact h
      have hq' : ((b * (k - u x)) / k) % 2 = ((k - u x) + x) % 2 :=
        parity_lemma b (k - u x) ((b * (k - u x)) / k) x hbodd hbkU
      omega
  calc ga_half_sum k a + ga_half_sum k b
      = (∑ x ∈ R, (-1 : Int) ^ ((x * a) / k)) + ∑ x ∈ R, (-1 : Int) ^ ((x * b) / k) := by
        show (∑ x ∈ ga_half_range k, (-1 : Int) ^ ((x * a) / k)) +
            ∑ x ∈ ga_half_range k, (-1 : Int) ^ ((x * b) / k) = _
        rw [show ga_half_range k = R from rfl]
      _ = (∑ x ∈ R, (-1 : Int) ^ ((x * a) / k)) + ∑ x ∈ R, (-1 : Int) ^ ((b * s x) / k) := by
        rw [hreindex]
      _ = ∑ x ∈ R, ((-1 : Int) ^ ((x * a) / k) + (-1 : Int) ^ ((b * s x) / k)) :=
        Finset.sum_add_distrib.symm
      _ = 0 := Finset.sum_eq_zero term

theorem ga_half_sum_eq_parity_card (k j : Nat) :
    ga_half_sum k j =
      (((ga_half_range k).filter (fun x => Even ((x * j) / k))).card : Int) -
      (((ga_half_range k).filter (fun x => Odd ((x * j) / k))).card : Int) := by
  have hneg : ∀ n : ℕ, (-1 : Int) ^ n = if Even n then (1 : Int) else -1 := by
    intro n
    by_cases h : Even n
    · rw [if_pos h, h.neg_one_pow]
    · rw [if_neg h, (Nat.not_even_iff_odd.mp h).neg_one_pow]
  have h1 : ∀ x ∈ (ga_half_range k).filter (fun x => Even ((x * j) / k)),
      (if Even ((x * j) / k) then (1 : Int) else -1) = 1 := by
    intro x hx
    rw [if_pos (Finset.mem_filter.mp hx).2]
  have h2 : ∀ x ∈ (ga_half_range k).filter (fun x => ¬ Even ((x * j) / k)),
      (if Even ((x * j) / k) then (1 : Int) else -1) = -1 := by
    intro x hx
    rw [if_neg (Finset.mem_filter.mp hx).2]
  have hfilt : (ga_half_range k).filter (fun x => ¬ Even ((x * j) / k)) =
      (ga_half_range k).filter (fun x => Odd ((x * j) / k)) := by
    apply Finset.ext
    intro x
    rw [Finset.mem_filter, Finset.mem_filter]
    exact ⟨fun h => ⟨h.1, Nat.not_even_iff_odd.mp h.2⟩, fun h => ⟨h.1, Nat.not_even_iff_odd.mpr h.2⟩⟩
  unfold ga_half_sum
  rw [Finset.sum_congr rfl (fun x _ => hneg ((x * j) / k))]
  rw [← Finset.sum_filter_add_sum_filter_not (ga_half_range k) (fun x => Even ((x * j) / k))
      (fun x => if Even ((x * j) / k) then (1 : Int) else -1)]
  rw [Finset.sum_congr rfl h1, Finset.sum_congr rfl h2]
  rw [Finset.sum_const, Finset.sum_const, ← hfilt]
  simp only [nsmul_eq_mul, mul_one, mul_neg, one_mul, sub_eq_add_neg]

def ga_sum_terms (k : Nat) : Finset Nat := Finset.Ico 1 k

theorem ga_prime_odd_ge_three (k : Nat) (hk : Nat.Prime k) (hodd : Odd k) : 3 <= k := by
  obtain ⟨m, rfl⟩ := hodd
  have h := Nat.Prime.two_le hk
  omega

theorem ga_sum_terms_eq_Ico (k : Nat) : ga_sum_terms k = Finset.Ico 1 k := by rfl

theorem ga_filter_odd_contains_one (k : Nat) (hk : Nat.Prime k) (hodd : Odd k) :
    1 ∈ Finset.filter Odd (ga_sum_terms k) := by
  have h3 : 3 ≤ k := ga_prime_odd_ge_three k hk hodd
  have h1 : 1 ∈ ga_sum_terms k := by
    rw [ga_sum_terms_eq_Ico]
    exact Finset.mem_Ico.mpr ⟨by omega, by omega⟩
  exact Finset.mem_filter.mpr ⟨h1, ⟨0, rfl⟩⟩

theorem ga_odd_half_sum_eq_one_add_tail (k : Nat) (hk : Nat.Prime k) (hodd : Odd k) :
    ∑ j ∈ Finset.filter Odd (ga_sum_terms k), ga_half_sum k j =
      ga_half_sum k 1 +
        ∑ j ∈ (Finset.filter Odd (ga_sum_terms k)).erase 1, ga_half_sum k j := by
  have h1 : 1 ∈ Finset.filter Odd (ga_sum_terms k) := ga_filter_odd_contains_one k hk hodd
  rw [← Finset.sum_erase_add (Finset.filter Odd (ga_sum_terms k)) (fun j => ga_half_sum k j) h1,
    add_comm]

def ga_odd_inv_search (k a y : Nat) : Nat :=
  match y with
  | 0 => 0
  | n + 1 =>
    let z := n + 1
    if Nat.bodd z && ((z * a) % k == 1 || (z * a) % k == k - 1) then
      z
    else
      ga_odd_inv_search k a n

def ga_odd_inv (k a : Nat) : Nat := ga_odd_inv_search k a (k - 1)

theorem ga_odd_inv_mod_product (k j : Nat) (hk : Nat.Prime k) (hj : j ∈ ga_sum_terms k) :
    (j * ga_odd_inv k j) % k = 1 ∨ (j * ga_odd_inv k j) % k = k - 1 := by
  obtain ⟨hj1, hjk⟩ := Finset.mem_Ico.mp hj
  have hk2 : 2 ≤ k := Nat.Prime.two_le hk
  have hmod1 : ∀ x : ℕ, k ∣ x + (k - 1) → x % k = 1 := by
    intro x ⟨t, ht⟩
    have hxk : x + k = k * t + 1 := by omega
    have h1 : (x + k) % k = x % k := by rw [Nat.add_mod, Nat.mod_self, Nat.add_zero, Nat.mod_mod]
    have h2 : (k * t) % k = 0 := Nat.mod_eq_zero_of_dvd ⟨t, rfl⟩
    have h3 : (k * t + 1) % k = 1 % k := by
      rw [Nat.add_comm, Nat.add_mod, h2, Nat.add_zero, Nat.mod_mod]
    have h4 : 1 % k = 1 := Nat.mod_eq_of_lt (by omega)
    calc x % k = (x + k) % k := h1.symm
      _ = (k * t + 1) % k := congrArg (fun m => m % k) hxk
      _ = 1 % k := h3
      _ = 1 := h4
  have hmod2 : ∀ x : ℕ, k ∣ x + 1 → x % k = k - 1 := by
    intro x ⟨t, ht⟩
    have hxk : x + k = k * t + (k - 1) := by omega
    have h1 : (x + k) % k = x % k := by rw [Nat.add_mod, Nat.mod_self, Nat.add_zero, Nat.mod_mod]
    have h2 : (k * t) % k = 0 := Nat.mod_eq_zero_of_dvd ⟨t, rfl⟩
    have h3 : (k * t + (k - 1)) % k = (k - 1) % k := by
      rw [Nat.add_comm, Nat.add_mod, h2, Nat.add_zero, Nat.mod_mod]
    have h4 : (k - 1) % k = k - 1 := Nat.mod_eq_of_lt (Nat.sub_lt (by omega) (by omega))
    calc x % k = (x + k) % k := h1.symm
      _ = (k * t + (k - 1)) % k := congrArg (fun m => m % k) hxk
      _ = (k - 1) % k := h3
      _ = k - 1 := h4
  have search_ok : ∀ (K A N : ℕ),
      (∃ z, z ≤ N ∧ Nat.bodd z = true ∧ ((z * A) % K = 1 ∨ (z * A) % K = K - 1)) →
        ((ga_odd_inv_search K A N) * A) % K = 1 ∨
          ((ga_odd_inv_search K A N) * A) % K = K - 1 := by
    intro K A N
    induction N with
    | zero =>
        intro h
        obtain ⟨z, hz, hb, _⟩ := h
        have hz0 : z = 0 := by omega
        subst hz0
        exact absurd hb (by simp)
    | succ N ih =>
        intro h
        obtain ⟨z, hz, hb, hp⟩ := h
        have hrec : ga_odd_inv_search K A (N + 1) =
            if (Nat.bodd (N + 1) && (((N + 1) * A) % K == 1 || ((N + 1) * A) % K == K - 1)) = true
            then N + 1 else ga_odd_inv_search K A N := rfl
        by_cases hhead :
            (Nat.bodd (N + 1) && (((N + 1) * A) % K == 1 || ((N + 1) * A) % K == K - 1)) = true
        · rw [hrec, if_pos hhead]
          rw [Bool.and_eq_true, Bool.or_eq_true] at hhead
          obtain ⟨_, h2⟩ := hhead
          cases h2 with
          | inl h2 => exact Or.inl (by simpa using h2)
          | inr h2 => exact Or.inr (by simpa using h2)
        · rw [hrec, if_neg hhead]
          have hzN : z ≤ N := by
            by_contra hlt
            have hzz : z = N + 1 := by omega
            rw [hzz] at hb hp
            rcases hp with h1 | h1
            · refine hhead (by rw [Bool.and_eq_true, Bool.or_eq_true]; exact ⟨hb, Or.inl (by simpa using h1)⟩)
            · refine hhead (by rw [Bool.and_eq_true, Bool.or_eq_true]; exact ⟨hb, Or.inr (by simpa using h1)⟩)
          exact ih ⟨z, hzN, hb, hp⟩
  have hex : ∃ z : ℕ, z ≤ k - 1 ∧ Nat.bodd z = true ∧ ((z * j) % k = 1 ∨ (z * j) % k = k - 1) := by
    have hgcd : Nat.gcd j k = 1 := by
      have hd : Nat.gcd j k ∣ k := Nat.gcd_dvd_right j k
      rcases Nat.Prime.eq_one_or_self_of_dvd hk (Nat.gcd j k) hd with h | h
      · exact h
      · have hd2 : Nat.gcd j k ∣ j := Nat.gcd_dvd_left j k
        rw [h] at hd2
        have hle : k ≤ j := Nat.le_of_dvd (by omega) hd2
        omega
    obtain ⟨a, halta, ha⟩ := Nat.exists_mul_mod_eq_gcd (n := j) (k := k) (by omega)
    have ha1 : j * a % k = 1 := by rw [ha, hgcd]
    have ha2 : a * j % k = 1 := by rw [Nat.mul_comm, ha1]
    have hapos : 1 ≤ a := by
      by_contra h
      have hz0 : a = 0 := by omega
      rw [hz0] at ha2
      simp at ha2
    by_cases hbo : Nat.bodd a = true
    · exact ⟨a, by omega, hbo, Or.inl ha2⟩
    · have hkodd : Nat.bodd k = true := by
        rcases Nat.Prime.eq_two_or_odd hk with h2 | hm2
        · subst h2
          have hz1 : a = 1 := by omega
          subst hz1
          exact absurd (by simp : Nat.bodd 1 = true) hbo
        · have hex2 : ∃ m, k = 2 * m + 1 := ⟨k / 2, by omega⟩
          obtain ⟨m, rfl⟩ := hex2
          simp [Nat.bodd_add, Nat.bodd_mul]
      have hka : a ≤ k := by omega
      refine ⟨k - a, by omega, ?_, Or.inr ?_⟩
      · have hsum : k = a + (k - a) := by omega
        have hb2 : Nat.bodd (a + (k - a)) = true := by
          rw [← hsum]
          exact hkodd
        clear hsum hkodd
        rw [Nat.bodd_add] at hb2
        have haf : Nat.bodd a = false := by
          cases hc : Nat.bodd a with
          | true => exact absurd hc hbo
          | false => rfl
        rw [haf] at hb2
        cases h : Nat.bodd (k - a) with
        | true => rfl
        | false => simp_all
      · apply hmod2
        have hEq : a * j = k * (a * j / k) + 1 := by
          have hd := Nat.div_add_mod (a * j) k
          rw [ha2] at hd
          omega
        have hle : a * j ≤ k * j := Nat.mul_le_mul_right j (by omega : a ≤ k)
        have hsle : a * j / k ≤ j := by
          by_contra h
          have hlt : j < a * j / k := by omega
          have hmul : k * j < k * (a * j / k) := Nat.mul_lt_mul_of_pos_left hlt (by omega)
          omega
        have hkey : (k - a) * j + 1 = k * (j - a * j / k) := by
          have hsm : (k - a) * j = k * j - a * j := Nat.sub_mul k a j
          rw [hsm, Nat.mul_sub_left_distrib]
          omega
        exact ⟨j - a * j / k, hkey⟩
  obtain ⟨z, hz, hb, hp⟩ := hex
  have H := search_ok k j (k - 1) ⟨z, hz, hb, hp⟩
  show (j * ga_odd_inv_search k j (k - 1)) % k = 1 ∨
    (j * ga_odd_inv_search k j (k - 1)) % k = k - 1
  cases H with
  | inl h => exact Or.inl (by rw [Nat.mul_comm]; exact h)
  | inr h => exact Or.inr (by rw [Nat.mul_comm]; exact h)

theorem ga_odd_inv_range (k j : Nat) (hk : Nat.Prime k) (hj : j ∈ ga_sum_terms k) (hoddj : Odd j) :
    1 ≤ ga_odd_inv k j ∧ ga_odd_inv k j < k ∧ Odd (ga_odd_inv k j) := by
  have hsearch_zero : ∀ (a : Nat), ga_odd_inv_search k a 0 = 0 := by intro a; rfl
  have hsearch_succ : ∀ (a n : Nat), ga_odd_inv_search k a (n + 1) =
      if Nat.bodd (n + 1) && (((n + 1) * a) % k == 1 || ((n + 1) * a) % k == k - 1) then n + 1
      else ga_odd_inv_search k a n := by
    intro a n; rfl
  have hbodd_iff : ∀ (n : Nat), Nat.bodd n ↔ n % 2 = 1 := by intro n; simp [Nat.bodd]
  have hbeq : ∀ (m n : Nat), m = n → (m == n) = true := by intro m n h; simp_all
  have hand_true : ∀ (b c : Bool), (b && c) = true → b = true := by
    intro b c h
    cases b with
    | true => rfl
    | false => cases h
  have hand_and : ∀ (b c : Bool), b = true → c = true → (b && c) = true := by
    intro b c hb hc; subst hb; subst hc; rfl
  have hor_or_left : ∀ (b c : Bool), b = true → (b || c) = true := by
    intro b c h; subst h; rfl
  have hor_or_right : ∀ (b c : Bool), c = true → (b || c) = true := by
    intro b c h
    cases b with
    | true => rfl
    | false => exact h
  have hk2 : 2 ≤ k := hk.two_le
  have hbound : ∀ (a y : Nat), ga_odd_inv_search k a y ≤ y := by
    intro a y
    induction y with
    | zero => rw [hsearch_zero]
    | succ n ih =>
      rw [hsearch_succ]
      by_cases hc : (Nat.bodd (n + 1) && (((n + 1) * a) % k == 1 || ((n + 1) * a) % k == k - 1)) = true
      · rw [if_pos hc]
      · rw [if_neg hc]; omega
  have hodd_or_zero : ∀ (a y : Nat), Nat.bodd (ga_odd_inv_search k a y) ∨ ga_odd_inv_search k a y = 0 := by
    intro a y
    induction y with
    | zero => exact Or.inr (hsearch_zero a)
    | succ n ih =>
      rw [hsearch_succ]
      by_cases hc : (Nat.bodd (n + 1) && (((n + 1) * a) % k == 1 || ((n + 1) * a) % k == k - 1)) = true
      · rw [if_pos hc]; exact Or.inl (hand_true _ _ hc)
      · rw [if_neg hc]; exact ih
  have hpos_search : ∀ (a y : Nat),
      (∃ z, z ≤ y ∧ Nat.bodd z ∧ ((z * a) % k == 1 ∨ (z * a) % k == k - 1)) →
        1 ≤ ga_odd_inv_search k a y := by
    intro a y
    induction y with
    | zero =>
      intro h
      obtain ⟨z, hz, hzb, _⟩ := h
      have hz0 : z = 0 := by omega
      rw [hz0] at hzb
      exact absurd hzb (by simp [Nat.bodd])
    | succ n ih =>
      intro h
      rw [hsearch_succ]
      by_cases hc : (Nat.bodd (n + 1) && (((n + 1) * a) % k == 1 || ((n + 1) * a) % k == k - 1)) = true
      · rw [if_pos hc]; omega
      · rw [if_neg hc]
        obtain ⟨z, hz, hzb, hzc⟩ := h
        apply ih
        refine ⟨z, ?_, hzb, hzc⟩
        by_contra hcon
        have hz1 : z = n + 1 := by omega
        rw [hz1] at hzb hzc
        have hc' : (((n + 1) * a) % k == 1 || ((n + 1) * a) % k == k - 1) = true := by
          rcases hzc with h1 | h1
          · exact hor_or_left _ _ h1
          · exact hor_or_right _ _ h1
        have htrue : (Nat.bodd (n + 1) && (((n + 1) * a) % k == 1 || ((n + 1) * a) % k == k - 1)) = true :=
          hand_and _ _ hzb hc'
        exact hc htrue
  have hmem : 1 ≤ j ∧ j < k := by simpa [ga_sum_terms] using hj
  have hjk : ¬ k ∣ j := by
    intro h
    have := Nat.le_of_dvd (by omega : 0 < j) h
    omega
  have hdiv_lemma : ∀ a b : Nat, a % k = b % k → k ∣ a - b := by
    intro a b hab
    set A := a / k with hA
    set B := b / k with hB
    set r := a % k with hr
    set s := b % k with hs
    have ha : a = k * A + r := by rw [hA, hr]; exact (Nat.div_add_mod a k).symm
    have hb : b = k * B + s := by rw [hB, hs]; exact (Nat.div_add_mod b k).symm
    have hrs : r = s := hr.trans (hab.trans hs.symm)
    have h1 : a - b = k * A - k * B := by
      rw [ha, hb, hrs]
      exact Nat.add_sub_add_right (k * A) s (k * B)
    rw [h1, ← Nat.mul_sub_left_distrib]
    exact Nat.dvd_mul_right k (A - B)
  have hinj : Set.InjOn (fun z => (z * j) % k) ((Finset.Ico 1 k : Finset Nat) : Set Nat) := by
    intro x hx y hy hxy
    simp only [Finset.mem_coe, Finset.mem_Ico] at hx hy
    have hxy' : (x * j) % k = (y * j) % k := hxy
    have hd1 : k ∣ x - y := by
      have h : k ∣ x * j - y * j := hdiv_lemma (x * j) (y * j) hxy'
      rw [← Nat.sub_mul] at h
      rcases (Nat.Prime.dvd_mul hk).mp h with h1 | h2
      · exact h1
      · exact absurd h2 hjk
    have hd2 : k ∣ y - x := by
      have h : k ∣ y * j - x * j := hdiv_lemma (y * j) (x * j) hxy'.symm
      rw [← Nat.sub_mul] at h
      rcases (Nat.Prime.dvd_mul hk).mp h with h1 | h2
      · exact h1
      · exact absurd h2 hjk
    have hxley : x ≤ y := by
      by_contra hcon
      have hp : 0 < x - y := by omega
      have := Nat.le_of_dvd hp hd1
      omega
    have hylex : y ≤ x := by
      by_contra hcon
      have hp : 0 < y - x := by omega
      have := Nat.le_of_dvd hp hd2
      omega
    omega
  have hrange : Finset.image (fun z => (z * j) % k) (Finset.Ico 1 k) ⊆ Finset.Ico 1 k := by
    refine Finset.image_subset_iff.mpr ?_
    intro z hz
    rw [Finset.mem_Ico] at hz ⊢
    have hlt : (z * j) % k < k := Nat.mod_lt _ (by omega : 0 < k)
    have hne : (z * j) % k ≠ 0 := by
      intro h
      have hdvd : k ∣ z * j := Nat.dvd_of_mod_eq_zero h
      rcases (Nat.Prime.dvd_mul hk).mp hdvd with hz' | hj'
      · have := Nat.le_of_dvd (by omega : 0 < z) hz'
        omega
      · have := Nat.le_of_dvd (by omega : 0 < j) hj'
        omega
    exact ⟨by omega, hlt⟩
  have hcard : (Finset.image (fun z => (z * j) % k) (Finset.Ico 1 k)).card = (Finset.Ico 1 k).card :=
    Finset.card_image_of_injOn hinj
  have himg : Finset.image (fun z => (z * j) % k) (Finset.Ico 1 k) = Finset.Ico 1 k :=
    Finset.eq_of_subset_of_card_le hrange (Nat.le_of_eq hcard.symm)
  have hex : ∃ x, 1 ≤ x ∧ x < k ∧ (x * j) % k = 1 := by
    have h1 : (1 : Nat) ∈ Finset.Ico 1 k := by
      rw [Finset.mem_Ico]; omega
    rw [← himg] at h1
    obtain ⟨x, hx, hxeq⟩ := Finset.mem_image.mp h1
    rw [Finset.mem_Ico] at hx
    exact ⟨x, hx.1, hx.2, by simpa using hxeq⟩
  obtain ⟨x, hx1, hxk, hxm⟩ := hex
  have hmodkx : ((k - x) * j) % k = k - 1 := by
    have hsum : (k - x) * j + x * j = k * j := by
      rw [← Nat.add_mul, Nat.sub_add_cancel (by omega : x ≤ k)]
    have hmod : (((k - x) * j) % k + 1) % k = 0 := by
      calc (((k - x) * j) % k + 1) % k
          = (((k - x) * j) % k + (x * j) % k) % k := by rw [hxm]
        _ = ((k - x) * j + x * j) % k := (Nat.add_mod _ _ _).symm
        _ = (k * j) % k := by rw [hsum]
        _ = 0 := Nat.mul_mod_right k j
    have hdvd : k ∣ ((k - x) * j) % k + 1 := Nat.dvd_of_mod_eq_zero hmod
    have hlt : ((k - x) * j) % k < k := Nat.mod_lt _ (by omega : 0 < k)
    have hge : k ≤ ((k - x) * j) % k + 1 := Nat.le_of_dvd (by omega) hdvd
    omega
  have hz_exist : ∃ z, 1 ≤ z ∧ z < k ∧ Nat.bodd z ∧ ((z * j) % k == 1 ∨ (z * j) % k == k - 1) := by
    by_cases hbx : Nat.bodd x = true
    · exact ⟨x, hx1, hxk, hbx, Or.inl (hbeq _ _ hxm)⟩
    · have hx2 : x % 2 = 0 := by
        rw [hbodd_iff] at hbx
        have hmodb : x % 2 < 2 := Nat.mod_lt x (by decide : (0 : Nat) < 2)
        omega
      have hkoddt : ∃ q, k = 2 * q + 1 := by
        rcases hk.eq_two_or_odd with h | h
        · subst h
          have hx' : x = 1 := by omega
          rw [hx'] at hbx
          have hp : Nat.bodd 1 = true := rfl
          exact absurd hp hbx
        · exact ⟨k / 2, by omega⟩
      obtain ⟨q, hq⟩ := hkoddt
      have hparity : (k - x) % 2 = 1 := by
        omega
      refine ⟨k - x, by omega, by omega, ?_, Or.inr (hbeq _ _ hmodkx)⟩
      · rw [hbodd_iff]
        exact hparity
  obtain ⟨z, hz1, hzk, hzb, hzc⟩ := hz_exist
  have hr1 : 1 ≤ ga_odd_inv_search k j (k - 1) := hpos_search j (k - 1) ⟨z, by omega, hzb, hzc⟩
  have hr2 : ga_odd_inv_search k j (k - 1) < k := by
    have hb := hbound j (k - 1)
    omega
  have hr3 : Odd (ga_odd_inv_search k j (k - 1)) := by
    rcases hodd_or_zero j (k - 1) with hb | hb
    · rw [Nat.odd_iff]
      exact (hbodd_iff _).mp hb
    · have h1 : 1 ≤ ga_odd_inv_search k j (k - 1) := hr1
      omega
  exact ⟨hr1, hr2, hr3⟩

theorem ga_odd_inv_ne_one (k j : Nat) (hk : Nat.Prime k)
    (hj : j ∈ ga_sum_terms k) (hoddj : Odd j) (hj1 : j ≠ 1) :
    ga_odd_inv k j ≠ 1 := by
  intro h
  simp only [ga_sum_terms] at hj
  obtain ⟨_, hjk⟩ := Finset.mem_Ico.mp hj
  have hprod := ga_odd_inv_mod_product k j hk hj
  rw [h, Nat.mul_one, Nat.mod_eq_of_lt hjk] at hprod
  rcases hoddj with ⟨m, rfl⟩
  cases hprod with
  | inl he => exact hj1 he
  | inr he =>
    have hd : 2 ∣ k := ⟨m + 1, by omega⟩
    have hk2 : (2 : Nat) = k := (Nat.Prime.eq_one_or_self_of_dvd hk 2 hd).resolve_left (by decide)
    exact hj1 (by omega)

theorem ga_sum_nonneg_of_involution_pair (S : Finset Nat) (f : Nat -> Int) (tau : Nat -> Nat)
    (h_tau_mem : ∀ x ∈ S, tau x ∈ S)
    (h_tau_inv : ∀ x ∈ S, tau (tau x) = x)
    (h_pair : ∀ x ∈ S, 0 ≤ f x + f (tau x)) :
    0 ≤ ∑ x ∈ S, f x := by
  have hinj : Set.InjOn tau (S : Set Nat) := by
    intro x hx y hy h
    have h1 : tau (tau x) = tau (tau y) := by rw [h]
    rwa [h_tau_inv x hx, h_tau_inv y hy] at h1
  have himg : S.image tau = S := by
    apply Finset.ext
    intro x
    constructor
    · intro h
      obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp h
      exact h_tau_mem y hy
    · intro hx
      exact Finset.mem_image.mpr ⟨tau x, h_tau_mem x hx, h_tau_inv x hx⟩
  have hcomp : ∑ x ∈ S, f (tau x) = ∑ x ∈ S, f x := by
    rw [← Finset.sum_image hinj, himg]
  have hsum : ∑ x ∈ S, (f x + f (tau x)) = ∑ x ∈ S, f x + ∑ x ∈ S, f (tau x) :=
    Finset.sum_add_distrib
  have htwo : (2 : Int) * ∑ x ∈ S, f x = ∑ x ∈ S, (f x + f (tau x)) := by
    rw [hsum, hcomp, two_mul]
  have hnonneg : 0 ≤ ∑ x ∈ S, f x + ∑ x ∈ S, f x := by
    rw [← two_mul, htwo]
    exact Finset.sum_nonneg (fun x hx => h_pair x hx)
  linarith

#ga_audit_proof ga_half_sum_add_eq_zero_of_modEq_neg_one
#ga_audit_proof ga_half_sum_eq_parity_card
#ga_audit_proof ga_prime_odd_ge_three
#ga_audit_proof ga_sum_terms_eq_Ico
#ga_audit_proof ga_filter_odd_contains_one
#ga_audit_proof ga_odd_half_sum_eq_one_add_tail
#ga_audit_proof ga_odd_inv_mod_product
#ga_audit_proof ga_odd_inv_range
#ga_audit_proof ga_odd_inv_ne_one
#ga_audit_proof ga_sum_nonneg_of_involution_pair
