import Mathlib.Algebra.Quaternion
import Mathlib.Tactic

/-!
# A two-witness polynomial definition of the center of Hamilton quaternions

STATUS: compiled with Lean 4.34.1 and pinned mathlib on 1 October 2026.
The final declarations use only standard Lean axioms; no mathematical novelty is asserted.
Independent of Quaternion67Sampler.lean and of Lagrange's four-square theorem.

For additive commutators [a,b]=ab-ba, the single equation
  ([u,v]^2+4)^2 - [q,u]^2 - [q,v]^2 = 0
with two unrestricted existential quaternion variables u,v defines exactly
Q inside Quaternion Q and Z inside Quaternion Z (the Lipschitz order).
The polynomial has integer coefficients and no quaternion basis constants.

Source subquestion: AIM, Extensions of Hilbert's Tenth Problem, Question 7.
https://aimath.org/WWN/hilberts10th/hilberts10th.pdf
The mathematical definability outcome is known; this candidate does not claim
new open-problem progress or formalize an undecidability theorem.
-/

namespace OPDP67TwoWitness

open scoped Quaternion

abbrev HQ := Quaternion ℚ
abbrev OZ := Quaternion ℤ

def addComm {R : Type*} [CommRing R] (a b : Quaternion R) : Quaternion R :=
  a * b - b * a

def crossI {R : Type*} [CommRing R] (a b : Quaternion R) : R :=
  a.imJ * b.imK - a.imK * b.imJ

def crossJ {R : Type*} [CommRing R] (a b : Quaternion R) : R :=
  a.imK * b.imI - a.imI * b.imK

def crossK {R : Type*} [CommRing R] (a b : Quaternion R) : R :=
  a.imI * b.imJ - a.imJ * b.imI

def crossSq {R : Type*} [CommRing R] (a b : Quaternion R) : R :=
  crossI a b ^ 2 + crossJ a b ^ 2 + crossK a b ^ 2

theorem addComm_sq {R : Type*} [CommRing R] (a b : Quaternion R) :
    addComm a b ^ 2 = ((-4 * crossSq a b : R) : Quaternion R) := by
  ext <;> simp [addComm, crossSq, crossI, crossJ, crossK, pow_two] <;> ring

def centerPolynomial {R : Type*} [CommRing R]
    (q u v : Quaternion R) : Quaternion R :=
  (addComm u v ^ 2 + 4) ^ 2 - addComm q u ^ 2 - addComm q v ^ 2

def scalarPolynomial {R : Type*} [CommRing R]
    (q u v : Quaternion R) : R :=
  16 * (crossSq u v - 1) ^ 2 + 4 * crossSq q u + 4 * crossSq q v

theorem centerPolynomial_eq_scalar {R : Type*} [CommRing R]
    (q u v : Quaternion R) :
    centerPolynomial q u v = ((scalarPolynomial (R := R) q u v : R) : Quaternion R) := by
  unfold centerPolynomial
  simp only [addComm_sq]
  ext <;> simp [scalarPolynomial, pow_two, QuaternionAlgebra.re_ofNat,
    QuaternionAlgebra.imI_ofNat, QuaternionAlgebra.imJ_ofNat, QuaternionAlgebra.imK_ofNat] <;> ring

/-- Dot product of two imaginary cross products. -/
def crossDot {R : Type*} [CommRing R]
    (a b c d : Quaternion R) : R :=
  crossI a b * crossI c d + crossJ a b * crossJ c d + crossK a b * crossK c d

/-- Dot product of an imaginary cross product with an imaginary vector. -/
def crossDotVec {R : Type*} [CommRing R] (a b c : Quaternion R) : R :=
  crossI a b * c.imI + crossJ a b * c.imJ + crossK a b * c.imK

/-- First coordinate of the division-free simultaneous-centralizer certificate. -/
theorem cross_certificate_I {R : Type*} [CommRing R] (q u v : Quaternion R) :
    q.imI * crossSq u v =
      u.imI * crossDot q v u v - v.imI * crossDot q u u v +
        crossI u v * crossDotVec q u v := by
  unfold crossSq crossDot crossDotVec crossI crossJ crossK
  ring

/-- Second coordinate of the same polynomial identity. -/
theorem cross_certificate_J {R : Type*} [CommRing R] (q u v : Quaternion R) :
    q.imJ * crossSq u v =
      u.imJ * crossDot q v u v - v.imJ * crossDot q u u v +
        crossJ u v * crossDotVec q u v := by
  unfold crossSq crossDot crossDotVec crossI crossJ crossK
  ring

/-- Third coordinate of the same polynomial identity. -/
theorem cross_certificate_K {R : Type*} [CommRing R] (q u v : Quaternion R) :
    q.imK * crossSq u v =
      u.imK * crossDot q v u v - v.imK * crossDot q u u v +
        crossK u v * crossDotVec q u v := by
  unfold crossSq crossDot crossDotVec crossI crossJ crossK
  ring

def qi {R : Type*} [CommRing R] : Quaternion R := ⟨0, 1, 0, 0⟩
def qj {R : Type*} [CommRing R] : Quaternion R := ⟨0, 0, 1, 0⟩

theorem centerPolynomial_scalar_witness {R : Type*} [CommRing R] (r : R) :
    centerPolynomial (r : Quaternion R) qi qj = 0 := by
  ext <;> simp [centerPolynomial, addComm, qi, qj, pow_two, QuaternionAlgebra.re_ofNat,
    QuaternionAlgebra.imI_ofNat, QuaternionAlgebra.imJ_ofNat, QuaternionAlgebra.imK_ofNat] <;> ring

section Ordered

variable {R : Type*} [CommRing R] [LinearOrder R] [IsStrictOrderedRing R]

theorem crossSq_nonneg (a b : Quaternion R) : 0 ≤ crossSq a b := by
  unfold crossSq
  positivity

theorem crossSq_zero_components (a b : Quaternion R) (h : crossSq a b = 0) :
    crossI a b = 0 ∧ crossJ a b = 0 ∧ crossK a b = 0 := by
  have hi := sq_nonneg (crossI a b)
  have hj := sq_nonneg (crossJ a b)
  have hk := sq_nonneg (crossK a b)
  unfold crossSq at h
  have hi0 : crossI a b ^ 2 = 0 := by linarith
  have hj0 : crossJ a b ^ 2 = 0 := by linarith
  have hk0 : crossK a b ^ 2 = 0 := by linarith
  exact ⟨sq_eq_zero_iff.mp hi0, sq_eq_zero_iff.mp hj0, sq_eq_zero_iff.mp hk0⟩

/-- Positivity is used only for scalar sums of squares in the ordered base ring. -/
theorem centerPolynomial_zero_constraints (q u v : Quaternion R)
    (h : centerPolynomial q u v = 0) :
    crossSq u v = 1 ∧ crossSq q u = 0 ∧ crossSq q v = 0 := by
  have hs := congrArg (fun x : Quaternion R => x.re) h
  simp only [centerPolynomial_eq_scalar, Quaternion.re_coe, Quaternion.re_zero] at hs
  unfold scalarPolynomial at hs
  have hu := crossSq_nonneg q u
  have hv := crossSq_nonneg q v
  have huv := sq_nonneg (crossSq u v - 1)
  have he : (crossSq u v - 1) ^ 2 = 0 := by linarith
  have he' : crossSq u v - 1 = 0 := sq_eq_zero_iff.mp he
  refine ⟨?_, ?_, ?_⟩ <;> linarith

/-- The coordinate certificate proves scalarity without importing a centralizer theorem. -/
theorem centerPolynomial_zero_is_scalar (q u v : Quaternion R)
    (h : centerPolynomial q u v = 0) : q = (q.re : Quaternion R) := by
  obtain ⟨huv, hqu, hqv⟩ := centerPolynomial_zero_constraints q u v h
  obtain ⟨huI, huJ, huK⟩ := crossSq_zero_components q u hqu
  obtain ⟨hvI, hvJ, hvK⟩ := crossSq_zero_components q v hqv
  have hi : q.imI = 0 := by
    simpa [crossDot, crossDotVec, huv, huI, huJ, huK, hvI, hvJ, hvK]
      using cross_certificate_I q u v
  have hj : q.imJ = 0 := by
    simpa [crossDot, crossDotVec, huv, huI, huJ, huK, hvI, hvJ, hvK]
      using cross_certificate_J q u v
  have hk : q.imK = 0 := by
    simpa [crossDot, crossDotVec, huv, huI, huJ, huK, hvI, hvJ, hvK]
      using cross_certificate_K q u v
  ext <;> simp [hi, hj, hk]

/-- The same explicit equation works over any linearly ordered commutative ring. -/
theorem scalar_ring_existentially_defined (q : Quaternion R) :
    (∃ u v : Quaternion R, centerPolynomial q u v = 0) ↔
      ∃ r : R, q = (r : Quaternion R) := by
  constructor
  · rintro ⟨u, v, h⟩
    exact ⟨q.re, centerPolynomial_zero_is_scalar q u v h⟩
  · rintro ⟨r, rfl⟩
    exact ⟨qi, qj, centerPolynomial_scalar_witness r⟩

end Ordered

/-- One integer-coefficient equation defines Q inside Hamilton's rational quaternions. -/
theorem rationals_existentially_defined (q : HQ) :
    (∃ u v : HQ, centerPolynomial q u v = 0) ↔ ∃ r : ℚ, q = (r : HQ) :=
  scalar_ring_existentially_defined q

/-- One integer-coefficient equation defines scalar Z inside the Lipschitz order. -/
theorem integers_existentially_defined (q : OZ) :
    (∃ u v : OZ, centerPolynomial q u v = 0) ↔ ∃ z : ℤ, q = (z : OZ) :=
  scalar_ring_existentially_defined q

/-- Fully expanded final integral statement, making the precise polynomial visible. -/
theorem integers_defined_by_explicit_equation (q : OZ) :
    (∃ u v : OZ,
      ((u * v - v * u) ^ 2 + 4) ^ 2 -
        (q * u - u * q) ^ 2 - (q * v - v * q) ^ 2 = 0) ↔
      ∃ z : ℤ, q = (z : OZ) := by
  simpa only [centerPolynomial, addComm] using integers_existentially_defined q

end OPDP67TwoWitness
