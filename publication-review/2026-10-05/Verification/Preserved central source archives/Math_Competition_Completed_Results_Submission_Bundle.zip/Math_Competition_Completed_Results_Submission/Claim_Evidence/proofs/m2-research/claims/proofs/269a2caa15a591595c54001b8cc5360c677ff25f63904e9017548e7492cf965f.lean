import Mathlib
import Lean
import FormalConjectures.ErdosProblems.«887»

set_option google.answer "postpone"


namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit

def ga_product8 (m : Nat) : Nat :=
  m * (m + 1) * (m + 2) * (m + 3) * (m + 4) * (m + 5) * (m + 6) * (m + 7)

theorem ga_infinite_of_exists_large {P : Nat -> Prop}
    (h : ∀ x : Nat, ∃ n : Nat, x < n ∧ P n) :
    Infinite {n : Nat | P n} := by
  classical
  let step : {n : Nat // P n} → {n : Nat // P n} :=
    fun a => ⟨Nat.find (h (a.val + 1)), And.right (Nat.find_spec (h (a.val + 1)))⟩
  let g : ℕ → {n : Nat // P n} :=
    Nat.rec (⟨Nat.find (h 0), And.right (Nat.find_spec (h 0))⟩ : {n : Nat // P n}) (fun _ a => step a)
  have hgt : ∀ n : ℕ, (g n).val < (g (n + 1)).val := by
    intro n
    have hs : (g (n + 1)).val = Nat.find (h ((g n).val + 1)) := rfl
    rw [hs]
    exact Nat.lt_trans (Nat.lt_succ_self _) (And.left (Nat.find_spec (h ((g n).val + 1))))
  have hlt : ∀ b a : ℕ, a < b → (g a).val < (g b).val := by
    intro b
    induction b with
    | zero => intro a ha; exact absurd ha (Nat.not_lt_zero a)
    | succ b ih =>
      intro a ha
      rcases Nat.lt_or_eq_of_le (Nat.le_of_lt_succ ha) with h2 | h2
      · exact Nat.lt_trans (ih a h2) (hgt b)
      · rw [h2]; exact hgt b
  have hinj : Function.Injective g := by
    intro a b hab
    by_contra hne
    rcases (show a < b ∨ b < a from by omega) with h2 | h2
    · have h3 := hlt b a h2
      rw [hab] at h3
      exact Nat.lt_irrefl _ h3
    · have h3 := hlt a b h2
      rw [hab] at h3
      exact Nat.lt_irrefl _ h3
  exact Infinite.of_injective g hinj

theorem ga_real_40_pos : (40 : ℝ) > (0 : ℝ) := by norm_num

theorem ga_exists_40 {P : ℝ -> Prop} (hP0 : (40 : ℝ) > (0 : ℝ)) (hP : P 40) :
    ∃ C : ℝ, C > (0 : ℝ) ∧ P C := by
  refine ⟨40, hP0, hP⟩

theorem ga_product8_unbounded (x : Nat) : x < ga_product8 (x + 6) := by
  have aux : ∀ n k : Nat, 1 ≤ k → n ≤ n * k := by
    intro n k hk
    calc n = n * 1 := by rw [Nat.mul_one]
      _ ≤ n * k := Nat.mul_le_mul_left n hk
  have h : x + 6 ≤ ga_product8 (x + 6) := by
    unfold ga_product8
    calc x + 6
      ≤ (x + 6) * (x + 6 + 1) := aux (x + 6) (x + 6 + 1) (by omega)
    _ ≤ (x + 6) * (x + 6 + 1) * (x + 6 + 2) :=
        aux ((x + 6) * (x + 6 + 1)) (x + 6 + 2) (by omega)
    _ ≤ (x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) :=
        aux ((x + 6) * (x + 6 + 1) * (x + 6 + 2)) (x + 6 + 3) (by omega)
    _ ≤ (x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4) :=
        aux ((x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3)) (x + 6 + 4) (by omega)
    _ ≤ (x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4) * (x + 6 + 5) :=
        aux ((x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4)) (x + 6 + 5) (by omega)
    _ ≤ (x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4) * (x + 6 + 5) * (x + 6 + 6) :=
        aux ((x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4) * (x + 6 + 5)) (x + 6 + 6) (by omega)
    _ ≤ (x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4) * (x + 6 + 5) * (x + 6 + 6) * (x + 6 + 7) :=
        aux ((x + 6) * (x + 6 + 1) * (x + 6 + 2) * (x + 6 + 3) * (x + 6 + 4) * (x + 6 + 5) * (x + 6 + 6)) (x + 6 + 7) (by omega)
  exact Nat.lt_of_lt_of_le (show x < x + 6 by omega) h

theorem ga_six_le_add_six (x : Nat) : 6 ≤ x + 6 := by
  exact Nat.le_add_left 6 x

theorem ga_contains_4_infinite :
    Infinite {n : Nat | 4 ≤ (Finset.filter (fun d => d ∣ n)
      (Finset.Ioo (Nat.floor ((n : ℝ).sqrt))
        (Nat.ceil ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)))))).card} := by
  refine ga_infinite_of_exists_large ?_
  intro x
  set m := x + 6 with hm_eq
  set n := ga_product8 m with hn_eq
  have hm6 : 6 ≤ m := ga_six_le_add_six x
  have hmn : x < n := ga_product8_unbounded x
  use n
  refine ⟨hmn, ?_⟩
  set F := Finset.filter (fun d => d ∣ n) (Finset.Ioo (Nat.floor ((n : ℝ).sqrt))
      (Nat.ceil ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4))))) with hF
  set d1 := (m + 1) * (m + 2) * (m + 4) * (m + 7)
  set c1 := m * (m + 3) * (m + 5) * (m + 6)
  set d2 := (m + 1) * (m + 2) * (m + 5) * (m + 6)
  set c2 := m * (m + 3) * (m + 4) * (m + 7)
  set d3 := (m + 1) * (m + 3) * (m + 4) * (m + 6)
  set c3 := m * (m + 2) * (m + 5) * (m + 7)
  set d4 := (m + 2) * (m + 3) * (m + 4) * (m + 5)
  set c4 := m * (m + 1) * (m + 6) * (m + 7)
  have hmain : (m : ℝ) ^ 2 ≤ (n : ℝ) ^ ((1 : ℝ) / 4) := by
    have hprod : (n : ℝ) = (m : ℝ) * ((m : ℝ) + 1) * ((m : ℝ) + 2) * ((m : ℝ) + 3) * ((m : ℝ) + 4) *
        ((m : ℝ) + 5) * ((m : ℝ) + 6) * ((m : ℝ) + 7) := by
      rw [hn_eq]
      unfold ga_product8
      push_cast
      ring
    have h8 : (m : ℝ) ^ 8 ≤ (n : ℝ) := by
      rw [hprod]
      have h : (m : ℝ) ^ 8 =
          (m : ℝ) * (m : ℝ) * (m : ℝ) * (m : ℝ) * (m : ℝ) * (m : ℝ) * (m : ℝ) * (m : ℝ) := by ring
      rw [h]
      gcongr
      all_goals nlinarith only [hm6]
    have hsq4 : (m : ℝ) ^ 4 ≤ Real.sqrt (n : ℝ) := by
      have h1 : Real.sqrt ((m : ℝ) ^ 8) = (m : ℝ) ^ 4 := by
        rw [show (m : ℝ) ^ 8 = ((m : ℝ) ^ 4) ^ 2 by ring, Real.sqrt_sq (by positivity)]
      rw [← h1]
      exact Real.sqrt_le_sqrt h8
    have hsq2 : (m : ℝ) ^ 2 ≤ Real.sqrt (Real.sqrt (n : ℝ)) := by
      have h2 : Real.sqrt ((m : ℝ) ^ 4) = (m : ℝ) ^ 2 := by
        rw [show (m : ℝ) ^ 4 = ((m : ℝ) ^ 2) ^ 2 by ring, Real.sqrt_sq (by positivity)]
      rw [← h2]
      exact Real.sqrt_le_sqrt hsq4
    have hq : ((n : ℝ) ^ ((1 : ℝ) / 4)) = Real.sqrt (Real.sqrt (n : ℝ)) := by
      rw [Real.sqrt_eq_rpow, Real.sqrt_eq_rpow,
        ← Real.rpow_mul (by positivity : (0 : ℝ) ≤ (n : ℝ))]
      congr 1
      norm_num
    rw [hq]
    exact hsq2
  have h40m : (40 : ℝ) * (m : ℝ) ^ 2 ≤ (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) :=
    mul_le_mul_of_nonneg_left hmain (by norm_num)
  have hmsq : m ^ 2 ≥ m := by
    have h : m ≤ m * m := Nat.le_mul_self m
    simpa [pow_two] using h
  have hm6sq : m ^ 2 ≥ 6 * m := by
    have h : 6 * m ≤ m * m := Nat.mul_le_mul hm6 (Nat.le_refl m)
    simpa [pow_two] using h
  have hbd1 : ((16 * m + 56 : ℕ) : ℝ) < (40 : ℝ) * (m : ℝ) ^ 2 := by
    exact_mod_cast (by nlinarith only [hm6, hmsq, hm6sq] : 16 * m + 56 < 40 * m ^ 2)
  have hbd2 : ((4 * m ^ 2 + 28 * m + 60 : ℕ) : ℝ) < (40 : ℝ) * (m : ℝ) ^ 2 := by
    exact_mod_cast (by nlinarith only [hm6, hmsq, hm6sq] : 4 * m ^ 2 + 28 * m + 60 < 40 * m ^ 2)
  have hbd3 : ((8 * m ^ 2 + 56 * m + 72 : ℕ) : ℝ) < (40 : ℝ) * (m : ℝ) ^ 2 := by
    exact_mod_cast (by nlinarith only [hm6, hmsq, hm6sq] : 8 * m ^ 2 + 56 * m + 72 < 40 * m ^ 2)
  have hbd4 : ((16 * m ^ 2 + 112 * m + 120 : ℕ) : ℝ) < (40 : ℝ) * (m : ℝ) ^ 2 := by
    exact_mod_cast (by nlinarith only [hm6, hmsq, hm6sq] : 16 * m ^ 2 + 112 * m + 120 < 40 * m ^ 2)
  have hd1 : d1 = c1 + (16 * m + 56) := by unfold d1 c1; ring
  have hd2 : d2 = c2 + (4 * m ^ 2 + 28 * m + 60) := by unfold d2 c2; ring
  have hd3 : d3 = c3 + (8 * m ^ 2 + 56 * m + 72) := by unfold d3 c3; ring
  have hd4 : d4 = c4 + (16 * m ^ 2 + 112 * m + 120) := by unfold d4 c4; ring
  have ho1 : d2 = d1 + (2 * m ^ 2 + 6 * m + 4) := by unfold d2 d1; ring
  have ho2 : d3 = d2 + (2 * m ^ 2 + 14 * m + 12) := by unfold d3 d2; ring
  have ho3 : d4 = d3 + (4 * m ^ 2 + 28 * m + 48) := by unfold d4 d3; ring
  have hc1d1 : c1 < d1 := by omega
  have hc2d2 : c2 < d2 := by omega
  have hc3d3 : c3 < d3 := by omega
  have hc4d4 : c4 < d4 := by omega
  have h12 : d1 < d2 := by omega
  have h13 : d1 < d3 := by omega
  have h14 : d1 < d4 := by omega
  have h23 : d2 < d3 := by omega
  have h24 : d2 < d4 := by omega
  have h34 : d3 < d4 := by omega
  have hb1 : ((16 * m + 56 : ℕ) : ℝ) < (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) :=
    lt_of_lt_of_le hbd1 h40m
  have hb2 : ((4 * m ^ 2 + 28 * m + 60 : ℕ) : ℝ) < (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) :=
    lt_of_lt_of_le hbd2 h40m
  have hb3 : ((8 * m ^ 2 + 56 * m + 72 : ℕ) : ℝ) < (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) :=
    lt_of_lt_of_le hbd3 h40m
  have hb4 : ((16 * m ^ 2 + 112 * m + 120 : ℕ) : ℝ) < (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) :=
    lt_of_lt_of_le hbd4 h40m
  have hn1 : n = d1 * c1 := by rw [hn_eq]; unfold ga_product8 d1 c1; ring
  have hn2 : n = d2 * c2 := by rw [hn_eq]; unfold ga_product8 d2 c2; ring
  have hn3 : n = d3 * c3 := by rw [hn_eq]; unfold ga_product8 d3 c3; ring
  have hn4 : n = d4 * c4 := by rw [hn_eq]; unfold ga_product8 d4 c4; ring
  have key : ∀ (d c t : ℕ), n = d * c → c < d → d = c + t →
      ((t : ℕ) : ℝ) < (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) →
      Nat.floor ((n : ℝ).sqrt) < d ∧
        d < Nat.ceil ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4))) := by
    intro d c t hprod' hcd hdt hdiff
    have hd0 : 0 < d := Nat.lt_of_le_of_lt (Nat.zero_le c) hcd
    have hcast : (n : ℝ) = (d : ℝ) * (c : ℝ) := by exact_mod_cast hprod'
    have hc2n : (c : ℝ) ^ 2 ≤ (n : ℝ) := by
      rw [hcast]
      have hcR' : (c : ℝ) ≤ (d : ℝ) := by exact_mod_cast Nat.le_of_lt hcd
      have hc0' : (0 : ℝ) ≤ (c : ℝ) := by positivity
      nlinarith only [hcR', hc0']
    have hcR : (c : ℝ) ≤ Real.sqrt (n : ℝ) := by
      have h : Real.sqrt ((c : ℝ) ^ 2) ≤ Real.sqrt (n : ℝ) := Real.sqrt_le_sqrt hc2n
      rwa [Real.sqrt_sq (by positivity : (0 : ℝ) ≤ (c : ℝ))] at h
    have hdR : Real.sqrt (n : ℝ) < (d : ℝ) := by
      refine (Real.sqrt_lt' (by positivity)).mpr ?_
      rw [hcast]
      have hcR' : (c : ℝ) < (d : ℝ) := by exact_mod_cast hcd
      have hd0' : (0 : ℝ) < (d : ℝ) := by exact_mod_cast hd0
      nlinarith only [hcR', hd0']
    have hfloor : Nat.floor ((n : ℝ).sqrt) < d := by
      have h : (Nat.floor ((n : ℝ).sqrt) : ℝ) ≤ (n : ℝ).sqrt := Nat.floor_le (Real.sqrt_nonneg _)
      exact_mod_cast h.trans_lt hdR
    have hdR2 : (d : ℝ) < (n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) := by
      have heq : (d : ℝ) = (c : ℝ) + (t : ℝ) := by exact_mod_cast hdt
      linarith only [hcR, hdiff, heq]
    have hceil : d < Nat.ceil ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4))) := by
      have h : ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4)) : ℝ) ≤
          (Nat.ceil ((n : ℝ).sqrt + (40 : ℝ) * ((n : ℝ) ^ ((1 : ℝ) / 4))) : ℝ) := Nat.le_ceil _
      exact_mod_cast hdR2.trans_le h
    exact ⟨hfloor, hceil⟩
  have hk1 := key d1 c1 (16 * m + 56) hn1 hc1d1 hd1 hb1
  have hk2 := key d2 c2 (4 * m ^ 2 + 28 * m + 60) hn2 hc2d2 hd2 hb2
  have hk3 := key d3 c3 (8 * m ^ 2 + 56 * m + 72) hn3 hc3d3 hd3 hb3
  have hk4 := key d4 c4 (16 * m ^ 2 + 112 * m + 120) hn4 hc4d4 hd4 hb4
  have hmF1 : d1 ∈ F :=
    Finset.mem_filter.mpr ⟨Finset.mem_Ioo.mpr ⟨hk1.1, hk1.2⟩, ⟨c1, hn1⟩⟩
  have hmF2 : d2 ∈ F :=
    Finset.mem_filter.mpr ⟨Finset.mem_Ioo.mpr ⟨hk2.1, hk2.2⟩, ⟨c2, hn2⟩⟩
  have hmF3 : d3 ∈ F :=
    Finset.mem_filter.mpr ⟨Finset.mem_Ioo.mpr ⟨hk3.1, hk3.2⟩, ⟨c3, hn3⟩⟩
  have hmF4 : d4 ∈ F :=
    Finset.mem_filter.mpr ⟨Finset.mem_Ioo.mpr ⟨hk4.1, hk4.2⟩, ⟨c4, hn4⟩⟩
  have hnmem1 : d1 ∉ ({d2, d3, d4} : Finset ℕ) := by
    intro hy
    rw [Finset.mem_insert, Finset.mem_insert, Finset.mem_singleton] at hy
    cases hy with
    | inl h => exact Nat.ne_of_lt h12 h
    | inr h =>
      cases h with
      | inl h => exact Nat.ne_of_lt h13 h
      | inr h => exact Nat.ne_of_lt h14 h
  have hnmem2 : d2 ∉ ({d3, d4} : Finset ℕ) := by
    intro hy
    rw [Finset.mem_insert, Finset.mem_singleton] at hy
    cases hy with
    | inl h => exact Nat.ne_of_lt h23 h
    | inr h => exact Nat.ne_of_lt h24 h
  have hnmem3 : d3 ∉ ({d4} : Finset ℕ) := by
    intro hy
    rw [Finset.mem_singleton] at hy
    exact Nat.ne_of_lt h34 hy
  have hcardT : ({d1, d2, d3, d4} : Finset ℕ).card = 4 := by
    rw [Finset.card_insert_of_notMem hnmem1, Finset.card_insert_of_notMem hnmem2,
      Finset.card_insert_of_notMem hnmem3, Finset.card_singleton]
  have hs : ({d1, d2, d3, d4} : Finset ℕ) ⊆ F := by
    intro y hy
    rw [Finset.mem_insert, Finset.mem_insert, Finset.mem_insert, Finset.mem_singleton] at hy
    obtain rfl | rfl | rfl | rfl := hy
    · exact hmF1
    · exact hmF2
    · exact hmF3
    · exact hmF4
  rw [← hcardT]
  exact Finset.card_mono hs

theorem ga_contains_4_core :
    ∃ C : ℝ, C > (0 : ℝ) ∧ Infinite {n : Nat | 4 ≤ (Finset.filter (fun d => d ∣ n)
      (Finset.Ioo (Nat.floor ((n : ℝ).sqrt))
        (Nat.ceil ((n : ℝ).sqrt + C * ((n : ℝ) ^ ((1 : ℝ) / 4)))))).card} := by
  refine ga_exists_40 ga_real_40_pos ?_
  exact ga_contains_4_infinite

#ga_audit_proof ga_infinite_of_exists_large
#ga_audit_proof ga_real_40_pos
#ga_audit_proof ga_exists_40
#ga_audit_proof ga_product8_unbounded
#ga_audit_proof ga_six_le_add_six
#ga_audit_proof ga_contains_4_infinite
#ga_audit_proof ga_contains_4_core
