# Verification and recovery status

## Historical verification: passed

Before the execution workspace was replaced on 2026-10-02, this exact seventeen-source proof closure passed a clean author replay in 111.415 seconds and an independent clean replay in 113.460 seconds. Every own module was freshly re-elaborated, with no own cached proof oleans, warnings or errors. Final transitive axioms were exactly propext, Classical.choice, and Quot.sound. Independent semantic review confirmed the actual normalized RBM model, 0 < |rho| <= 1, arbitrary finite hidden bias, all nine free parameters, every affine directional derivative, the sharp iff and full-neighborhood saddle conditions.

These historical outcomes are preserved in recorded execution/conversation evidence. The original local seventeen-module replay logs and audit report were lost when the workspace was replaced. This recovered package does not fabricate or relabel replacements as those original logs.

## Exact source recovery

The eleven inherited Lean files were restored from the previously saved strict-region Library archive. All six new Lean files, including the final audit source, were reconstructed from recorded tool history. Every one of the seventeen proof files matches its original frozen SHA-256 value exactly. SOURCE_MANIFEST.json itself is also byte-identical to the original, with SHA-256 a9107e9c4c546451166108f1faab9e25cf4ac73926e766ef0659638d2463ae7b.

The original strict-region ZIP is unchanged, SHA-256 7400d9083e3afca3ee0e961b43a43870c2ad2c1c7ddb6b979d0d0a06e22527dc. The previously generated but unsaved sharp ZIP was lost; this regenerated archive intentionally has a new filename and hash. Documentation and archive metadata were regenerated; proof bytes were not changed.

## Fresh post-recovery replay: pending

The official Lean 4.33.1 compiler was restored, but dependency-cache restoration encountered a network-policy block. Fresh post-recovery replay is pending authorized dependency access. No new replay success is claimed. The supplied replay script performs the complete source-only check once the pinned dependencies are available.

Compiler commit: 819816b2e0a3bf405af45ae5c7af2491d8f5bee6. Mathlib revision: 0df444a360eaa60ab8c11dca51a86af692955474. All other dependency revisions are pinned in lake-manifest.json.

The historical verification and exact hash recovery preserve the verified mathematical source identity. They do not certify novelty, competition eligibility, credit, or resolution of the broad OPDP89 program. The sharp result upgrades the same family; fallback endpoints are not additional independent credit units.
