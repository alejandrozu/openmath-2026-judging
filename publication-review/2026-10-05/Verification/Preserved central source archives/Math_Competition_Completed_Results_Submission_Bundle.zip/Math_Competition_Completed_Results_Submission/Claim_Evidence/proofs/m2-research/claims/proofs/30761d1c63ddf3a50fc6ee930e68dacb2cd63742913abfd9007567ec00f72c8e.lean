import Mathlib
import Lean
import FormalConjectures.OEIS.«7406»

set_option google.answer "postpone"

-- Already imported, audited repository definitions (do not redeclare):
-- def OeisA7406.a : ℕ → ℕ := fun n => (∑ k ∈ Finset.Icc 1 n, 1 / ↑k ^ 2).num.natAbs
-- 
-- def OeisA89026.a : ℕ → ℕ := fun n => if Nat.Prime n then n else 1

namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit

theorem a7406_Icc_pred_eq_Ico (n : Nat) :
    Finset.Icc (1 : Nat) (n - 1) = Finset.Ico (1 : Nat) n := by
  cases n with
  | zero =>
      ext k
      simp only [Finset.mem_Icc, Finset.mem_Ico]
      omega
  | succ n =>
      ext k
      simp only [Finset.mem_Icc, Finset.mem_Ico, Nat.succ_sub_succ_eq_sub, Nat.sub_zero]
      omega

theorem a7406_dvd_prod_id {s : Finset Nat} {x : Nat} (hx : x ∈ s) :
    x ∣ s.prod id := by
  exact Finset.dvd_prod_of_mem id hx

def a7406_block_den (p t : Nat) : Nat :=
  ∏ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
    (x.1 * p + x.2) ^ 2

def a7406_block_num (p t : Nat) : Nat :=
  ∑ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
    a7406_block_den p t / (x.1 * p + x.2) ^ 2

theorem a7406_nat_div_cast_eq_rat_div {k D : Nat} (hk : k ≠ 0) (hD : k ^ 2 ∣ D) :
    ((D / k ^ 2 : Nat) : ℚ) = (D : ℚ) / ((k : ℚ) ^ 2) := by
  rw [Nat.cast_div hD, Nat.cast_pow]
  exact_mod_cast pow_ne_zero 2 hk

theorem a7406_dvd_prod_sq {s : Finset Nat} {x : Nat} (hx : x ∈ s) :
    x ^ 2 ∣ (∏ y ∈ s, y ^ 2) := by
  exact Finset.dvd_prod_of_mem (fun y => y ^ 2) hx

theorem a7406_block_clear_denom_eq {p t : Nat} (hp : 1 < p) (ht : 1 ≤ t) :
    ∑ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
        (1 : ℚ) / ((((x.1 * p + x.2 : Nat) : ℚ) ^ 2)) =
      ((a7406_block_num p t : Nat) : ℚ) / ((a7406_block_den p t : Nat) : ℚ) := by
  have hmem : ∀ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
      (x.1 * p + x.2 : ℕ) ≠ 0 := by
    intro x hx
    obtain ⟨-, hx2⟩ := Finset.mem_product.mp hx
    obtain ⟨hx21, -⟩ := Finset.mem_Icc.mp hx2
    have hpos : 0 < x.2 := lt_of_lt_of_le Nat.zero_lt_one hx21
    exact Nat.ne_of_gt (Nat.lt_of_lt_of_le hpos (Nat.le_add_left x.2 (x.1 * p)))
  have hD0 : a7406_block_den p t ≠ 0 := by
    apply Nat.ne_of_gt
    show 0 < ∏ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)), (x.1 * p + x.2) ^ 2
    refine Finset.prod_pos ?_
    intro x hx
    exact Nat.pos_of_ne_zero (pow_ne_zero 2 (hmem x hx))
  have hterm : ∀ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
      (1 : ℚ) / (((x.1 * p + x.2 : Nat) : ℚ) ^ 2) =
        ((a7406_block_den p t / (x.1 * p + x.2) ^ 2 : ℕ) : ℚ) / ((a7406_block_den p t : Nat) : ℚ) := by
    intro x hx
    have hk : (x.1 * p + x.2 : ℕ) ≠ 0 := hmem x hx
    have hdvd : (x.1 * p + x.2) ^ 2 ∣ a7406_block_den p t :=
      Finset.dvd_prod_of_mem (fun y : ℕ × ℕ => (y.1 * p + y.2) ^ 2) hx
    have h := a7406_nat_div_cast_eq_rat_div hk hdvd
    rw [h]
    field_simp [hD0, hk]
  rw [Finset.sum_congr rfl (fun x hx => hterm x hx)]
  rw [← Finset.sum_div]
  rw [← Nat.cast_sum]
  unfold a7406_block_num
  rfl

theorem a7406_coprime_pow {p n : Nat} (h : Nat.Coprime p n) :
    Nat.Coprime p (n ^ 2) := by
  exact h.pow_right 2

theorem a7406_coprime_prod_of_each {p : Nat} [Fact (Nat.Prime p)] {s : Finset Nat}
    (h : ∀ x ∈ s, Nat.Coprime p x) :
    Nat.Coprime p (s.prod id) := by
  classical
  suffices key : ∀ (t : Finset Nat), (∀ x ∈ t, Nat.Coprime p x) → Nat.Coprime p (t.prod id) by
    exact key s h
  intro t
  induction t using Finset.induction_on with
  | empty =>
    intro _
    simp only [Finset.prod_empty]
    exact Nat.coprime_one_right p
  | @insert a t' has ih =>
    intro ht
    rw [Finset.prod_insert has]
    refine Nat.Coprime.mul_right (ht a (Finset.mem_insert_self a t'))
      (ih (fun x hx => ht x (Finset.mem_insert_of_mem hx)))

theorem a7406_not_dvd_of_coprime_prime {p : Nat} [Fact (Nat.Prime p)] {n : Nat}
    (h : Nat.Coprime p n) : ¬ p ∣ n := by
  intro hd
  have hp : Nat.Prime p := Fact.out
  have h1 : p ∣ Nat.gcd p n := Nat.dvd_gcd (dvd_refl p) hd
  rw [h] at h1
  exact hp.not_dvd_one h1

theorem a7406_block_factor_coprime {p : Nat} [Fact (Nat.Prime p)] {j r : Nat}
    (hr : r ∈ Finset.Icc (1 : Nat) (p - 1)) :
    Nat.Coprime p (j * p + r) := by
  obtain ⟨hr1, hr2⟩ := Finset.mem_Icc.mp hr
  have hprime : Nat.Prime p := Fact.out
  have h2 : 2 ≤ p := Nat.Prime.two_le hprime
  have hrp : r < p := by omega
  have key : Nat.gcd p r = 1 := by
    rcases Nat.Prime.eq_one_or_self_of_dvd hprime _ (Nat.gcd_dvd_left p r) with h | h
    · exact h
    · have hpos : 0 < r := by omega
      have hdiv : p ∣ r := by rw [← h]; exact Nat.gcd_dvd_right p r
      have hp_le : p ≤ r := Nat.le_of_dvd hpos hdiv
      omega
  rw [Nat.coprime_iff_gcd_eq_one, ← key]
  rw [show j * p + r = r + j * p from Nat.add_comm _ _]
  exact Nat.gcd_add_mul_right_right p r j

theorem a7406_block_factor_sq_coprime {p : Nat} [Fact (Nat.Prime p)] {j r : Nat}
    (hr : r ∈ Finset.Icc (1 : Nat) (p - 1)) :
    Nat.Coprime p ((j * p + r) ^ 2) := by
  exact a7406_coprime_pow (a7406_block_factor_coprime hr)

theorem a7406_block_clear_denom_not_dvd {p : Nat} [Fact (Nat.Prime p)] {t : Nat} (ht : 1 ≤ t) :
    ¬ p ∣ a7406_block_den p t := by
  unfold a7406_block_den
  refine Prime.not_dvd_finsetProd (Nat.Prime.prime (Fact.out (p := Nat.Prime p))) ?_
  intro x hx
  have hmem := Finset.mem_product.mp hx
  exact a7406_not_dvd_of_coprime_prime (a7406_block_factor_sq_coprime hmem.2)

theorem a7406_zmod_Icc_image_eq_units {p : Nat} [Fact (Nat.Prime p)] :
    (Finset.Icc 1 (p - 1)).image (fun k : Nat => (k : ZMod p)) =
      (Finset.univ : Finset (ZMod p)).erase 0 := by
  have hp : 0 < p := (Fact.out (p := Nat.Prime p)).pos
  apply Finset.ext
  intro x
  simp only [Finset.mem_image, Finset.mem_Icc, Finset.mem_erase, Finset.mem_univ, false_or,
    true_and, and_true]
  constructor
  · rintro ⟨k, ⟨h1, h2⟩, rfl⟩
    have hlt : k < p := by omega
    intro h
    have hval := congrArg ZMod.val h
    rw [ZMod.val_zero, ZMod.val_natCast p k, Nat.mod_eq_of_lt hlt] at hval
    omega
  · intro hx
    have hlt := ZMod.val_lt x
    have hne : x.val ≠ 0 := by
      intro h
      exact hx ((ZMod.val_eq_zero x).1 h)
    refine ⟨x.val, ⟨Nat.pos_of_ne_zero hne, by omega⟩, ?_⟩
    simpa using (ZMod.natCast_val (R := ZMod p) x)

theorem a7406_zmod_units_sum_sq_zero {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 = 0 := by
  -- 2 and 3 are nonzero in ZMod p since p > 3
  have h2n : (2 : ZMod p) ≠ 0 := by
    intro hc
    have hd : p ∣ 2 := (ZMod.natCast_eq_zero_iff (2 : ℕ) p).mp hc
    have := Nat.le_of_dvd (by decide : (0 : Nat) < 2) hd
    omega
  have h3n : (3 : ZMod p) ≠ 0 := by
    intro hc
    have hd : p ∣ 3 := (ZMod.natCast_eq_zero_iff (3 : ℕ) p).mp hc
    have := Nat.le_of_dvd (by decide : (0 : Nat) < 3) hd
    omega
  -- multiplication by 2 is injective on the nonzero elements, and maps them into nonzero elements
  have inj : Set.InjOn (fun x : ZMod p => (2 : ZMod p) * x)
      ((Finset.univ : Finset (ZMod p)).erase 0 : Set (ZMod p)) := by
    intro x _ y _ he
    exact mul_left_cancel₀ h2n he
  have hsub : ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x) ⊆
      (Finset.univ : Finset (ZMod p)).erase 0 := by
    rw [Finset.image_subset_iff]
    intro x hx
    simp only [Finset.mem_erase, Finset.mem_univ, and_true] at hx ⊢
    exact mul_ne_zero h2n hx
  have hcard : (((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x)).card =
      ((Finset.univ : Finset (ZMod p)).erase 0).card := Finset.card_image_of_injOn inj
  have himg : ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x) =
      (Finset.univ : Finset (ZMod p)).erase 0 :=
    Finset.eq_of_subset_of_card_le hsub (Nat.le_of_eq hcard.symm)
  -- the sum is invariant under x ↦ 2*x
  have e1 : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2
      = ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x), x ^ 2 :=
    (by rw [himg] :
      ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x), x ^ 2
        = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2).symm
  have e2 : ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x), x ^ 2
      = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, ((2 : ZMod p) * x) ^ 2 :=
    Finset.sum_image inj
  have h3 : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, ((2 : ZMod p) * x) ^ 2
      = (2 : ZMod p) ^ 2 * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 := by
    rw [Finset.sum_congr rfl (fun x _ => mul_pow (2 : ZMod p) x 2), ← Finset.mul_sum]
  have hT : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2
      = (2 : ZMod p) ^ 2 * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 :=
    e1.trans (e2.trans h3)
  -- hence 3 * S = 0, and 3 ≠ 0 in ZMod p
  have hzero : (3 : ZMod p) * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 = 0 := by
    have h : ((2 : ZMod p) ^ 2 - 1) * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 = 0 := by
      rw [sub_mul, one_mul, ← hT]
      exact sub_self _
    rwa [show ((2 : ZMod p) ^ 2 - 1 : ZMod p) = (3 : ZMod p) from by norm_num] at h
  rcases mul_eq_zero.mp hzero with hc | hc
  · exact absurd hc h3n
  · exact hc

theorem a7406_zmod_Icc_inv_sq_sum_zero {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    ∑ k ∈ Finset.Icc 1 (p - 1), ((k : ZMod p)⁻¹) ^ 2 = 0 := by
  have ninj : ∀ a b : ℕ, a < p → b < p → (a : ZMod p) = (b : ZMod p) → a = b := by
    intro a b ha hb hab
    have h : a % p = b % p := by
      have h2 := congrArg ZMod.val hab
      rwa [ZMod.val_natCast p a, ZMod.val_natCast p b] at h2
    rwa [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at h
  have hinj : Set.InjOn (fun k : ℕ => (k : ZMod p)) (Finset.Icc 1 (p - 1)) := by
    intro a ha b hb hab
    simp only [Finset.mem_coe, Finset.mem_Icc] at ha hb
    refine ninj a b (Nat.lt_of_le_of_lt ha.2 (Nat.sub_lt (by omega) (by omega)))
      (Nat.lt_of_le_of_lt hb.2 (Nat.sub_lt (by omega) (by omega))) hab
  have A : ∑ k ∈ Finset.Icc 1 (p - 1), ((k : ZMod p)⁻¹) ^ 2
      = ∑ x ∈ (Finset.Icc 1 (p - 1)).image (fun k : ℕ => (k : ZMod p)), x⁻¹ ^ 2 :=
    (Finset.sum_image (f := fun x : ZMod p => x⁻¹ ^ 2)
      (g := fun k : ℕ => (k : ZMod p))
      (s := Finset.Icc 1 (p - 1)) hinj).symm
  have e1 : (Finset.Icc 1 (p - 1)).image (fun k : ℕ => (k : ZMod p)) =
      (Finset.univ : Finset (ZMod p)).erase 0 := a7406_zmod_Icc_image_eq_units
  have B : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x⁻¹ ^ 2
      = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 := by
    have hinv : Set.InjOn (fun x : ZMod p => x⁻¹) ((Finset.univ : Finset (ZMod p)).erase 0) := by
      intro a _ b _ hab
      have := congrArg (fun y : ZMod p => y⁻¹) hab
      rwa [inv_inv, inv_inv] at this
    have himg : ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x : ZMod p => x⁻¹)
        = (Finset.univ : Finset (ZMod p)).erase 0 := by
      apply Finset.ext
      intro x
      simp only [Finset.mem_image, Finset.mem_erase, Finset.mem_univ, and_true, true_and]
      constructor
      · rintro ⟨y, hy, rfl⟩
        exact inv_ne_zero hy
      · intro hx
        exact ⟨x⁻¹, inv_ne_zero hx, inv_inv x⟩
    calc ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x⁻¹ ^ 2
        = ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x : ZMod p => x⁻¹), x ^ 2 :=
          (Finset.sum_image (f := fun x : ZMod p => x ^ 2) (g := fun x : ZMod p => x⁻¹)
            (s := (Finset.univ : Finset (ZMod p)).erase 0) hinv).symm
      _ = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 := by rw [himg]
  rw [A, e1, B]
  exact a7406_zmod_units_sum_sq_zero h

theorem a7406_block_clear_denom_num_cast_zero {p : Nat} [Fact (Nat.Prime p)] {t : Nat}
    (h : 3 < p) (ht : 1 ≤ t) :
    ((a7406_block_num p t : Nat) : ZMod p) = 0 := by
  classical
  -- s indexes the block; f is the squared factor; D is the common denominator
  set s : Finset (Nat × Nat) := Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)) with hs
  set f : Nat × Nat → Nat := fun x => (x.1 * p + x.2) ^ 2 with hf
  set D : Nat := a7406_block_den p t with hD
  have hDprod : D = ∏ x ∈ s, f x := rfl
  have hseq : s = Finset.range t ×ˢ Finset.Icc (1 : Nat) (p - 1) := rfl
  -- modulo p every factor (x.1 * p + x.2)^2 equals x.2^2
  have h2 : ∀ x ∈ s, (f x : ZMod p) = (x.2 : ZMod p) ^ 2 := by
    intro x _
    have e : ((x.1 * p + x.2 : Nat) : ZMod p) = (x.2 : ZMod p) := by
      rw [Nat.cast_add, Nat.cast_mul, ZMod.natCast_self p, mul_zero, zero_add]
    simp only [hf, Nat.cast_pow, e]
  -- the second coordinates are exactly the nonzero residues (up to the parent lemma)
  have nz2 : ∀ x ∈ s, (x.2 : ZMod p) ≠ 0 := by
    intro x hx
    have hIcc : x.2 ∈ Finset.Icc (1 : Nat) (p - 1) := by
      rw [hs] at hx
      exact (Finset.mem_product.mp hx).2
    have hmem : ((x.2 : Nat) : ZMod p) ∈
        ((Finset.Icc (1 : Nat) (p - 1)).image (fun k : Nat => (k : ZMod p))) :=
      Finset.mem_image.mpr ⟨x.2, hIcc, rfl⟩
    rw [a7406_zmod_Icc_image_eq_units] at hmem
    rw [Finset.mem_erase] at hmem
    exact hmem.1
  have nzf : ∀ x ∈ s, (f x : ZMod p) ≠ 0 := by
    intro x hx
    rw [h2 x hx]
    exact pow_ne_zero 2 (nz2 x hx)
  -- each factor divides the common denominator
  have hdvd : ∀ x ∈ s, f x ∣ D := by
    intro x hx
    rw [hDprod]
    exact Finset.dvd_prod_of_mem f hx
  -- termwise, the cleared numerator equals D * (factor)⁻¹ in ZMod p
  have termwise : ∀ x ∈ s, ((D / f x : Nat) : ZMod p) = (D : ZMod p) * (f x : ZMod p)⁻¹ := by
    intro x hx
    have hdiv : (D : ZMod p) / (f x : ZMod p) = ((D / f x : Nat) : ZMod p) := by
      rw [div_eq_iff (nzf x hx), ← Nat.cast_mul, Nat.div_mul_cancel (hdvd x hx)]
    rw [← div_eq_mul_inv, hdiv]
  -- the sum of the inverses vanishes: it is t copies of the (known) zero sum
  have hsuminv : ∑ x ∈ s, (f x : ZMod p)⁻¹ = 0 := by
    have step1 : ∑ x ∈ s, (f x : ZMod p)⁻¹ = ∑ x ∈ s, ((x.2 : ZMod p)⁻¹) ^ 2 := by
      apply Finset.sum_congr rfl
      intro x hx
      rw [h2 x hx, ← inv_pow]
    have step2 : ∑ x ∈ s, ((x.2 : ZMod p)⁻¹) ^ 2
        = ∑ i ∈ Finset.range t, ∑ k ∈ Finset.Icc (1 : Nat) (p - 1), ((k : ZMod p)⁻¹) ^ 2 := by
      rw [hseq, Finset.sum_product]
    rw [step1, step2]
    rw [a7406_zmod_Icc_inv_sq_sum_zero h]
    exact Finset.sum_const_zero
  calc ((a7406_block_num p t : Nat) : ZMod p)
      = ∑ x ∈ s, ((D / f x : Nat) : ZMod p) := by
          simp only [a7406_block_num, ← hD]
          rw [Nat.cast_sum]
      _ = ∑ x ∈ s, (D : ZMod p) * (f x : ZMod p)⁻¹ := by
          apply Finset.sum_congr rfl
          intro x hx
          exact termwise x hx
      _ = (D : ZMod p) * ∑ x ∈ s, (f x : ZMod p)⁻¹ := by rw [← Finset.mul_sum]
      _ = (D : ZMod p) * 0 := by rw [hsuminv]
      _ = 0 := mul_zero _

theorem a7406_nat_cast_zero_dvd {p : Nat} [Fact (Nat.Prime p)] {N : Nat}
    (h : (N : ZMod p) = 0) : p ∣ N := by
  exact (ZMod.natCast_eq_zero_iff N p).mp h

theorem a7406_block_clear_denom_num_dvd {p : Nat} [Fact (Nat.Prime p)] {t : Nat}
    (h : 3 < p) (ht : 1 ≤ t) :
    p ∣ a7406_block_num p t := by
  exact a7406_nat_cast_zero_dvd (a7406_block_clear_denom_num_cast_zero h ht)

theorem a7406_block_clear_denom_pos {p t : Nat} (hp : 1 < p) (ht : 1 ≤ t) :
    0 < a7406_block_den p t := by
  unfold a7406_block_den
  apply Finset.prod_pos
  intro x hx
  obtain ⟨-, h2⟩ := Finset.mem_product.mp hx
  have h2' : 1 ≤ x.2 := (Finset.mem_Icc.mp h2).1
  exact pow_pos (by omega : 0 < x.1 * p + x.2) 2

theorem a7406_block_double_sum_eq_product {p t : Nat} :
    (∑ j ∈ Finset.range t,
        (∑ r ∈ Finset.Icc 1 (p - 1),
          (1 : ℚ) / ((((j * p + r : Nat) : ℚ) ^ 2)))) =
      ∑ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
        (1 : ℚ) / ((((x.1 * p + x.2 : Nat) : ℚ) ^ 2)) := by
  exact (Finset.sum_product (Finset.range t) (Finset.Icc 1 (p - 1))
    (fun uv => (1 : ℚ) / (((uv.1 * p + uv.2 : Nat) : ℚ) ^ 2))).symm

theorem a7406_block_num_ne_zero {p t : Nat} (hp : 1 < p) (ht : 1 ≤ t) :
    a7406_block_num p t ≠ 0 := by
  have h0 : 0 < t := by omega
  have hmem : ((0, 1) : Nat × Nat) ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)) :=
    Finset.mem_product.mpr ⟨Finset.mem_range.mpr h0, Finset.mem_Icc.mpr ⟨by omega, by omega⟩⟩
  have hpos : 0 < a7406_block_den p t := a7406_block_clear_denom_pos hp ht
  have hnum : a7406_block_num p t =
      ∑ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
        a7406_block_den p t / (x.1 * p + x.2) ^ 2 := rfl
  have hle : a7406_block_den p t / (((0, 1) : Nat × Nat).1 * p + ((0, 1) : Nat × Nat).2) ^ 2 ≤
      ∑ x ∈ Finset.product (Finset.range t) (Finset.Icc (1 : Nat) (p - 1)),
        a7406_block_den p t / (x.1 * p + x.2) ^ 2 :=
    Finset.single_le_sum
      (f := fun x : Nat × Nat => a7406_block_den p t / (x.1 * p + x.2) ^ 2)
      (fun _ _ => Nat.zero_le _) hmem
  have h1 : a7406_block_den p t / (((0, 1) : Nat × Nat).1 * p + ((0, 1) : Nat × Nat).2) ^ 2 =
      a7406_block_den p t := by simp
  have hge : a7406_block_den p t ≤ a7406_block_num p t := by
    rw [hnum]
    rwa [h1] at hle
  exact Nat.ne_of_gt (Nat.lt_of_lt_of_le hpos hge)

theorem a7406_composite_exists_mul {p n : Nat} [Fact (Nat.Prime p)]
    (hn : 3 < n) (hnp : ¬ Nat.Prime n) (hpd : p ∣ n) :
    ∃ t : Nat, 2 ≤ t ∧ n = p * t := by
  obtain ⟨t, ht⟩ := hpd
  refine ⟨t, ?_, ht⟩
  by_contra h
  have hle : t ≤ 1 := by omega
  rcases Nat.eq_zero_or_pos t with h0 | hpos
  · rw [h0, mul_zero] at ht
    omega
  · have ht1 : t = 1 := by omega
    rw [ht1, mul_one] at ht
    exact hnp (by rw [ht]; exact Fact.out)

theorem rational_dvd_num_iff_padicValRat_pos
    {p : Nat} [Fact (Nat.Prime p)] {r : ℚ} (hr : 0 < r) :
    p ∣ r.num.natAbs ↔ 0 < padicValRat p r := by
  have hp : p.Prime := Fact.out
  have hnpos : 0 < r.num := Rat.num_pos.mpr hr
  have hnum0 : r.num.natAbs ≠ 0 := by
    rintro h
    have := Int.natAbs_eq_zero.mp h
    linarith
  have hcop : Nat.gcd r.num.natAbs r.den = 1 := Rat.reduced r
  have hden0 : r.den ≠ 0 := Nat.pos_iff_ne_zero.mp (Rat.den_pos r)
  have heq : padicValRat p r = (padicValNat p r.num.natAbs : ℤ) - (padicValNat p r.den : ℤ) := rfl
  constructor
  · intro hvd
    have h1 : (padicValNat p r.num.natAbs : ℤ) ≥ 1 := by
      exact_mod_cast one_le_padicValNat_of_dvd hnum0 hvd
    have h2 : (padicValNat p r.den : ℤ) = 0 := by
      have hnd : ¬ p ∣ r.den := by
        intro hd
        have h' : p ∣ Nat.gcd r.num.natAbs r.den := Nat.dvd_gcd hvd hd
        rw [hcop] at h'
        exact hp.ne_one (Nat.dvd_one.mp h')
      rw [padicValNat.eq_zero_of_not_dvd hnd]
      simp
    rw [heq, h2]
    linarith
  · intro hpos
    by_contra hnd
    have h1 : (padicValNat p r.num.natAbs : ℤ) = 0 := by
      rw [padicValNat.eq_zero_of_not_dvd hnd]
      simp
    rw [heq, h1] at hpos
    have h2 : (0 : ℤ) ≤ (padicValNat p r.den : ℤ) := by exact_mod_cast Nat.zero_le _
    linarith

theorem a7406_padicValRat_div_nat_le_zero
    {p N D : Nat} [Fact (Nat.Prime p)] (hN : ¬ p ∣ N) (hD : 0 < D) :
    padicValRat p ((N : ℚ) / (D : ℚ)) ≤ 0 := by
  by_cases hN0 : N = 0
  · subst hN0
    simp
  set r : ℚ := (N : ℚ) / (D : ℚ) with hr
  have hD0 : (D : ℚ) ≠ 0 := by exact_mod_cast hD.ne'
  have hden : (r.den : ℚ) ≠ 0 := by exact_mod_cast (Rat.den_nz r)
  have hpos : (0 : ℚ) < r := by
    refine div_pos ?_ ?_
    · exact_mod_cast Nat.pos_of_ne_zero hN0
    · exact_mod_cast hD
  have h3 : (r.num : ℚ) * (D : ℚ) = (N : ℚ) * (r.den : ℚ) :=
    (div_eq_div_iff hden hD0).mp ((Rat.num_div_den r).trans hr)
  have h4 : (r.num : ℤ) * (D : ℤ) = (N : ℤ) * (r.den : ℤ) := by exact_mod_cast h3
  have h5 : r.num.natAbs * D = N * r.den := by
    have h := congrArg Int.natAbs h4
    simpa [Int.natAbs_mul] using h
  have h8 : r.num.natAbs ∣ N * r.den := ⟨D, h5.symm⟩
  have hcop : Nat.Coprime r.num.natAbs r.den := Rat.reduced r
  have h9 : r.num.natAbs ∣ N := hcop.dvd_of_dvd_mul_right h8
  have hnotdvd : ¬ p ∣ r.num.natAbs := fun h => hN (Nat.dvd_trans h h9)
  have key := rational_dvd_num_iff_padicValRat_pos (p := p) hpos
  exact le_of_not_gt (fun hh => hnotdvd (key.mpr hh))

theorem a7406_rat_sum_inv_sq_eq_nat_div_common_den {m D : Nat}
    (hD : 0 < D)
    (hdiv : ∀ k ∈ Finset.Icc (1 : Nat) m, k ^ 2 ∣ D) :
    (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) =
      ((∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 : Nat) : ℚ) / (D : ℚ) := by
  have hDq : (D : ℚ) ≠ 0 := by
    exact_mod_cast Nat.ne_of_gt hD
  have key : ∀ k ∈ Finset.Icc (1 : ℕ) m,
      (1 : ℚ) / ((k : ℚ) ^ 2) = ((D / k ^ 2 : ℕ) : ℚ) / (D : ℚ) := by
    intro k hk
    have hk0 : k ≠ 0 := by
      have h1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
      omega
    have hkq : (k : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hk0
    have hsq : ((k : ℚ) ^ 2) ≠ 0 := pow_ne_zero 2 hkq
    rw [a7406_nat_div_cast_eq_rat_div hk0 (hdiv k hk)]
    field_simp [hDq, hsq]
  rw [Nat.cast_sum, Finset.sum_div, ← Finset.sum_congr rfl key]

theorem a7406_three_common_den_quotient_sum_not_dvd {a m P D : Nat}
    (ha1 : 3 ^ a ≤ m) (ha2 : m < 3 ^ (a + 1))
    (hP : P = ((Finset.Icc (1 : Nat) m).filter (fun j => ¬ 3 ∣ j)).prod id)
    (hD : D = (3 ^ a * P) * (3 ^ a * P)) :
    ¬ 3 ∣ ∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 := by
  have h3 : Nat.Prime 3 := by decide
  have hn3P : ¬ 3 ∣ P := by
    rw [hP]
    have aux : ∀ s : Finset ℕ, (∀ x ∈ s, ¬ 3 ∣ x) → ¬ 3 ∣ s.prod id := by
      intro s
      induction s using Finset.induction_on with
      | empty => intro _ h; exact absurd h (by decide)
      | @insert x s hx ih =>
          intro hs h
          rw [Finset.prod_insert hx] at h
          cases (Nat.Prime.dvd_mul (m := x) (n := s.prod id) h3).mp h with
          | inl hxx => exact hs x (Finset.mem_insert.mpr (Or.inl rfl)) hxx
          | inr hrest => exact ih (fun y hy => hs y (Finset.mem_insert.mpr (Or.inr hy))) hrest
    exact aux _ (fun x hx => (Finset.mem_filter.mp hx).2)
  let N := 3 ^ a * P
  have hNdef : N = 3 ^ a * P := rfl
  have hD2 : D = N * N := by rw [hD, ← hNdef]
  have h3a0 : 0 < 3 ^ a := by positivity
  have hdivN : ∀ k ∈ Finset.Icc (1 : ℕ) m, k ∣ N := by
    intro k hk
    have hk1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
    have hkm : k ≤ m := (Finset.mem_Icc.mp hk).2
    obtain ⟨b, hba, hg⟩ : ∃ b ≤ a, Nat.gcd k (3 ^ a) = 3 ^ b :=
      (Nat.dvd_prime_pow h3).mp (Nat.gcd_dvd_right k (3 ^ a))
    have hg2 : 3 ^ b ∣ k := by rw [← hg]; exact Nat.gcd_dvd_left k (3 ^ a)
    obtain ⟨c, rfl⟩ : ∃ c, k = 3 ^ b * c := ⟨k / 3 ^ b, (Nat.mul_div_cancel' hg2).symm⟩
    have h3b0 : 0 < 3 ^ b := by positivity
    have h3b1 : 1 ≤ 3 ^ b := by omega
    have hc1 : 1 ≤ c := by
      by_contra hc
      have hc0 : c = 0 := by omega
      rw [hc0, Nat.mul_zero] at hk1
      omega
    have hcb : c ≤ 3 ^ b * c :=
      calc c = 1 * c := (Nat.one_mul c).symm
        _ ≤ 3 ^ b * c := Nat.mul_le_mul_right c h3b1
    have hcm : c ≤ m := Nat.le_trans hcb hkm
    have hc3 : ¬ 3 ∣ c := by
      intro hc
      obtain ⟨u, hu⟩ := hc
      have h5 : 3 ^ b * (3 * u) = 3 ^ (b + 1) * u := by
        rw [Nat.pow_succ]
        ring
      have hkdiv : 3 ^ (b + 1) ∣ 3 ^ b * c := by
        subst hu
        exact ⟨u, h5⟩
      by_cases hlt : b < a
      · have h2 : 3 ^ (b + 1) ∣ 3 ^ a := pow_dvd_pow 3 (by omega)
        have hgg : 3 ^ (b + 1) ∣ Nat.gcd (3 ^ b * c) (3 ^ a) := Nat.dvd_gcd hkdiv h2
        have hgb : 3 ^ (b + 1) ∣ 3 ^ b := by rwa [hg] at hgg
        have hle : 3 ^ (b + 1) ≤ 3 ^ b := Nat.le_of_dvd h3b0 hgb
        have heq : 3 ^ (b + 1) = 3 ^ b * 3 := by rw [Nat.pow_succ]
        omega
      · have hbeq : b = a := by omega
        have h2 : 3 ^ (b + 1) ≤ 3 ^ b * c := Nat.le_of_dvd (by omega : 0 < 3 ^ b * c) hkdiv
        rw [hbeq] at h2 hkm
        omega
    have hcF : c ∈ (Finset.Icc (1 : ℕ) m).filter (fun j => ¬ 3 ∣ j) :=
      Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨hc1, hcm⟩, hc3⟩
    have hcP : c ∣ P := by rw [hP]; exact a7406_dvd_prod_id hcF
    exact Nat.mul_dvd_mul (pow_dvd_pow 3 hba) hcP
  have hA : ∀ k ∈ Finset.Icc (1 : ℕ) m, 3 ^ a ∣ k → ¬ 3 ∣ N / k := by
    intro k hk hdk
    have hk1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
    have hkm : k ≤ m := (Finset.mem_Icc.mp hk).2
    have h1 : k ∣ N := hdivN k hk
    obtain ⟨t, ht⟩ : ∃ t, k = 3 ^ a * t := hdk
    have ht3 : t < 3 := by
      have hlt : t * 3 ^ a < 3 * 3 ^ a := by
        have h2 : t * 3 ^ a = k := by rw [ht] <;> ring
        rw [h2]
        have hlt' : k < 3 ^ (a + 1) := Nat.lt_of_le_of_lt hkm ha2
        have heq : 3 ^ (a + 1) = 3 * 3 ^ a := by
          rw [Nat.pow_succ]
          ring
        rw [← heq]
        exact hlt'
      exact Nat.lt_of_mul_lt_mul_right hlt
    have ht1 : 1 ≤ t := by
      by_contra h
      have ht0 : t = 0 := by omega
      rw [ht0, Nat.mul_zero] at ht
      omega
    have hP_eq : P = t * (N / k) := by
      refine Nat.eq_of_mul_eq_mul_left h3a0 ?_
      calc 3 ^ a * P = N := hNdef.symm
        _ = k * (N / k) := (Nat.mul_div_cancel' h1).symm
        _ = (3 ^ a * t) * (N / k) := by rw [ht]
        _ = 3 ^ a * (t * (N / k)) := by ring
    intro h3d
    obtain ⟨w, hw⟩ := h3d
    exact hn3P ⟨t * w, by rw [hP_eq, hw] <;> ring⟩
  have key : ∀ x : ℕ, ∀ d k : ℕ, 3 ^ x * P = k * d → ¬ 3 ∣ d → 3 ^ x ∣ k := by
    intro x
    induction x with
    | zero => intro d k _ _; exact one_dvd k
    | succ x ih =>
        intro d k h hnd
        have hdvd3 : 3 ∣ k * d := by
          refine ⟨3 ^ x * P, ?_⟩
          rw [← h, Nat.pow_succ]
          ring
        cases (Nat.Prime.dvd_mul (m := k) (n := d) h3).mp hdvd3 with
        | inl hkd =>
            obtain ⟨k', rfl⟩ := hkd
            have h3eq : 3 * (3 ^ x * P) = 3 ^ (x + 1) * P := by
              rw [Nat.pow_succ]
              ring
            have h2 : 3 ^ x * P = k' * d := by
              refine Nat.eq_of_mul_eq_mul_left (show 0 < 3 from by norm_num) ?_
              rw [h3eq, h]
              ring
            obtain ⟨u, hu⟩ := ih d k' h2 hnd
            use u
            rw [hu, Nat.pow_succ]
            ring
        | inr hdd => exact absurd hdd hnd
  have hB : ∀ k ∈ Finset.Icc (1 : ℕ) m, ¬ 3 ^ a ∣ k → 3 ∣ N / k := by
    intro k hk hnd
    have h1 : k ∣ N := hdivN k hk
    by_contra h
    exact hnd (key a (N / k) k (hNdef.symm.trans ((Nat.mul_div_cancel' h1).symm)) h)
  have hsq0 : ∀ x : ℕ, 3 ∣ x → x ^ 2 % 3 = 0 := by
    intro x hx
    refine Nat.mod_eq_zero_of_dvd ?_
    obtain ⟨y, rfl⟩ := hx
    exact ⟨3 * y ^ 2, by ring⟩
  have hsq1 : ∀ x : ℕ, ¬ 3 ∣ x → x ^ 2 % 3 = 1 := by
    intro x hx
    have hcases : x % 3 = 1 ∨ x % 3 = 2 := by
      have hb : x % 3 < 3 := Nat.mod_lt x (by norm_num : 0 < (3 : ℕ))
      have nz : x % 3 ≠ 0 := by intro h; exact hx (Nat.dvd_of_mod_eq_zero h)
      have aux : ∀ n : ℕ, n < 3 → n ≠ 0 → n = 1 ∨ n = 2 := by
        intro n h1 h2
        interval_cases n
        · exact absurd rfl h2
        · exact Or.inl rfl
        · exact Or.inr rfl
      exact aux (x % 3) hb nz
    cases hcases with
    | inl h => rw [Nat.pow_mod, h] <;> norm_num
    | inr h => rw [Nat.pow_mod, h] <;> norm_num
  have hterm : ∀ k ∈ Finset.Icc (1 : ℕ) m, (N / k) ^ 2 % 3 = if 3 ^ a ∣ k then (1 : ℕ) else 0 := by
    intro k hk
    by_cases h : 3 ^ a ∣ k
    · rw [if_pos h, hsq1 (N / k) (hA k hk h)]
    · rw [if_neg h, hsq0 (N / k) (hB k hk h)]
  have hterm_div : ∀ k ∈ Finset.Icc (1 : ℕ) m, D / k ^ 2 = (N / k) ^ 2 := by
    intro k hk
    obtain ⟨t, ht⟩ : ∃ t, N = k * t := hdivN k hk
    have hkpos : 0 < k := (Finset.mem_Icc.mp hk).1
    have hNk : N / k = t := by
      rw [ht]
      exact Nat.mul_div_cancel_left t hkpos
    have hDk : D = k ^ 2 * t ^ 2 := by
      rw [hD2, ht]
      ring
    rw [hNk, hDk, Nat.mul_div_cancel_left (t ^ 2) (by positivity : 0 < k ^ 2)]
  classical
  let E := (Finset.Icc (1 : ℕ) m).filter (fun k => 3 ^ a ∣ k)
  have hcard : (∑ k ∈ Finset.Icc (1 : ℕ) m, (if 3 ^ a ∣ k then (1 : ℕ) else 0)) = E.card := by
    rw [← Finset.sum_filter]
    exact (Finset.card_eq_sum_ones _).symm
  have hEone : 1 ≤ E.card := by
    have hsing : ({3 ^ a} : Finset ℕ) ⊆ E := by
      rw [Finset.singleton_subset_iff]
      have : 3 ^ a ∈ (Finset.Icc (1 : ℕ) m).filter (fun k => 3 ^ a ∣ k) :=
        Finset.mem_filter.mpr
          ⟨Finset.mem_Icc.mpr ⟨Nat.one_le_pow a 3 (by norm_num : 0 < (3 : ℕ)), ha1⟩, dvd_refl _⟩
      exact this
    have hle : ({3 ^ a} : Finset ℕ).card ≤ E.card := Finset.card_le_card hsing
    rw [Finset.card_singleton] at hle
    omega
  have hEtwo : E.card ≤ 2 := by
    have hsub : E ⊆ ({3 ^ a, 2 * 3 ^ a} : Finset ℕ) := by
      intro k hk
      have hk' : k ∈ (Finset.Icc (1 : ℕ) m).filter (fun k => 3 ^ a ∣ k) := hk
      rw [Finset.mem_filter] at hk'
      obtain ⟨hmem, hdiv⟩ := hk'
      obtain ⟨t, rfl⟩ : ∃ t, k = 3 ^ a * t := hdiv
      rw [Finset.mem_insert, Finset.mem_singleton]
      obtain ⟨hk1v, htle⟩ := Finset.mem_Icc.mp hmem
      have heq : 3 ^ (a + 1) = 3 ^ a * 3 := by rw [Nat.pow_succ]
      have ht3 : t < 3 := by
        have hlt : 3 ^ a * t < 3 ^ a * 3 := by
          have hlt' : 3 ^ a * t < 3 ^ (a + 1) := Nat.lt_of_le_of_lt htle ha2
          rw [heq] at hlt'
          exact hlt'
        exact Nat.lt_of_mul_lt_mul_left hlt
      have ht1 : 1 ≤ t := by
        by_contra h
        have ht0 : t = 0 := by omega
        rw [ht0, Nat.mul_zero] at hk1v
        omega
      rcases (show t = 1 ∨ t = 2 from by omega) with h | h
      · left
        rw [h, Nat.mul_one]
      · right
        rw [h]
        ring
    have h2 : ({3 ^ a, 2 * 3 ^ a} : Finset ℕ).card ≤ 2 := by
      calc ({3 ^ a, 2 * 3 ^ a} : Finset ℕ).card ≤ ({2 * 3 ^ a} : Finset ℕ).card + 1 :=
          Finset.card_insert_le (3 ^ a) ({2 * 3 ^ a} : Finset ℕ)
        _ ≤ 2 := by rw [Finset.card_singleton] <;> omega
    exact Nat.le_trans (Finset.card_le_card hsub) h2
  have hsum_congr : (∑ k ∈ Finset.Icc (1 : ℕ) m, D / k ^ 2) =
      ∑ k ∈ Finset.Icc (1 : ℕ) m, (N / k) ^ 2 :=
    Finset.sum_congr rfl (fun k hk => hterm_div k hk)
  have hmod_sum : ((∑ k ∈ Finset.Icc (1 : ℕ) m, D / k ^ 2) % 3) = E.card := by
    have h2 : ∑ k ∈ Finset.Icc (1 : ℕ) m, (N / k) ^ 2 % 3 =
        ∑ k ∈ Finset.Icc (1 : ℕ) m, (if 3 ^ a ∣ k then (1 : ℕ) else 0) :=
      Finset.sum_congr rfl (fun k hk => hterm k hk)
    rw [hsum_congr, Finset.sum_nat_mod, h2, hcard]
    omega
  intro hdvd
  have h0 : (∑ k ∈ Finset.Icc (1 : ℕ) m, D / k ^ 2) % 3 = 0 := Nat.mod_eq_zero_of_dvd hdvd
  rw [hmod_sum] at h0
  omega

theorem a7406_nat_max_pow_three_exists (m : Nat) (hm1 : 1 ≤ m) :
    ∃ a : Nat, 3 ^ a ≤ m ∧ m < 3 ^ (a + 1) := by
  have key : ∀ k : ℕ, ∃ a : ℕ, 3 ^ a ≤ k + 1 ∧ k + 1 < 3 ^ (a + 1) := by
    intro k
    induction k with
    | zero => exact ⟨0, by norm_num, by norm_num⟩
    | succ k ih =>
      obtain ⟨a, ha1, ha2⟩ := ih
      have hle : k + 1 + 1 ≤ 3 ^ (a + 1) := Nat.succ_le_of_lt ha2
      by_cases h : k + 1 + 1 < 3 ^ (a + 1)
      · exact ⟨a, Nat.le_step ha1, h⟩
      · have heq : k + 1 + 1 = 3 ^ (a + 1) := Nat.le_antisymm hle (Nat.le_of_not_lt h)
        refine ⟨a + 1, Nat.le_of_eq heq.symm, ?_⟩
        have hs : (3 : ℕ) ^ (a + 1 + 1) = 3 ^ (a + 1) * 3 := pow_succ 3 (a + 1)
        have hpos : (0 : ℕ) < 3 ^ (a + 1) := pow_pos (by decide) _
        have h2 : 3 ^ (a + 1) * 1 < 3 ^ (a + 1) * 3 :=
          Nat.mul_lt_mul_of_pos_left (by decide : 1 < (3 : ℕ)) hpos
        rw [Nat.mul_one] at h2
        rw [heq, hs]
        exact h2
  have hm : m = m - 1 + 1 := by omega
  obtain ⟨a, ha1, ha2⟩ := key (m - 1)
  refine ⟨a, ?_, ?_⟩
  · rw [hm]; exact ha1
  · rw [hm]; exact ha2

theorem a7406_padicValRat_three {m : Nat} (hm1 : 1 ≤ m) :
    padicValRat 3 (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0 := by
  obtain ⟨a, ha1, ha2⟩ := a7406_nat_max_pow_three_exists m hm1
  let P := ((Finset.Icc (1 : Nat) m).filter (fun j => ¬ 3 ∣ j)).prod id
  let D := (3 ^ a * P) * (3 ^ a * P)
  have h3p : (0 : Nat) < 3 := by omega
  have h31 : (3 : Nat) ≠ 1 := by omega
  have hP : 0 < P := by
    refine Finset.prod_pos ?_
    intro j hj
    exact (Finset.mem_Icc.mp (Finset.mem_filter.mp hj).1).1
  have hD : 0 < D := by
    have h1 : 0 < 3 ^ a * P := Nat.mul_pos (pow_pos h3p a) hP
    exact Nat.mul_pos h1 h1
  have hdiv : ∀ k ∈ Finset.Icc (1 : Nat) m, k ^ 2 ∣ D := by
    intro k hk
    have hk1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
    have hkm : k ≤ m := (Finset.mem_Icc.mp hk).2
    have hk0 : k ≠ 0 := by omega
    have hpow : 3 ^ padicValNat 3 k ∣ k := pow_padicValNat_dvd
    have hmax : ¬ 3 ^ (padicValNat 3 k + 1) ∣ k := by
      intro hdvd
      have hle :=
        (Nat.pow_dvd_iff_le_padicValNat (p := (3 : Nat)) (n := k) (k := padicValNat 3 k + 1) h31 hk0).mp hdvd
      omega
    have hp3v : 0 < 3 ^ padicValNat 3 k := pow_pos h3p _
    have hle3 : 3 ^ padicValNat 3 k ≤ k := Nat.le_of_dvd (by omega : 0 < k) hpow
    have ht_pos : 0 < k / 3 ^ padicValNat 3 k := Nat.div_pos hle3 hp3v
    have hte : 3 ^ padicValNat 3 k * (k / 3 ^ padicValNat 3 k) = k := Nat.mul_div_cancel' hpow
    have ht_le : k / 3 ^ padicValNat 3 k ≤ k := Nat.div_le_self k _
    have hnot : ¬ 3 ∣ k / 3 ^ padicValNat 3 k := by
      intro hc
      apply hmax
      have h1 : 3 ^ (padicValNat 3 k + 1) ∣ 3 ^ padicValNat 3 k * (k / 3 ^ padicValNat 3 k) := by
        simpa [pow_succ] using Nat.mul_dvd_mul_left (3 ^ padicValNat 3 k) hc
      rwa [hte] at h1
    have hin : k / 3 ^ padicValNat 3 k ∈
        ((Finset.Icc (1 : Nat) m).filter (fun j => ¬ 3 ∣ j)) :=
      Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨by omega, by omega⟩, hnot⟩
    have htP : k / 3 ^ padicValNat 3 k ∣ P := a7406_dvd_prod_id hin
    have hv_le : padicValNat 3 k ≤ a := by
      by_contra hc
      have hp2 : 3 ^ (a + 1) ≤ 3 ^ padicValNat 3 k :=
        Nat.pow_le_pow_right h3p (by omega : a + 1 ≤ padicValNat 3 k)
      omega
    have h1 : 3 ^ padicValNat 3 k * (k / 3 ^ padicValNat 3 k) ∣ 3 ^ padicValNat 3 k * P :=
      Nat.mul_dvd_mul_left _ htP
    have h2 : 3 ^ padicValNat 3 k * P ∣ 3 ^ a * P :=
      Nat.mul_dvd_mul_right (Nat.pow_dvd_pow 3 hv_le) P
    have hkd : k ∣ 3 ^ a * P := by
      rw [← hte]
      exact Nat.dvd_trans h1 h2
    have h3 : k ^ 2 ∣ (3 ^ a * P) ^ 2 := by
      obtain ⟨c, hc⟩ := hkd
      use c * c
      rw [hc, mul_pow]
      ring
    simpa [D, pow_two] using h3
  have key : (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) =
      ((∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 : Nat) : ℚ) / (D : ℚ) :=
    a7406_rat_sum_inv_sq_eq_nat_div_common_den hD hdiv
  have hN : ¬ 3 ∣ ∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 :=
    a7406_three_common_den_quotient_sum_not_dvd ha1 ha2 rfl rfl
  have hres := a7406_padicValRat_div_nat_le_zero (p := 3) hN hD
  rw [key]
  exact hres

theorem a7406_padicValRat_three_two_mod {m : Nat} (hm : m % 3 = 2) (hm1 : 1 ≤ m) :
    padicValRat 3 (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0 := by
  exact a7406_padicValRat_three hm1

theorem a7406_composite_padicValRat_three {p n : Nat} [Fact (Nat.Prime p)]
    (hp : p = 3) (hn : 3 < n) (hpd : p ∣ n) :
    padicValRat p
      (∑ k ∈ Finset.Icc (1 : Nat) (n - 1), (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0 := by
  have h1 : 1 ≤ n - 1 := by omega
  have hsum := a7406_padicValRat_three (m := n - 1) h1
  rw [hp]
  exact hsum

theorem a7406_nat_max_pow_two_exists (m : Nat) (hm1 : 1 ≤ m) :
    ∃ a : Nat, 2 ^ a ≤ m ∧ m < 2 ^ (a + 1) := by
  have hne : m ≠ 0 := by omega
  refine ⟨Nat.log 2 m, Nat.pow_log_le_self 2 hne, ?_⟩
  exact Nat.lt_pow_succ_log_self (by omega : 1 < 2) m

theorem a7406_two_unique_max_multiple {a m : Nat} (h1 : 2 ^ a ≤ m) (h2 : m < 2 ^ (a + 1)) :
    ∀ k : Nat, 1 ≤ k → k ≤ m → 2 ^ a ∣ k → k = 2 ^ a := by
  intro k hk1 hkm hdvd
  obtain ⟨t, rfl⟩ := hdvd
  rw [pow_succ] at h2
  have ht : t < 2 := by
    by_contra h
    have h' : 2 ≤ t := Nat.le_of_not_lt h
    have H : 2 ^ a * 2 ≤ 2 ^ a * t := Nat.mul_le_mul_left (2 ^ a) h'
    exact absurd (lt_of_le_of_lt H (lt_of_le_of_lt hkm h2)) (Nat.lt_irrefl _)
  have ht1 : 0 < t := Nat.pos_of_ne_zero fun e => by
    rw [e, Nat.mul_zero] at hk1
    exact Nat.not_succ_le_zero 0 hk1
  have key : ∀ n : ℕ, n < 2 → 0 < n → n = 1 := by
    intro n hn hn'
    omega
  have : t = 1 := key t ht ht1
  subst this
  exact Nat.mul_one _

theorem a7406_two_common_den_quotient_parity {a m P D : Nat}
    (ha1 : 2 ^ a ≤ m) (ha2 : m < 2 ^ (a + 1))
    (hP : P = ((Finset.Icc (1 : Nat) m).filter (fun j => ¬ 2 ∣ j)).prod id)
    (hD : D = (2 ^ a * P) * (2 ^ a * P)) :
    ∀ k ∈ Finset.Icc (1 : Nat) m,
      k ^ 2 ∣ D ∧ (k ≠ 2 ^ a → 2 ∣ D / k ^ 2) := by
  have hdecomp : ∀ n : Nat, 1 ≤ n → ∃ b u : Nat, n = 2 ^ b * u ∧ ¬ 2 ∣ u := by
    intro n
    induction' n using Nat.strong_induction_on with n ih
    intro hn
    by_cases h2 : 2 ∣ n
    · obtain ⟨c, hc⟩ := h2
      have hc1 : 1 ≤ c := by omega
      have hcn : c < n := by omega
      obtain ⟨b, u, hbu, hu⟩ := ih c hcn hc1
      refine ⟨b + 1, u, ?_, hu⟩
      rw [hc, hbu, pow_succ']
      exact (Nat.mul_assoc 2 (2 ^ b) u).symm
    · exact ⟨0, n, by rw [pow_zero, one_mul], h2⟩
  intro k hk
  have hk1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
  have hkm : k ≤ m := (Finset.mem_Icc.mp hk).2
  have hk0 : 0 < k := by omega
  obtain ⟨b, u, hbu, huodd⟩ := hdecomp k hk1
  have hu_ne : u ≠ 0 := by
    intro h
    rw [h, Nat.mul_zero] at hbu
    omega
  have hu1 : 1 ≤ u := Nat.pos_of_ne_zero hu_ne
  have hu_le_k : u ≤ k := Nat.le_of_dvd hk0 ⟨2 ^ b, by rw [mul_comm, hbu]⟩
  have h2b_le_k : 2 ^ b ≤ k := Nat.le_of_dvd hk0 ⟨u, hbu⟩
  have hb0 : 0 < 2 ^ b := Nat.pos_of_dvd_of_pos ⟨u, hbu⟩ hk0
  have hu_le_m : u ≤ m := le_trans hu_le_k hkm
  have hudvdP : u ∣ P := by
    rw [hP]
    refine a7406_dvd_prod_id ?_
    rw [Finset.mem_filter, Finset.mem_Icc]
    exact ⟨⟨hu1, hu_le_m⟩, huodd⟩
  have hb_le_a : b ≤ a := by
    by_contra h
    push_neg at h
    have hpow : 2 ^ (a + 1) ≤ 2 ^ b := by
      gcongr <;> omega
    exact lt_irrefl _ (lt_of_le_of_lt hpow (lt_of_le_of_lt h2b_le_k (lt_of_le_of_lt hkm ha2)))
  have hkdvd : k ∣ 2 ^ a * P := by
    rw [hbu]
    exact Nat.mul_dvd_mul (Nat.pow_dvd_pow 2 hb_le_a) hudvdP
  obtain ⟨t, ht⟩ := hkdvd
  have hsq : D = k ^ 2 * t ^ 2 := by
    rw [hD, ht]
    ring
  have hk2 : 0 < k ^ 2 := by
    have hpow : k ^ 2 = k * k := by ring
    rw [hpow]
    exact Nat.mul_pos hk0 hk0
  have hquot : D / k ^ 2 = t ^ 2 :=
    Nat.div_eq_of_eq_mul_left hk2 (by rw [hsq]; ring)
  refine ⟨⟨t ^ 2, hsq⟩, fun hkne => ?_⟩
  have hb_lt_a : b < a := by
    apply Nat.lt_of_le_of_ne hb_le_a
    intro hba
    apply hkne
    have hd : 2 ^ a ∣ k := ⟨u, by rw [hbu, hba]⟩
    exact a7406_two_unique_max_multiple ha1 ha2 k hk1 hkm hd
  have hpowa : 2 ^ a = 2 ^ b * 2 ^ (a - b) := by
    rw [← pow_add, Nat.add_sub_cancel' (Nat.le_of_lt hb_lt_a)]
  have hcancel : u * t = 2 ^ (a - b) * P := by
    have h1 : 2 ^ b * (u * t) = 2 ^ b * (2 ^ (a - b) * P) := by
      calc 2 ^ b * (u * t) = (2 ^ b * u) * t := (Nat.mul_assoc _ _ _).symm
        _ = k * t := by rw [hbu]
        _ = 2 ^ a * P := ht.symm
        _ = (2 ^ b * 2 ^ (a - b)) * P := by rw [hpowa]
        _ = 2 ^ b * (2 ^ (a - b) * P) := Nat.mul_assoc _ _ _
    exact Nat.eq_of_mul_eq_mul_left hb0 h1
  have h2ab : 2 ∣ 2 ^ (a - b) := by
    obtain ⟨e, he⟩ : ∃ e, a - b = e + 1 := ⟨a - b - 1, by omega⟩
    rw [he, pow_succ']
    exact ⟨2 ^ e, rfl⟩
  have h2ut : 2 ∣ u * t := by
    rw [hcancel]
    obtain ⟨s, hs⟩ := h2ab
    rw [hs]
    exact ⟨s * P, Nat.mul_assoc 2 s P⟩
  have h2t : 2 ∣ t := ((Nat.Prime.dvd_mul Nat.prime_two).mp h2ut).resolve_left huodd
  have h2t2 : 2 ∣ t ^ 2 := by
    obtain ⟨s, hs⟩ := h2t
    use 2 * s ^ 2
    rw [hs]
    ring
  rw [hquot]
  exact h2t2

theorem a7406_two_sum_odd_num {a m P D : Nat}
    (ha1 : 2 ^ a ≤ m)
    (hPodd : ¬ 2 ∣ P)
    (hD : D = (2 ^ a * P) * (2 ^ a * P))
    (hq : ∀ k ∈ Finset.Icc (1 : Nat) m,
        k ^ 2 ∣ D ∧ (k ≠ 2 ^ a → 2 ∣ D / k ^ 2)) :
    ¬ 2 ∣ ∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 := by
  have ht1 : 1 ≤ (2 : Nat) ^ a := Nat.one_le_pow a 2 (by norm_num : (0 : Nat) < 2)
  have hpz : 0 < (2 : Nat) ^ a := by omega
  have htmem : (2 : Nat) ^ a ∈ Finset.Icc (1 : Nat) m :=
    Finset.mem_Icc.mpr ⟨ht1, ha1⟩
  have hsum : ∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 =
      (∑ k ∈ (Finset.Icc (1 : Nat) m).erase ((2 : Nat) ^ a), D / k ^ 2) + D / ((2 : Nat) ^ a) ^ 2 :=
    (Finset.sum_erase_add (Finset.Icc (1 : Nat) m) (fun k => D / k ^ 2) htmem).symm
  have hAeven : 2 ∣ ∑ k ∈ (Finset.Icc (1 : Nat) m).erase ((2 : Nat) ^ a), D / k ^ 2 := by
    refine Finset.dvd_sum ?_
    intro k hk
    obtain ⟨hne, hmem⟩ := Finset.mem_erase.mp hk
    exact (hq k hmem).2 hne
  have hB : D / ((2 : Nat) ^ a) ^ 2 = P * P := by
    have hp : ((2 : Nat) ^ a) ^ 2 = (2 : Nat) ^ a * 2 ^ a := by ring
    have heq : (2 ^ a * P) * (2 ^ a * P) = (2 ^ a * 2 ^ a) * (P * P) := by ring
    rw [hD, hp, heq]
    exact Nat.mul_div_cancel_left (P * P) (Nat.mul_pos hpz hpz)
  have hPmod : P % 2 = 1 := by
    cases' Nat.mod_two_eq_zero_or_one P with h h
    · exact absurd (Nat.dvd_of_mod_eq_zero h) hPodd
    · exact h
  have hBmod : D / ((2 : Nat) ^ a) ^ 2 % 2 = 1 := by
    rw [hB, Nat.mul_mod, hPmod]
  have hAmod : (∑ k ∈ (Finset.Icc (1 : Nat) m).erase ((2 : Nat) ^ a), D / k ^ 2) % 2 = 0 :=
    Nat.mod_eq_zero_of_dvd hAeven
  intro hdiv
  have hmod := Nat.mod_eq_zero_of_dvd hdiv
  rw [hsum, Nat.add_mod, hAmod, hBmod] at hmod
  exact absurd hmod (by decide)

theorem a7406_padicValRat_two {m : Nat} (hm1 : 1 ≤ m) :
    padicValRat 2 (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0 := by
  haveI : Fact (Nat.Prime 2) := ⟨by decide⟩
  obtain ⟨a, ha1, ha2⟩ := a7406_nat_max_pow_two_exists m hm1
  let P := ((Finset.Icc (1 : Nat) m).filter (fun j => ¬ 2 ∣ j)).prod id
  let D := (2 ^ a * P) * (2 ^ a * P)
  have hPodd : ¬ 2 ∣ P := by
    have hc : Nat.Coprime 2 P :=
      a7406_coprime_prod_of_each (p := 2)
        (s := (Finset.Icc (1 : Nat) m).filter (fun j => ¬ 2 ∣ j))
        (fun x hx =>
          (Nat.Prime.coprime_iff_not_dvd Nat.prime_two).2 ((Finset.mem_filter.mp hx).2))
    exact ((Nat.Prime.coprime_iff_not_dvd Nat.prime_two).1 hc)
  have hP0 : 0 < P := by
    refine Finset.prod_pos (fun x hx => ?_)
    have hmem : x ∈ Finset.Icc (1 : Nat) m := (Finset.mem_filter.mp hx).1
    have h1x : 1 ≤ x := (Finset.mem_Icc.mp hmem).1
    change 0 < x
    exact Nat.lt_of_lt_of_le (by decide : 0 < 1) h1x
  have hp2a : 0 < (2 : ℕ) ^ a := pow_pos (by decide : (0 : ℕ) < 2) a
  have hmul : 0 < 2 ^ a * P := mul_pos hp2a hP0
  have hD0 : 0 < D := mul_pos hmul hmul
  have hDdef : D = (2 ^ a * P) * (2 ^ a * P) := rfl
  have hPdef : P = ((Finset.Icc (1 : Nat) m).filter (fun j => ¬ 2 ∣ j)).prod id := rfl
  have hpar : ∀ k ∈ Finset.Icc (1 : Nat) m,
      k ^ 2 ∣ D ∧ (k ≠ 2 ^ a → 2 ∣ D / k ^ 2) :=
    a7406_two_common_den_quotient_parity ha1 ha2 hPdef hDdef
  have hsum : (∑ k ∈ Finset.Icc (1 : Nat) m, (1 : ℚ) / ((k : ℚ) ^ 2)) =
      ((∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 : Nat) : ℚ) / (D : ℚ) :=
    a7406_rat_sum_inv_sq_eq_nat_div_common_den hD0 (fun k hk => (hpar k hk).1)
  have hodd : ¬ 2 ∣ ∑ k ∈ Finset.Icc (1 : Nat) m, D / k ^ 2 :=
    a7406_two_sum_odd_num ha1 hPodd hDdef hpar
  rw [hsum]
  exact a7406_padicValRat_div_nat_le_zero hodd hD0

theorem a7406_padicValRat_two_odd {m : Nat} (hm : m % 2 = 1) (hm1 : 1 ≤ m) :
    padicValRat 2 (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0 := by
  exact a7406_padicValRat_two hm1

theorem a7406_composite_padicValRat_two {p n : Nat} [Fact (Nat.Prime p)]
    (hp : p = 2) (hn : 3 < n) (hpd : p ∣ n) :
    padicValRat p
      (∑ k ∈ Finset.Icc (1 : Nat) (n - 1), (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0 := by
  subst hp
  have h1 : 1 ≤ n - 1 := by omega
  exact a7406_padicValRat_two (m := n - 1) h1

theorem a7406_disjoint_Ico {p t : Nat} (hp : 1 < p) :
    Disjoint ((Finset.Ico (1 : Nat) t).image (fun m : Nat => p * m))
      ((Finset.product (Finset.range t) (Finset.Ico (1 : Nat) p)).image
          (fun x : Nat × Nat => x.1 * p + x.2)) := by
  refine Finset.disjoint_left.mpr ?_
  intro x hx hxb
  rw [Finset.mem_image] at hx
  obtain ⟨m, hm, rfl⟩ := hx
  rw [Finset.mem_image] at hxb
  obtain ⟨⟨a, b⟩, hab, h⟩ := hxb
  have h2 : a * p + b = p * m := h
  have h1 : (a, b) ∈ (Finset.range t) ×ˢ (Finset.Ico (1 : Nat) p) := hab
  rw [Finset.mem_product] at h1
  rw [Finset.mem_range, Finset.mem_Ico] at h1
  obtain ⟨hat, hb1, hbp⟩ := h1
  have hb : b = p * (m - a) :=
    calc b = p * m - a * p := by rw [← h2]; omega
         _ = p * m - p * a := by rw [Nat.mul_comm a p]
         _ = p * (m - a) := (Nat.mul_sub_left_distrib p m a).symm
  have hdv : p ∣ b := ⟨m - a, hb⟩
  have hle : p ≤ b := Nat.le_of_dvd (by omega) hdv
  omega

theorem a7406_padicValRat_nat_div_one_le
    {p N D : Nat} [Fact (Nat.Prime p)]
    (hpN : p ∣ N) (hN : N ≠ 0) (hD : 0 < D) (hDcop : ¬ p ∣ D) :
    1 ≤ padicValRat p ((N : ℚ) / (D : ℚ)) := by
  have hN0 : (N : ℚ) ≠ 0 := by exact_mod_cast hN
  have hD0 : (D : ℚ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hD)
  have hval : padicValRat p ((N : ℚ) / (D : ℚ)) = (padicValNat p N : ℤ) - (padicValNat p D : ℤ) := by
    rw [padicValRat.div hN0 hD0, ← padicValRat_of_nat N, ← padicValRat_of_nat D]
  have h1n : 1 ≤ padicValNat p N := one_le_padicValNat_of_dvd (n := N) hN hpN
  have h1 : (1 : ℤ) ≤ (padicValNat p N : ℤ) := by exact_mod_cast h1n
  have h2 : padicValNat p D = 0 := padicValNat.eq_zero_of_not_dvd hDcop
  rw [hval, h2]
  simpa using h1

theorem a7406_nonmult_block_padicVal_ge_one
    {p t : Nat} [Fact (Nat.Prime p)] (h : 3 < p) (ht : 1 ≤ t) :
    1 ≤ padicValRat p
      (∑ j ∈ Finset.range t,
        (∑ r ∈ Finset.Icc 1 (p - 1),
          (1 : ℚ) / ((((j * p + r : Nat) : ℚ) ^ 2)))) := by
  have hp : 1 < p := by omega
  rw [a7406_block_double_sum_eq_product, a7406_block_clear_denom_eq hp ht]
  refine a7406_padicValRat_nat_div_one_le ?_ ?_ ?_ ?_
  · exact a7406_block_clear_denom_num_dvd h ht
  · exact a7406_block_num_ne_zero hp ht
  · exact a7406_block_clear_denom_pos hp ht
  · exact a7406_block_clear_denom_not_dvd ht

theorem a7406_padicValRat_add_lt
    {p : Nat} [Fact (Nat.Prime p)] {x y : ℚ}
    (hx : x ≠ 0) (h : padicValRat p x < padicValRat p y) :
    padicValRat p (x + y) = padicValRat p x := by
  by_cases hy : y = 0
  · rw [hy, add_zero]
  · have hxy : x + y ≠ 0 := by
      intro hcon
      have hx2 : x = -y := by
        rw [eq_neg_iff_add_eq_zero]
        exact hcon
      rw [hx2, padicValRat.neg] at h
      exact lt_irrefl _ h
    exact padicValRat.add_eq_of_lt hxy hx hy h

theorem a7406_padicValRat_div_p_sq
    {p : Nat} [Fact (Nat.Prime p)] {r : ℚ} (hr : r ≠ 0) :
    padicValRat p (r / ((p : ℚ) ^ 2)) = padicValRat p r - 2 := by
  have hpp : Nat.Prime p := Fact.out
  have hpos : (p : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr hpp.ne_zero
  have hs : padicValRat p (p : ℚ) = 1 := padicValRat.self hpp.one_lt
  have h2 : padicValRat p ((p : ℚ) ^ 2) = 2 := by
    rw [pow_two, padicValRat.mul hpos hpos, hs]
    norm_num
  rw [padicValRat.div hr (pow_ne_zero 2 hpos), h2]

theorem a7406_split_Ico {p t : Nat} (hp : 1 < p) :
    Finset.Ico (1 : Nat) (p * t) =
      (Finset.Ico (1 : Nat) t).image (fun m : Nat => p * m) ∪
        (Finset.product (Finset.range t) (Finset.Ico (1 : Nat) p)).image
          (fun x : Nat × Nat => x.1 * p + x.2) := by
  have hp0 : 0 < p := by omega
  have hp1 : 1 ≤ p := by omega
  ext n
  constructor
  · intro h
    obtain ⟨h1, h2⟩ := Finset.mem_Ico.mp h
    have hmod : n % p < p := Nat.mod_lt n hp0
    have hkey1 : p * (n / p) + n % p = n :=
      (Nat.add_comm (n % p) (p * (n / p))).symm.trans (Nat.mod_add_div n p)
    have hkey : n / p * p + n % p = n := by
      rw [Nat.mul_comm (n / p) p]
      exact hkey1
    have hB : n / p * p ≤ n := by
      have hle : n / p * p ≤ n / p * p + n % p := Nat.le_add_right _ _
      rw [hkey] at hle
      exact hle
    by_cases hm : n % p = 0
    · have hkey' : p * (n / p) = n := by
        have htmp := hkey1
        rw [hm, add_zero] at htmp
        exact htmp
      have hq1 : 1 ≤ n / p := by
        by_contra hc
        rw [Nat.not_le] at hc
        have hz : n / p = 0 := Nat.lt_one_iff.mp hc
        rw [hz, mul_zero] at hkey'
        omega
      have hqt : n / p < t := by
        by_contra hc
        have hge : t ≤ n / p := Nat.le_of_not_lt hc
        have hA : t * p ≤ n / p * p := Nat.mul_le_mul_right p hge
        have hC : p * t ≤ n := by
          rw [Nat.mul_comm]
          exact Nat.le_trans hA hB
        linarith
      apply Finset.mem_union.mpr
      left
      exact Finset.mem_image.mpr ⟨n / p, Finset.mem_Ico.mpr ⟨hq1, hqt⟩, hkey'⟩
    · have hqt : n / p < t := by
        by_contra hc
        have hge : t ≤ n / p := Nat.le_of_not_lt hc
        have hA : t * p ≤ n / p * p := Nat.mul_le_mul_right p hge
        have hC : p * t ≤ n := by
          rw [Nat.mul_comm]
          exact Nat.le_trans hA hB
        linarith
      have hr1 : 1 ≤ n % p := Nat.pos_of_ne_zero hm
      apply Finset.mem_union.mpr
      right
      exact Finset.mem_image.mpr ⟨(n / p, n % p),
        Finset.mem_product.mpr ⟨Finset.mem_range.mpr hqt, Finset.mem_Ico.mpr ⟨hr1, hmod⟩⟩, hkey⟩
  · intro h
    obtain hL | hR := Finset.mem_union.mp h
    · obtain ⟨m, hm, hnm⟩ := Finset.mem_image.mp hL
      obtain ⟨hm1, hm2⟩ := Finset.mem_Ico.mp hm
      have hnm' : p * m = n := hnm
      have h1' : 1 ≤ p * m := by
        have hle : 1 * m ≤ p * m := Nat.mul_le_mul_right m hp1
        have h2 : m ≤ p * m := by simpa using hle
        exact Nat.le_trans hm1 h2
      have h2' : p * m < p * t := Nat.mul_lt_mul_of_pos_left hm2 hp0
      rw [hnm'] at h1' h2'
      exact Finset.mem_Ico.mpr ⟨h1', h2'⟩
    · obtain ⟨x, hx, hnx⟩ := Finset.mem_image.mp hR
      obtain ⟨hx1, hx2⟩ := Finset.mem_product.mp hx
      have hk : x.1 < t := Finset.mem_range.mp hx1
      obtain ⟨hr1, hr2⟩ := Finset.mem_Ico.mp hx2
      have hnx' : x.1 * p + x.2 = n := hnx
      have hA : 1 ≤ x.1 * p + x.2 := Nat.le_trans hr1 (Nat.le_add_left x.2 (x.1 * p))
      have hBnd : x.1 * p + x.2 < p * t := by
        have ht : x.1 + 1 ≤ t := by omega
        have hlt : x.1 * p + x.2 < (x.1 + 1) * p := by
          rw [Nat.add_mul, Nat.one_mul]
          exact Nat.add_lt_add_left hr2 (x.1 * p)
        have hle : (x.1 + 1) * p ≤ t * p := Nat.mul_le_mul_right p ht
        have h1 : x.1 * p + x.2 < t * p := calc
          x.1 * p + x.2 < (x.1 + 1) * p := hlt
          _ ≤ t * p := hle
        rwa [Nat.mul_comm p t]
      rw [hnx'] at hA hBnd
      exact Finset.mem_Ico.mpr ⟨hA, hBnd⟩

theorem a7406_sum_scaled_Ico {p t : Nat} (hp : 1 < p) :
    ∑ k ∈ (Finset.Ico (1 : Nat) t).image (fun m : Nat => p * m),
        (1 : ℚ) / ((k : ℚ) ^ 2) =
      ((∑ m ∈ Finset.Ico (1 : Nat) t, (1 : ℚ) / ((m : ℚ) ^ 2)) / ((p : ℚ) ^ 2)) := by
  have hp0 : 0 < p := by omega
  have hinj_on : Set.InjOn (fun m : ℕ => p * m) (Finset.Ico (1 : ℕ) t : Set ℕ) := by
    intro a _ b _ h
    exact Nat.eq_of_mul_eq_mul_left hp0 h
  have hsum : ∑ k ∈ (Finset.Ico (1 : Nat) t).image (fun m : Nat => p * m), (1 : ℚ) / ((k : ℚ) ^ 2)
      = ∑ m ∈ Finset.Ico (1 : Nat) t, (1 : ℚ) / (((p * m : ℕ) : ℚ) ^ 2) := by
    rw [Finset.sum_image (ι := ℕ) (κ := ℕ) (M := ℚ)
        (f := fun k : ℕ => (1 : ℚ) / ((k : ℚ) ^ 2))
        (s := Finset.Ico (1 : ℕ) t) (g := fun m : ℕ => p * m) hinj_on]
  have key : ∑ m ∈ Finset.Ico (1 : Nat) t, (1 : ℚ) / (((p * m : ℕ) : ℚ) ^ 2)
      = ∑ m ∈ Finset.Ico (1 : Nat) t, (1 : ℚ) / ((m : ℚ) ^ 2) / ((p : ℚ) ^ 2) :=
    Finset.sum_congr (M := ℚ) rfl fun m hm => by
      have hm0 : (m : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt ((Finset.mem_Ico.mp hm).1))
      have hpq0 : (p : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.ne_of_gt hp0)
      rw [Nat.cast_mul, mul_pow]
      field_simp [hm0, hpq0]
  rw [hsum, key]
  simp only [div_eq_mul_inv, one_mul]
  rw [← Finset.sum_mul]

theorem a7406_sum_offset_Ico {p t : Nat} (hp : 1 < p) :
    ∑ k ∈ (Finset.product (Finset.range t) (Finset.Ico (1 : Nat) p)).image
          (fun x : Nat × Nat => x.1 * p + x.2),
        (1 : ℚ) / ((k : ℚ) ^ 2) =
      ∑ j ∈ Finset.range t, ∑ r ∈ Finset.Ico (1 : Nat) p,
          (1 : ℚ) / ((((j * p + r : Nat) : ℚ) ^ 2)) := by
  classical
  have key : Set.InjOn (fun x : ℕ × ℕ => x.1 * p + x.2)
      (↑(Finset.product (Finset.range t) (Finset.Ico (1 : ℕ) p))) := by
    rintro ⟨j1, r1⟩ hx1 ⟨j2, r2⟩ hx2 h
    have h1 : 1 ≤ r1 ∧ r1 < p := Finset.mem_Ico.mp (Finset.mem_product.mp hx1).2
    have h2 : 1 ≤ r2 ∧ r2 < p := Finset.mem_Ico.mp (Finset.mem_product.mp hx2).2
    have e1 : (j1 * p + r1) % p = r1 := by
      rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt h1.2]
    have e2 : (j2 * p + r2) % p = r2 := by
      rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt h2.2]
    have h' : j1 * p + r1 = j2 * p + r2 := h
    have hr : r1 = r2 := by rw [← e1, ← e2, h']
    subst hr
    have hj : j1 = j2 :=
      Nat.eq_of_mul_eq_mul_right (by omega : 0 < p) (Nat.add_right_cancel h')
    exact Prod.ext hj rfl
  rw [Finset.sum_image key]
  rw [show (Finset.range t).product (Finset.Ico (1 : ℕ) p) =
        Finset.range t ×ˢ Finset.Ico (1 : ℕ) p from rfl]
  rw [Finset.sum_product]

theorem a7406_sum_decomp_Ico {p t : Nat} (hp : 1 < p) :
    (∑ k ∈ Finset.Ico (1 : Nat) (p * t), (1 : ℚ) / ((k : ℚ) ^ 2)) =
      ((∑ m ∈ Finset.Ico (1 : Nat) t, (1 : ℚ) / ((m : ℚ) ^ 2)) / ((p : ℚ) ^ 2)) +
        ∑ j ∈ Finset.range t, ∑ r ∈ Finset.Ico (1 : Nat) p,
          (1 : ℚ) / ((((j * p + r : Nat) : ℚ) ^ 2)) := by
  have hsplit : Finset.Ico (1 : Nat) (p * t) =
      (Finset.Ico (1 : Nat) t).image (fun m : Nat => p * m) ∪
        (Finset.product (Finset.range t) (Finset.Ico (1 : Nat) p)).image
          (fun x : Nat × Nat => x.1 * p + x.2) := a7406_split_Ico hp
  have hdisj : Disjoint ((Finset.Ico (1 : Nat) t).image (fun m : Nat => p * m))
      ((Finset.product (Finset.range t) (Finset.Ico (1 : Nat) p)).image
          (fun x : Nat × Nat => x.1 * p + x.2)) := a7406_disjoint_Ico hp
  rw [hsplit, Finset.sum_union hdisj]
  rw [a7406_sum_scaled_Ico hp, a7406_sum_offset_Ico hp]

theorem a7406_sum_decomp_mul_prime_sub_one {p t : Nat} (hp : 1 < p) :
    (∑ k ∈ Finset.Icc 1 (p * t - 1), (1 : ℚ) / ((k : ℚ) ^ 2)) =
      ((∑ k ∈ Finset.Icc 1 (t - 1), (1 : ℚ) / ((k : ℚ) ^ 2)) / (p : ℚ) ^ 2) +
        ∑ j ∈ Finset.range t,
          (∑ r ∈ Finset.Icc 1 (p - 1),
            (1 : ℚ) / ((((j * p + r : Nat) : ℚ) ^ 2))) := by
  rw [a7406_Icc_pred_eq_Ico (p * t), a7406_Icc_pred_eq_Ico t, a7406_Icc_pred_eq_Ico p]
  exact a7406_sum_decomp_Ico hp

#ga_audit_proof a7406_Icc_pred_eq_Ico
#ga_audit_proof a7406_dvd_prod_id
#ga_audit_proof a7406_nat_div_cast_eq_rat_div
#ga_audit_proof a7406_dvd_prod_sq
#ga_audit_proof a7406_block_clear_denom_eq
#ga_audit_proof a7406_coprime_pow
#ga_audit_proof a7406_coprime_prod_of_each
#ga_audit_proof a7406_not_dvd_of_coprime_prime
#ga_audit_proof a7406_block_factor_coprime
#ga_audit_proof a7406_block_factor_sq_coprime
#ga_audit_proof a7406_block_clear_denom_not_dvd
#ga_audit_proof a7406_zmod_Icc_image_eq_units
#ga_audit_proof a7406_zmod_units_sum_sq_zero
#ga_audit_proof a7406_zmod_Icc_inv_sq_sum_zero
#ga_audit_proof a7406_block_clear_denom_num_cast_zero
#ga_audit_proof a7406_nat_cast_zero_dvd
#ga_audit_proof a7406_block_clear_denom_num_dvd
#ga_audit_proof a7406_block_clear_denom_pos
#ga_audit_proof a7406_block_double_sum_eq_product
#ga_audit_proof a7406_block_num_ne_zero
#ga_audit_proof a7406_composite_exists_mul
#ga_audit_proof rational_dvd_num_iff_padicValRat_pos
#ga_audit_proof a7406_padicValRat_div_nat_le_zero
#ga_audit_proof a7406_rat_sum_inv_sq_eq_nat_div_common_den
#ga_audit_proof a7406_three_common_den_quotient_sum_not_dvd
#ga_audit_proof a7406_nat_max_pow_three_exists
#ga_audit_proof a7406_padicValRat_three
#ga_audit_proof a7406_padicValRat_three_two_mod
#ga_audit_proof a7406_composite_padicValRat_three
#ga_audit_proof a7406_nat_max_pow_two_exists
#ga_audit_proof a7406_two_unique_max_multiple
#ga_audit_proof a7406_two_common_den_quotient_parity
#ga_audit_proof a7406_two_sum_odd_num
#ga_audit_proof a7406_padicValRat_two
#ga_audit_proof a7406_padicValRat_two_odd
#ga_audit_proof a7406_composite_padicValRat_two
#ga_audit_proof a7406_disjoint_Ico
#ga_audit_proof a7406_padicValRat_nat_div_one_le
#ga_audit_proof a7406_nonmult_block_padicVal_ge_one
#ga_audit_proof a7406_padicValRat_add_lt
#ga_audit_proof a7406_padicValRat_div_p_sq
#ga_audit_proof a7406_split_Ico
#ga_audit_proof a7406_sum_scaled_Ico
#ga_audit_proof a7406_sum_offset_Ico
#ga_audit_proof a7406_sum_decomp_Ico
#ga_audit_proof a7406_sum_decomp_mul_prime_sub_one
