import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.GCD.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-!
Partial results for OEIS A135508.

The definitions below are copied verbatim from Formal Conjectures commit
137aec5c7abd3aa61f7a73138a97279acfc79e93, OEIS/135508.lean.
Source: https://oeis.org/A135508

This file does not assert the complete conjecture.
-/

namespace OeisA135508

def x : ℕ → ℕ
  | 0 => 0
  | 1 => 1
  | n + 1 => 2 * x n + Nat.lcm (x n) (n + 1)

def a (n : ℕ) : ℕ :=
  if n = 0 then 0 else (x (n + 1) / x n) - 2

theorem x_step (n : ℕ) (hn : 1 ≤ n) :
    x (n + 1) = x n * (2 + (n + 1) / Nat.gcd (x n) (n + 1)) := by
  obtain ⟨k, rfl⟩ := Nat.exists_eq_succ_of_ne_zero (by omega : n ≠ 0)
  rw [x, Nat.lcm_eq_mul_div, Nat.mul_div_assoc _ (Nat.gcd_dvd_right _ _)]
  · ring
  · omega

theorem x_pos (n : ℕ) (hn : 1 ≤ n) : 0 < x n := by
  induction n with
  | zero => omega
  | succ n ih =>
    by_cases h : n = 0
    · subst n; decide
    · rw [x_step n (by omega)]
      exact Nat.mul_pos (ih (by omega)) (Nat.add_pos_left (by decide) _)

theorem x_dvd_next (n : ℕ) (hn : 1 ≤ n) : x n ∣ x (n + 1) := by
  rw [x_step n hn]
  exact dvd_mul_right _ _

theorem x_dvd_of_le {i j : ℕ} (hi : 1 ≤ i) (hij : i ≤ j) : x i ∣ x j := by
  induction j, hij using Nat.le_induction with
  | base => exact dvd_rfl
  | succ j hij ih => exact ih.trans (x_dvd_next j (by omega))

theorem a_eq_quotient (n : ℕ) (hn : 1 ≤ n) :
    a n = (n + 1) / Nat.gcd (x n) (n + 1) := by
  rw [a, if_neg (by omega), x_step n hn, Nat.mul_div_cancel_left _ (x_pos n hn)]
  exact Nat.add_sub_cancel_left 2 _

theorem a_at_prime {p : ℕ} (hp : p.Prime) (h : ¬ p ∣ x (p - 1)) :
    a (p - 1) = p := by
  have hp2 := hp.two_le
  rw [a_eq_quotient _ (by omega), Nat.sub_add_cancel (by omega)]
  have hc : Nat.Coprime (x (p - 1)) p := (hp.coprime_iff_not_dvd.mpr h).symm
  rw [hc.gcd_eq_one, Nat.div_one]

theorem a_at_prime_of_dvd {p : ℕ} (hp : p.Prime) (h : p ∣ x (p - 1)) :
    a (p - 1) = 1 := by
  have hp2 := hp.two_le
  rw [a_eq_quotient _ (by omega), Nat.sub_add_cancel (by omega),
    Nat.gcd_eq_right h, Nat.div_self hp.pos]

/-- Before index `p-2`, no multiplier in the recurrence can introduce the prime `p`. -/
theorem prime_not_dvd_early {p : ℕ} (hp : p.Prime) :
    ∀ n : ℕ, 1 ≤ n → n + 2 < p → ¬ p ∣ x n := by
  intro n
  induction n with
  | zero => omega
  | succ n ih =>
    intro hn hnp
    by_cases h : n = 0
    · subst n
      simpa [x] using hp.not_dvd_one
    · rw [x_step n (by omega)]
      apply hp.not_dvd_mul (ih (by omega) (by omega))
      apply Nat.not_dvd_of_pos_of_lt (Nat.add_pos_left (by decide) _)
      have := Nat.div_le_self (n + 1) (Nat.gcd (x n) (n + 1))
      omega

/-- An exact obstruction: for a prime greater than three, it can enter by index `p-1`
only through the multiplier at index `p-2`. -/
theorem prime_not_dvd_of_gcd {p : ℕ} (hp : p.Prime) (hp3 : 3 < p)
    (hg : 1 < Nat.gcd (x (p - 3)) (p - 2)) : ¬ p ∣ x (p - 1) := by
  have hprev : ¬ p ∣ x (p - 3) := prime_not_dvd_early hp _ (by omega) (by omega)
  have hmid : ¬ p ∣ x (p - 2) := by
    rw [show p - 2 = (p - 3) + 1 by omega, x_step _ (by omega)]
    apply hp.not_dvd_mul hprev
    apply Nat.not_dvd_of_pos_of_lt (Nat.add_pos_left (by decide) _)
    have hd : (p - 2) / Nat.gcd (x (p - 3)) (p - 2) < p - 2 :=
      Nat.div_lt_self (by omega) hg
    simpa only [show p - 3 + 1 = p - 2 by omega] using (show
      2 + (p - 2) / Nat.gcd (x (p - 3)) (p - 2) < p by omega)
  rw [show p - 1 = (p - 2) + 1 by omega, x_step _ (by omega)]
  apply hp.not_dvd_mul hmid
  intro hdvd
  let g := Nat.gcd (x (p - 2)) (p - 1)
  let q := (p - 1) / g
  have hq : q ≤ p - 1 := Nat.div_le_self _ _
  have hpred : p - 1 + 1 = p := by omega
  have hdvd' : p ∣ 2 + q := by
    simpa only [show p - 2 + 1 = p - 1 by omega] using hdvd
  have heq : 2 + q = p := by
    obtain ⟨t, ht⟩ := hdvd'
    have ht1 : t ≥ 1 := by nlinarith
    have ht2 : t < 2 := by nlinarith
    have htone : t = 1 := by omega
    simpa only [htone, Nat.mul_one] using ht
  have hdiv : q ∣ p - 1 := Nat.div_dvd_of_dvd (Nat.gcd_dvd_right _ _)
  have hqeq : q = p - 2 := by omega
  rw [hqeq] at hdiv
  have : p - 2 ∣ 1 := (Nat.dvd_add_iff_right (dvd_refl (p - 2))).mpr
    (by simpa only [show p - 2 + 1 = p - 1 by omega] using hdiv)
  have := Nat.le_of_dvd (by omega : 0 < (1 : ℕ)) this
  omega

/-- The original prime-index question reduces to one earlier gcd. -/
theorem prime_index_iff {p : ℕ} (hp : p.Prime) (hp3 : 3 < p) :
    a (p - 1) = p ↔ 1 < Nat.gcd (x (p - 3)) (p - 2) := by
  constructor
  · intro ha
    by_contra h
    have hgpos := Nat.gcd_pos_of_pos_right (x (p - 3)) (show 0 < p - 2 by omega)
    have hg : Nat.gcd (x (p - 3)) (p - 2) = 1 := by omega
    have hd : p ∣ x (p - 2) := by
      rw [show p - 2 = (p - 3) + 1 by omega, x_step _ (by omega)]
      rw [show p - 3 + 1 = p - 2 by omega, hg, Nat.div_one]
      rw [show 2 + (p - 2) = p by omega]
      exact dvd_mul_left p (x (p - 3))
    have hd' := hd.trans (x_dvd_of_le (by omega) (show p - 2 ≤ p - 1 by omega))
    have := a_at_prime_of_dvd hp hd'
    omega
  · exact fun hg => a_at_prime hp (prime_not_dvd_of_gcd hp hp3 hg)

/-- An already acquired divisor supplies a family of prime-index instances. -/
theorem conjecture_of_acquired_divisor {p d m : ℕ} (hp : p.Prime) (hp3 : 3 < p)
    (hd : 1 < d) (hm : 1 ≤ m) (hmp : m ≤ p - 3)
    (hx : d ∣ x m) (hdp : d ∣ p - 2) : a (p - 1) = p := by
  apply prime_index_iff hp hp3 |>.mpr
  have hg := Nat.dvd_gcd (hx.trans (x_dvd_of_le hm hmp)) hdp
  have hgpos := Nat.gcd_pos_of_pos_right (x (p - 3)) (show 0 < p - 2 by omega)
  have := Nat.le_of_dvd hgpos hg
  omega

/-- A proved infinite congruence class of instances of the original conjecture. -/
theorem conjecture_mod_three {p : ℕ} (hp : p.Prime) (hp7 : 7 ≤ p)
    (hmod : p % 3 = 2) : a (p - 1) = p := by
  exact conjecture_of_acquired_divisor hp (by omega) (d := 3) (m := 4)
    (by decide) (by decide) (by omega) (by decide) (Nat.dvd_of_mod_eq_zero (by omega))

theorem conjecture_mod_five {p : ℕ} (hp : p.Prime) (hp7 : 7 ≤ p)
    (hmod : p % 5 = 2) : a (p - 1) = p := by
  exact conjecture_of_acquired_divisor hp (by omega) (d := 5) (m := 3)
    (by decide) (by decide) (by omega) (by decide) (Nat.dvd_of_mod_eq_zero (by omega))

#print axioms conjecture_mod_three
#print axioms conjecture_mod_five
#print axioms prime_index_iff
#print axioms prime_not_dvd_of_gcd

end OeisA135508
