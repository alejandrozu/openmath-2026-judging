/-
Copyright 2026 The Formal Conjectures Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-/
import OpHack.QuadraticResidue224.GeneratedCertificate
import OpHack.QuadraticResidue224.NecessaryBounds
import OpHack.QuadraticResidue224.SquareCount
import Mathlib.Data.Nat.ModEq

/-!
Exact A000224 definition from Formal Conjectures, with a restricted theorem.
The original open conjecture and its sorry are not imported.
-/
namespace OeisA224

def a (n : ℕ) : ℕ :=
  if n = 0 then 1
  else Finset.card ((Finset.range n).image (fun k : ℕ => k ^ 2 % n))

open OpHack.QuadraticResidue224

theorem not_divisible_three_primes {p q r : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hp2 : 2 < p) (hpq : p < q) (hqr : q < r) :
    ¬ a (p * q * r) * (a (p * q * r) - 1) ∣ (p * q * r) ^ 2 - 1 := by
  have ha : a (p * q * r) = halfPrime p * halfPrime q * halfPrime r :=
    upstream_a_three_primes hp hq hr hp2 hpq hqr
  rw [ha]
  exact no_three_prime_arithmetic necessaryBounds_proof
    SplitCertificate.finite_discriminant_certificate hp hq hr hp2 hpq hqr

theorem not_modEq_three_primes {p q r : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hp2 : 2 < p) (hpq : p < q) (hqr : q < r) :
    ¬ (p * q * r) ^ 2 ≡ 1 [MOD a (p * q * r) * (a (p * q * r) - 1)] := by
  intro h
  exact not_divisible_three_primes hp hq hr hp2 hpq hqr h.symm.dvd'

theorem conjecture_three_primes {p q r : ℕ}
    (hp : p.Prime) (hq : q.Prime) (hr : r.Prime)
    (hp2 : 2 < p) (hpq : p < q) (hqr : q < r) :
    ((p * q * r).Prime ∧ p * q * r ≠ 2) ↔
      (p * q * r) ^ 2 ≡ 1 [MOD a (p * q * r) * (a (p * q * r) - 1)] := by
  have hpq1 : p * q ≠ 1 := by
    have := hp.two_le
    have := hq.two_le
    nlinarith
  have hnp : ¬ (p * q * r).Prime := Nat.not_prime_mul hpq1 hr.ne_one
  constructor
  · intro h
    exact False.elim (hnp h.1)
  · intro h
    exact False.elim (not_modEq_three_primes hp hq hr hp2 hpq hqr h)

#print axioms not_divisible_three_primes
#print axioms not_modEq_three_primes
#print axioms conjecture_three_primes
end OeisA224
