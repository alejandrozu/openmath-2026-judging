/-
Uncompiled optional source draft. Parent owns all Lean execution/API repairs.
This packages the actual lower and upper quartic theorems as a quantified
squeeze for the least positive admissible exponent. Exponent zero is excluded.
-/
import OpHack.PowerUpper.MainUpper
import OpHack.PowerFourier.Growth
import Mathlib.Algebra.Order.Floor.Semiring
import Mathlib.Algebra.Order.Archimedean.Real.Basic

noncomputable section
namespace PowerUpper.LeastIndex

/-- Positivity of the exponent is essential: the zeroth power is always 1. -/
def Admissible (δ : ℝ) (n : ℕ) : Prop :=
  0 < n ∧ PowerSemigroup.CoeffNonneg (PowerSemigroup.quartic (8-δ)^n)

def IsLeastAdmissible (δ : ℝ) (n : ℕ) : Prop :=
  Admissible δ n ∧ ∀ m : ℕ, Admissible δ m → n ≤ m

/-- The value 0 is used only when there is no positive admissible exponent.
The squeeze theorem proves admissibility and minimality in its whole domain. -/
noncomputable def leastPositiveIndex (δ : ℝ) : ℕ := by
  classical
  exact if hex : ∃ n : ℕ, Admissible δ n then Nat.find hex else 0

theorem leastPositiveIndex_spec (δ : ℝ) (hex : ∃ n : ℕ, Admissible δ n) :
    IsLeastAdmissible δ (leastPositiveIndex δ) := by
  classical
  unfold leastPositiveIndex
  rw [dif_pos hex]
  exact ⟨Nat.find_spec hex, fun m hm => Nat.find_min' hex hm⟩

theorem least_admissible_unique (δ : ℝ) (m n : ℕ)
    (hm : IsLeastAdmissible δ m) (hn : IsLeastAdmissible δ n) : m = n :=
  Nat.le_antisymm (hm.2 n hn.1) (hn.2 m hm.1)

/-- Quantified asymptotic ratio bounds, without introducing a filter limit.
Both sides concern the actual least positive coefficientwise-nonnegative power. -/
theorem leastPositiveIndex_squeeze :
    ∀ ε : ℝ, 0 < ε → ∃ δ0 : ℝ, 0 < δ0 ∧ δ0 ≤ 1 ∧
      ∀ δ : ℝ, 0 < δ → δ < δ0 →
        IsLeastAdmissible δ (leastPositiveIndex δ) ∧
        1-ε ≤ δ*(leastPositiveIndex δ : ℝ)/Real.log (1/δ) ∧
        δ*(leastPositiveIndex δ : ℝ)/Real.log (1/δ) ≤ 1+ε := by
  intro ε hε
  have hεhalf : 0 < ε/2 := by positivity
  obtain ⟨δU, hδU, _hδU1, hUpper⟩ :=
    PowerUpper.quartic_near_boundary_nonneg (ε/2) hεhalf
  obtain ⟨δL, hδL, hLower⟩ := PowerFourier.quartic_logarithmic_growth ε hε
  let δ0 : ℝ := min δU (min δL (min (Real.exp (-1)) (min (ε/2) 1)))
  have hδ0 : 0 < δ0 :=
    lt_min hδU (lt_min hδL (lt_min (Real.exp_pos _) (lt_min hεhalf (by norm_num))))
  have hδ01 : δ0 ≤ 1 :=
    (min_le_right _ _).trans ((min_le_right _ _).trans
      ((min_le_right _ _).trans (min_le_right _ _)))
  refine ⟨δ0, hδ0, hδ01, ?_⟩
  intro δ hδ hδsmall
  have hparts : δ < δU ∧ δ < δL ∧ δ < Real.exp (-1) ∧ δ < ε/2 ∧ δ < 1 := by
    simpa only [δ0, lt_min_iff] using hδsmall
  obtain ⟨hδU', hδL', hδexp, hδε, hδ1⟩ := hparts
  let L : ℝ := Real.log (1/δ)
  have hL1 : 1 < L := by
    have hl := Real.log_lt_log hδ hδexp
    rw [Real.log_exp] at hl
    dsimp [L]
    rw [one_div, Real.log_inv]
    linarith only [hl]
  have hL : 0 < L := by linarith only [hL1]

  let A : ℝ := (1+ε/2)*L/δ
  have hA : 0 < A := by dsimp [A]; positivity
  let P : ℕ := Nat.ceil A
  have hP : 0 < P := Nat.ceil_pos.mpr hA
  have hPbound : (1+ε/2)*Real.log (1/δ)/δ ≤ (P : ℝ) := Nat.le_ceil A
  have hPadm : Admissible δ P :=
    ⟨hP, hUpper δ P hδ hδU' hPbound⟩
  have hspec : IsLeastAdmissible δ (leastPositiveIndex δ) :=
    leastPositiveIndex_spec δ ⟨P, hPadm⟩

  have hceil : (P : ℝ) < A+1 := Nat.ceil_lt_add_one hA.le
  have hceilδ := mul_lt_mul_of_pos_left hceil hδ
  have hAidentity : δ*A = (1+ε/2)*L := by
    dsimp [A]
    field_simp [hδ.ne']
    <;> ring
  have hRound : δ ≤ (ε/2)*L := by
    have hh := mul_le_mul_of_nonneg_left hL1.le hεhalf.le
    nlinarith only [hh, hδε]
  have hPupper : δ*(P : ℝ) ≤ (1+ε)*L := by
    nlinarith only [hceilδ, hAidentity, hRound]
  have hminP : leastPositiveIndex δ ≤ P := hspec.2 P hPadm
  have hminPr : (leastPositiveIndex δ : ℝ) ≤ (P : ℝ) := by exact_mod_cast hminP
  have hIndexUpper : δ*(leastPositiveIndex δ : ℝ) ≤ (1+ε)*L :=
    (mul_le_mul_of_nonneg_left hminPr hδ.le).trans hPupper

  have ht7 : 7 ≤ 8-δ := by linarith only [hδ1]
  have ht8 : 8-δ < 8 := by linarith only [hδ]
  have hParameter : 8-(8-δ) = δ := by ring
  have hIndexLower := hLower (8-δ) (leastPositiveIndex δ) ht7 ht8
    hspec.1.1 hspec.1.2 (by simpa only [hParameter] using hδL')
  rw [hParameter] at hIndexLower
  refine ⟨hspec, ?_, ?_⟩
  · exact (le_div_iff₀ hL).mpr hIndexLower
  · exact (div_le_iff₀ hL).mpr hIndexUpper

#print axioms leastPositiveIndex_spec
#print axioms leastPositiveIndex_squeeze

end PowerUpper.LeastIndex
