import AsymptoticBridge
import SigmaFiberEntropy
import SigmaCanonicalCount

/-!
# Unconditional uniform upper bound for the original arithmetic fiber

This file connects the proved finite arithmetic estimate to the real-asymptotic
bridge. Its final theorem counts the exact finite set appearing in Erdős 1060.
It proves a positive-constant improvement, not the zero-constant asymptotic
asked for in the open problem. No novelty assertion is encoded here.
-/

open Filter Topology Finset

namespace Erdos1060

open Erdos1060Partial Erdos1060Asymptotic

lemma entropyConstant_eq_candidateConstant : entropyConstant = candidateConstant := by
  unfold entropyConstant
  exact candidateConstant_eq_sub_log.symm

/-- The unconditional bound on the original positive arithmetic fiber. -/
theorem eventually_sigmaFiber_card_le {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ n : ℕ in atTop,
      ((sigmaFiber n).card : ℝ) ≤
        Real.exp ((candidateConstant + ε) * Real.log (n : ℝ) /
          Real.log (Real.log (n : ℝ))) := by
  apply eventual_bound_of_cutoff_estimate (fun n => ((sigmaFiber n).card : ℝ))
    1 candidateConstant roundingConstant ?_ hε
  filter_upwards [eventually_ge_atTop (2 : ℕ)] with n hn
  intro y hy
  simpa only [one_mul, entropyConstant_eq_candidateConstant, mul_div_assoc]
    using sigmaFiber_exp_bound hn hy

/-- Exact canonical count, with the claimed rational constant displayed explicitly. -/
theorem canonical_count_eventually_upper {ε : ℝ} (hε : 0 < ε) :
    ∀ᶠ n : ℕ in atTop,
      (#{k ≤ n | k * ArithmeticFunction.sigma 1 k = n} : ℝ) ≤
        Real.exp (((Real.log (2539 / 1000) / 3 + Real.log (10 / 9) / 2) + ε) *
          Real.log (n : ℝ) / Real.log (Real.log (n : ℝ))) := by
  filter_upwards [eventually_sigmaFiber_card_le hε, eventually_gt_atTop (0 : ℕ)]
    with n hn hn0
  rw [sigmaFiber_card_eq_canonical hn0] at hn
  simpa only [candidateConstant] using hn

/-- Threshold form of the exact, unconditional canonical-count theorem. -/
theorem canonical_count_upper {ε : ℝ} (hε : 0 < ε) :
    ∃ N : ℕ, ∀ n : ℕ, N ≤ n →
      (#{k ≤ n | k * ArithmeticFunction.sigma 1 k = n} : ℝ) ≤
        Real.exp (((Real.log (2539 / 1000) / 3 + Real.log (10 / 9) / 2) + ε) *
          Real.log (n : ℝ) / Real.log (Real.log (n : ℝ))) :=
  eventually_atTop.mp (canonical_count_eventually_upper hε)

#print canonical_count_eventually_upper
#print canonical_count_upper
#print axioms eventually_sigmaFiber_card_le
#print axioms canonical_count_eventually_upper
#print axioms canonical_count_upper

end Erdos1060
