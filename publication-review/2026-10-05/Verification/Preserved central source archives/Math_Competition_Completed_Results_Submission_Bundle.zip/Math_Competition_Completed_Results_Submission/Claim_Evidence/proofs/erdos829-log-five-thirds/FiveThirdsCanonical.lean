import FiveThirdsNonnegative
import CubicCanonicalCount

namespace Erdos829FiveThirds
open Erdos829Candidate Filter

/-- Stronger rational-constant partial for the exact ordered nonnegative cube-value count. -/
theorem canonicalCubeCount_eventually_exp {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ n : ℕ in atTop, (canonicalCubeCount n : ℝ) ≤
      Real.exp ((Real.log (5/3 : ℝ)+ε)*Real.log (n : ℝ)/Real.log (Real.log (n : ℝ))) := by
  simpa only [canonicalCubeCount_eq_nonnegativeCount] using nonnegativeCount_eventually_exp hε

/-- The same bound with explicit eventual quantifiers. -/
theorem canonicalCubeCount_eventual_threshold {ε : ℝ} (hε : 0<ε) :
    ∃ N : ℕ, ∀ n : ℕ, N≤n → (canonicalCubeCount n : ℝ) ≤
      Real.exp ((Real.log (5/3 : ℝ)+ε)*Real.log (n : ℝ)/Real.log (Real.log (n : ℝ))) :=
  eventually_atTop.mp (canonicalCubeCount_eventually_exp hε)

/-- Strict improvement over the earlier rational-constant endpoint in the same family. -/
theorem coefficient_lt_seven_fourths : Real.log (5/3 : ℝ) < Real.log (7/4 : ℝ) :=
  Real.log_lt_log (by norm_num) (by norm_num)

#print axioms canonicalCubeCount_eventually_exp
#print axioms canonicalCubeCount_eventual_threshold
end Erdos829FiveThirds
