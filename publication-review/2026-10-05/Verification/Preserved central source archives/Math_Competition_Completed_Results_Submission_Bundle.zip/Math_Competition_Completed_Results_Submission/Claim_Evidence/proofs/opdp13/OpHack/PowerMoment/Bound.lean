import OpHack.PowerMoment.Parity
import OpHack.PowerSemigroup.Evaluation

noncomputable section
namespace PowerMoment
open Polynomial

theorem quartic_parity_moments (t : ℝ) (ht : 0 < t) (ha : t < 16) (n : ℕ) :
    parityMoment (PowerSemigroup.quartic t ^ n) ((n : ℝ)*2) n 0 =
      ((16-t)^n-t^n)/2 ∧
    parityMoment (PowerSemigroup.quartic t ^ n) ((n : ℝ)*2) n 2 =
      8*(n : ℝ)/(16-t)*(16-t)^n ∧
    parityMoment (PowerSemigroup.quartic t ^ n) ((n : ℝ)*2) n 4 =
      (20*(n : ℝ)/(16-t)+384*(n : ℝ)*((n : ℝ)-1)/(16-t)^2)*(16-t)^n +
      12*(n : ℝ)/t*t^n := by
  obtain ⟨p0,p1,p2,p3,p4⟩ := quartic_moments_pos t
  obtain ⟨m0,m1,m2,m3,m4⟩ := quartic_moments_neg t
  obtain ⟨a0,a1,a2,a3,a4⟩ := power_moments _ 2 1 (16-t) 16 40
    (by linarith) p0 p1 p2 p3 p4 n
  obtain ⟨b0,b1,b2,b3,b4⟩ := power_moments _ 2 (-1) (-t) 0 24
    (by linarith) m0 m1 m2 m3 m4 n
  have hsign : (-1 : ℝ)^n * (-t)^n = t^n := by rw [←mul_pow]; congr 1; ring
  repeat' apply And.intro
  · rw [parityMoment_eq,a0,b0,hsign]
  · rw [parityMoment_eq,a2,b2]
    simp only [mul_zero,zero_div,zero_mul,sub_zero]
    ring
  · rw [parityMoment_eq,a4,b4]
    simp only [mul_zero,zero_div,zero_pow (by decide : 2 ≠ 0),add_zero,zero_mul]
    have h : (-1 : ℝ)^n * ((n : ℝ)*24 / (-t)*(-t)^n) =
        -(24*(n : ℝ)/t*t^n) := by
      calc
        _ = -(24*(n : ℝ)/t*((-1 : ℝ)^n*(-t)^n)) := by ring
        _ = _ := by rw [hsign]
    rw [h]
    field_simp
    ring

/-- Quantitative obstruction as the quartic approaches the radical boundary. -/
theorem quartic_exponent_lower_bound (t : ℝ) (ht : 6 < t) (ht8 : t < 8)
    (n : ℕ) (hn : 0 < n) (hp : PowerSemigroup.CoeffNonneg (PowerSemigroup.quartic t ^ n)) :
    t*(10-t) ≤ 12*(n : ℝ)*(8-t) := by
  let A : ℝ := 16-t
  let P : ℝ := A^n
  have hA : 0 < A := by dsimp [A]; linarith
  have ht0 : 0 < t := by linarith
  have htA : t ≤ A := by dsimp [A]; linarith
  have hN : 0 < (n : ℝ) := by exact_mod_cast hn
  have hP : 0 < P := pow_pos hA n
  obtain ⟨h0,h2,h4⟩ := quartic_parity_moments t ht0 (by linarith) n
  have hc := parity_cauchy hp ((n : ℝ)*2) n
  rw [h0,h2,h4] at hc
  have hg := power_gap_upper A t hA ht0.le htA n
  have hm := normalized_power_mono A t hA ht0 htA n hn
  have hzero := parityMoment_nonneg hp ((n : ℝ)*2) n
  rw [h0] at hzero
  change 0 ≤ (P-t^n)/2 at hzero
  have hzupper : (P-t^n)/2 ≤ (8-t)*(n : ℝ)/A*P := by
    have hh := div_le_div_of_nonneg_right hg (by norm_num : (0 : ℝ) ≤ 2)
    convert hh using 1 <;> dsimp [A,P] <;> ring
  have hfour : (20*(n : ℝ)/A+384*(n : ℝ)*((n : ℝ)-1)/A^2)*P +
      12*(n : ℝ)/t*t^n ≤ (32*(n : ℝ)/A+384*(n : ℝ)*((n : ℝ)-1)/A^2)*P := by
    have hh := mul_le_mul_of_nonneg_left hm (by positivity : 0 ≤ 12*(n : ℝ))
    change t^n/t ≤ P/A at hm
    change 12*(n : ℝ)*(t^n/t) ≤ 12*(n : ℝ)*(P/A) at hh
    convert add_le_add_left hh ((20*(n : ℝ)/A+384*(n : ℝ)*((n : ℝ)-1)/A^2)*P) using 1 <;> ring
  have hupper_nonneg : 0 ≤ (32*(n : ℝ)/A+384*(n : ℝ)*((n : ℝ)-1)/A^2)*P := by
    have hn1 : (1 : ℝ) ≤ n := by exact_mod_cast hn
    positivity
  have hprod := mul_le_mul hfour hzupper hzero hupper_nonneg
  change (8*(n : ℝ)/A*P)^2 ≤ (P-t^n)/2 *
    ((20*(n : ℝ)/A+384*(n : ℝ)*((n : ℝ)-1)/A^2)*P+12*(n : ℝ)/t*t^n) at hc
  have hbound : (8*(n : ℝ)/A*P)^2 ≤
      ((8-t)*(n : ℝ)/A*P)*((32*(n : ℝ)/A+384*(n : ℝ)*((n : ℝ)-1)/A^2)*P) := by
    nlinarith [hprod]
  have hcancel : 64*A ≤ (8-t)*(32*A+384*((n : ℝ)-1)) := by
    have hscale : 0 < A^3 / ((n : ℝ)^2*P^2) := by positivity
    have hh := mul_le_mul_of_nonneg_right hbound hscale.le
    field_simp [ne_of_gt hA,ne_of_gt hN,ne_of_gt hP] at hh
    nlinarith [sq_pos_of_pos hN, sq_pos_of_pos hP]
  dsimp [A] at hcancel
  nlinarith

/-- Function-level obstruction for unrestricted finite sums of holomorphic
polynomial squared norms. -/
theorem function_exponent_lower_bound (t : ℝ) (ht : 6 < t) (ht8 : t < 8)
    (n : ℕ) (hn : 0 < n)
    (h : PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
      (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ))) :
    t*(10-t) ≤ 12*(n : ℝ)*(8-t) := by
  apply quartic_exponent_lower_bound t ht ht8 n hn
  apply (PowerSemigroup.diagonal_squaredNorm_iff _).mp
  apply (PowerSemigroup.squaredNorm_iff_function _).mpr
  simpa [PowerSemigroup.evaluate_diagonal,PowerSemigroup.quartic] using h

#print axioms function_exponent_lower_bound
#print axioms quartic_exponent_lower_bound
end PowerMoment
