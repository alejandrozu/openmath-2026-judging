import OpHack.SubsetProducts.ProductGap
import OpHack.SubsetProducts.WitnessChoices
import OpHack.SubsetProducts.Separation
import OpHack.SubsetProducts.Face

noncomputable section
namespace SubsetProductGap
open Finset

/-- Identical mathematical definition to FormalConjectures/OEIS/60957.lean. -/
def productsOfSubsets (n : ℕ) : Set ℕ :=
  {m : ℕ | ∃ s ⊆ Finset.Icc 1 n, m = s.prod id}

theorem subset_interval_prod_pos {N : ℕ} {S : Finset ℕ} (hS : S ⊆ Icc 1 N) : 0 < S.prod id := by
  apply Finset.prod_pos
  intro j hj
  exact (mem_Icc.mp (hS hj)).1

/-- The isolated seventeen-atom face gives a missing p-exponent four. -/
theorem counterexample_for_parameters (P : Parameters) : ∃ m : ℕ,
    0 < m ∧ m ∈ productsOfSubsets P.N ∧ P.p^5*m ∈ productsOfSubsets P.N ∧
    P.p^4*m ∉ productsOfSubsets P.N := by
  classical
  let U : Finset ℕ := Icc 1 P.N
  obtain ⟨f,hfV,hsep⟩ := exists_isolating_functional (globalAtomSpace P.q)
    (U.image (freeExponents P.p))
  let w : ℕ → ℚ := fun j => f (freeExponents P.p j)
  let W : Finset ℕ := U.filter (fun j => 0 < w j)
  have hWU : W ⊆ U := filter_subset _ _
  have hWpos : 0 < W.prod id := subset_interval_prod_pos hWU
  have hWne : W.prod id ≠ 0 := ne_of_gt hWpos
  have hRpos := targetNumber_pos P.q_prime
  have hRne : targetNumber P.q ≠ 0 := ne_of_gt hRpos
  have hmpos : 0 < W.prod id*targetNumber P.q := Nat.mul_pos hWpos hRpos
  have hwChoice (c : Choice) : w (choiceNumber P c) = 0 :=
    hfV _ (choiceNumber_global P c)
  have hdisj (S : Finset Choice) : Disjoint W (S.image (choiceNumber P)) := by
    apply Finset.disjoint_left.mpr
    intro j hjW hjS
    obtain ⟨c,hc,rfl⟩ := mem_image.mp hjS
    have hh := (mem_filter.mp hjW).2
    rw [hwChoice] at hh
    exact lt_irrefl _ hh
  have hRspace : freeExponents P.p (targetNumber P.q) ∈ globalAtomSpace P.q := by
    rw [targetNumber_free P.p P.q P.q_prime P.coord_ne_p]
    exact ⟨targetVector,targetVector_mem,rfl⟩
  have hfR : f (freeExponents P.p (targetNumber P.q)) = 0 := hfV _ hRspace
  refine ⟨W.prod id*targetNumber P.q,hmpos,?_,?_,?_⟩
  · refine ⟨W ∪ lowChoices.image (choiceNumber P),
      Finset.union_subset hWU (image_choices_subset P lowChoices),?_⟩
    rw [Finset.prod_union (hdisj lowChoices),image_choices_product,lowChoices_product]
  · refine ⟨W ∪ highChoices.image (choiceNumber P),
      Finset.union_subset hWU (image_choices_subset P highChoices),?_⟩
    rw [Finset.prod_union (hdisj highChoices),image_choices_product,highChoices_product]
    ring
  · rintro ⟨T,hTU,hT⟩
    have hTpos : 0 < T.prod id := subset_interval_prod_pos hTU
    have hTnonzero : ∀ j ∈ T, j ≠ 0 := fun j hj => ne_of_gt ((mem_Icc.mp (hTU hj)).1)
    have hWnonzero : ∀ j ∈ W, j ≠ 0 := fun j hj => ne_of_gt ((mem_Icc.mp (hWU hj)).1)
    have heq : (∑ j ∈ T, w j) = ∑ j ∈ W, w j := by
      change (∑ j ∈ T, f (freeExponents P.p j)) = ∑ j ∈ W, f (freeExponents P.p j)
      rw [←linear_weight_prod P.p f T hTnonzero,←linear_weight_prod P.p f W hWnonzero]
      rw [←hT,freeExponents_mul P.p _ _ (pow_ne_zero _ P.p_prime.ne_zero) (ne_of_gt hmpos)]
      rw [freeExponents_prime_power P.p_prime,zero_add,
        freeExponents_mul P.p _ _ hWne hRne,map_add,hfR,add_zero]
    have hface := exposed_face_forces U T w hTU heq
    have hWT : W ⊆ T := by
      intro j hj
      exact hface.1 j (mem_filter.mp hj).1 (mem_filter.mp hj).2
    have hZU : T \ W ⊆ Icc 1 P.N := fun j hj => hTU (mem_sdiff.mp hj).1
    have hZspace : ∀ j ∈ T \ W, freeExponents P.p j ∈ globalAtomSpace P.q := by
      intro j hj
      have hjT := (mem_sdiff.mp hj).1
      have hjW := (mem_sdiff.mp hj).2
      have hjU : j ∈ U := hTU hjT
      have hw0 : w j = 0 := by
        have hnon := hface.2 j hjT
        have hnpos : ¬0 < w j := fun hpos => hjW (mem_filter.mpr ⟨hjU,hpos⟩)
        exact le_antisymm (le_of_not_gt hnpos) hnon
      exact (hsep _ (mem_image.mpr ⟨j,hjU,rfl⟩)).mp hw0
    apply zero_product_ne P (T \ W) hZU hZspace
    apply mul_right_cancel₀ hWne
    calc
      (T \ W).prod id*W.prod id = T.prod id := Finset.prod_sdiff hWT
      _ = P.p^4*(W.prod id*targetNumber P.q) := hT.symm
      _ = (P.p^4*targetNumber P.q)*W.prod id := by ring

/-- Counterexample to the complete interpolation statement, with m positive. -/
theorem subset_product_counterexample : ∃ n p m : ℕ, p.Prime ∧ p ≤ n ∧ 0 < m ∧
    m ∈ productsOfSubsets n ∧ p^5*m ∈ productsOfSubsets n ∧ p^4*m ∉ productsOfSubsets n := by
  obtain ⟨P⟩ := parameters_exist
  obtain ⟨m,hm,h0,h5,h4⟩ := counterexample_for_parameters P
  have hpn : P.p ≤ P.N := by have h1 := P.p_prime.two_le; have h2 := P.p_sq_lt; nlinarith
  exact ⟨P.N,P.p,m,P.p_prime,hpn,hm,h0,h5,h4⟩

/-- Direct negation of the OEIS A060957 conjecture's complete quantified proposition. -/
theorem interpolation_conjecture_false : ¬ (∀ (n p : ℕ), p.Prime → p ≤ n →
    ∀ (m a : ℕ), m ∈ productsOfSubsets n → p^a*m ∈ productsOfSubsets n →
    ∀ k : ℕ, 0 < k → k < a → p^k*m ∈ productsOfSubsets n) := by
  intro h
  obtain ⟨n,p,m,hp,hpn,hm,h0,h5,h4⟩ := subset_product_counterexample
  exact h4 (h n p hp hpn m 5 h0 h5 4 (by decide) (by decide))

#print axioms subset_product_counterexample
#print axioms interpolation_conjecture_false
end SubsetProductGap
