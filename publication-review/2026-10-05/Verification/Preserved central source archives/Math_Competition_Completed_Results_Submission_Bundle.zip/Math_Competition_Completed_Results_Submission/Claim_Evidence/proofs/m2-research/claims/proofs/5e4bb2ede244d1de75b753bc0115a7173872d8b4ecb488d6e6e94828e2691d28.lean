import Mathlib
import Lean
import FormalConjectures.OEIS.«60841»

set_option google.answer "postpone"

-- Already imported, audited repository definitions (do not redeclare):
-- def OeisA60841.lcmMatrix : (n : ℕ) → Matrix (Fin n) (Fin n) ℚ := fun n => Matrix.of fun i j => 1 / ↑((↑i + 1).lcm (↑j + 1))
-- 
-- def OeisA60841.integerDetN : Set ℕ := Set.Icc 1 34 ∪ {36, 38}

namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit
def in_a60841_integer_det_set (n : Nat) : Prop := n ∈ OeisA60841.integerDetN

theorem in_a60841_integer_det_set_def_iff (n : Nat) :
    in_a60841_integer_det_set n ↔ n ∈ OeisA60841.integerDetN := by
  rfl

theorem in_a60841_integer_det_set_characterization (n : Nat) (h1 : 1 <= n) : in_a60841_integer_det_set n ↔ n <= 34 ∨ n = 36 ∨ n = 38 := by
  simp [in_a60841_integer_det_set, OeisA60841.integerDetN]
  <;> omega

theorem a60841_factorial_pos (n : Nat) : 0 < Nat.factorial n := by
  exact Nat.factorial_pos n

theorem a60841_fact_sq_pos (n : Nat) : 0 < (Nat.factorial n) ^ 2 := by
  exact pow_pos (a60841_factorial_pos n) 2

theorem a60841_prod_totient_pos (n : Nat) (hn : 1 ≤ n) :
    0 < (Finset.Icc 1 n).prod (fun k => Nat.totient k) := by
  apply Finset.prod_pos
  intro k hk
  rw [Finset.mem_Icc] at hk
  exact Nat.totient_pos.mpr (by omega)

theorem a60841_rat_div_inv_den_eq_one_iff_div {a b : Nat} (ha : 0 < a) (hb : 0 < b) :
    (((a : ℚ) / (b : ℚ))⁻¹).den = 1 ↔ a ∣ b := by
  have h : ((a : ℚ) / (b : ℚ))⁻¹ = (b : ℚ) / (a : ℚ) := by
    simp only [div_eq_mul_inv, mul_inv_rev, inv_inv]
  rw [h]
  exact Rat.den_div_natCast_eq_one_iff b a (Nat.ne_of_gt ha)

theorem a60841_prod_fin_totient_eq_Icc_prod_totient (n : Nat) (hn : 1 ≤ n) :
    (Finset.univ : Finset (Fin n)).prod (fun i => Nat.totient (i.val + 1)) =
      (Finset.Icc 1 n).prod (fun k => Nat.totient k) := by
  classical
  have hfinj : Set.InjOn (fun i : Fin n => (i : ℕ) + 1)
      ((Finset.univ : Finset (Fin n)) : Set (Fin n)) := by
    intro a _ b _ h
    have h' : (a : ℕ) = (b : ℕ) := by
      have : (a : ℕ) + 1 = (b : ℕ) + 1 := h
      omega
    exact Fin.eq_of_val_eq h'
  have himg : (Finset.univ : Finset (Fin n)).image (fun i : Fin n => (i : ℕ) + 1) =
      Finset.Icc 1 n := by
    apply Finset.ext
    intro k
    constructor
    · intro h
      obtain ⟨i, _, hk⟩ := Finset.mem_image.mp h
      have hk' : (i : ℕ) + 1 = k := hk
      exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
    · intro h
      obtain ⟨h1, h2⟩ := Finset.mem_Icc.mp h
      refine Finset.mem_image.mpr ⟨⟨k - 1, ?_⟩, Finset.mem_univ _, ?_⟩
      · omega
      · exact (by omega : (k - 1 : ℕ) + 1 = k)
  exact calc (Finset.univ : Finset (Fin n)).prod (fun i => Nat.totient (i.val + 1))
      _ = (Finset.univ : Finset (Fin n)).prod (fun i => Nat.totient ((fun i : Fin n => (i : ℕ) + 1) i)) := rfl
      _ = ((Finset.univ : Finset (Fin n)).image (fun i : Fin n => (i : ℕ) + 1)).prod Nat.totient :=
          (Finset.prod_image hfinj).symm
      _ = (Finset.Icc 1 n).prod Nat.totient := by rw [himg]
      _ = (Finset.Icc 1 n).prod (fun k => Nat.totient k) := rfl

theorem a60841_prod_fin_inv_factorial (n : Nat) (hn : 1 ≤ n) :
    (Finset.univ : Finset (Fin n)).prod (fun i => (((i.val + 1 : ℕ) : ℚ))⁻¹) =
      ((Nat.factorial n : ℚ))⁻¹ := by
  clear hn
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Fin.prod_univ_castSucc]
    have h1 : (Finset.univ : Finset (Fin n)).prod (fun i => ((i.castSucc.val + 1 : ℕ) : ℚ)⁻¹) =
        (Finset.univ : Finset (Fin n)).prod (fun i => ((i.val + 1 : ℕ) : ℚ)⁻¹) := by
      refine Finset.prod_congr rfl fun i _ => ?_
      push_cast
      simp [Fin.castSucc]
    rw [h1, ih]
    push_cast
    simp only [Nat.factorial_succ, Nat.cast_mul]
    rw [mul_inv_rev]
    simp only [Nat.cast_add, Nat.cast_one]

theorem a60841_lcmMatrix_eq_scaled_gcd_matrix (n : Nat) (hn : 1 ≤ n) :
    OeisA60841.lcmMatrix n =
      Matrix.diagonal (fun i : Fin n => (((i.val + 1 : ℕ) : ℚ))⁻¹) *
        (Matrix.of fun i j : Fin n => (Nat.gcd (i.val + 1) (j.val + 1) : ℚ)) *
        Matrix.diagonal (fun i : Fin n => (((i.val + 1 : ℕ) : ℚ))⁻¹) := by
  ext i j
  classical
  have ha : (((i.val + 1 : ℕ) : ℚ)) ≠ 0 := by positivity
  have hb : (((j.val + 1 : ℕ) : ℚ)) ≠ 0 := by positivity
  have hl : ((Nat.lcm (i.val + 1) (j.val + 1) : ℕ) : ℚ) ≠ 0 := by
    refine mod_cast Nat.lcm_ne_zero ?_ ?_
    · omega
    · omega
  have h : ((Nat.gcd (i.val + 1) (j.val + 1) : ℕ) : ℚ) * ((Nat.lcm (i.val + 1) (j.val + 1) : ℕ) : ℚ)
      = ((i.val + 1 : ℕ) : ℚ) * ((j.val + 1 : ℕ) : ℚ) := by
    rw [← Nat.cast_mul, Nat.gcd_mul_lcm, Nat.cast_mul]
  have hg : ((Nat.gcd (i.val + 1) (j.val + 1) : ℕ) : ℚ)
      = ((i.val + 1 : ℕ) : ℚ) * ((j.val + 1 : ℕ) : ℚ) *
        ((Nat.lcm (i.val + 1) (j.val + 1) : ℕ) : ℚ)⁻¹ := by
    rw [← h, mul_assoc, mul_inv_cancel₀ hl, mul_one]
  simp only [OeisA60841.lcmMatrix, Matrix.mul_diagonal, Matrix.diagonal_mul, Matrix.of_apply]
  rw [hg]
  field_simp

theorem a60841_gcdMatrix_factorization (n : Nat) (hn : 1 ≤ n) :
    (Matrix.of fun i j : Fin n => (Nat.gcd (i.val + 1) (j.val + 1) : ℚ)) =
      (Matrix.of fun i j : Fin n =>
          if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0).transpose *
        Matrix.diagonal (fun i : Fin n => (Nat.totient (i.val + 1) : ℚ)) *
        (Matrix.of fun i j : Fin n =>
          if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0) := by
  have hsum : ∀ (m l : ℕ), 1 ≤ m → m ≤ n → 1 ≤ l → l ≤ n →
      (∑ k : Fin n, (if (k.val + 1) ∣ m then (Nat.totient (k.val + 1) : ℚ) else 0) *
          (if (k.val + 1) ∣ l then (1 : ℚ) else 0)) = (Nat.gcd m l : ℚ) := by
    intro m l hm hmn hl hln
    set g := Nat.gcd m l with hgdef
    have hgm : g ≤ m := Nat.le_of_dvd (by omega : 0 < m) (Nat.gcd_dvd_left m l)
    have hg0 : g ≠ 0 := by
      rw [hgdef]
      intro h
      have := (Nat.gcd_eq_zero_iff).mp h
      omega
    have hg1 : 0 < g := Nat.pos_of_ne_zero hg0
    have hterm : ∀ k : Fin n, (if (k.val + 1) ∣ m then (Nat.totient (k.val + 1) : ℚ) else 0) *
          (if (k.val + 1) ∣ l then (1 : ℚ) else 0)
        = if (k.val + 1) ∣ g then (Nat.totient (k.val + 1) : ℚ) else 0 := by
      intro k
      rw [hgdef]
      by_cases h1 : (k.val + 1) ∣ m <;> by_cases h2 : (k.val + 1) ∣ l <;>
        simp [h1, h2, Nat.dvd_gcd_iff]
    have hfilter : (∑ k : Fin n, if (k.val + 1) ∣ g then (Nat.totient (k.val + 1) : ℚ) else 0)
        = Finset.sum ((Finset.univ : Finset (Fin n)).filter (fun k : Fin n => (k.val + 1) ∣ g))
            (fun k : Fin n => (Nat.totient (k.val + 1) : ℚ)) := by
      rw [← Finset.sum_filter]
    have hinj : Set.InjOn (fun k : Fin n => k.val + 1)
        (↑((Finset.univ : Finset (Fin n)).filter (fun k : Fin n => (k.val + 1) ∣ g))) := by
      intro x _ y _ hxy
      apply Fin.eq_of_val_eq
      have h1 : x.val + 1 = y.val + 1 := hxy
      omega
    have himg : ((Finset.univ : Finset (Fin n)).filter (fun k : Fin n => (k.val + 1) ∣ g)).image
        (fun k : Fin n => k.val + 1) = g.divisors := by
      apply Finset.ext
      intro d
      constructor
      · intro h
        obtain ⟨k, hku, rfl⟩ := Finset.mem_image.mp h
        have hpg : (k.val + 1) ∣ g := (Finset.mem_filter.mp hku).2
        rw [Nat.mem_divisors]
        exact ⟨hpg, hg0⟩
      · intro h
        have hpos : 0 < d := Nat.pos_of_mem_divisors h
        have hdvd : d ∣ g := (Nat.mem_divisors.mp h).1
        have hdg : d ≤ g := Nat.le_of_dvd hg1 hdvd
        have hdn : d ≤ n := le_trans hdg (le_trans hgm hmn)
        have hdv : d - 1 < n := by omega
        let k : Fin n := ⟨d - 1, hdv⟩
        have hkv : k.val = d - 1 := rfl
        have hv : k.val + 1 = d := by omega
        have hk : k ∈ (Finset.univ : Finset (Fin n)).filter (fun k : Fin n => (k.val + 1) ∣ g) :=
          Finset.mem_filter.mpr ⟨Finset.mem_univ _, by rw [hv]; exact hdvd⟩
        exact Finset.mem_image.mpr ⟨k, hk, hv⟩
    have h3 : Finset.sum ((Finset.univ : Finset (Fin n)).filter (fun k : Fin n => (k.val + 1) ∣ g))
          (fun k : Fin n => (Nat.totient (k.val + 1) : ℚ))
        = Finset.sum g.divisors (fun d : ℕ => (Nat.totient d : ℚ)) := by
      conv_rhs => rw [← himg]
      rw [Finset.sum_image hinj]
    have h4 : Finset.sum g.divisors (fun d : ℕ => (Nat.totient d : ℚ)) = (g : ℚ) := by
      rw [← Nat.cast_sum, Nat.sum_totient]
    have h1 : (∑ k : Fin n, (if (k.val + 1) ∣ m then (Nat.totient (k.val + 1) : ℚ) else 0) *
          (if (k.val + 1) ∣ l then (1 : ℚ) else 0))
        = ∑ k : Fin n, if (k.val + 1) ∣ g then (Nat.totient (k.val + 1) : ℚ) else 0 := by
      refine Finset.sum_congr rfl (fun k _ => hterm k)
    rw [h1, hfilter, h3, h4]
  ext i j
  simp only [Matrix.mul_apply, Matrix.transpose_apply, Matrix.of_apply, Matrix.diagonal_apply]
  have hcol : ∀ a : Fin n,
      (∑ b : Fin n, (if (b.val + 1) ∣ (i.val + 1) then (1 : ℚ) else 0) *
          (if b = a then (Nat.totient (b.val + 1) : ℚ) else 0))
        = if (a.val + 1) ∣ (i.val + 1) then (Nat.totient (a.val + 1) : ℚ) else 0 := by
    intro a
    have h1 : (∑ b : Fin n, (if (b.val + 1) ∣ (i.val + 1) then (1 : ℚ) else 0) *
            (if b = a then (Nat.totient (b.val + 1) : ℚ) else 0))
        = ∑ b : Fin n, (if b = a
            then (if (a.val + 1) ∣ (i.val + 1) then (1 : ℚ) else 0) * (Nat.totient (a.val + 1) : ℚ)
            else 0) := by
      refine Finset.sum_congr rfl (fun b _ => ?_)
      by_cases hb : b = a <;> simp [hb]
    rw [h1, Finset.sum_ite_eq']
    by_cases h : (a.val + 1) ∣ (i.val + 1) <;> simp [h]
  have hentry : (Nat.gcd (i.val + 1) (j.val + 1) : ℚ) =
      ∑ a : Fin n, (∑ b : Fin n, (if (b.val + 1) ∣ (i.val + 1) then (1 : ℚ) else 0) *
            (if b = a then (Nat.totient (b.val + 1) : ℚ) else 0)) *
          (if (a.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0) := by
    refine Eq.trans ((hsum (i.val + 1) (j.val + 1) (by omega) (by omega) (by omega) (by omega)).symm) ?_
    apply Finset.sum_congr rfl
    intro a _
    rw [hcol a]
  exact hentry

theorem a60841_divisibilityMatrix_det_one (n : Nat) (hn : 1 ≤ n) :
    (Matrix.of fun i j : Fin n =>
        if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0).det = 1 := by
  classical
  have hzero : ∀ i j : Fin n, j < i →
      (Matrix.of fun i j : Fin n => if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0) i j = 0 := by
    intro i j hij
    have hnd : ¬ ((i.val + 1) ∣ (j.val + 1)) := by
      intro hd
      have hij' : j.val < i.val := hij
      have hle := Nat.le_of_dvd (by omega : 0 < j.val + 1) hd
      omega
    simp only [Matrix.of_apply, if_neg hnd]
  have hdiag : ∀ i : Fin n,
      (Matrix.of fun i j : Fin n => if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0) i i = 1 := by
    intro i
    simp only [Matrix.of_apply, if_pos (Nat.dvd_refl (i.val + 1))]
  -- a permutation of `Fin n` bounded above by the identity is the identity
  have hperm : ∀ (σ : Equiv.Perm (Fin n)), (∀ i : Fin n, σ i ≤ i) → σ = 1 := by
    intro σ h
    by_contra hne
    obtain ⟨i, hi⟩ : ∃ i : Fin n, σ i ≠ i := by
      by_contra hall
      apply hne
      refine Equiv.Perm.ext (fun a => ?_)
      by_contra h2
      exact hall ⟨a, h2⟩
    obtain ⟨m, hm, hmin⟩ :
        ∃ m ∈ Finset.univ.filter (fun x : Fin n => σ x ≠ x),
          ∀ y ∈ Finset.univ.filter (fun x : Fin n => σ x ≠ x), (m : ℕ) ≤ (y : ℕ) :=
      Finset.exists_min_image (Finset.univ.filter (fun x : Fin n => σ x ≠ x))
        (fun x : Fin n => (x : ℕ))
        ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ i, hi⟩⟩
    have hm1 : σ m ≠ m := (Finset.mem_filter.mp hm).2
    have hlt : (σ m : ℕ) < (m : ℕ) := Nat.lt_of_le_of_ne (h m) (Fin.val_ne_iff.mpr hm1)
    have h2 : σ (σ m) = σ m := by
      by_contra h3
      have hc : σ m ∈ Finset.univ.filter (fun x : Fin n => σ x ≠ x) :=
        Finset.mem_filter.mpr ⟨Finset.mem_univ (σ m), h3⟩
      have hle := hmin (σ m) hc
      omega
    exact hm1 (σ.injective h2)
  -- hence every nontrivial permutation moves some index strictly upwards
  have hgt : ∀ (σ : Equiv.Perm (Fin n)), σ ≠ 1 → ∃ i : Fin n, i < σ i := by
    intro σ hσ
    by_contra hedge
    have hle : ∀ i : Fin n, σ i ≤ i := by
      intro i
      by_contra h2
      exact hedge ⟨i, by omega⟩
    exact hσ (hperm σ hle)
  -- the matrix is upper triangular with unit diagonal: only the identity permutation survives
  have hprod : ∀ σ : Equiv.Perm (Fin n),
      (∏ i : Fin n, (Matrix.of fun i j : Fin n => if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0) (σ i) i)
        = (if σ = 1 then (1 : ℚ) else 0) := by
    intro σ
    by_cases hσ : σ = 1
    · subst hσ
      transitivity (1 : ℚ)
      · apply Finset.prod_eq_one
        intro k _
        exact hdiag k
      · exact (if_pos rfl).symm
    · obtain ⟨i, hi⟩ := hgt σ hσ
      rw [if_neg hσ]
      exact Finset.prod_eq_zero (Finset.mem_univ i) (hzero (σ i) i hi)
  have hsum1 : (∑ σ : Equiv.Perm (Fin n), (if σ = 1 then (1 : ℚ) else 0)) = (1 : ℚ) := by
    rw [Finset.sum_ite_eq']
    simp
  have hsum2 : (∑ σ : Equiv.Perm (Fin n),
      Equiv.Perm.sign σ • (∏ i : Fin n,
        (Matrix.of fun i j : Fin n => if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0) (σ i) i))
      = (∑ σ : Equiv.Perm (Fin n), (if σ = 1 then (1 : ℚ) else 0)) := by
    apply Finset.sum_congr rfl
    intro σ _
    rw [hprod σ]
    by_cases hσ : σ = 1
    · subst hσ
      simp [Equiv.Perm.sign_one]
    · simp [hσ]
  rw [Matrix.det_apply, hsum2, hsum1]

theorem a60841_divisibilityMatrixTranspose_det_one (n : Nat) (hn : 1 ≤ n) :
    (Matrix.of fun i j : Fin n =>
        if (i.val + 1) ∣ (j.val + 1) then (1 : ℚ) else 0).transpose.det = 1 := by
  rw [Matrix.det_transpose]
  exact a60841_divisibilityMatrix_det_one n hn

theorem a60841_diag_totient_det (n : Nat) (hn : 1 ≤ n) :
    (Matrix.diagonal (fun i : Fin n => (Nat.totient (i.val + 1) : ℚ))).det =
      ((Finset.Icc 1 n).prod (fun k => Nat.totient k) : ℚ) := by
  classical
  have h1 : (Matrix.diagonal (fun i : Fin n => (Nat.totient (i.val + 1) : ℚ))).det =
      ∏ i : Fin n, (Nat.totient (i.val + 1) : ℚ) := by
    rw [Matrix.det_diagonal]
  rw [h1]
  have h2 : (∏ i : Fin n, (Nat.totient (i.val + 1) : ℚ)) =
      ((Finset.univ : Finset (Fin n)).prod (fun i => Nat.totient (i.val + 1)) : ℚ) := by
    norm_cast
  rw [h2]
  norm_cast
  exact a60841_prod_fin_totient_eq_Icc_prod_totient n hn

theorem a60841_diag_inv_factorial_det (n : Nat) (hn : 1 ≤ n) :
    (Matrix.diagonal (fun i : Fin n => (((i.val + 1 : ℕ) : ℚ))⁻¹)).det =
      ((Nat.factorial n : ℚ))⁻¹ := by
  classical
  rw [Matrix.det_diagonal]
  exact a60841_prod_fin_inv_factorial n hn

theorem a60841_gcdMatrix_det (n : Nat) (hn : 1 ≤ n) :
    (Matrix.of fun i j : Fin n => (Nat.gcd (i.val + 1) (j.val + 1) : ℚ)).det =
      ((Finset.Icc 1 n).prod (fun k => Nat.totient k) : ℚ) := by
  rw [a60841_gcdMatrix_factorization n hn]
  rw [Matrix.det_mul, Matrix.det_mul]
  rw [a60841_divisibilityMatrixTranspose_det_one n hn,
      a60841_divisibilityMatrix_det_one n hn,
      a60841_diag_totient_det n hn]
  simp

theorem a60841_det_lcm_eq_inv_fact_mul_totient_mul_inv_fact (n : Nat) (hn : 1 ≤ n) :
    (OeisA60841.lcmMatrix n).det =
      ((Nat.factorial n : ℚ))⁻¹ *
        ((Finset.Icc 1 n).prod (fun k => Nat.totient k) : ℚ) *
        ((Nat.factorial n : ℚ))⁻¹ := by
  rw [a60841_lcmMatrix_eq_scaled_gcd_matrix n hn]
  rw [Matrix.det_mul, Matrix.det_mul]
  rw [a60841_diag_inv_factorial_det n hn, a60841_gcdMatrix_det n hn]

theorem a60841_inv_fact_mul_totient_mul_inv_fact_eq_div (n : Nat) (hn : 1 ≤ n) :
    ((Nat.factorial n : ℚ))⁻¹ *
        ((Finset.Icc 1 n).prod (fun k => Nat.totient k) : ℚ) *
        ((Nat.factorial n : ℚ))⁻¹ =
      ((Finset.Icc 1 n).prod (fun k => Nat.totient k) : ℚ) /
        ((Nat.factorial n : ℚ) ^ 2) := by
  simp only [div_eq_mul_inv, pow_two, mul_inv_rev]
  ring

theorem lcmMatrix_det_eq_prod_totient_div_factorial_sq (n : Nat) (hn : 1 ≤ n) :
    (OeisA60841.lcmMatrix n).det =
      ((Finset.Icc 1 n).prod (fun k => Nat.totient k) : ℚ) /
        ((Nat.factorial n : ℚ) ^ 2) := by
  rw [a60841_det_lcm_eq_inv_fact_mul_totient_mul_inv_fact n hn,
      a60841_inv_fact_mul_totient_mul_inv_fact_eq_div n hn]

theorem lcmMatrix_det_inv_den_eq_one_iff_divisibility (n : Nat) (hn : 1 ≤ n) :
    (((OeisA60841.lcmMatrix n).det)⁻¹).den = 1 ↔
      (Finset.Icc 1 n).prod (fun k => Nat.totient k) ∣ (Nat.factorial n) ^ 2 := by
  have hP : 0 < (Finset.Icc 1 n).prod (fun k => Nat.totient k) := a60841_prod_totient_pos n hn
  have hF : 0 < (Nat.factorial n) ^ 2 := a60841_fact_sq_pos n
  have hnum : (∏ k ∈ Finset.Icc 1 n, ((Nat.totient k : ℕ) : ℚ)) =
      Nat.cast (∏ k ∈ Finset.Icc 1 n, Nat.totient k) := by
    simp
  rw [lcmMatrix_det_eq_prod_totient_div_factorial_sq (n := n) (hn := hn)]
  rw [hnum, ← Nat.cast_pow (Nat.factorial n) 2]
  exact a60841_rat_div_inv_den_eq_one_iff_div hP hF

theorem a60841_prod_totient_dvd_fact_sq_on_1_to_34 (n : Nat) (h1 : 1 ≤ n) (h2 : n ≤ 34) :
    (Finset.Icc 1 n).prod (fun k => Nat.totient k) ∣ (Nat.factorial n) ^ 2 := by
  have key : ∀ n ∈ Finset.Icc 1 34, (Finset.Icc 1 n).prod (fun k => Nat.totient k) ∣ (Nat.factorial n) ^ 2 := by
    decide
  exact key n (Finset.mem_Icc.mpr ⟨h1, h2⟩)

theorem a60841_prod_totient_dvd_fact_sq_36 :
    (Finset.Icc 1 36).prod (fun k => Nat.totient k) ∣ (Nat.factorial 36) ^ 2 := by
  decide

theorem a60841_prod_totient_dvd_fact_sq_38 :
    (Finset.Icc 1 38).prod (fun k => Nat.totient k) ∣ (Nat.factorial 38) ^ 2 := by decide

theorem a60841_prod_totient_not_dvd_fact_sq_35 :
    ¬ (Finset.Icc 1 35).prod (fun k => Nat.totient k) ∣ (Nat.factorial 35) ^ 2 := by decide

theorem a60841_prod_totient_not_dvd_fact_sq_37 :
    ¬ (Finset.Icc 1 37).prod (fun k => Nat.totient k) ∣ (Nat.factorial 37) ^ 2 := by
  have h : ¬ (Finset.Icc 1 37).prod (fun k => Nat.totient k) ∣ (Nat.factorial 37) ^ 2 := by decide
  exact h

theorem a60841_ge39_imp_ge_one (n : Nat) (h : 39 ≤ n) : 1 ≤ n := by
  omega

theorem a60841_not_dvd_of_padicValNat2_gt {a b : Nat} (ha : 0 < a) (hb : 0 < b)
    (h : padicValNat 2 a > padicValNat 2 b) : ¬ a ∣ b := by
  intro hab
  obtain ⟨c, rfl⟩ := hab
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  have ha0 : a ≠ 0 := Nat.ne_of_gt ha
  have hc : c ≠ 0 := by
    intro hc
    rw [hc, mul_zero] at hb
    exact Nat.not_lt_zero 0 hb
  have H : padicValNat 2 (a * c) = padicValNat 2 a + padicValNat 2 c :=
    padicValNat.mul (p := 2) ha0 hc
  rw [H] at h
  omega

def a60841_twoTailSum (n : Nat) : Nat :=
  (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i)

def a60841_primeValSum (n : Nat) : Nat :=
  (Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ n) (Finset.range (n + 1))).sum
    (fun p => padicValNat 2 (p - 1) * (n / p))

def a60841_reducedGoal (n : Nat) : Prop :=
  2 * (n / 2) + a60841_twoTailSum n < a60841_primeValSum n

theorem a60841_padicValNat_fact_val_two_eq_sum_div (n : Nat) :
    (Finset.Icc 1 n).sum (fun k => padicValNat 2 k) =
      (Finset.Ico 1 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i) := by
  classical
  have key : ∀ m : ℕ, (Finset.Icc 1 m).sum (fun k => padicValNat 2 k) = padicValNat 2 m.factorial := by
    intro m
    induction m with
    | zero => simp
    | succ m ih =>
      haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
      rw [Finset.sum_Icc_succ_top (by omega : 1 ≤ m + 1),
        Nat.factorial_succ, padicValNat.mul (by omega : (m + 1 : ℕ) ≠ 0) (Nat.factorial_ne_zero m), ih]
      exact add_comm _ _
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  exact (key n).trans
    (padicValNat_factorial (p := 2) (b := Nat.log 2 n + 1) (Nat.lt_succ_self (Nat.log 2 n)))

theorem a60841_twoTailSum_split_one (n : Nat) :
    (Finset.Ico 1 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i) =
      n / 2 + a60841_twoTailSum n := by
  -- If Nat.log 2 n = 0 then n ≤ 1, hence n / 2 = 0.
  have hkey : Nat.log 2 n = 0 → n ≤ 1 := by
    intro hz
    by_contra h1
    push_neg at h1
    have hr : Nat.log 2 n = Nat.log 2 (n / 2) + 1 :=
      Nat.log_of_one_lt_of_le (by decide : 1 < (2 : ℕ)) (by omega : 2 ≤ n)
    omega
  by_cases h : (1 : ℕ) ∈ Finset.Ico 1 (Nat.log 2 n + 1)
  · -- the index 1 occurs in the range, so split off that term
    have hsub : ({1} : Finset ℕ) ⊆ Finset.Ico 1 (Nat.log 2 n + 1) := by
      intro x hx
      rw [Finset.mem_singleton] at hx
      subst hx
      exact h
    have hsd : Finset.Ico 1 (Nat.log 2 n + 1) \ ({1} : Finset ℕ) =
        Finset.Ico 2 (Nat.log 2 n + 1) := by
      apply Finset.ext
      intro x
      simp only [Finset.mem_sdiff, Finset.mem_singleton, Finset.mem_Ico]
      omega
    have h2 : (∑ i ∈ Finset.Ico 1 (Nat.log 2 n + 1) \ ({1} : Finset ℕ), n / 2 ^ i) +
        (∑ i ∈ ({1} : Finset ℕ), n / 2 ^ i) = ∑ i ∈ Finset.Ico 1 (Nat.log 2 n + 1), n / 2 ^ i :=
      Finset.sum_sdiff hsub
    simp only [hsd, Finset.sum_singleton, Nat.pow_one] at h2
    rw [← h2, add_comm]
    rfl
  · -- the range is empty, and then also n / 2 = 0
    have hlog : Nat.log 2 n = 0 := by
      have hnot : ¬ 1 < Nat.log 2 n + 1 := by
        intro hlt
        exact h (Finset.mem_Ico.mpr ⟨by omega, hlt⟩)
      omega
    have hn : n ≤ 1 := hkey hlog
    have he1 : Finset.Ico 1 (Nat.log 2 n + 1) = ∅ :=
      Finset.Ico_eq_empty_of_le (by omega : Nat.log 2 n + 1 ≤ 1)
    have he2 : Finset.Ico 2 (Nat.log 2 n + 1) = ∅ :=
      Finset.Ico_eq_empty_of_le (by omega : Nat.log 2 n + 1 ≤ 2)
    have hdiv : n / 2 = 0 := Nat.div_eq_of_lt (by omega : n < 2)
    simp only [a60841_twoTailSum, he1, he2, Finset.sum_empty, hdiv, add_zero]

theorem a60841_padicValNat_fact_eq_twoTail (n : Nat) :
    padicValNat 2 (Nat.factorial n) =
      n / 2 + a60841_twoTailSum n := by
  haveI : Fact (Nat.Prime 2) := ⟨by decide⟩
  have h : padicValNat 2 (Nat.factorial n) =
      (Finset.Ico 1 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i) := by
    rw [padicValNat_factorial (p := 2) (n := n) (b := Nat.log 2 n + 1) (Nat.lt_succ_self _)]
  rw [h, a60841_twoTailSum_split_one]

theorem a60841_padicValNat_fact_sq_eq_two (n : Nat) :
    padicValNat 2 ((Nat.factorial n) ^ 2) = 2 * padicValNat 2 (Nat.factorial n) := by
  rw [padicValNat.pow]

theorem a60841_v2_fact_sq_eq_twoTail (n : Nat) :
    padicValNat 2 ((Nat.factorial n) ^ 2) =
      2 * (n / 2) + 2 * a60841_twoTailSum n := by
  rw [a60841_padicValNat_fact_sq_eq_two, a60841_padicValNat_fact_eq_twoTail, Nat.mul_add]

theorem a60841_padicValNat_prod_totient_eq_sum_totient_vals (n : Nat) (hn : 1 ≤ n) :
    padicValNat 2 ((Finset.Icc 1 n).prod (fun k => Nat.totient k)) =
      (Finset.Icc 1 n).sum (fun k => padicValNat 2 (Nat.totient k)) := by
  classical
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  have key : ∀ n : ℕ,
      padicValNat 2 ((Finset.Icc 1 n).prod (fun k => Nat.totient k)) =
        (Finset.Icc 1 n).sum (fun k => padicValNat 2 (Nat.totient k)) := by
    intro n
    induction n with
    | zero =>
        rw [Finset.Icc_eq_empty (show ¬ (1 : ℕ) ≤ 0 by omega), Finset.prod_empty,
          Finset.sum_empty]
        exact padicValNat_one_right 2
    | succ n ih =>
        have hset : Finset.Icc 1 (n + 1) = insert (n + 1) (Finset.Icc 1 n) := by
          ext m
          simp only [Finset.mem_insert, Finset.mem_Icc]
          omega
        have hnm : n + 1 ∉ Finset.Icc 1 n := by
          intro h
          simp only [Finset.mem_Icc] at h
          omega
        have htz : Nat.totient (n + 1) ≠ 0 :=
          Nat.ne_of_gt (Nat.totient_pos.mpr (Nat.succ_pos n))
        have hpz : (Finset.Icc 1 n).prod (fun k => Nat.totient k) ≠ 0 := by
          rw [Finset.prod_ne_zero_iff]
          intro k hk
          rw [Finset.mem_Icc] at hk
          exact Nat.ne_of_gt (Nat.totient_pos.mpr (by omega : 0 < k))
        rw [hset, Finset.prod_insert hnm, Finset.sum_insert hnm,
          padicValNat.mul htz hpz, ih]
  exact key n

theorem a60841_padicValNat_totient_eq (k : Nat) (hk : 1 ≤ k) :
    padicValNat 2 (Nat.totient k) =
      (if 2 ∣ k then padicValNat 2 k - 1 else 0) +
      ((Nat.factorization k).support.sum (fun p =>
          if p = 2 then 0 else padicValNat 2 (p - 1))) := by
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  have k0 : k ≠ 0 := Nat.ne_of_gt (by omega : 0 < k)
  classical
  have hA : ∀ (p n : ℕ), p.Prime → 0 < n →
      padicValNat 2 (Nat.totient (p ^ n)) = if p = 2 then n - 1 else padicValNat 2 (p - 1) := by
    intro p n hp hn
    by_cases h2 : p = 2
    · subst h2
      have h1 : padicValNat 2 (Nat.totient (2 ^ n)) = n - 1 := by
        have hc : (2 : ℕ) ^ (n - 1) * (2 - 1) = (2 : ℕ) ^ (n - 1) := by simp
        rw [Nat.totient_prime_pow Nat.prime_two hn, hc]
        exact padicValNat.prime_pow (n - 1)
      rw [if_pos rfl]
      exact h1
    · rw [if_neg h2, Nat.totient_prime_pow hp hn,
        padicValNat.mul (Nat.ne_of_gt (pow_pos hp.pos (n - 1))) (Nat.sub_ne_zero_of_lt hp.one_lt)]
      have hm : ¬ (2 : ℕ) ∣ p := by
        intro hd
        exact h2 ((Nat.Prime.eq_one_or_self_of_dvd hp 2 hd).resolve_left (by norm_num)).symm
      have hd : ¬ (2 : ℕ) ∣ p ^ (n - 1) := by
        intro h
        exact hm (Nat.Prime.dvd_of_dvd_pow Nat.prime_two h)
      rw [padicValNat.eq_zero_of_not_dvd hd]
      omega
  have key : ∀ (f : ℕ → ℕ) (t : Finset ℕ), (∀ p ∈ t, p.Prime) → (∀ p ∈ t, 1 ≤ f p) →
      padicValNat 2 (Nat.totient (t.prod (fun p => p ^ f p))) =
        t.sum (fun p => if p = 2 then f 2 - 1 else padicValNat 2 (p - 1)) := by
    intro f t
    refine Finset.induction_on t ?_ ?_
    · intro _ _
      simp
    · intro a t' has ih
      intro hsp hfp
      have ha : a.Prime := hsp a (Finset.mem_insert_self a t')
      have hfa : 1 ≤ f a := hfp a (Finset.mem_insert_self a t')
      have hsp' : ∀ p ∈ t', p.Prime := fun p hp => hsp p (Finset.mem_insert_of_mem hp)
      have hcop : (a : ℕ).Coprime (t'.prod (fun p => p ^ f p)) := by
        refine Nat.Coprime.prod_right ?_
        intro p hp
        have hcp : (a : ℕ).Coprime p :=
          (Nat.coprime_primes ha (hsp' p hp)).mpr (fun heq => has (heq ▸ hp))
        exact Nat.Coprime.pow_right (f p) hcp
      have h1 : Nat.totient (a ^ f a) ≠ 0 :=
        Nat.ne_of_gt (Nat.totient_pos.mpr (pow_pos ha.pos (f a)))
      have h2 : Nat.totient (t'.prod (fun p => p ^ f p)) ≠ 0 :=
        Nat.ne_of_gt (Nat.totient_pos.mpr
          (Finset.prod_pos (fun p hp => pow_pos (hsp' p hp).pos (f p))))
      rw [Finset.prod_insert has, Nat.totient_mul (Nat.Coprime.pow_left (f a) hcop),
        padicValNat.mul h1 h2, ih hsp' (fun p hp => hfp p (Finset.mem_insert_of_mem hp)),
        hA a (f a) ha (by omega : 0 < f a), Finset.sum_insert has]
      by_cases hc : a = 2 <;> simp [hc]
  have hprod : k.factorization.support.prod (fun p => p ^ k.factorization p) = k :=
    Nat.factorization_prod_pow_eq_self k0
  have hsp : ∀ p ∈ k.factorization.support, p.Prime := by
    intro p hp
    have hne : k.factorization p ≠ 0 := Finsupp.mem_support_iff.mp hp
    by_contra hnp
    exact hne ((Nat.factorization_eq_zero_iff k p).mpr (Or.inl hnp))
  have hf1 : ∀ p ∈ k.factorization.support, 1 ≤ k.factorization p := by
    intro p hp
    have hne : k.factorization p ≠ 0 := Finsupp.mem_support_iff.mp hp
    omega
  have hmain : padicValNat 2 (Nat.totient k) =
      k.factorization.support.sum (fun p => if p = 2 then k.factorization 2 - 1 else padicValNat 2 (p - 1)) :=
    (congr_arg (fun x => padicValNat 2 (Nat.totient x)) hprod.symm).trans
      (key (fun p => k.factorization p) k.factorization.support hsp hf1)
  have hsplit :
      k.factorization.support.sum (fun p => if p = 2 then k.factorization 2 - 1 else padicValNat 2 (p - 1))
        = (k.factorization 2 - 1) +
          k.factorization.support.sum (fun p => if p = 2 then 0 else padicValNat 2 (p - 1)) := by
    by_cases hmem : (2 : ℕ) ∈ k.factorization.support
    · have hne : (2 : ℕ) ∉ k.factorization.support.erase 2 := by simpa
      have he1 : (k.factorization.support.erase 2).sum
          (fun p => if p = 2 then k.factorization 2 - 1 else padicValNat 2 (p - 1))
          = (k.factorization.support.erase 2).sum (fun p => padicValNat 2 (p - 1)) :=
        Finset.sum_congr rfl (fun p hp => if_neg (Finset.mem_erase.mp hp).1)
      have he2 : (k.factorization.support.erase 2).sum
          (fun p => if p = 2 then 0 else padicValNat 2 (p - 1))
          = (k.factorization.support.erase 2).sum (fun p => padicValNat 2 (p - 1)) :=
        Finset.sum_congr rfl (fun p hp => if_neg (Finset.mem_erase.mp hp).1)
      rw [(Finset.insert_erase hmem).symm, Finset.sum_insert hne, Finset.sum_insert hne, he1, he2]
      try simp
    · have hf0 : k.factorization 2 = 0 := by
        by_contra hne
        exact hmem (Finsupp.mem_support_iff.mpr hne)
      have he1 : k.factorization.support.sum
          (fun p => if p = 2 then k.factorization 2 - 1 else padicValNat 2 (p - 1))
          = k.factorization.support.sum (fun p => padicValNat 2 (p - 1)) :=
        Finset.sum_congr rfl (fun p hp => if_neg (fun (h : p = 2) => hmem (h ▸ hp)))
      have he2 : k.factorization.support.sum (fun p => if p = 2 then 0 else padicValNat 2 (p - 1))
          = k.factorization.support.sum (fun p => padicValNat 2 (p - 1)) :=
        Finset.sum_congr rfl (fun p hp => if_neg (fun (h : p = 2) => hmem (h ▸ hp)))
      rw [he1, hf0, ← he2]
      try simp
  have hvk : padicValNat 2 k = k.factorization 2 := (Nat.factorization_def k Nat.prime_two).symm
  rw [hmain, hsplit]
  by_cases hd : (2 : ℕ) ∣ k
  · rw [if_pos hd, hvk]
  · rw [if_neg hd]
    have hf0 : k.factorization 2 = 0 := by
      rw [← hvk]
      exact padicValNat.eq_zero_of_not_dvd hd
    rw [hf0]
    try simp

theorem a60841_padicValNat_totient_sum_twoPart_eq_twoTail (n : Nat) (hn : 1 ≤ n) :
    (Finset.Icc 1 n).sum (fun k => if 2 ∣ k then padicValNat 2 k - 1 else 0) =
      a60841_twoTailSum n := by
  classical
  have hpc : Nat.Prime 2 := Nat.prime_two
  haveI : Fact (Nat.Prime 2) := ⟨hpc⟩
  have hIcc_image : ∀ m : ℕ, (Finset.Icc 1 m : Finset ℕ) = (Finset.range m).image (fun j => j + 1) := by
    intro m
    apply Finset.ext
    intro x
    simp only [Finset.mem_Icc, Finset.mem_image, Finset.mem_range]
    constructor
    · intro hx
      exact ⟨x - 1, by omega, by omega⟩
    · rintro ⟨y, hy, rfl⟩
      omega
  have cardIcc1 : ∀ m : ℕ, (Finset.Icc 1 m : Finset ℕ).card = m := by
    intro m
    rw [hIcc_image m, Finset.card_image_of_injective]
    · exact Finset.card_range m
    · intro a b e
      simpa using e
  have hIco_image : ∀ v : ℕ, (Finset.Ico 2 (v + 1) : Finset ℕ) = (Finset.Icc 1 (v - 1)).image (fun j => j + 1) := by
    intro v
    apply Finset.ext
    intro x
    simp only [Finset.mem_Ico, Finset.mem_Icc, Finset.mem_image]
    constructor
    · intro hx
      exact ⟨x - 1, by omega, by omega⟩
    · rintro ⟨y, hy, rfl⟩
      omega
  have cardIco2 : ∀ v : ℕ, (Finset.Ico 2 (v + 1) : Finset ℕ).card = v - 1 := by
    intro v
    rw [hIco_image v, Finset.card_image_of_injective]
    · exact cardIcc1 (v - 1)
    · intro a b e
      simpa using e
  have hfilt : ∀ (d : ℕ), 1 ≤ d →
      (Finset.Icc 1 n).filter (fun k => d ∣ k) = (Finset.Icc 1 (n / d)).image (fun j => d * j) := by
    intro d hd
    have hd0 : 0 < d := hd
    apply Finset.ext
    intro x
    constructor
    · intro hx
      have hxn : x ∈ Finset.Icc 1 n := (Finset.mem_filter.mp hx).1
      have hdx : d ∣ x := (Finset.mem_filter.mp hx).2
      obtain ⟨m, rfl⟩ := hdx
      have h1 : 1 ≤ d * m := (Finset.mem_Icc.mp hxn).1
      have h2 : d * m ≤ n := (Finset.mem_Icc.mp hxn).2
      have hm : m ∈ Finset.Icc 1 (n / d) := by
        refine Finset.mem_Icc.mpr ⟨?_, ?_⟩
        · rcases eq_or_ne m 0 with hm0 | hm0
          · simp only [hm0, mul_zero] at h1; omega
          · exact Nat.pos_of_ne_zero hm0
        · have hmd : m * d ≤ n := by
            rw [Nat.mul_comm]
            exact h2
          exact (Nat.le_div_iff_mul_le hd0).mpr hmd
      exact Finset.mem_image.mpr ⟨m, hm, rfl⟩
    · intro hx
      obtain ⟨m, hm, rfl⟩ := Finset.mem_image.mp hx
      have hm1 : 1 ≤ m := (Finset.mem_Icc.mp hm).1
      have hm2 : m ≤ n / d := (Finset.mem_Icc.mp hm).2
      have hb : 1 ≤ d * m := by
        have hpos : 0 < d * m := by
          rcases eq_or_ne m 0 with hm0 | hm0
          · simp_all
          · exact Nat.mul_pos hd0 (Nat.pos_of_ne_zero hm0)
        omega
      have hc : d * m ≤ n := by
        calc d * m ≤ d * (n / d) := Nat.mul_le_mul_left d hm2
          _ = n / d * d := Nat.mul_comm _ _
          _ ≤ n := Nat.div_mul_le_self n d
      refine Finset.mem_filter.mpr ⟨Finset.mem_Icc.mpr ⟨hb, hc⟩, ⟨m, rfl⟩⟩
  have hcard : ∀ (d : ℕ), 1 ≤ d → ((Finset.Icc 1 n).filter (fun k => d ∣ k)).card = n / d := by
    intro d hd
    rw [hfilt d hd, Finset.card_image_of_injective]
    · exact cardIcc1 (n / d)
    · intro a b e
      exact Nat.eq_of_mul_eq_mul_left hd e
  have key : ∀ k ∈ Finset.Icc 1 n,
      (if 2 ∣ k then padicValNat 2 k - 1 else 0) =
        (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => if 2 ^ i ∣ k then 1 else 0) := by
    intro k hk
    rcases Finset.mem_Icc.mp hk with ⟨hk1, hk2⟩
    have hk0 : k ≠ 0 := by omega
    have hpdvd : 2 ^ padicValNat 2 k ∣ k := pow_padicValNat_dvd
    by_cases hk2' : 2 ∣ k
    · have hle : padicValNat 2 k ≤ Nat.log 2 n :=
        Nat.le_log_of_pow_le (by norm_num : (1 : ℕ) < 2)
          (Nat.le_trans (Nat.le_of_dvd (by omega : 0 < k) hpdvd) hk2)
      rw [if_pos hk2']
      have hsum : (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => if 2 ^ i ∣ k then 1 else 0) =
          ((Finset.Ico 2 (Nat.log 2 n + 1)).filter (fun i => 2 ^ i ∣ k)).card := by
        rw [← Finset.sum_filter, Finset.card_eq_sum_ones]
      have hset : (Finset.Ico 2 (Nat.log 2 n + 1)).filter (fun i => 2 ^ i ∣ k) =
          Finset.Ico 2 (padicValNat 2 k + 1) := by
        apply Finset.ext
        intro i
        constructor
        · intro hi
          have hmf := Finset.mem_filter.mp hi
          have hico := Finset.mem_Ico.mp hmf.1
          have hiv : i ≤ padicValNat 2 k := by
            by_contra H
            have hsucc : padicValNat 2 k + 1 ≤ i := by omega
            have hd : 2 ^ (padicValNat 2 k + 1) ∣ k :=
              Nat.dvd_trans (Nat.pow_dvd_pow 2 hsucc) hmf.2
            exact absurd hd (pow_succ_padicValNat_not_dvd hk0)
          exact Finset.mem_Ico.mpr ⟨hico.1, Nat.lt_succ_of_le hiv⟩
        · intro hi
          have hico := Finset.mem_Ico.mp hi
          have hiv : i ≤ padicValNat 2 k := Nat.lt_succ_iff.mp hico.2
          exact Finset.mem_filter.mpr
            ⟨Finset.mem_Ico.mpr ⟨hico.1, Nat.lt_succ_of_le (Nat.le_trans hiv hle)⟩,
             Nat.dvd_trans (Nat.pow_dvd_pow 2 hiv) hpdvd⟩
      rw [hsum, hset, cardIco2]
    · rw [if_neg hk2']
      symm
      apply Finset.sum_eq_zero
      intro i hi
      have h2i : 2 ≤ i := (Finset.mem_Ico.mp hi).1
      have hpow : 2 ∣ 2 ^ i := by
        have hieq : i = 1 + (i - 1) := by omega
        rw [hieq, pow_add, pow_one]
        exact dvd_mul_right 2 _
      by_cases h : 2 ^ i ∣ k
      · exfalso
        exact absurd (Nat.dvd_trans hpow h) hk2'
      · rw [if_neg h]
  calc (Finset.Icc 1 n).sum (fun k => if 2 ∣ k then padicValNat 2 k - 1 else 0)
      _ = (Finset.Icc 1 n).sum (fun k =>
            (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => if 2 ^ i ∣ k then 1 else 0)) :=
        Finset.sum_congr rfl key
      _ = (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i =>
            (Finset.Icc 1 n).sum (fun k => if 2 ^ i ∣ k then 1 else 0)) := Finset.sum_comm
      _ = (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i) := by
        apply Finset.sum_congr rfl
        intro i hi
        have hd : 1 ≤ (2 : ℕ) ^ i := by
          have := Nat.one_le_pow i 2
          omega
        have hsum : (Finset.Icc 1 n).sum (fun k => if 2 ^ i ∣ k then 1 else 0) =
            ((Finset.Icc 1 n).filter (fun k => 2 ^ i ∣ k)).card := by
          rw [← Finset.sum_filter, Finset.card_eq_sum_ones]
        rw [hsum, hcard (2 ^ i) hd]
      _ = a60841_twoTailSum n := rfl

theorem a60841_padicValNat_totient_sum_primePart_eq_primeValSum (n : Nat) (hn : 1 ≤ n) :
    (Finset.Icc 1 n).sum (fun k =>
        (Nat.factorization k).support.sum (fun p =>
          if p = 2 then 0 else padicValNat 2 (p - 1))) =
      a60841_primeValSum n := by
  have hcard : ∀ (N P : ℕ), 1 ≤ P → ((Finset.Icc 1 N).filter (fun k => P ∣ k)).card = N / P := by
    intro N P hP
    have hp0 : 0 < P := by omega
    have hset : (Finset.Icc 1 N).filter (fun k => P ∣ k) = (Finset.Icc 1 (N / P)).image (fun j => P * j) := by
      apply Finset.ext
      intro k
      simp only [Finset.mem_filter, Finset.mem_image, Finset.mem_Icc]
      constructor
      · rintro ⟨⟨h1, h2⟩, hd⟩
        have hpk : P ≤ k := Nat.le_of_dvd h1 hd
        refine ⟨k / P, ⟨(Nat.one_le_div_iff hp0).mpr hpk, Nat.div_le_div_right h2⟩, ?_⟩
        rw [Nat.mul_comm, Nat.div_mul_cancel hd]
      · rintro ⟨j, ⟨h1, h2⟩, rfl⟩
        refine ⟨⟨by nlinarith, ?_⟩, dvd_mul_right P j⟩
        calc P * j ≤ P * (N / P) := by gcongr
          _ ≤ N := Nat.mul_div_le N P
    rw [hset, Finset.card_image_of_injective]
    · simp
    · exact fun a b h => Nat.eq_of_mul_eq_mul_left hp0 h
  have hmem_aux : ∀ (k : ℕ), k ≠ 0 → ∀ p : ℕ, p ∈ (Nat.factorization k).support ↔ p.Prime ∧ p ∣ k := by
    intro k hk0 p
    have key : (¬p.Prime ∨ ¬p ∣ k ∨ k = 0) ↔ ¬(p.Prime ∧ p ∣ k) := by
      constructor
      · intro he hh
        exact he.elim (fun h1 => h1 hh.1) (fun h23 =>
          h23.elim (fun h2 => h2 hh.2) (fun h3 => hk0 h3))
      · intro h
        by_cases hp : p.Prime
        · by_cases hd : p ∣ k
          · exfalso; exact h ⟨hp, hd⟩
          · exact Or.inr (Or.inl hd)
        · exact Or.inl hp
    have key2 : k.factorization p = 0 ↔ ¬(p.Prime ∧ p ∣ k) := (@Nat.factorization_eq_zero_iff k p).trans key
    constructor
    · intro h
      by_contra hn2
      rw [Finsupp.mem_support_iff] at h
      exact h (key2.mpr hn2)
    · intro h
      rw [Finsupp.mem_support_iff]
      exact fun h2 => key2.mp h2 h
  have hinner : ∀ k ∈ Finset.Icc 1 n,
      (Nat.factorization k).support.sum (fun p => if p = 2 then 0 else padicValNat 2 (p - 1))
        = (Finset.range (n + 1)).sum (fun p => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0) := by
    intro k hk
    have hkm := Finset.mem_Icc.mp hk
    have hk0 : k ≠ 0 := by omega
    have hmem := hmem_aux k hk0
    have hsub : (Nat.factorization k).support ⊆ Finset.range (n + 1) := by
      intro p hp
      have hA := (hmem p).mp hp
      have hle : p ≤ k := Nat.le_of_dvd (Nat.pos_of_ne_zero hk0) hA.2
      exact Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.le_trans hle hkm.2))
    calc (Nat.factorization k).support.sum (fun p => if p = 2 then 0 else padicValNat 2 (p - 1))
        = (Nat.factorization k).support.sum (fun p => if p ≠ 2 then padicValNat 2 (p - 1) else 0) := by
            refine Finset.sum_congr rfl (fun p _ => ?_)
            by_cases h : p = 2
            · rw [if_pos h, if_neg (fun hn2 => hn2 h)]
            · rw [if_neg h, if_pos h]
      _ = (Nat.factorization k).support.sum (fun p => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0) := by
            refine Finset.sum_congr rfl (fun p hp => ?_)
            have hA := (hmem p).mp hp
            have hB : 2 ≤ p := Nat.Prime.two_le hA.1
            have hEq : (p.Prime ∧ 2 < p ∧ p ∣ k) ↔ p ≠ 2 := by
              constructor
              · intro h; omega
              · intro h; exact And.intro hA.1 (And.intro (by omega) hA.2)
            exact if_congr hEq.symm rfl rfl
      _ = (Finset.range (n + 1)).sum (fun p => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0) := by
            refine Finset.sum_subset hsub (fun p _ hp => ?_)
            exact if_neg (fun h : p.Prime ∧ 2 < p ∧ p ∣ k => hp ((hmem p).mpr (And.intro h.1 h.2.2)))
  have hsum_p : ∀ p : ℕ,
      (Finset.Icc 1 n).sum (fun k => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0)
        = if p.Prime ∧ 2 < p then padicValNat 2 (p - 1) * (n / p) else 0 := by
    intro p
    by_cases hc : p.Prime ∧ 2 < p
    · have hp1 : 1 ≤ p := by omega
      rw [if_pos hc]
      have h5 : (Finset.Icc 1 n).sum (fun k => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0)
          = (Finset.Icc 1 n).sum (fun k => if p ∣ k then padicValNat 2 (p - 1) else 0) := by
          refine Finset.sum_congr rfl (fun k _ =>
            if_congr (Iff.intro (fun h => h.2.2) (fun h => And.intro hc.1 (And.intro hc.2 h))) rfl rfl)
      rw [h5, (Finset.sum_filter (fun k => p ∣ k) (fun _ => padicValNat 2 (p - 1))).symm,
        Finset.sum_const, Nat.nsmul_eq_mul, hcard n p hp1, Nat.mul_comm]
    · rw [if_neg hc, Finset.sum_eq_zero
        (fun k _ => if_neg (fun h : p.Prime ∧ 2 < p ∧ p ∣ k => hc (And.intro h.1 h.2.1)))]
  calc (Finset.Icc 1 n).sum (fun k => (Nat.factorization k).support.sum (fun p => if p = 2 then 0 else padicValNat 2 (p - 1)))
      = (Finset.Icc 1 n).sum (fun k => (Finset.range (n + 1)).sum (fun p => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0)) := by
          refine Finset.sum_congr rfl (fun k hk => hinner k hk)
    _ = (Finset.range (n + 1)).sum (fun p => (Finset.Icc 1 n).sum (fun k => if p.Prime ∧ 2 < p ∧ p ∣ k then padicValNat 2 (p - 1) else 0)) := by
          rw [Finset.sum_comm]
    _ = (Finset.range (n + 1)).sum (fun p => if p.Prime ∧ 2 < p then padicValNat 2 (p - 1) * (n / p) else 0) := by
          refine Finset.sum_congr rfl (fun p _ => hsum_p p)
    _ = (Finset.range (n + 1)).sum (fun p => if p.Prime ∧ 2 < p ∧ p ≤ n then padicValNat 2 (p - 1) * (n / p) else 0) := by
          refine Finset.sum_congr rfl (fun p hp => ?_)
          exact if_congr (Iff.intro (fun h => And.intro h.1 (And.intro h.2 (Nat.le_of_lt_succ (Finset.mem_range.mp hp))))
            (fun h => And.intro h.1 h.2.1)) rfl rfl
    _ = (Finset.filter (fun p => p.Prime ∧ 2 < p ∧ p ≤ n) (Finset.range (n + 1))).sum (fun p => padicValNat 2 (p - 1) * (n / p)) := by
          rw [← Finset.sum_filter]
    _ = a60841_primeValSum n := rfl

theorem a60841_v2_prod_totient_eq_sums (n : Nat) (hn : 1 ≤ n) :
    padicValNat 2 ((Finset.Icc 1 n).prod (fun k => Nat.totient k)) =
      a60841_primeValSum n + a60841_twoTailSum n := by
  have h2 (k : ℕ) (hk : k ∈ Finset.Icc 1 n) :
      padicValNat 2 (Nat.totient k) =
        (if 2 ∣ k then padicValNat 2 k - 1 else 0) +
        (Nat.factorization k).support.sum (fun p => if p = 2 then 0 else padicValNat 2 (p - 1)) :=
    a60841_padicValNat_totient_eq k (Finset.mem_Icc.mp hk).1
  rw [a60841_padicValNat_prod_totient_eq_sum_totient_vals n hn,
      Finset.sum_congr rfl h2, Finset.sum_add_distrib,
      a60841_padicValNat_totient_sum_twoPart_eq_twoTail n hn,
      a60841_padicValNat_totient_sum_primePart_eq_primeValSum n hn,
      add_comm]

theorem a60841_padicVal2_gt_of_reducedGoal (n : Nat) (hn : 1 ≤ n)
    (h : a60841_reducedGoal n) :
    padicValNat 2 ((Finset.Icc 1 n).prod (fun k => Nat.totient k)) >
      padicValNat 2 ((Nat.factorial n) ^ 2) := by
  have h1 := a60841_v2_prod_totient_eq_sums n hn
  have h2 := a60841_v2_fact_sq_eq_twoTail n
  unfold a60841_reducedGoal at h
  rw [h1, h2]
  omega

def a60841_primeWeightTable : Finset (Nat × Nat) :=
  List.toFinset ([(3, 1), (5, 2), (7, 1), (11, 1), (13, 2), (17, 4),
    (19, 1), (23, 1), (29, 2), (31, 1), (37, 2), (41, 3),
    (43, 1), (47, 1), (53, 2), (59, 1), (61, 2), (67, 1),
    (71, 1), (73, 3), (79, 1), (83, 1), (89, 3), (97, 5)] :
    List (Nat × Nat))

def a60841_primeWeightSet : Finset Nat :=
  Finset.image Prod.fst a60841_primeWeightTable

def a60841_fixedPrimeSum (n : Nat) : Nat :=
  a60841_primeWeightTable.sum (fun x => x.2 * (n / x.1))

theorem a60841_primeWeightTable_spec :
    ∀ x : Nat × Nat, x ∈ a60841_primeWeightTable →
      0 < x.1 ∧ Nat.Prime x.1 ∧ 2 < x.1 ∧ x.1 ≤ 97 ∧
        padicValNat 2 (x.1 - 1) = x.2 := by
  haveI : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩
  have key : ∀ (n k m : ℕ), m ≠ 0 → ¬ 2 ∣ m → n = 2 ^ k * m → padicValNat 2 n = k := by
    intro n k m hm hd hn
    subst hn
    have hp : 0 < (2 : ℕ) ^ k := by positivity
    have hne : (2 : ℕ) ^ k * m ≠ 0 := Nat.mul_ne_zero (by positivity) hm
    have h1 : k ≤ padicValNat 2 (2 ^ k * m) :=
      (padicValNat_dvd_iff_le (p := 2) (a := 2 ^ k * m) (n := k) hne).mp (dvd_mul_right _ _)
    have hge : ¬(k.succ ≤ padicValNat 2 (2 ^ k * m)) := by
      intro h
      have hdiv : (2 : ℕ) ^ k.succ ∣ 2 ^ k * m :=
        (padicValNat_dvd_iff_le (p := 2) (a := 2 ^ k * m) (n := k.succ) hne).mpr h
      rw [Nat.pow_succ, Nat.mul_dvd_mul_iff_left hp] at hdiv
      exact hd hdiv
    exact Nat.le_antisymm (by omega) h1
  intro x hx
  have h : x = (3, 1) ∨ x = (5, 2) ∨ x = (7, 1) ∨ x = (11, 1) ∨ x = (13, 2) ∨ x = (17, 4) ∨
      x = (19, 1) ∨ x = (23, 1) ∨ x = (29, 2) ∨ x = (31, 1) ∨ x = (37, 2) ∨ x = (41, 3) ∨
      x = (43, 1) ∨ x = (47, 1) ∨ x = (53, 2) ∨ x = (59, 1) ∨ x = (61, 2) ∨ x = (67, 1) ∨
      x = (71, 1) ∨ x = (73, 3) ∨ x = (79, 1) ∨ x = (83, 1) ∨ x = (89, 3) ∨ x = (97, 5) := by
    simpa [a60841_primeWeightTable, List.mem_toFinset] using hx
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  all_goals
    refine ⟨by norm_num, by norm_num, by norm_num, by norm_num, ?_⟩
  all_goals
    first
      | exact key 2 1 1 (by decide) (by decide) (by norm_num)
      | exact key 4 2 1 (by decide) (by decide) (by norm_num)
      | exact key 6 1 3 (by decide) (by decide) (by norm_num)
      | exact key 10 1 5 (by decide) (by decide) (by norm_num)
      | exact key 12 2 3 (by decide) (by decide) (by norm_num)
      | exact key 16 4 1 (by decide) (by decide) (by norm_num)
      | exact key 18 1 9 (by decide) (by decide) (by norm_num)
      | exact key 22 1 11 (by decide) (by decide) (by norm_num)
      | exact key 28 2 7 (by decide) (by decide) (by norm_num)
      | exact key 30 1 15 (by decide) (by decide) (by norm_num)
      | exact key 36 2 9 (by decide) (by decide) (by norm_num)
      | exact key 40 3 5 (by decide) (by decide) (by norm_num)
      | exact key 42 1 21 (by decide) (by decide) (by norm_num)
      | exact key 46 1 23 (by decide) (by decide) (by norm_num)
      | exact key 52 2 13 (by decide) (by decide) (by norm_num)
      | exact key 58 1 29 (by decide) (by decide) (by norm_num)
      | exact key 60 2 15 (by decide) (by decide) (by norm_num)
      | exact key 66 1 33 (by decide) (by decide) (by norm_num)
      | exact key 70 1 35 (by decide) (by decide) (by norm_num)
      | exact key 72 3 9 (by decide) (by decide) (by norm_num)
      | exact key 78 1 39 (by decide) (by decide) (by norm_num)
      | exact key 82 1 41 (by decide) (by decide) (by norm_num)
      | exact key 88 3 11 (by decide) (by decide) (by norm_num)
      | exact key 96 5 3 (by decide) (by decide) (by norm_num)

theorem a60841_primeWeightTable_inj_fst :
    ∀ x y : Nat × Nat, x ∈ a60841_primeWeightTable →
      y ∈ a60841_primeWeightTable → x.1 = y.1 → x = y := by
  classical
  have h : ∀ x ∈ a60841_primeWeightTable, ∀ y ∈ a60841_primeWeightTable, x.1 = y.1 → x = y := by decide
  intro x y hx hy hxy
  exact h x hx y hy hxy

theorem a60841_primeWeightTable_sum_weights :
    a60841_primeWeightTable.sum Prod.snd = 43 := by
  decide

theorem a60841_primeWeightTable_ratio :
    a60841_primeWeightTable.sum
      (fun x => ((x.2 : ℚ) / (x.1 : ℚ))) ≥ ((199 : ℚ) / 100) := by
  norm_num [a60841_primeWeightTable]

theorem a60841_fixedPrimeSum_eq_set_sum (n : Nat) :
    a60841_fixedPrimeSum n =
      a60841_primeWeightSet.sum (fun p => padicValNat 2 (p - 1) * (n / p)) := by
  have hspec : ∀ x ∈ a60841_primeWeightTable, padicValNat 2 (x.1 - 1) = x.2 :=
    fun x hx => (a60841_primeWeightTable_spec x hx).2.2.2.2
  have hinj : Set.InjOn (Prod.fst : Nat × Nat → Nat)
      (a60841_primeWeightTable : Set (Nat × Nat)) :=
    fun x hx y hy h => a60841_primeWeightTable_inj_fst x y hx hy h
  show a60841_primeWeightTable.sum (fun x => x.2 * (n / x.1)) =
      (a60841_primeWeightTable.image Prod.fst).sum (fun p => padicValNat 2 (p - 1) * (n / p))
  rw [Finset.sum_image (s := a60841_primeWeightTable)
      (g := (Prod.fst : Nat × Nat → Nat)) hinj]
  apply Finset.sum_congr rfl
  intro x hx
  simp only [hspec x hx]

theorem a60841_fixedPrimeSum_le_primeValSum (n : Nat) (hn : 106 ≤ n) :
    a60841_fixedPrimeSum n ≤ a60841_primeValSum n := by
  have h97 : 97 ≤ n := by omega
  have hsub : a60841_primeWeightSet ⊆
      Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ n) (Finset.range (n + 1)) := by
    intro p hp
    have hp' : p ∈ Finset.image Prod.fst a60841_primeWeightTable := hp
    rw [Finset.mem_image] at hp'
    obtain ⟨x, hx, rfl⟩ := hp'
    have h := a60841_primeWeightTable_spec x hx
    have hle : x.1 ≤ 97 := h.2.2.2.1
    have h2 : 2 < x.1 := h.2.2.1
    have hpr : Nat.Prime x.1 := h.2.1
    rw [Finset.mem_filter, Finset.mem_range]
    exact ⟨by omega, hpr, h2, by omega⟩
  have hnonneg : ∀ i ∈ Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ n) (Finset.range (n + 1)),
      i ∉ a60841_primeWeightSet → 0 ≤ padicValNat 2 (i - 1) * (n / i) := by
    intro i hi hni
    exact Nat.zero_le (padicValNat 2 (i - 1) * (n / i))
  have hstep : a60841_primeWeightSet.sum (fun p => padicValNat 2 (p - 1) * (n / p)) ≤
      (Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ n) (Finset.range (n + 1))).sum
        (fun p => padicValNat 2 (p - 1) * (n / p)) :=
    Finset.sum_le_sum_of_subset_of_nonneg hsub hnonneg
  calc a60841_fixedPrimeSum n
      = a60841_primeWeightSet.sum (fun p => padicValNat 2 (p - 1) * (n / p)) :=
        a60841_fixedPrimeSum_eq_set_sum n
    _ ≤ (Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ n) (Finset.range (n + 1))).sum
          (fun p => padicValNat 2 (p - 1) * (n / p)) := hstep
    _ = a60841_primeValSum n := rfl

theorem a60841_nat_div_ge_rat_sub_one {d n : Nat} (hd : 0 < d) :
    ((n / d : Nat) : ℚ) ≥ (n : ℚ) / (d : ℚ) - 1 := by
  have h0 : (0 : ℚ) < (d : ℚ) := by exact_mod_cast hd
  have h1 : n = (n / d) * d + n % d := by
    rw [Nat.mul_comm]
    exact (Nat.div_add_mod n d).symm
  have hlt : n < (n / d) * d + d := calc
    n = (n / d) * d + n % d := h1
    _ < (n / d) * d + d := Nat.add_lt_add_left (Nat.mod_lt n hd) ((n / d) * d)
  have H : (n : ℚ) < ((n / d : ℕ) : ℚ) * (d : ℚ) + (d : ℚ) := by
    exact_mod_cast hlt
  have hsub : (n : ℚ) - ((n / d : ℕ) : ℚ) * (d : ℚ) ≤ (d : ℚ) := by
    refine sub_le_iff_le_add.mpr ?_
    linarith
  have hfrac : ((n : ℚ) - ((n / d : ℕ) : ℚ) * (d : ℚ)) / (d : ℚ) ≤ 1 :=
    (div_le_one h0).mpr hsub
  have hrew : ((n : ℚ) - ((n / d : ℕ) : ℚ) * (d : ℚ)) / (d : ℚ) = (n : ℚ) / (d : ℚ) - ((n / d : ℕ) : ℚ) := by
    rw [sub_div, mul_div_assoc, div_self h0.ne', mul_one]
  linarith

theorem a60841_fixedPrimeSum_rat_ge_raw (n : Nat) :
    (a60841_fixedPrimeSum n : ℚ) ≥
      (n : ℚ) * a60841_primeWeightTable.sum
        (fun x => ((x.2 : ℚ) / (x.1 : ℚ))) -
      Nat.cast (a60841_primeWeightTable.sum Prod.snd) := by
  have key : ∀ x ∈ a60841_primeWeightTable,
      ((x.2 * (n / x.1) : ℕ) : ℚ) ≥ (n : ℚ) * ((x.2 : ℚ) / (x.1 : ℚ)) - (x.2 : ℚ) := by
    intro x hx
    have hspec := a60841_primeWeightTable_spec x hx
    have hpos : 0 < x.1 := hspec.1
    have haux := a60841_nat_div_ge_rat_sub_one (d := x.1) (n := n) hpos
    have hnn : 0 ≤ (x.2 : ℚ) := Nat.cast_nonneg _
    calc ((x.2 * (n / x.1) : ℕ) : ℚ)
        = (x.2 : ℚ) * ((n / x.1 : ℕ) : ℚ) := Nat.cast_mul _ _
      _ ≥ (x.2 : ℚ) * ((n : ℚ) / (x.1 : ℚ) - 1) :=
          mul_le_mul_of_nonneg_left haux hnn
      _ = (n : ℚ) * ((x.2 : ℚ) / (x.1 : ℚ)) - (x.2 : ℚ) := by ring
  have hsum : (a60841_fixedPrimeSum n : ℚ) =
      a60841_primeWeightTable.sum (fun x => ((x.2 * (n / x.1) : ℕ) : ℚ)) := by
    rw [a60841_fixedPrimeSum, Nat.cast_sum]
  have hcalc : a60841_primeWeightTable.sum
        (fun x => (n : ℚ) * ((x.2 : ℚ) / (x.1 : ℚ)) - (x.2 : ℚ))
      = (n : ℚ) * a60841_primeWeightTable.sum (fun x => ((x.2 : ℚ) / (x.1 : ℚ)))
          - Nat.cast (a60841_primeWeightTable.sum Prod.snd) := by
    rw [Finset.sum_sub_distrib, Finset.mul_sum, ← Nat.cast_sum]
  have hle : a60841_primeWeightTable.sum
        (fun x => (n : ℚ) * ((x.2 : ℚ) / (x.1 : ℚ)) - (x.2 : ℚ))
      ≤ a60841_primeWeightTable.sum (fun x => ((x.2 * (n / x.1) : ℕ) : ℚ)) :=
      Finset.sum_le_sum fun x hx => key x hx
  rw [hsum, ← hcalc]
  exact hle

theorem a60841_fixedPrimeSum_rat_ge (n : Nat) :
    (a60841_fixedPrimeSum n : ℚ) ≥
      (n : ℚ) * ((199 : ℚ) / 100) - (43 : ℚ) := by
  have h := a60841_fixedPrimeSum_rat_ge_raw n
  have hw : (Nat.cast (a60841_primeWeightTable.sum Prod.snd) : ℚ) = (43 : ℚ) := by
    rw [a60841_primeWeightTable_sum_weights]
    norm_cast
  have hr := a60841_primeWeightTable_ratio
  have hn : 0 ≤ (n : ℚ) := Nat.cast_nonneg n
  have hmul :
      (n : ℚ) * ((199 : ℚ) / 100) ≤
        (n : ℚ) * a60841_primeWeightTable.sum (fun x => ((x.2 : ℚ) / (x.1 : ℚ))) :=
    mul_le_mul_of_nonneg_left hr hn
  rw [hw] at h
  linarith

theorem a60841_nat_half_le_rat_half (n : Nat) :
    ((n / 2 : Nat) : ℚ) ≤ (n : ℚ) / 2 := by
  have h : ((n / 2 : ℕ) : ℚ) * 2 ≤ (n : ℚ) := by
    exact_mod_cast Nat.div_mul_le_self n 2
  have h0 : (0 : ℚ) < 2 := by norm_num
  have h2 : (n : ℚ) = (n : ℚ) / 2 * 2 := by
    field_simp
  rw [h2] at h
  exact le_of_mul_le_mul_right h h0

theorem a60841_two_div_le_n (n : Nat) : 2 * (n / 2) ≤ n := by
  omega

theorem a60841_twoTailSum_le_div_two (n : Nat) :
    a60841_twoTailSum n ≤ n / 2 := by
  have shift : ∀ (L : ℕ) (g : ℕ → ℕ),
      (Finset.range (L + 1)).sum g = g 0 + (Finset.range L).sum (fun i => g (i + 1)) := by
    intro L
    induction L with
    | zero => intro g; simp
    | succ L ih =>
      intro g
      calc (Finset.range (L + 1 + 1)).sum g
          = (Finset.range (L + 1)).sum g + g (L + 1) := Finset.sum_range_succ _ _
        _ = (g 0 + (Finset.range L).sum (fun i => g (i + 1))) + g (L + 1) := by rw [ih]
        _ = g 0 + ((Finset.range L).sum (fun i => g (i + 1)) + g (L + 1)) := by rw [add_assoc]
        _ = g 0 + (Finset.range (L + 1)).sum (fun i => g (i + 1)) := by rw [Finset.sum_range_succ]
  have key : ∀ L m : ℕ, (Finset.range L).sum (fun i => m / 2 ^ (i + 1)) ≤ m := by
    intro L
    induction L with
    | zero => intro m; simp
    | succ L ih =>
      intro m
      have hsum : (Finset.range L).sum (fun i => m / 2 ^ (i + 1 + 1))
          = (Finset.range L).sum (fun i => m / 2 / 2 ^ (i + 1)) := by
        apply Finset.sum_congr rfl
        intro i _
        show m / 2 ^ (i + 1 + 1) = m / 2 / 2 ^ (i + 1)
        rw [show i + 1 + 1 = i + 2 from rfl,
          show (2 : ℕ) ^ (i + 2) = 2 * 2 ^ (i + 1) by
            rw [show i + 2 = i + 1 + 1 from rfl, Nat.pow_succ, Nat.mul_comm],
          Nat.div_div_eq_div_mul]
      have hdiv : m / 2 + m / 2 ≤ m := by
        have := Nat.div_mul_le_self m 2
        omega
      calc (Finset.range (L + 1)).sum (fun i => m / 2 ^ (i + 1))
          = m / 2 ^ 1 + (Finset.range L).sum (fun i => m / 2 ^ (i + 1 + 1)) := shift L _
        _ = m / 2 + (Finset.range L).sum (fun i => m / 2 / 2 ^ (i + 1)) := by
            rw [show m / 2 ^ 1 = m / 2 by norm_num, hsum]
        _ ≤ m / 2 + m / 2 := Nat.add_le_add (le_refl _) (ih (m / 2))
        _ ≤ m := hdiv
  show (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i) ≤ n / 2
  have hre : (Finset.Ico 2 (Nat.log 2 n + 1)).sum (fun i => n / 2 ^ i)
      = (Finset.range (Nat.log 2 n + 1 - 2)).sum (fun j => n / 2 / 2 ^ (j + 1)) := by
    rw [Finset.sum_Ico_eq_sum_range]
    apply Finset.sum_congr rfl
    intro j _
    show n / 2 ^ (2 + j) = n / 2 / 2 ^ (j + 1)
    rw [show (2 : ℕ) + j = j + 1 + 1 by omega, Nat.pow_succ, Nat.mul_comm,
      ← Nat.div_div_eq_div_mul]
  rw [hre]
  exact key (Nat.log 2 n + 1 - 2) (n / 2)

theorem a60841_fixedPrimeSum_gt_linear_rat (n : Nat) (hn : 106 ≤ n) :
    (n : ℚ) + (n : ℚ) / 2 < (a60841_fixedPrimeSum n : ℚ) := by
  have h := a60841_fixedPrimeSum_rat_ge n
  have hn' : (106 : ℚ) ≤ (n : ℚ) := by exact_mod_cast hn
  have h2 : (n : ℚ) * ((199 : ℚ) / 100) - (43 : ℚ) > (n : ℚ) + (n : ℚ) / 2 := by
    linarith
  linarith

theorem a60841_fixedPrimeSum_gt_linear (n : Nat) (hn : 106 ≤ n) :
    n + n / 2 < a60841_fixedPrimeSum n := by
  have h2 : ((n + n / 2 : ℕ) : ℚ) < (a60841_fixedPrimeSum n : ℚ) := by
    push_cast
    refine lt_of_le_of_lt ?_ (a60841_fixedPrimeSum_gt_linear_rat n hn)
    linarith [a60841_nat_half_le_rat_half n]
  exact_mod_cast h2

theorem a60841_reduced_goal_large (n : Nat) (hn : 106 ≤ n) :
    a60841_reducedGoal n := by
  unfold a60841_reducedGoal
  have h1 : 2 * (n / 2) + a60841_twoTailSum n ≤ n + n / 2 :=
    Nat.add_le_add (a60841_two_div_le_n n) (a60841_twoTailSum_le_div_two n)
  have h2 : n + n / 2 < a60841_fixedPrimeSum n := a60841_fixedPrimeSum_gt_linear n hn
  have h3 : a60841_fixedPrimeSum n ≤ a60841_primeValSum n := a60841_fixedPrimeSum_le_primeValSum n hn
  exact lt_of_le_of_lt h1 (lt_of_lt_of_le h2 h3)

theorem a60841_reduced_goal_small_69_87 (n : Nat) (h69 : 69 ≤ n) (h87 : n ≤ 87) :
    a60841_reducedGoal n := by
  have key2 : ∀ (m k : ℕ), 1 ≤ m → m ≤ 127 → padicValNat 2 m = k →
      k = (if 64 ∣ m then 6 else if 32 ∣ m then 5 else if 16 ∣ m then 4
        else if 8 ∣ m then 3 else if 4 ∣ m then 2 else if 2 ∣ m then 1 else 0) := by
    intro m k hm1 hm127 hkm
    have hn : m ≠ 0 := by omega
    have hd : ∀ j : ℕ, (2 : ℕ) ^ j ∣ m ↔ j ≤ k := by
      intro j
      rw [← hkm]
      exact Nat.pow_dvd_iff_le_padicValNat (by norm_num : (2 : ℕ) ≠ 1) hn
    have hle : k ≤ 6 := by
      by_contra hc
      have h7 : 7 ≤ k := by omega
      have h2 : (2 : ℕ) ^ 7 ∣ m := (hd 7).mpr h7
      have h3 : (128 : ℕ) ∣ m := by
        have h4 : (2 : ℕ) ^ 7 = 128 := by norm_num
        rw [← h4]
        exact h2
      have h5 : (128 : ℕ) ≤ m := Nat.le_of_dvd (by omega : 0 < m) h3
      omega
    have h6 : (64 ∣ m) ↔ (6 ≤ k) := by
      have t : (64 : ℕ) = 2 ^ 6 := by norm_num
      rw [t, hd 6]
    have h5 : (32 ∣ m) ↔ (5 ≤ k) := by
      have t : (32 : ℕ) = 2 ^ 5 := by norm_num
      rw [t, hd 5]
    have h4 : (16 ∣ m) ↔ (4 ≤ k) := by
      have t : (16 : ℕ) = 2 ^ 4 := by norm_num
      rw [t, hd 4]
    have h3 : (8 ∣ m) ↔ (3 ≤ k) := by
      have t : (8 : ℕ) = 2 ^ 3 := by norm_num
      rw [t, hd 3]
    have h2 : (4 ∣ m) ↔ (2 ≤ k) := by
      have t : (4 : ℕ) = 2 ^ 2 := by norm_num
      rw [t, hd 2]
    have h1 : (2 ∣ m) ↔ (1 ≤ k) := by
      have t : (2 : ℕ) = 2 ^ 1 := by norm_num
      rw [t, hd 1]
    interval_cases k <;> simp only [h6, h5, h4, h3, h2, h1] <;> norm_num
  have hproxy : ∀ N : ℕ, N ≤ 126 → a60841_primeValSum N =
      (Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ N) (Finset.range (N + 1))).sum
        (fun p => (if 64 ∣ p - 1 then 6 else if 32 ∣ p - 1 then 5 else if 16 ∣ p - 1 then 4
          else if 8 ∣ p - 1 then 3 else if 4 ∣ p - 1 then 2 else if 2 ∣ p - 1 then 1
            else 0) * (N / p)) := by
    intro N hN
    unfold a60841_primeValSum
    refine Finset.sum_congr rfl (fun p hp => ?_)
    have hP : Nat.Prime p ∧ 2 < p ∧ p ≤ N := (Finset.mem_filter.mp hp).2
    have h1 : 1 ≤ p - 1 := by omega
    have h2 : p - 1 ≤ 127 := by omega
    have he : padicValNat 2 (p - 1) * (N / p) =
        (if 64 ∣ p - 1 then 6 else if 32 ∣ p - 1 then 5 else if 16 ∣ p - 1 then 4
          else if 8 ∣ p - 1 then 3 else if 4 ∣ p - 1 then 2 else if 2 ∣ p - 1 then 1
            else 0) * (N / p) := by
      rw [key2 (p - 1) (padicValNat 2 (p - 1)) h1 h2 rfl]
    exact he
  have hN126 : n ≤ 126 := by omega
  have hpr := hproxy n hN126
  interval_cases n
  all_goals
    unfold a60841_reducedGoal
    rw [hpr]
    decide

theorem a60841_reduced_goal_ge_39 (n : Nat) (hn : 39 ≤ n) :
    a60841_reducedGoal n := by
  have lemmaA : ∀ k : ℕ, a60841_fixedPrimeSum k ≤ a60841_primeValSum k := by
    intro k
    have hspec : ∀ p ∈ a60841_primeWeightSet, Nat.Prime p ∧ 2 < p := by
      intro p hp
      rcases Finset.mem_image.mp hp with ⟨x, hx, rfl⟩
      have h := a60841_primeWeightTable_spec x hx
      exact ⟨h.2.1, h.2.2.1⟩
    have hsub : (a60841_primeWeightSet.filter (fun p => p ≤ k)) ⊆
        Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ k) (Finset.range (k + 1)) := by
      intro p hp
      rcases Finset.mem_filter.mp hp with ⟨hps, hle⟩
      rcases hspec p hps with ⟨hpr, h2⟩
      exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (Nat.lt_succ_of_le hle), hpr, h2, hle⟩
    have hzero :
        (a60841_primeWeightSet \ a60841_primeWeightSet.filter (fun p => p ≤ k)).sum
            (fun p => padicValNat 2 (p - 1) * (k / p)) = 0 := by
      refine Finset.sum_eq_zero ?_
      intro p hp
      rcases Finset.mem_sdiff.mp hp with ⟨hps, hn⟩
      have hgt : k < p := Nat.lt_of_not_le fun h => hn (Finset.mem_filter.mpr ⟨hps, h⟩)
      rw [Nat.div_eq_of_lt hgt, Nat.mul_zero]
    have hSsum : a60841_primeWeightSet.sum (fun p => padicValNat 2 (p - 1) * (k / p)) =
        (a60841_primeWeightSet.filter (fun p => p ≤ k)).sum
          (fun p => padicValNat 2 (p - 1) * (k / p)) := by
      rw [← Finset.sum_sdiff (Finset.filter_subset (fun p => p ≤ k) a60841_primeWeightSet), hzero,
        Nat.zero_add]
    have hmono :
        (a60841_primeWeightSet.filter (fun p => p ≤ k)).sum
            (fun p => padicValNat 2 (p - 1) * (k / p)) ≤
          (Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ k) (Finset.range (k + 1))).sum
            (fun p => padicValNat 2 (p - 1) * (k / p)) := by
      rw [← Finset.sum_sdiff hsub]
      exact Nat.le_add_left _ _
    calc a60841_fixedPrimeSum k
        = a60841_primeWeightSet.sum (fun p => padicValNat 2 (p - 1) * (k / p)) :=
          a60841_fixedPrimeSum_eq_set_sum k
      _ = (a60841_primeWeightSet.filter (fun p => p ≤ k)).sum
            (fun p => padicValNat 2 (p - 1) * (k / p)) := hSsum
      _ ≤ (Finset.filter (fun p => Nat.Prime p ∧ 2 < p ∧ p ≤ k) (Finset.range (k + 1))).sum
            (fun p => padicValNat 2 (p - 1) * (k / p)) := hmono
      _ = a60841_primeValSum k := rfl
  have hkey : ∀ m : Nat, 39 ≤ m → m ≤ 105 →
      2 * (m / 2) + a60841_twoTailSum m < a60841_fixedPrimeSum m := by
    intro m hm1 hm2
    interval_cases m <;> decide
  rcases Nat.lt_or_ge n 106 with h | h
  · show 2 * (n / 2) + a60841_twoTailSum n < a60841_primeValSum n
    exact lt_of_lt_of_le (hkey n hn (Nat.le_of_lt_succ h)) (lemmaA n)
  · exact a60841_reduced_goal_large n h

theorem a60841_padicVal2_prod_totient_gt_fact_sq_ge_39 (n : Nat) (hn : 39 ≤ n) :
    padicValNat 2 ((Finset.Icc 1 n).prod (fun k => Nat.totient k)) >
      padicValNat 2 ((Nat.factorial n) ^ 2) := by
  have h1 : 1 ≤ n := a60841_ge39_imp_ge_one n hn
  exact a60841_padicVal2_gt_of_reducedGoal n h1 (a60841_reduced_goal_ge_39 n hn)

theorem a60841_prod_totient_not_dvd_fact_sq_ge_39 (n : Nat) (h : 39 ≤ n) :
    ¬ (Finset.Icc 1 n).prod (fun k => Nat.totient k) ∣ (Nat.factorial n) ^ 2 := by
  have h1 : 1 ≤ n := a60841_ge39_imp_ge_one n h
  have ha : 0 < (Finset.Icc 1 n).prod (fun k => Nat.totient k) :=
    a60841_prod_totient_pos n h1
  have hb : 0 < (Nat.factorial n) ^ 2 := a60841_fact_sq_pos n
  have hv : padicValNat 2 ((Finset.Icc 1 n).prod (fun k => Nat.totient k)) >
      padicValNat 2 ((Nat.factorial n) ^ 2) :=
    a60841_padicVal2_prod_totient_gt_fact_sq_ge_39 n h
  exact a60841_not_dvd_of_padicValNat2_gt ha hb hv

theorem reciprocal_det_den_is_one_for_1_to_34 (n : Nat) (h1 : 1 <= n) (h2 : n <= 34) :
    (((OeisA60841.lcmMatrix n).det)⁻¹).den = 1 := by
  rw [lcmMatrix_det_inv_den_eq_one_iff_divisibility n h1]
  exact a60841_prod_totient_dvd_fact_sq_on_1_to_34 n h1 h2

theorem reciprocal_det_den_is_one_for_36 :
    (((OeisA60841.lcmMatrix 36).det)⁻¹).den = 1 := by
  have hpos : 1 ≤ (36 : Nat) := by decide
  have hdiv : (Finset.Icc 1 36).prod (fun k => Nat.totient k) ∣ (Nat.factorial 36) ^ 2 :=
    a60841_prod_totient_dvd_fact_sq_36
  exact (lcmMatrix_det_inv_den_eq_one_iff_divisibility 36 hpos).mpr hdiv

theorem reciprocal_det_den_is_one_for_38 :
    (((OeisA60841.lcmMatrix 38).det)⁻¹).den = 1 := by
  have h1 : 1 ≤ (38 : Nat) := by decide
  exact (lcmMatrix_det_inv_den_eq_one_iff_divisibility 38 h1).mpr
    a60841_prod_totient_dvd_fact_sq_38

theorem not_reciprocal_det_den_is_one_for_35 :
    ¬ (((OeisA60841.lcmMatrix 35).det)⁻¹).den = 1 := by
  intro h
  have hI : 1 ≤ (35 : Nat) := by decide
  refine a60841_prod_totient_not_dvd_fact_sq_35 ?_
  exact (lcmMatrix_det_inv_den_eq_one_iff_divisibility 35 hI).mp h

theorem not_reciprocal_det_den_is_one_for_37 :
    ¬ (((OeisA60841.lcmMatrix 37).det)⁻¹).den = 1 := by
  intro h
  have hdiv : (Finset.Icc 1 37).prod (fun k => Nat.totient k) ∣ (Nat.factorial 37) ^ 2 :=
    (lcmMatrix_det_inv_den_eq_one_iff_divisibility 37 (by decide)).mp h
  exact a60841_prod_totient_not_dvd_fact_sq_37 hdiv

theorem not_reciprocal_det_den_is_one_for_ge_39 (n : Nat) (h : 39 <= n) :
    ¬ (((OeisA60841.lcmMatrix n).det)⁻¹).den = 1 := by
  intro hd
  have hn : 1 ≤ n := a60841_ge39_imp_ge_one n h
  have H := (lcmMatrix_det_inv_den_eq_one_iff_divisibility n hn).mp hd
  exact a60841_prod_totient_not_dvd_fact_sq_ge_39 n h H
theorem ga_target_5e67b0763c763225 : ∀ (n : Nat),
  @LE.le.{0} Nat instLENat (@OfNat.ofNat.{0} Nat (nat_lit 1) (instOfNatNat (nat_lit 1))) n →
    Iff
      (@Eq.{1} Nat
        (@Inv.inv.{0} Rat Rat.instInv
            (@Matrix.det.{0, 0} (Fin n) (instDecidableEqFin n) (Fin.fintype n) Rat Rat.commRing
              (OeisA60841.lcmMatrix n))).den
        (@OfNat.ofNat.{0} Nat (nat_lit 1) (instOfNatNat (nat_lit 1))))
      (@Membership.mem.{0, 0} Nat (Set.{0} Nat) (@Set.instMembership.{0} Nat) OeisA60841.integerDetN n) := by
  intro n hn
  have hden : (((OeisA60841.lcmMatrix n).det)⁻¹).den = 1 ↔ n ≤ 34 ∨ n = 36 ∨ n = 38 := by
    constructor
    · intro h
      by_cases h34 : n ≤ 34
      · exact Or.inl h34
      · have h39 : 39 ≤ n ∨ n = 35 ∨ n = 36 ∨ n = 37 ∨ n = 38 := by omega
        rcases h39 with hge | rfl | heq36 | rfl | heq38
        · exact absurd h (not_reciprocal_det_den_is_one_for_ge_39 n hge)
        · exact absurd h not_reciprocal_det_den_is_one_for_35
        · exact Or.inr (Or.inl heq36)
        · exact absurd h not_reciprocal_det_den_is_one_for_37
        · exact Or.inr (Or.inr heq38)
    · intro h
      rcases h with hle | rfl | rfl
      · exact reciprocal_det_den_is_one_for_1_to_34 n hn hle
      · exact reciprocal_det_den_is_one_for_36
      · exact reciprocal_det_den_is_one_for_38
  have hchar : (n ∈ OeisA60841.integerDetN) ↔ n ≤ 34 ∨ n = 36 ∨ n = 38 :=
    (in_a60841_integer_det_set_def_iff n).symm.trans (in_a60841_integer_det_set_characterization n hn)
  exact Iff.trans hden hchar.symm
#ga_audit_proof in_a60841_integer_det_set_def_iff
#ga_audit_proof in_a60841_integer_det_set_characterization
#ga_audit_proof a60841_factorial_pos
#ga_audit_proof a60841_fact_sq_pos
#ga_audit_proof a60841_prod_totient_pos
#ga_audit_proof a60841_rat_div_inv_den_eq_one_iff_div
#ga_audit_proof a60841_prod_fin_totient_eq_Icc_prod_totient
#ga_audit_proof a60841_prod_fin_inv_factorial
#ga_audit_proof a60841_lcmMatrix_eq_scaled_gcd_matrix
#ga_audit_proof a60841_gcdMatrix_factorization
#ga_audit_proof a60841_divisibilityMatrix_det_one
#ga_audit_proof a60841_divisibilityMatrixTranspose_det_one
#ga_audit_proof a60841_diag_totient_det
#ga_audit_proof a60841_diag_inv_factorial_det
#ga_audit_proof a60841_gcdMatrix_det
#ga_audit_proof a60841_det_lcm_eq_inv_fact_mul_totient_mul_inv_fact
#ga_audit_proof a60841_inv_fact_mul_totient_mul_inv_fact_eq_div
#ga_audit_proof lcmMatrix_det_eq_prod_totient_div_factorial_sq
#ga_audit_proof lcmMatrix_det_inv_den_eq_one_iff_divisibility
#ga_audit_proof a60841_prod_totient_dvd_fact_sq_on_1_to_34
#ga_audit_proof a60841_prod_totient_dvd_fact_sq_36
#ga_audit_proof a60841_prod_totient_dvd_fact_sq_38
#ga_audit_proof a60841_prod_totient_not_dvd_fact_sq_35
#ga_audit_proof a60841_prod_totient_not_dvd_fact_sq_37
#ga_audit_proof a60841_ge39_imp_ge_one
#ga_audit_proof a60841_not_dvd_of_padicValNat2_gt
#ga_audit_proof a60841_padicValNat_fact_val_two_eq_sum_div
#ga_audit_proof a60841_twoTailSum_split_one
#ga_audit_proof a60841_padicValNat_fact_eq_twoTail
#ga_audit_proof a60841_padicValNat_fact_sq_eq_two
#ga_audit_proof a60841_v2_fact_sq_eq_twoTail
#ga_audit_proof a60841_padicValNat_prod_totient_eq_sum_totient_vals
#ga_audit_proof a60841_padicValNat_totient_eq
#ga_audit_proof a60841_padicValNat_totient_sum_twoPart_eq_twoTail
#ga_audit_proof a60841_padicValNat_totient_sum_primePart_eq_primeValSum
#ga_audit_proof a60841_v2_prod_totient_eq_sums
#ga_audit_proof a60841_padicVal2_gt_of_reducedGoal
#ga_audit_proof a60841_primeWeightTable_spec
#ga_audit_proof a60841_primeWeightTable_inj_fst
#ga_audit_proof a60841_primeWeightTable_sum_weights
#ga_audit_proof a60841_primeWeightTable_ratio
#ga_audit_proof a60841_fixedPrimeSum_eq_set_sum
#ga_audit_proof a60841_fixedPrimeSum_le_primeValSum
#ga_audit_proof a60841_nat_div_ge_rat_sub_one
#ga_audit_proof a60841_fixedPrimeSum_rat_ge_raw
#ga_audit_proof a60841_fixedPrimeSum_rat_ge
#ga_audit_proof a60841_nat_half_le_rat_half
#ga_audit_proof a60841_two_div_le_n
#ga_audit_proof a60841_twoTailSum_le_div_two
#ga_audit_proof a60841_fixedPrimeSum_gt_linear_rat
#ga_audit_proof a60841_fixedPrimeSum_gt_linear
#ga_audit_proof a60841_reduced_goal_large
#ga_audit_proof a60841_reduced_goal_small_69_87
#ga_audit_proof a60841_reduced_goal_ge_39
#ga_audit_proof a60841_padicVal2_prod_totient_gt_fact_sq_ge_39
#ga_audit_proof a60841_prod_totient_not_dvd_fact_sq_ge_39
#ga_audit_proof reciprocal_det_den_is_one_for_1_to_34
#ga_audit_proof reciprocal_det_den_is_one_for_36
#ga_audit_proof reciprocal_det_den_is_one_for_38
#ga_audit_proof not_reciprocal_det_den_is_one_for_35
#ga_audit_proof not_reciprocal_det_den_is_one_for_37
#ga_audit_proof not_reciprocal_det_den_is_one_for_ge_39
#ga_audit_proof ga_target_5e67b0763c763225
#ga_audit_target ga_target_5e67b0763c763225 against OeisA60841.conjecture1
