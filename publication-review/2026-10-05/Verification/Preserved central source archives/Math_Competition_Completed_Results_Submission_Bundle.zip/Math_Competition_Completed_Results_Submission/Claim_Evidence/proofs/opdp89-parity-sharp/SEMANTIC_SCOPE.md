# Recovered semantic-scope summary

This is a regenerated summary of the scope confirmed during independent review before workspace replacement. It is not the original local audit report.

The actual formal definitions use sixteen four-spin states, dataMass=(1+rho*parity)/16, positive normalized modelMass, and proved equality with summation over the hidden spin. The objective is data-weighted log normalized probability. Parameters contains all nine real parameters.

The final endpoint ParityFour.sharp_parity_classification assumes exactly 0 < |rho| <= 1 and arbitrary c0 in R. It establishes:

- A zero derivative along every affine parameter direction at the collapsed point
- IsLocalMax if and only if tanh(c0)^2 < (3+2|rho|)/(3+6|rho|)
- At equality and outside: strictly larger and strictly smaller objective values in every full parameter neighborhood
- Existence of a strictly better finite RBM parameter point
- Distinct equal-likelihood parameter points in every neighborhood

ParameterSaddle is defined by both strict-sign neighborhood conditions. The separate all-direction derivative statement supplies stationarity. The proof does not replace the model by an unconstrained family of visible distributions or assume a Taylor remainder. It proves finite-state fourth derivatives and obtains exterior ascent by successive mean-value arguments; the equality case follows by topology along the constant-objective fiber.

The scope excludes higher-dimensional/four-wise-uniform extensions, additional hidden units, arbitrary data, EM dynamics, attraction basins, training-time guarantees and distribution-local maximality. Novelty and contest credit are not determined by this verification.
