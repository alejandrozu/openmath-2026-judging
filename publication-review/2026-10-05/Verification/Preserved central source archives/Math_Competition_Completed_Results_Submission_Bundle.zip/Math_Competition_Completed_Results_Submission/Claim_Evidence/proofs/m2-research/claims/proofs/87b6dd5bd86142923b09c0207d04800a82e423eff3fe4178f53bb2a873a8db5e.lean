import Mathlib
import Lean
import FormalConjectures.OEIS.«7406»

set_option google.answer "postpone"

-- Already imported, audited repository definitions (do not redeclare):
-- def OeisA7406.a : ℕ → ℕ := fun n => (∑ k ∈ Finset.Icc 1 n, 1 / ↑k ^ 2).num.natAbs
-- 
-- def OeisA89026.a : ℕ → ℕ := fun n => if Nat.Prime n then n else 1

namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit

theorem a7406_bridge (m : Nat) :
    OeisA7406.a m =
      (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)).num.natAbs := by
  rfl

theorem a7406_clear_denom_dvd {p : Nat} [Fact (Nat.Prime p)] (r : ℚ) (N D : Nat)
    (hD : D ≠ 0) (hcop : Nat.Coprime p D) (hN : p ∣ N)
    (hr : r = (N : ℚ) / (D : ℚ)) : p ∣ r.num.natAbs := by
  have hp : Nat.Prime p := Fact.out
  have h1 : (r.num : ℚ) / (r.den : ℚ) = (N : ℚ) / (D : ℚ) := by
    rw [Rat.num_div_den, hr]
  have hden : (r.den : ℚ) ≠ 0 := by
    exact_mod_cast (Rat.den_pos r).ne'
  have hDq : (D : ℚ) ≠ 0 := by
    exact_mod_cast hD
  have h2 : (r.num : ℚ) * (D : ℚ) = (N : ℚ) * (r.den : ℚ) :=
    (div_eq_div_iff hden hDq).mp h1
  have h3 : (r.num : ℤ) * (D : ℤ) = (N : ℤ) * (r.den : ℤ) := by
    exact_mod_cast h2
  have h4 : r.num.natAbs * D = N * r.den := by
    have hz := congrArg Int.natAbs h3
    simpa only [Int.natAbs_mul, Int.natAbs_natCast] using hz
  have h5 : p ∣ r.num.natAbs * D := by
    rw [h4]
    exact hN.mul_right r.den
  cases hp.dvd_mul.mp h5 with
  | inl h => exact h
  | inr h => exact absurd h ((Nat.Prime.coprime_iff_not_dvd hp).mp hcop)

theorem a7406_sum_pos {m : Nat} (hm : 1 ≤ m) :
    0 < ∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2) := by
  have h1 : (1 : ℕ) ∈ Finset.Icc 1 m := Finset.mem_Icc.mpr ⟨by norm_num, hm⟩
  have hnonneg : ∀ k ∈ Finset.Icc (1 : ℕ) m, 0 ≤ (1 : ℚ) / ((k : ℚ) ^ 2) := by
    intro k hk
    have hk1 : (1 : ℚ) ≤ (k : ℚ) := by
      rw [Finset.mem_Icc] at hk
      exact_mod_cast hk.1
    positivity
  have hle : (1 : ℚ) / ((1 : ℚ) ^ 2) ≤ ∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2) :=
    Finset.single_le_sum hnonneg h1
  have hpos : 0 < (1 : ℚ) / ((1 : ℚ) ^ 2) := by norm_num
  exact lt_of_lt_of_le hpos hle

theorem rational_dvd_num_iff_padicValRat_pos
    {p : Nat} [Fact (Nat.Prime p)] {r : ℚ} (hr : 0 < r) :
    p ∣ r.num.natAbs ↔ 0 < padicValRat p r := by
  have hp : p.Prime := Fact.out
  have hnpos : 0 < r.num := Rat.num_pos.mpr hr
  have hnum0 : r.num.natAbs ≠ 0 := by
    rintro h
    have := Int.natAbs_eq_zero.mp h
    linarith
  have hcop : Nat.gcd r.num.natAbs r.den = 1 := Rat.reduced r
  have hden0 : r.den ≠ 0 := Nat.pos_iff_ne_zero.mp (Rat.den_pos r)
  have heq : padicValRat p r = (padicValNat p r.num.natAbs : ℤ) - (padicValNat p r.den : ℤ) := rfl
  constructor
  · intro hvd
    have h1 : (padicValNat p r.num.natAbs : ℤ) ≥ 1 := by
      exact_mod_cast one_le_padicValNat_of_dvd hnum0 hvd
    have h2 : (padicValNat p r.den : ℤ) = 0 := by
      have hnd : ¬ p ∣ r.den := by
        intro hd
        have h' : p ∣ Nat.gcd r.num.natAbs r.den := Nat.dvd_gcd hvd hd
        rw [hcop] at h'
        exact hp.ne_one (Nat.dvd_one.mp h')
      rw [padicValNat.eq_zero_of_not_dvd hnd]
      simp
    rw [heq, h2]
    linarith
  · intro hpos
    by_contra hnd
    have h1 : (padicValNat p r.num.natAbs : ℤ) = 0 := by
      rw [padicValNat.eq_zero_of_not_dvd hnd]
      simp
    rw [heq, h1] at hpos
    have h2 : (0 : ℤ) ≤ (padicValNat p r.den : ℤ) := by exact_mod_cast Nat.zero_le _
    linarith

theorem a7406_dvd_iff_padicValRat_pos
    {p m : Nat} [Fact (Nat.Prime p)] (hm : 1 ≤ m) :
    p ∣ OeisA7406.a m ↔
      0 < padicValRat p (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)) := by
  rw [a7406_bridge]
  exact rational_dvd_num_iff_padicValRat_pos (a7406_sum_pos hm)

theorem a7406_nat_cast_zero_dvd {p : Nat} [Fact (Nat.Prime p)] {N : Nat}
    (h : (N : ZMod p) = 0) : p ∣ N := by
  exact (ZMod.natCast_eq_zero_iff N p).mp h

theorem a7406_not_dvd_of_padicValRat_nonpos
    {p m : Nat} [Fact (Nat.Prime p)] (hm : 1 ≤ m)
    (h : padicValRat p (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)) ≤ 0) :
    ¬ p ∣ OeisA7406.a m := by
  intro hdvd
  have hpos : 0 < padicValRat p (∑ k ∈ Finset.Icc 1 m, (1 : ℚ) / ((k : ℚ) ^ 2)) :=
    (a7406_dvd_iff_padicValRat_pos hm).mp hdvd
  linarith

theorem a7406_zmod_Icc_image_eq_units {p : Nat} [Fact (Nat.Prime p)] :
    (Finset.Icc 1 (p - 1)).image (fun k : Nat => (k : ZMod p)) =
      (Finset.univ : Finset (ZMod p)).erase 0 := by
  have hp : 0 < p := (Fact.out (p := Nat.Prime p)).pos
  apply Finset.ext
  intro x
  simp only [Finset.mem_image, Finset.mem_Icc, Finset.mem_erase, Finset.mem_univ, false_or,
    true_and, and_true]
  constructor
  · rintro ⟨k, ⟨h1, h2⟩, rfl⟩
    have hlt : k < p := by omega
    intro h
    have hval := congrArg ZMod.val h
    rw [ZMod.val_zero, ZMod.val_natCast p k, Nat.mod_eq_of_lt hlt] at hval
    omega
  · intro hx
    have hlt := ZMod.val_lt x
    have hne : x.val ≠ 0 := by
      intro h
      exact hx ((ZMod.val_eq_zero x).1 h)
    refine ⟨x.val, ⟨Nat.pos_of_ne_zero hne, by omega⟩, ?_⟩
    simpa using (ZMod.natCast_val (R := ZMod p) x)

theorem a7406_zmod_units_sum_sq_zero {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 = 0 := by
  -- 2 and 3 are nonzero in ZMod p since p > 3
  have h2n : (2 : ZMod p) ≠ 0 := by
    intro hc
    have hd : p ∣ 2 := (ZMod.natCast_eq_zero_iff (2 : ℕ) p).mp hc
    have := Nat.le_of_dvd (by decide : (0 : Nat) < 2) hd
    omega
  have h3n : (3 : ZMod p) ≠ 0 := by
    intro hc
    have hd : p ∣ 3 := (ZMod.natCast_eq_zero_iff (3 : ℕ) p).mp hc
    have := Nat.le_of_dvd (by decide : (0 : Nat) < 3) hd
    omega
  -- multiplication by 2 is injective on the nonzero elements, and maps them into nonzero elements
  have inj : Set.InjOn (fun x : ZMod p => (2 : ZMod p) * x)
      ((Finset.univ : Finset (ZMod p)).erase 0 : Set (ZMod p)) := by
    intro x _ y _ he
    exact mul_left_cancel₀ h2n he
  have hsub : ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x) ⊆
      (Finset.univ : Finset (ZMod p)).erase 0 := by
    rw [Finset.image_subset_iff]
    intro x hx
    simp only [Finset.mem_erase, Finset.mem_univ, and_true] at hx ⊢
    exact mul_ne_zero h2n hx
  have hcard : (((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x)).card =
      ((Finset.univ : Finset (ZMod p)).erase 0).card := Finset.card_image_of_injOn inj
  have himg : ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x) =
      (Finset.univ : Finset (ZMod p)).erase 0 :=
    Finset.eq_of_subset_of_card_le hsub (Nat.le_of_eq hcard.symm)
  -- the sum is invariant under x ↦ 2*x
  have e1 : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2
      = ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x), x ^ 2 :=
    (by rw [himg] :
      ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x), x ^ 2
        = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2).symm
  have e2 : ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x => (2 : ZMod p) * x), x ^ 2
      = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, ((2 : ZMod p) * x) ^ 2 :=
    Finset.sum_image inj
  have h3 : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, ((2 : ZMod p) * x) ^ 2
      = (2 : ZMod p) ^ 2 * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 := by
    rw [Finset.sum_congr rfl (fun x _ => mul_pow (2 : ZMod p) x 2), ← Finset.mul_sum]
  have hT : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2
      = (2 : ZMod p) ^ 2 * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 :=
    e1.trans (e2.trans h3)
  -- hence 3 * S = 0, and 3 ≠ 0 in ZMod p
  have hzero : (3 : ZMod p) * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 = 0 := by
    have h : ((2 : ZMod p) ^ 2 - 1) * ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 = 0 := by
      rw [sub_mul, one_mul, ← hT]
      exact sub_self _
    rwa [show ((2 : ZMod p) ^ 2 - 1 : ZMod p) = (3 : ZMod p) from by norm_num] at h
  rcases mul_eq_zero.mp hzero with hc | hc
  · exact absurd hc h3n
  · exact hc

theorem a7406_zmod_Icc_inv_sq_sum_zero {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    ∑ k ∈ Finset.Icc 1 (p - 1), ((k : ZMod p)⁻¹) ^ 2 = 0 := by
  have ninj : ∀ a b : ℕ, a < p → b < p → (a : ZMod p) = (b : ZMod p) → a = b := by
    intro a b ha hb hab
    have h : a % p = b % p := by
      have h2 := congrArg ZMod.val hab
      rwa [ZMod.val_natCast p a, ZMod.val_natCast p b] at h2
    rwa [Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb] at h
  have hinj : Set.InjOn (fun k : ℕ => (k : ZMod p)) (Finset.Icc 1 (p - 1)) := by
    intro a ha b hb hab
    simp only [Finset.mem_coe, Finset.mem_Icc] at ha hb
    refine ninj a b (Nat.lt_of_le_of_lt ha.2 (Nat.sub_lt (by omega) (by omega)))
      (Nat.lt_of_le_of_lt hb.2 (Nat.sub_lt (by omega) (by omega))) hab
  have A : ∑ k ∈ Finset.Icc 1 (p - 1), ((k : ZMod p)⁻¹) ^ 2
      = ∑ x ∈ (Finset.Icc 1 (p - 1)).image (fun k : ℕ => (k : ZMod p)), x⁻¹ ^ 2 :=
    (Finset.sum_image (f := fun x : ZMod p => x⁻¹ ^ 2)
      (g := fun k : ℕ => (k : ZMod p))
      (s := Finset.Icc 1 (p - 1)) hinj).symm
  have e1 : (Finset.Icc 1 (p - 1)).image (fun k : ℕ => (k : ZMod p)) =
      (Finset.univ : Finset (ZMod p)).erase 0 := a7406_zmod_Icc_image_eq_units
  have B : ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x⁻¹ ^ 2
      = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 := by
    have hinv : Set.InjOn (fun x : ZMod p => x⁻¹) ((Finset.univ : Finset (ZMod p)).erase 0) := by
      intro a _ b _ hab
      have := congrArg (fun y : ZMod p => y⁻¹) hab
      rwa [inv_inv, inv_inv] at this
    have himg : ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x : ZMod p => x⁻¹)
        = (Finset.univ : Finset (ZMod p)).erase 0 := by
      apply Finset.ext
      intro x
      simp only [Finset.mem_image, Finset.mem_erase, Finset.mem_univ, and_true, true_and]
      constructor
      · rintro ⟨y, hy, rfl⟩
        exact inv_ne_zero hy
      · intro hx
        exact ⟨x⁻¹, inv_ne_zero hx, inv_inv x⟩
    calc ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x⁻¹ ^ 2
        = ∑ x ∈ ((Finset.univ : Finset (ZMod p)).erase 0).image (fun x : ZMod p => x⁻¹), x ^ 2 :=
          (Finset.sum_image (f := fun x : ZMod p => x ^ 2) (g := fun x : ZMod p => x⁻¹)
            (s := (Finset.univ : Finset (ZMod p)).erase 0) hinv).symm
      _ = ∑ x ∈ (Finset.univ : Finset (ZMod p)).erase 0, x ^ 2 := by rw [himg]
  rw [A, e1, B]
  exact a7406_zmod_units_sum_sq_zero h

theorem a7406_prime_clear_denom_ne_zero {p : Nat} :
    (∏ k ∈ Finset.Icc 1 (p - 1), k ^ 2) ≠ 0 := by
  apply Finset.prod_ne_zero_iff.mpr
  intro k hk
  have h1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
  have h2 : 0 < k := by omega
  have h3 : 0 < k ^ 2 := pow_pos h2 2
  exact Nat.ne_of_gt h3

theorem a7406_prime_clear_denom_coprime {p : Nat} [Fact (Nat.Prime p)] :
    Nat.Coprime p (∏ k ∈ Finset.Icc 1 (p - 1), k ^ 2) := by
  have pp : p.Prime := Fact.out
  have hp1 : 1 < p := pp.one_lt
  refine Nat.Coprime.prod_right (fun k hk => ?_)
  have hk1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
  have hkm : k ≤ p - 1 := (Finset.mem_Icc.mp hk).2
  have hpos : 0 < k := hk1
  have hnd : ¬ p ∣ k := by
    intro hd
    have hle : p ≤ k := Nat.le_of_dvd hpos hd
    omega
  have hc : p.Coprime k := (pp.coprime_iff_not_dvd).mpr hnd
  exact Nat.Coprime.pow_right 2 hc

theorem a7406_prime_clear_denom_eq {p : Nat} :
    (∑ k ∈ Finset.Icc 1 (p - 1), (1 : ℚ) / ((k : ℚ) ^ 2)) =
      (((∑ k ∈ Finset.Icc 1 (p - 1),
          ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2) / k ^ 2) : Nat) : ℚ) /
        ((∏ k ∈ Finset.Icc 1 (p - 1), k ^ 2 : Nat) : ℚ)) := by
  have hPpos : (0 : ℕ) < ∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2 := by
    refine Finset.prod_pos ?_
    intro j hj
    have h1 : 1 ≤ j := (Finset.mem_Icc.mp hj).1
    nlinarith
  have hPne : ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2 : ℕ) : ℚ) ≠ 0 :=
    Nat.cast_ne_zero.mpr (Nat.pos_iff_ne_zero.mp hPpos)
  have key : ∀ k ∈ Finset.Icc 1 (p - 1),
      ((((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2) / k ^ 2 : ℕ) : ℚ) /
        ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2 : ℕ) : ℚ)) = (1 : ℚ) / ((k : ℚ) ^ 2) := by
    intro k hk
    have hd : k ^ 2 ∣ ∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2 :=
      Finset.dvd_prod_of_mem (fun j => j ^ 2) hk
    have hk1 : 1 ≤ k := (Finset.mem_Icc.mp hk).1
    have hk0 : (0 : ℕ) < k := by omega
    have hb : (k : ℚ) ≠ 0 := Nat.cast_ne_zero.mpr (Nat.pos_iff_ne_zero.mp hk0)
    have hb2 : (k : ℚ) ^ 2 ≠ 0 := pow_ne_zero 2 hb
    have hmul : (((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2) / k ^ 2 : ℕ) : ℚ) * (k : ℚ) ^ 2 =
        ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2 : ℕ) : ℚ) := by
      exact_mod_cast Nat.div_mul_cancel hd
    rw [div_eq_div_iff hPne hb2, one_mul]
    exact hmul
  rw [Nat.cast_sum, Finset.sum_div]
  refine Finset.sum_congr rfl (fun k hk => ?_)
  exact (key k hk).symm

theorem a7406_prime_clear_denom_num_cast_zero {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    ((∑ k ∈ Finset.Icc 1 (p - 1),
        ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2) / k ^ 2) : Nat) : ZMod p) = 0 := by
  classical
  set P := ∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2 with hP
  have hcast : ((∑ k ∈ Finset.Icc 1 (p - 1), P / k ^ 2 : ℕ) : ZMod p) =
      ∑ k ∈ Finset.Icc 1 (p - 1), ((P / k ^ 2 : ℕ) : ZMod p) := by
    push_cast
    rfl
  have hnz : ∀ k ∈ Finset.Icc 1 (p - 1), (k : ZMod p) ≠ 0 := by
    intro k hk
    have himg : (k : ZMod p) ∈ (Finset.Icc 1 (p - 1)).image (fun x : Nat => (x : ZMod p)) :=
      Finset.mem_image_of_mem _ hk
    rw [a7406_zmod_Icc_image_eq_units] at himg
    exact (Finset.mem_erase.mp himg).1
  have hdiv : ∀ k ∈ Finset.Icc 1 (p - 1), k ^ 2 ∣ P := by
    intro k hk
    rw [hP]
    exact Finset.dvd_prod_of_mem (fun j => j ^ 2) hk
  have hterm : ∀ k ∈ Finset.Icc 1 (p - 1),
      ((P / k ^ 2 : ℕ) : ZMod p) = (P : ZMod p) * ((k : ZMod p)⁻¹) ^ 2 := by
    intro k hk
    have hz := hnz k hk
    have hd := hdiv k hk
    have hmul : ((P / k ^ 2 : ℕ) : ZMod p) * (k : ZMod p) ^ 2 = (P : ZMod p) := by
      rw [← Nat.cast_pow, ← Nat.cast_mul, Nat.div_mul_cancel hd]
    have hinv : (k : ZMod p) ^ 2 * ((k : ZMod p)⁻¹) ^ 2 = 1 := by
      rw [← mul_pow]
      field_simp [hz]
    calc ((P / k ^ 2 : ℕ) : ZMod p)
        = ((P / k ^ 2 : ℕ) : ZMod p) * 1 := by rw [mul_one]
      _ = ((P / k ^ 2 : ℕ) : ZMod p) * ((k : ZMod p) ^ 2 * ((k : ZMod p)⁻¹) ^ 2) := by rw [hinv]
      _ = (((P / k ^ 2 : ℕ) : ZMod p) * (k : ZMod p) ^ 2) * ((k : ZMod p)⁻¹) ^ 2 := by rw [mul_assoc]
      _ = (P : ZMod p) * ((k : ZMod p)⁻¹) ^ 2 := by rw [hmul]
  have hsum : ∑ k ∈ Finset.Icc 1 (p - 1), ((P / k ^ 2 : ℕ) : ZMod p) =
      ∑ k ∈ Finset.Icc 1 (p - 1), (P : ZMod p) * ((k : ZMod p)⁻¹) ^ 2 :=
    Finset.sum_congr rfl hterm
  rw [hcast, hsum, ← Finset.mul_sum]
  rw [a7406_zmod_Icc_inv_sq_sum_zero h]
  exact mul_zero _

theorem a7406_prime_clear_denom_num_dvd {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    p ∣ ∑ k ∈ Finset.Icc 1 (p - 1),
        ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2) / k ^ 2) := by
  exact a7406_nat_cast_zero_dvd (a7406_prime_clear_denom_num_cast_zero h)

theorem a7406_prime_inv_sq_num_dvd {p : Nat} [Fact (Nat.Prime p)] (h : 3 < p) :
    p ∣ (∑ k ∈ Finset.Icc 1 (p - 1), (1 : ℚ) / ((k : ℚ) ^ 2)).num.natAbs := by
  have hD : (∏ k ∈ Finset.Icc 1 (p - 1), k ^ 2) ≠ 0 := a7406_prime_clear_denom_ne_zero
  have hcop : Nat.Coprime p (∏ k ∈ Finset.Icc 1 (p - 1), k ^ 2) :=
    a7406_prime_clear_denom_coprime
  have hN : p ∣ ∑ k ∈ Finset.Icc 1 (p - 1),
      ((∏ j ∈ Finset.Icc 1 (p - 1), j ^ 2) / k ^ 2) :=
    a7406_prime_clear_denom_num_dvd h
  exact a7406_clear_denom_dvd _ _ _ hD hcop hN a7406_prime_clear_denom_eq

theorem a7406_prime_num_sum_divisible :
  ∀ (p : Nat), Nat.Prime p → 3 < p → p ∣ OeisA7406.a (p - 1) := by
  intro p hp h3
  haveI : Fact (Nat.Prime p) := ⟨hp⟩
  rw [a7406_bridge]
  exact a7406_prime_inv_sq_num_dvd h3

theorem gcd_prime_left_eq_self_of_dvd :
  ∀ (p a : Nat), Nat.Prime p → p ∣ a → Nat.gcd p a = p := by
  intro p a hp h
  exact Nat.dvd_antisymm (Nat.gcd_dvd_left p a) (Nat.dvd_gcd (Nat.dvd_refl p) h)

theorem a7406_prime_case_gcd :
  ∀ (p : Nat), Nat.Prime p → 3 < p →
    Nat.gcd p (OeisA7406.a (p - 1)) = p := by
  intro p hp h3
  exact gcd_prime_left_eq_self_of_dvd p (OeisA7406.a (p - 1)) hp
    (a7406_prime_num_sum_divisible p hp h3)

theorem prime_two_three_or_gt_three {p : Nat} (hp : Nat.Prime p) :
    p = 2 ∨ p = 3 ∨ 3 < p := by
  have h : 2 ≤ p := Nat.Prime.two_le hp
  omega

#ga_audit_proof a7406_bridge
#ga_audit_proof a7406_clear_denom_dvd
#ga_audit_proof a7406_sum_pos
#ga_audit_proof rational_dvd_num_iff_padicValRat_pos
#ga_audit_proof a7406_dvd_iff_padicValRat_pos
#ga_audit_proof a7406_nat_cast_zero_dvd
#ga_audit_proof a7406_not_dvd_of_padicValRat_nonpos
#ga_audit_proof a7406_zmod_Icc_image_eq_units
#ga_audit_proof a7406_zmod_units_sum_sq_zero
#ga_audit_proof a7406_zmod_Icc_inv_sq_sum_zero
#ga_audit_proof a7406_prime_clear_denom_ne_zero
#ga_audit_proof a7406_prime_clear_denom_coprime
#ga_audit_proof a7406_prime_clear_denom_eq
#ga_audit_proof a7406_prime_clear_denom_num_cast_zero
#ga_audit_proof a7406_prime_clear_denom_num_dvd
#ga_audit_proof a7406_prime_inv_sq_num_dvd
#ga_audit_proof a7406_prime_num_sum_divisible
#ga_audit_proof gcd_prime_left_eq_self_of_dvd
#ga_audit_proof a7406_prime_case_gcd
#ga_audit_proof prime_two_three_or_gt_three
