import OpHack.Erdos944Graph
import CriticalCodeBound

/-! Explicit necessary order bounds for the still-open r≥2 portion of Erdős #944.
This is a partial obstruction theorem, not an existence construction or full solution.
The criticality definitions exactly match the current Formal Conjectures 944 source. -/
namespace Erdos944Bounds
open Finset
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V)

/-- Graph hypotheses supply every premise of the finite-code counting theorem. -/
theorem code_parameters [Nonempty V] {s : ℕ} (hs : 2 ≤ s)
    (hr : EdgeRobust G s) (hvcrit : ∀ v, ∃ c, ProperExcept G v c) :
    ∃ a h : ℕ, Fintype.card V = a + h ∧ 0 < a ∧
      Fintype.card V - 1 ≤ 3*a ∧ 9*a*s ≤ (2*a+1)*h := by
  classical
  obtain ⟨A,hA,ha,hlarge⟩ := exists_large_independent_two G hs hr hvcrit
  refine ⟨A.card, (univ \ A).card, ?_, by omega, hlarge, ?_⟩
  · have hh := card_sdiff_add_card_eq_card (subset_univ A)
    simpa [add_comm] using hh.symm
  · exact CriticalCodeBound.finite_code_bound A (univ \ A)
      (outsideNonneighbors G A) s (by omega) (by omega)
      (fun v _ => outsideNonneighbors_subset G A v)
      (fun v hv => outsideNonneighbors_weight G hr hvcrit hA hv)
      (fun u hu v hv huv => outsideNonneighbors_separation G hr hvcrit hA hu hv huv)

/-- Quadratic necessary condition using the exact current criticality definitions. -/
theorem erdos944_order_quadratic {r : ℕ} (hr : 1 ≤ r)
    (hG : G.IsCritical 4)
    (hE : ∀ edges : Set (Sym2 V), G.IsCriticalEdges edges → r < edges.ncard) :
    27 * (r+1) * (Fintype.card V - 1) ≤ (2 * Fintype.card V + 1)^2 := by
  letI : Nonempty V := nonempty_of_isCritical G hG
  have hs : 2 ≤ r+1 := by omega
  have he := edgeRobust_of_criticalEdges G hG hE
  have hv := properExcept_of_isCritical G hG
  obtain ⟨a,h,hn,ha,hlarge,hcode⟩ := code_parameters G hs he hv
  exact CriticalCodeBound.order_polynomial_bound a h (Fintype.card V) (r+1)
    hn ha hlarge hcode

/-- Explicit finite improvement of the previously stated bound |V|≥5r+6.
This does not improve the separate known asymptotic r=o(|V|). -/
theorem erdos944_order_linear {r : ℕ} (hr : 1 ≤ r)
    (hG : G.IsCritical 4)
    (hE : ∀ edges : Set (Sym2 V), G.IsCriticalEdges edges → r < edges.ncard) :
    27*r + 19 ≤ 4 * Fintype.card V := by
  letI : Nonempty V := nonempty_of_isCritical G hG
  have he := edgeRobust_of_criticalEdges G hG hE
  have hv := properExcept_of_isCritical G hG
  have hn := order_ge_six_s G (by omega : 2 ≤ r+1) he hv
  exact CriticalCodeBound.integer_order_bound_r (Fintype.card V) r hr hn
    (erdos944_order_quadratic G hr hG hE)

/-- The stronger exact integral filter retains ceil((|V|−1)/3). -/
theorem erdos944_order_exact {r : ℕ} (hr : 1 ≤ r)
    (hG : G.IsCritical 4)
    (hE : ∀ edges : Set (Sym2 V), G.IsCriticalEdges edges → r < edges.ncard) :
    9 * ((Fintype.card V + 1) / 3) * (r+1) ≤
      (2 * ((Fintype.card V + 1) / 3) + 1) *
        (Fintype.card V - (Fintype.card V + 1) / 3) := by
  letI : Nonempty V := nonempty_of_isCritical G hG
  have he := edgeRobust_of_criticalEdges G hG hE
  have hv := properExcept_of_isCritical G hG
  obtain ⟨a,h,hn,ha,hlarge,hcode⟩ := code_parameters G (by omega : 2 ≤ r+1) he hv
  exact CriticalCodeBound.exact_independence_filter a h (Fintype.card V) (r+1)
    hn ha hlarge hcode

end Erdos944Bounds

#check Erdos944Bounds.erdos944_order_linear
#print axioms Erdos944Bounds.erdos944_order_quadratic
#print axioms Erdos944Bounds.erdos944_order_linear
#print axioms Erdos944Bounds.erdos944_order_exact
