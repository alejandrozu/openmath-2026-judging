import OpHack.Erdos21.PackingBarrier
import OpHack.Erdos21.SharpEndpoint

/-!
# The sharp residual cover bound

For every finite intersecting r-uniform hypergraph J with maximum vertex degree
at most three, 4*tau(J) <= |J|+r+3. The additive constant three is optimal (the
sharpness examples were given by Sivashankar).

This answers the explicit sharp-constant question after Lemma2 of
Varun Sivashankar, arXiv:2606.24878v2 (29 July2026), conditional on no mathematical
assumptions beyond the standard Lean axioms. The proof reuses the author's
unconditional matching/witness infrastructure with attribution in AuthorBaseline.
The original paper gives +4 and the uniform corollary g(r)>=3r-4.

This is not a solution of the already-solved O(r) Erdős#21 problem and does not
improve the original paper's stronger asymptotic coefficient about3.053.
-/

namespace ErdosLovasz
variable {V : Type*} [DecidableEq V]

/-- Sharp residual theorem over actual finite hypergraphs. -/
theorem residual_cover_bound_sharp (r : ℕ) (J : Finset (Finset V))
    (huni : IsUniform r J) (hint : Intersecting J)
    (hdeg : ∀ v, edgeDeg J v ≤ 3) :
    4 * coverNum J ≤ J.card + r + 3 := by
  exact sharp_residual_from_packing
    (fun P hodd hu ht => P.support_barrier hodd hu ht) r J huni hint hdeg

/-- The sharp residual estimate lifts to all intersecting uniform hypergraphs. -/
theorem cover_bound_sharp (r : ℕ) (H : Finset (Finset V))
    (huni : IsUniform r H) (hint : Intersecting H) :
    4 * coverNum H ≤ H.card + r + 3 := by
  exact peeling_lift r 3 (fun J huni hint hdeg =>
    residual_cover_bound_sharp r J huni hint hdeg) H huni hint

/-- Every r-uniform intersecting family with maximal cover number r has at least
3r-3 edges. The form below avoids natural-number truncated subtraction. -/
theorem erdos_lovasz_lower_three (r : ℕ) (H : Finset (Finset V))
    (huni : IsUniform r H) (hint : Intersecting H) (hcover : coverNum H = r) :
    3 * r ≤ H.card + 3 := by
  have hh := cover_bound_sharp r H huni hint
  rw [hcover] at hh
  omega

/-- Equivalent natural-number lower bound. -/
theorem erdos_lovasz_lower_three_sub (r : ℕ) (H : Finset (Finset V))
    (huni : IsUniform r H) (hint : Intersecting H) (hcover : coverNum H = r) :
    3 * r - 3 ≤ H.card := by
  have hh := erdos_lovasz_lower_three r H huni hint hcover
  omega

/-- An explicit small-uniformity consequence: g(8)>=21. -/
theorem erdos_lovasz_eight_lower (H : Finset (Finset V))
    (huni : IsUniform 8 H) (hint : Intersecting H) (hcover : coverNum H = 8) :
    21 ≤ H.card := by
  have hh := erdos_lovasz_lower_three 8 H huni hint hcover
  omega

end ErdosLovasz

#check ErdosLovasz.residual_cover_bound_sharp
#check ErdosLovasz.erdos_lovasz_lower_three
#print axioms ErdosLovasz.ThreeLinkPacking.support_barrier
#print axioms ErdosLovasz.residual_cover_bound_sharp
#print axioms ErdosLovasz.cover_bound_sharp
#print axioms ErdosLovasz.erdos_lovasz_lower_three
#print axioms ErdosLovasz.erdos_lovasz_eight_lower
