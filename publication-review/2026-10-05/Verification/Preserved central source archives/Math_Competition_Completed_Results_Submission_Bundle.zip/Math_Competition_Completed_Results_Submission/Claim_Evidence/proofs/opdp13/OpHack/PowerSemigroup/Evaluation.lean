import OpHack.PowerSemigroup.Hermitian
import Mathlib.Algebra.Polynomial.Roots

noncomputable section
namespace PowerSemigroup
open Polynomial

/-- Evaluate the formal variables at z and conjugate(z). -/
def evaluate (z : ℂ) : HermitianRing →+* ℂ :=
  Polynomial.eval₂RingHom (Polynomial.evalRingHom (star z)) z

/-- Evaluate the two independent variables at z,w. -/
def evaluatePair (P : HermitianRing) (z w : ℂ) : ℂ :=
  P.eval₂ (Polynomial.evalRingHom w) z

theorem evaluate_norm (p : ℂ[X]) (z : ℂ) :
    evaluate z (normPolynomial p) = (Complex.normSq (p.eval z) : ℂ) := by
  have hid (w : ℂ) : (Polynomial.evalRingHom w).comp Polynomial.C = RingHom.id ℂ := by
    ext a
    simp
  simpa [evaluate,normPolynomial,Polynomial.eval₂_map,Polynomial.eval_map_apply,hid]
    using Complex.mul_conj (p.eval z)

theorem evaluate_diagonal (p : ℝ[X]) (z : ℂ) :
    evaluate z (diagonal p) = ((p.eval (Complex.normSq z) : ℝ) : ℂ) := by
  induction p using Polynomial.induction_on' with
  | add p q hp hq => simp [hp,hq]
  | monomial n a =>
    rw [diagonal_monomial]
    simp [evaluate,Polynomial.eval₂_monomial,Polynomial.eval_monomial]
    rw [← Complex.mul_conj, mul_pow]
    ring

theorem zero_of_real_family {R : Type*} [CommRing R] [IsDomain R]
    (p : R[X]) (f : ℝ → R) (hf : Function.Injective f)
    (hz : ∀ x : ℝ, p.eval (f x) = 0) : p = 0 := by
  apply Polynomial.eq_zero_of_infinite_isRoot
  apply (Set.infinite_range_of_injective hf).mono
  rintro _ ⟨x, rfl⟩
  exact hz x

/-- Substitute conjugate-variable = z-c, producing one ordinary polynomial. -/
def alongLine (P : HermitianRing) (c : ℂ) : ℂ[X] :=
  P.eval₂ (Polynomial.compRingHom (Polynomial.X-Polynomial.C c)) Polynomial.X

theorem alongLine_eval (P : HermitianRing) (c z : ℂ) :
    (alongLine P c).eval z = evaluatePair P z (z-c) := by
  induction P using Polynomial.induction_on' with
  | add p q hp hq => simp [alongLine,evaluatePair, hp,hq] at *
  | monomial n a => simp [alongLine,evaluatePair,Polynomial.coe_compRingHom_apply,Polynomial.eval_comp]

theorem partial_eval (P : HermitianRing) (z w : ℂ) :
    (P.eval (Polynomial.C z)).eval w = evaluatePair P z w := by
  induction P using Polynomial.induction_on' with
  | add p q hp hq => simp [evaluatePair,hp,hq]
  | monomial n a => simp [evaluatePair,Polynomial.eval₂_monomial]

/-- A formal polynomial in z and conjugate(z) is determined by its values on ℂ.
The proof uses only finite-root bounds for ordinary polynomials. -/
theorem evaluate_injective_zero (P : HermitianRing)
    (h : ∀ z : ℂ, evaluate z P = 0) : P = 0 := by
  have hline (y : ℝ) : alongLine P (2*Complex.I*(y : ℂ)) = 0 := by
    apply zero_of_real_family _ (fun x : ℝ => (x : ℂ)+Complex.I*(y : ℂ))
    · intro x x' heq
      apply Complex.ofReal_injective
      exact add_right_cancel heq
    · intro x
      rw [alongLine_eval]
      have hstar : ((x : ℂ)+Complex.I*(y : ℂ)) - 2*Complex.I*(y : ℂ) =
          star ((x : ℂ)+Complex.I*(y : ℂ)) := by
        simp [Complex.star_def]
        ring
      rw [hstar]
      exact h _
  have hpartial (z : ℂ) : P.eval (Polynomial.C z) = 0 := by
    apply zero_of_real_family _ (fun y : ℝ => z-2*Complex.I*(y : ℂ))
    · intro y y' heq
      have hi := congrArg Complex.im heq
      simp [Complex.mul_im] at hi
      linarith
    · intro y
      rw [partial_eval, ← alongLine_eval, hline]
      simp
  apply zero_of_real_family P (fun x : ℝ => Polynomial.C (x : ℂ))
  · intro x y heq
    exact Complex.ofReal_injective (Polynomial.C_injective heq)
  · intro x; exact hpartial (x : ℂ)

theorem evaluate_injective : Function.Injective (fun P : HermitianRing => fun z : ℂ => evaluate z P) := by
  intro P Q heq
  apply sub_eq_zero.mp
  apply evaluate_injective_zero
  intro z
  simp only [map_sub]
  exact sub_eq_zero.mpr (congrFun heq z)

/-- Function-level squared norms of arbitrary one-variable holomorphic polynomials. -/
def FunctionSquaredNorm (F : ℂ → ℂ) : Prop :=
  ∃ (I : Finset ℕ) (f : ℕ → ℂ[X]),
    ∀ z : ℂ, F z = ∑ i ∈ I, (Complex.normSq ((f i).eval z) : ℂ)

theorem squaredNorm_iff_function (P : HermitianRing) :
    IsSquaredNorm P ↔ FunctionSquaredNorm (fun z => evaluate z P) := by
  constructor
  · rintro ⟨I,f,h⟩
    refine ⟨I,f,?_⟩
    intro z
    simp [h,evaluate_norm]
  · rintro ⟨I,f,h⟩
    refine ⟨I,f,?_⟩
    apply evaluate_injective
    funext z
    simpa [evaluate_norm] using h z

/-- Exact function-level exponent theorem for H_t(z)=(1+|z|²)^4-t|z|⁴. -/
theorem function_exact_exponent_semigroup {t : ℝ} (ht6 : 6 < t) (ht7 : t ≤ 7)
    (n : ℕ) (hn : 0 < n) :
    FunctionSquaredNorm (fun z : ℂ =>
      (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ)) ↔
      n=2 ∨ 4≤n ∨ (n=3 ∧ 0≤924-210*t+18*t^2-t^3) := by
  have h := hermitian_exact_exponent_semigroup ht6 ht7 n hn
  rw [squaredNorm_iff_function] at h
  simpa [evaluate_diagonal,quartic] using h

#print axioms evaluate_injective
#print axioms function_exact_exponent_semigroup
end PowerSemigroup
