import OpHack.SubsetProducts.Generic.ExactFiber
import OpHack.SubsetProducts.Generic.Circulant

/-! Kernel-checked arbitrary-gap development. See the verification records for the checked source revision. -/

noncomputable section
namespace SubsetProductGap.Generic

section Normalize
variable {I V : Type*} [Fintype I] [Fintype V]
  [DecidableEq I] [DecidableEq V] [Nonempty I] [Nonempty V]
variable (G : ShiftSystem I V)
variable (hr : 5 ≤ Fintype.card V)
variable (hcard : Fintype.card V = 2 * Fintype.card I + 1)

/- Normalize the entire exposed face, including every absolute level below
the baseline. The stronger complete-face theorem handles the lower bound
implicitly by producing only nonnegative relative exponents. -/
include G hr hcard in
theorem normalized_fiber_for_parameters (P : Parameters I V) :
    ∃ d h : ℕ, 0 < d ∧ ¬ P.p ∣ d ∧ ∀ e : ℕ,
      P.p^e * d ∈ productsOfSubsets P.N ↔
        ∃ t : ℕ, e = h + t ∧ BlockSupport (Fintype.card I) t := by
  obtain ⟨m, hm, hface⟩ := complete_face_for_parameters G hr hcard P
  have hmne : m ≠ 0 := ne_of_gt hm
  let h : ℕ := m.factorization P.p
  let d : ℕ := ordCompl[P.p] m
  have hd : 0 < d := Nat.ordCompl_pos P.p hmne
  have hdne : d ≠ 0 := ne_of_gt hd
  have hpd : ¬ P.p ∣ d := Nat.not_dvd_ordCompl P.p_prime hmne
  have hmEq : P.p^h * d = m := pow_factorization_mul_ordCompl P.p_prime
  have hshift (t : ℕ) : P.p^(h + t) * d = P.p^t * m := by
    rw [← hmEq, pow_add]
    ring
  refine ⟨d, h, hd, hpd, ?_⟩
  intro e
  have hx : 0 < P.p^e * d := Nat.mul_pos (pow_pos P.p_prime.pos e) hd
  have hfree : freeExponents P.p (P.p^e * d) = freeExponents P.p m := by
    rw [freeExponents_mul P.p _ _ (pow_ne_zero _ P.p_prime.ne_zero) hdne,
      freeExponents_prime_power P.p_prime, zero_add]
    exact freeExponents_ordCompl P.p m
  have hf := hface (P.p^e * d) hx hfree
  constructor
  · intro he
    obtain ⟨t, ht, heq⟩ := hf.mp he
    have hpEq : P.p^e = P.p^(h + t) :=
      mul_right_cancel₀ hdne (heq.trans (hshift t).symm)
    exact ⟨t, Nat.pow_right_injective P.p_prime.two_le hpEq, ht⟩
  · rintro ⟨t, he, ht⟩
    apply hf.mpr
    refine ⟨t, ht, ?_⟩
    rw [he]
    exact hshift t
end Normalize

/-- Any prescribed positive gap, with p additionally above an arbitrary
bound, in the exact absolute prime-exponent fiber of the complete interval. -/
theorem arbitrary_gap_exact_fiber_above (g : ℕ) (hg : 1 ≤ g) (lower : ℕ) :
    ∃ n p d h : ℕ, p.Prime ∧ lower < p ∧ p ≤ n ∧ 0 < d ∧ ¬ p ∣ d ∧
      ∀ e : ℕ, p^e * d ∈ productsOfSubsets n ↔
        ∃ t : ℕ, e = h + t ∧ BlockSupport (g + 4) t := by
  haveI : Nonempty (Fin (g + 4)) := ⟨⟨0, by omega⟩⟩
  have hr : 5 ≤ Fintype.card (CyclicVertex (g + 4)) := by
    simpa [CyclicVertex] using (show 5 ≤ 2 * (g + 4) + 1 by omega)
  have hcard : Fintype.card (CyclicVertex (g + 4)) =
      2 * Fintype.card (Fin (g + 4)) + 1 := by
    simp [CyclicVertex]
  obtain ⟨P, hlower⟩ := parameters_above
    (I := Fin (g + 4)) (V := CyclicVertex (g + 4)) lower
  obtain ⟨d, h, hd, hpd, hfiber⟩ :=
    normalized_fiber_for_parameters (cyclicSystem (g + 4)) hr hcard P
  have hpn : P.p ≤ P.N := by
    have hp := P.p_prime.two_le
    have hN := P.p_sq_lt
    nlinarith
  refine ⟨P.N, P.p, d, h, P.p_prime, hlower, hpn, hd, hpd, ?_⟩
  intro e
  simpa using hfiber e

theorem arbitrary_gap_exact_fiber (g : ℕ) (hg : 1 ≤ g) :
    ∃ n p d h : ℕ, p.Prime ∧ p ≤ n ∧ 0 < d ∧ ¬ p ∣ d ∧
      ∀ e : ℕ, p^e * d ∈ productsOfSubsets n ↔
        ∃ t : ℕ, e = h + t ∧ BlockSupport (g + 4) t := by
  obtain ⟨n, p, d, h, hp, hlo, hpn, hd, hpd, hf⟩ :=
    arbitrary_gap_exact_fiber_above g hg 0
  exact ⟨n, p, d, h, hp, hpn, hd, hpd, hf⟩

/-- The requested literal eight-level fiber, still permitting arbitrarily
large distinguished primes. -/
theorem arbitrary_gap_eight_levels_above (g : ℕ) (hg : 1 ≤ g) (lower : ℕ) :
    ∃ n p d h : ℕ, p.Prime ∧ lower < p ∧ p ≤ n ∧ 0 < d ∧ ¬ p ∣ d ∧
      ∀ e : ℕ, p^e * d ∈ productsOfSubsets n ↔
        e = h ∨ e = h + 1 ∨ e = h + 2 ∨ e = h + 3 ∨
          e = h + g + 4 ∨ e = h + g + 5 ∨ e = h + g + 6 ∨ e = h + g + 7 := by
  obtain ⟨n, p, d, h, hp, hlo, hpn, hd, hpd, hf⟩ :=
    arbitrary_gap_exact_fiber_above g hg lower
  refine ⟨n, p, d, h, hp, hlo, hpn, hd, hpd, ?_⟩
  intro e
  simpa [Nat.add_assoc] using
    (hf e).trans (blockSupport_shift_iff_eight h (g + 4) e)

theorem arbitrary_gap_eight_levels (g : ℕ) (hg : 1 ≤ g) :
    ∃ n p d h : ℕ, p.Prime ∧ p ≤ n ∧ 0 < d ∧ ¬ p ∣ d ∧
      ∀ e : ℕ, p^e * d ∈ productsOfSubsets n ↔
        e = h ∨ e = h + 1 ∨ e = h + 2 ∨ e = h + 3 ∨
          e = h + g + 4 ∨ e = h + g + 5 ∨ e = h + g + 6 ∨ e = h + g + 7 := by
  obtain ⟨n, p, d, h, hp, hlo, hpn, hd, hpd, hf⟩ :=
    arbitrary_gap_eight_levels_above g hg 0
  exact ⟨n, p, d, h, hp, hpn, hd, hpd, hf⟩

/-- Exactly g consecutive missing relative levels between two attainable
products, with all factors still drawn from the complete initial interval. -/
theorem arbitrary_gap_consecutive_above (g : ℕ) (hg : 1 ≤ g) (lower : ℕ) :
    ∃ n p M : ℕ, p.Prime ∧ lower < p ∧ p ≤ n ∧ 0 < M ∧
      M ∈ productsOfSubsets n ∧ p^(g + 1) * M ∈ productsOfSubsets n ∧
        ∀ j : ℕ, 1 ≤ j → j ≤ g → p^j * M ∉ productsOfSubsets n := by
  obtain ⟨n, p, d, h, hp, hlo, hpn, hd, hpd, hf⟩ :=
    arbitrary_gap_exact_fiber_above g hg lower
  let M : ℕ := p^(h + 3) * d
  have hM : 0 < M := Nat.mul_pos (pow_pos hp.pos _) hd
  have hpower (j : ℕ) : p^j * M = p^(h + 3 + j) * d := by
    dsimp [M]
    rw [pow_add]
    ring
  refine ⟨n, p, M, hp, hlo, hpn, hM, ?_, ?_, ?_⟩
  · apply (hf (h + 3)).mpr
    exact ⟨3, rfl, Or.inl (by omega)⟩
  · rw [hpower]
    apply (hf (h + 3 + (g + 1))).mpr
    refine ⟨g + 4, by omega, Or.inr ?_⟩
    constructor <;> omega
  · intro j hj1 hjg hmem
    rw [hpower] at hmem
    obtain ⟨t, ht, hB⟩ := (hf (h + 3 + j)).mp hmem
    unfold BlockSupport at hB
    omega

#print axioms normalized_fiber_for_parameters
#print axioms arbitrary_gap_exact_fiber_above
#print axioms arbitrary_gap_eight_levels
#print axioms arbitrary_gap_consecutive_above
end SubsetProductGap.Generic
