import WeightedCutoff
import Mathlib.Analysis.SpecialFunctions.Log.Basic

namespace Erdos1060Partial

noncomputable def entropyConstant : ℝ :=
  Real.log (2539 / 1000 : ℝ) / 3 - Real.log (9 / 10 : ℝ) / 2

noncomputable def roundingConstant : ℝ := -Real.log (9 / 10 : ℝ)

/-- Convert the exact cubic bound to the desired exponential form,
allowing one unit of rounding in the exponent budget. -/
theorem cubic_bound_to_exp (F Q R T : ℝ) (m s : ℕ)
    (hF : 0 ≤ F) (hQ : 0 < Q)
    (hc : F ^ 3 * (9 / 10 : ℝ) ^ (3 * m) ≤
      Q ^ 3 * (2539 / 1000 : ℝ) ^ s)
    (hs : (s : ℝ) ≤ R) (hm : (m : ℝ) ≤ R / 2 + 1)
    (hsmall : Real.log Q ≤ T) :
    F ≤ Real.exp (T + entropyConstant * R + roundingConstant) := by
  by_cases hFzero : F = 0
  · subst F
    exact (Real.exp_pos _).le
  have hFpos : 0 < F := lt_of_le_of_ne hF (Ne.symm hFzero)
  have hlog := Real.log_le_log (by positivity :
      (0 : ℝ) < F ^ 3 * (9 / 10 : ℝ) ^ (3 * m)) hc
  rw [Real.log_mul (by positivity) (by positivity),
      Real.log_mul (by positivity) (by positivity)] at hlog
  simp only [Real.log_pow, Nat.cast_mul, Nat.cast_ofNat] at hlog
  have hxneg : Real.log (9 / 10 : ℝ) < 0 := Real.log_neg (by norm_num) (by norm_num)
  have hBpos : 0 < Real.log (2539 / 1000 : ℝ) := Real.log_pos (by norm_num)
  have hslog := mul_le_mul_of_nonneg_right hs hBpos.le
  have hmlog := mul_le_mul_of_nonneg_right hm (neg_nonneg.mpr hxneg.le)
  have hfinal : Real.log F ≤ T + entropyConstant * R + roundingConstant := by
    unfold entropyConstant roundingConstant
    nlinarith
  exact (Real.log_le_iff_le_exp hFpos).mp hfinal

theorem entropyConstant_pos : 0 < entropyConstant := by
  have hB : 0 < Real.log (2539 / 1000 : ℝ) := Real.log_pos (by norm_num)
  have hx : Real.log (9 / 10 : ℝ) < 0 := Real.log_neg (by norm_num) (by norm_num)
  unfold entropyConstant
  linarith

/-- Strict improvement over the located unweighted-core exponent constant. -/
theorem entropyConstant_lt_old : entropyConstant < Real.log 3 / 3 := by
  have h := Real.log_lt_log (by positivity : (0 : ℝ) < (2539 / 1000 : ℝ) ^ 2)
    exact_constant_improvement
  rw [Real.log_pow, Real.log_mul (by norm_num) (by positivity), Real.log_pow] at h
  have h9 : Real.log (9 : ℝ) = 2 * Real.log 3 := by
    calc
      Real.log (9 : ℝ) = Real.log ((3 : ℝ) ^ 2) := by norm_num
      _ = 2 * Real.log 3 := by rw [Real.log_pow]; norm_num
  rw [h9] at h
  norm_num at h
  unfold entropyConstant
  linarith

#print axioms cubic_bound_to_exp
#print axioms entropyConstant_pos
#print axioms entropyConstant_lt_old
end Erdos1060Partial
