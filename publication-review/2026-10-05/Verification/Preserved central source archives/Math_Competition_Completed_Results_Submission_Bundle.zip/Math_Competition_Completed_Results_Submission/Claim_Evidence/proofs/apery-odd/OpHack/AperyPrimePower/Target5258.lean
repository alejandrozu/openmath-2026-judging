/-
The definition `OeisA5258.aperyPoly` below is reproduced from
FormalConjectures/OEIS/5258.lean, copyright 2026 The Formal Conjectures Authors,
licensed under Apache License 2.0. Only the definition is reproduced; no
open conjecture or unproved axiom is imported. The theorems are restricted
instances, not a solution for every positive degree.
-/
import OpHack.AperyPrimePower.ThreePower
import OpHack.AperyPrimePower.BinaryPower
import OpHack.AperyPrimePower.OddPrimePower

noncomputable section
namespace OeisA5258
open Polynomial
noncomputable def aperyPoly (n : ℕ) : ℚ[X] :=
  ∑ k ∈ Finset.range (n + 1),
    C (((n.choose k) ^ 2 * ((n + k).choose k) : ℕ) : ℚ) * X ^ k

theorem aperyPoly_eq (n : ℕ) :
    aperyPoly n = AperyPrimePower.aperyRat n 1 := by
  simp only [aperyPoly, AperyPrimePower.aperyRat, AperyPrimePower.coeffNat, pow_one]

theorem conjecture_two_pow (r : ℕ) : Irreducible (aperyPoly (2 ^ r)) := by
  rw [aperyPoly_eq]
  exact AperyPrimePower.irreducible_aperyRat_two_pow_one r

theorem conjecture_three_pow (r : ℕ) : Irreducible (aperyPoly (3 ^ r)) := by
  rw [aperyPoly_eq]
  exact AperyPrimePower.irreducible_aperyRat_three_pow_one r

theorem conjecture_odd_nonWieferich_prime_pow {p r : ℕ} (hp : p.Prime)
    (htwo : p ≠ 2) (hr : 1 ≤ r)
    (hWieferich : ¬ p ^ 2 ∣ 2 ^ (p - 1) - 1) :
    Irreducible (aperyPoly (p ^ r)) := by
  rw [aperyPoly_eq]
  exact AperyPrimePower.irreducible_aperyRat_odd_prime_pow_one hp htwo hr hWieferich

#print axioms conjecture_two_pow
#print axioms conjecture_three_pow
#print axioms conjecture_odd_nonWieferich_prime_pow
end OeisA5258
