import OpHack.PowerUpper.MainUpper
import OpHack.PowerSemigroup.Evaluation

noncomputable section
namespace PowerUpper

/-- Every sufficiently large power of the concrete Hermitian quartic is a
finite sum of squared absolute values of holomorphic polynomials. -/
theorem function_near_boundary_upper :
    ∀ ε : ℝ, 0 < ε → ∃ δ0 : ℝ, 0 < δ0 ∧ δ0 ≤ 1 ∧
      ∀ (δ : ℝ) (N : ℕ), 0 < δ → δ < δ0 →
        (1+ε)*Real.log (1/δ)/δ ≤ (N : ℝ) →
        PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
          (((1+Complex.normSq z)^4-(8-δ)*(Complex.normSq z)^2)^N : ℝ)) := by
  intro ε hε
  obtain ⟨δ0, hδ0, hδ01, hnonneg⟩ := quartic_near_boundary_nonneg ε hε
  refine ⟨δ0, hδ0, hδ01, ?_⟩
  intro δ N hδ hsmall hN
  have hp := (PowerSemigroup.diagonal_squaredNorm_iff _).mpr (hnonneg δ N hδ hsmall hN)
  have hf := (PowerSemigroup.squaredNorm_iff_function _).mp hp
  simpa [PowerSemigroup.evaluate_diagonal, PowerSemigroup.quartic] using hf

#print axioms function_near_boundary_upper
end PowerUpper
