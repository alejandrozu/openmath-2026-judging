import OpHack.Ferrers.DeficientTopArm
import OpHack.Ferrers.DefectRankBounds

namespace FerrersArm.TightDefectCorner
open Finset CornerCuts MatchingClasses

/-- Extract the special-red budget from a tight defect corner and extend its top arm. -/
theorem exists_defect_top_matching_family {n W : ℕ} (ℓ : Fin n → ℕ) (hℓ : Antitone ℓ)
    {r k e i j : ℕ} (hr : 1 ≤ r) (he : e < r)
    (hs : IsTightDefectCorner (W := W) ℓ r k e i j)
    (F : Finset (Fin n × Fin W)) (hF : Feasible ℓ r F) (hcard : F.card = r*k-e) :
    ∃ A : Fin (r-e) → Finset (Fin n × Fin W),
      (∀ c, IsMatching (A c) ∧ (A c).card = i ∧
        ∀ p ∈ A c, p.1.val < i ∧ j ≤ p.2.val ∧ Allowed ℓ p.1 p.2 ∧ p ∉ F) ∧
      (∀ c d, c ≠ d → Disjoint (A c) (A d)) := by
  have hrSq : r ≤ r*r := by simpa only [Nat.mul_one] using Nat.mul_le_mul_left r hr
  have heSq : e ≤ r*r := (Nat.le_of_lt he).trans hrSq
  have hi : i ≤ n := by have := hs.rows_fit; omega
  obtain ⟨hrows,hcols,hno,hfill,hbudget⟩ := defect_red_structure ℓ heSq hs F hF hcard
  apply DeficientTopArm.exists_embedded_extension ℓ hℓ r j e hi hs.columns_fit F hF
  · intro u
    exact hrows (TopArm.rowEmbedding hi u) u.isLt
  · intro u v hv
    by_contra hh
    exact hno (TopArm.rowEmbedding hi u,v) hv ⟨u.isLt,lt_of_not_ge hh⟩
  · intro u c
    apply IsTightDefectCorner.top_special_allowed hℓ hr hs (TopArm.rowEmbedding hi u) u.isLt
      (TopArm.columnEmbedding j r hs.columns_fit (Sum.inr c))
    · change j ≤ j+c.val
      omega
    · change j+c.val < j+r
      have hc := c.isLt
      omega
  · exact hbudget

/-- Both arms combine color by color, retaining every edge of the chosen red
factor. The r-e new matching classes all have size i+j = k-r. -/
theorem exists_defect_green_matching_family {n W : ℕ} (ℓ : Fin n → ℕ) (hℓ : Antitone ℓ)
    {r k e i j : ℕ} (hr : 1 ≤ r) (he : e < r) (hs : IsTightDefectCorner (W := W) ℓ r k e i j)
    (F : Finset (Fin n × Fin W)) (hF : Feasible ℓ r F) (hcard : F.card = r*k-e) :
    ∃ G : Fin (r-e) → Finset (Fin n × Fin W),
      (∀ c, IsMatching (G c) ∧ (G c).card = k-r ∧
        ∀ p ∈ G c, Allowed ℓ p.1 p.2 ∧ p ∉ F) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) := by
  classical
  obtain ⟨A,hA,hAd⟩ := exists_defect_top_matching_family ℓ hℓ hr he hs F hF hcard
  let ℓT := transposeLengths (W := W) ℓ
  let FT := F.image Prod.swap
  have hFT : Feasible ℓT r FT := feasible_transpose ℓ hℓ r F hF
  have hFTcard : FT.card = r*k-e := (card_transpose F).trans hcard
  obtain ⟨B,hB,hBd⟩ := exists_defect_top_matching_family ℓT (transposeLengths_antitone ℓ)
    hr he (hs.transpose ℓ hℓ) FT hFT hFTcard
  let C : Fin (r-e) → Finset (Fin n × Fin W) := fun c => (B c).image Prod.swap
  have hC (c : Fin (r-e)) : IsMatching (C c) ∧ (C c).card = j ∧
      ∀ p ∈ C c, i ≤ p.1.val ∧ p.2.val < j ∧ Allowed ℓ p.1 p.2 ∧ p ∉ F := by
    refine ⟨(hB c).1.transpose, (card_transpose (B c)).trans (hB c).2.1, ?_⟩
    intro p hp
    obtain ⟨q,hq,rfl⟩ := mem_image.mp hp
    obtain ⟨hqrow,hqcol,hqa,hqF⟩ := (hB c).2.2 q hq
    refine ⟨hqcol,hqrow,(allowed_transpose_iff ℓ hℓ q.2 q.1).mp hqa, ?_⟩
    intro hqSwap
    apply hqF
    exact mem_image.mpr ⟨q.swap,hqSwap,Prod.swap_swap q⟩
  have hCd (c d : Fin (r-e)) (hcd : c ≠ d) : Disjoint (C c) (C d) := by
    apply disjoint_left.mpr
    intro p hp hq
    obtain ⟨a,ha,hap⟩ := mem_image.mp hp
    obtain ⟨b,hb,hbp⟩ := mem_image.mp hq
    have hab : a=b := Prod.swap_injective (hap.trans hbp.symm)
    subst b
    exact disjoint_left.mp (hBd c d hcd) ha hb
  have hsep (c d : Fin (r-e)) : ∀ p ∈ A c, ∀ q ∈ C d, p.1 ≠ q.1 ∧ p.2 ≠ q.2 := by
    intro p hp q hq
    have hpinfo := (hA c).2.2 p hp
    have hqinfo := (hC d).2.2 q hq
    constructor
    · intro heq
      have hh := congrArg Fin.val heq
      omega
    · intro heq
      have hh := congrArg Fin.val heq
      omega
  have hcross (c d : Fin (r-e)) : Disjoint (A c) (C d) :=
    disjoint_of_rows (fun p hp q hq => (hsep c d p hp q hq).1)
  refine ⟨fun c => A c ∪ C c, ?_, ?_⟩
  · intro c
    refine ⟨(hA c).1.union (hC c).1 (hsep c c), ?_, ?_⟩
    · rw [card_union_of_disjoint (hcross c c), (hA c).2.1, (hC c).2.1]
      have hh := hs.cut_sum
      omega
    · intro p hp
      rcases mem_union.mp hp with hp | hp
      · exact (hA c).2.2 p hp |>.2.2
      · exact (hC c).2.2 p hp |>.2.2
  · intro c d hcd
    apply disjoint_union_left.mpr
    constructor
    · exact disjoint_union_right.mpr ⟨hAd c d hcd,hcross c d⟩
    · exact disjoint_union_right.mpr ⟨(hcross d c).symm,hCd c d hcd⟩


/-- The general deficiency-preserving hierarchy. Initial red colors are
unchanged; only the total initial deficit is specified for e greater than one. -/
theorem defect_preserves_factor {n W : ℕ} (ℓ : Fin n → ℕ) (hℓ : Antitone ℓ)
    (r k e : ℕ) (hr : 1 ≤ r) (hk : r ≤ k) (he : e < r)
    (hR : factorRank (W := W) ℓ r = r*k-e)
    (hNext : factorRank (W := W) ℓ (r+1) = (r+1)*k-r-e)
    (F : Finset (Fin n × Fin W)) (hF : Feasible ℓ r F) (hcard : F.card = r*k-e) :
    ∃ G : Fin (r-e) → Finset (Fin n × Fin W),
      (∀ c, IsMatching (G c) ∧ (G c).card = k-r ∧
        ∀ p ∈ G c, Allowed ℓ p.1 p.2 ∧ p ∉ F) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) ∧
      (∀ h ≤ r-e, factorRank (W := W) ℓ (r+h) = (r+h)*k-h*r-e) ∧
      factorRank (W := W) ℓ 1 = k := by
  obtain ⟨i,hi,j,hj,hs⟩ := exists_tight_defect_corner_of_ranks ℓ hℓ r k e hr hk he hR hNext
  obtain ⟨G,hG,hdis⟩ := exists_defect_green_matching_family ℓ hℓ hr he hs F hF hcard
  have hrSq : r ≤ r*r := by simpa only [Nat.mul_one] using Nat.mul_le_mul_left r hr
  have heSq : e ≤ r*r := (Nat.le_of_lt he).trans hrSq
  refine ⟨G,hG,hdis,?_,rank_one_eq_of_defect ℓ hℓ hr he hs hR⟩
  intro h hh
  exact defect_rank_r_add_h ℓ heSq hs F hF hcard G hG hdis h hh

#print axioms exists_defect_green_matching_family
#print axioms defect_preserves_factor
end FerrersArm.TightDefectCorner
