import OpHack.Ferrers.OneDefectPrefix
import OpHack.Ferrers.YoungDiagramRestrictedPrefix

namespace FerrersArm.YoungDiagramBridge
open Finset

/-- Exact copied-FC graph ranks throughout the general deficiency extension. -/
theorem defect_indepNumK_later_ranks (μ : YoungDiagram) (r k e : ℕ)
    (hr : 1 ≤ r) (hk : r ≤ k) (he : e < r)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r*k-e)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+1) = (r+1)*k-r-e) :
    ∀ h ≤ r-e, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+h) = (r+h)*k-h*r-e := by
  have hR' := (factorRank_eq_indepNumK μ r).trans hR
  have hNext' := (factorRank_eq_indepNumK μ (r+1)).trans hNext
  obtain ⟨F,hF,hcard,_,_⟩ := CornerCuts.exists_rank_factor_and_corner
    (W := width μ) (rowLengths μ) (rowLengths_antitone μ) r
  obtain ⟨G,hG,hdis,hranks,_⟩ := TightDefectCorner.defect_preserves_factor
    (rowLengths μ) (rowLengths_antitone μ) r k e hr hk he hR' hNext'
    F hF (hcard.trans hR')
  intro h hh
  exact (factorRank_eq_indepNumK μ (r+h)).symm.trans (hranks h hh)

/-- The complete one-defect rank formula through 2r-1 on actual μ.cells. -/
theorem one_defect_indepNumK_formula (μ : YoungDiagram) (r k : ℕ)
    (hr : 2 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r*k-1)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+1) = (r+1)*k-r-1) :
    ∀ t ≤ 2*r-1, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) t =
      if t < r then t*k else t*k-(t-r)*r-1 := by
  have hR' := (factorRank_eq_indepNumK μ r).trans hR
  have hNext' := (factorRank_eq_indepNumK μ (r+1)).trans hNext
  intro t ht
  exact (factorRank_eq_indepNumK μ t).symm.trans
    (TightDefectCorner.one_defect_rank_formula (rowLengths μ) (rowLengths_antitone μ)
      r k hr hk hR' hNext' t ht)

/-- Simultaneous one-defect target classes on the exact natural-coordinate
diagram graph, together with the complete matching rank formula. -/
theorem one_defect_independent_sets (μ : YoungDiagram) (r k : ℕ)
    (hr : 2 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r*k-1)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r+1) = (r+1)*k-r-1) :
    ∃ (R : Fin r → Finset (FCCompat.YoungDiagram.Cell μ))
      (G : Fin (r-1) → Finset (FCCompat.YoungDiagram.Cell μ)),
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (R c : Set (FCCompat.YoungDiagram.Cell μ)) ∧
        (R c).card = (if c.val < r-1 then k else k-1)) ∧
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (G c : Set (FCCompat.YoungDiagram.Cell μ)) ∧ (G c).card = k-r) ∧
      (∀ c d, c ≠ d → Disjoint (R c) (R d)) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) ∧
      (∀ c d, Disjoint (R c) (G d)) ∧
      (∀ t ≤ 2*r-1, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) t =
        if t < r then t*k else t*k-(t-r)*r-1) := by
  have hR' := (factorRank_eq_indepNumK μ r).trans hR
  have hNext' := (factorRank_eq_indepNumK μ (r+1)).trans hNext
  obtain ⟨R,G,hRed,hGreen,hRR,hGG,hRG,_,_⟩ := TightDefectCorner.one_defect_matchings
    (rowLengths μ) (rowLengths_antitone μ) r k hr hk hR' hNext'
  refine ⟨fun c => cellFinset μ (R c),fun c => cellFinset μ (G c),?_,?_,?_,?_,?_,
    one_defect_indepNumK_formula μ r k hr hk hR hNext⟩
  · intro c
    exact ⟨cellFinset_independent μ (R c) (hRed c).1,
      (cellFinset_card μ (R c) (hRed c).2.2).trans (hRed c).2.1⟩
  · intro c
    exact ⟨cellFinset_independent μ (G c) (hGreen c).1,
      (cellFinset_card μ (G c) (hGreen c).2.2).trans (hGreen c).2.1⟩
  · intro c d hcd
    exact cellFinset_disjoint μ (hRR c d hcd)
  · intro c d hcd
    exact cellFinset_disjoint μ (hGG c d hcd)
  · intro c d
    exact cellFinset_disjoint μ (hRG c d)

#print axioms defect_indepNumK_later_ranks
#print axioms one_defect_independent_sets
end FerrersArm.YoungDiagramBridge
