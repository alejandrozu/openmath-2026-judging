import Mathlib
import Lean
import FormalConjectures.ErdosProblems.«94»

set_option google.answer "postpone"

-- Already imported, audited repository definitions (do not redeclare):
-- def EuclideanGeometry.ConvexIndep : Set (EuclideanSpace ℝ (Fin 2)) → Prop := fun S => ∀ a ∈ S, a ∉ (convexHull ℝ) (S \ {a})
-- 
-- def distanceSet : {X : Type u_1} → [MetricSpace X] → Finset X → Finset ℝ := fun {X} [MetricSpace X] points => Finset.image (fun pair => Dist.dist pair.1 pair.2) points.offDiag
-- 
-- def distanceMultiplicity : {X : Type u_1} → [MetricSpace X] → Finset X → ℝ → ℕ := fun {X} [MetricSpace X] points d => {pair ∈ points.offDiag | Dist.dist pair.1 pair.2 = d}.card / 2
-- 
-- def Erdos94.regularNGon : ℕ → Finset (EuclideanSpace ℝ (Fin 2)) := fun n => Finset.image (fun k => !₂[Real.cos (2 * Real.pi * ↑k / ↑n), Real.sin (2 * Real.pi * ↑k / ↑n)]) (Finset.range n)

namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit

theorem multiplicity_sum_identity
    (P : Finset (EuclideanSpace Real (Fin 2))) :
    (distanceSet P).sum (fun d => distanceMultiplicity P d) =
      Nat.choose P.card 2 := by
  classical
  have h_even : ∀ (α : Type) (t : Finset α) (σ : α → α),
      Function.Involutive σ → (∀ x ∈ t, σ x ∈ t) → (∀ x ∈ t, σ x ≠ x) → 2 ∣ t.card := by
    intro α
    have key : ∀ (n : ℕ) (t : Finset α) (σ : α → α), Function.Involutive σ →
        (∀ x ∈ t, σ x ∈ t) → (∀ x ∈ t, σ x ≠ x) → t.card ≤ n → 2 ∣ t.card := by
      intro n
      induction n with
      | zero =>
        intro t σ _ _ _ ht
        have h0 : t = ∅ := Finset.card_eq_zero.mp (Nat.eq_zero_of_le_zero ht)
        subst h0
        exact ⟨0, by simp⟩
      | succ n ih =>
        intro t σ hinv hcl hne ht
        by_cases h : t = ∅
        · subst h
          exact ⟨0, by simp⟩
        · obtain ⟨a, ha⟩ := Finset.nonempty_iff_ne_empty.mpr h
          set b : α := σ a with hb_def
          have hb : b ∈ t := hcl a ha
          have hab : b ≠ a := hne a ha
          have hba : b ∈ t.erase a := Finset.mem_erase.mpr ⟨hab, hb⟩
          have he1 : (t.erase a).card = t.card - 1 := Finset.card_erase_of_mem ha
          have he2 : ((t.erase a).erase b).card = (t.erase a).card - 1 := Finset.card_erase_of_mem hba
          have h2 : 1 ≤ (t.erase a).card := Finset.card_pos.mpr ⟨b, hba⟩
          have hcl2 : ∀ x ∈ (t.erase a).erase b, σ x ∈ (t.erase a).erase b := by
            intro x hx
            obtain ⟨hxb, hxta⟩ := Finset.mem_erase.mp hx
            obtain ⟨hxa, hxt⟩ := Finset.mem_erase.mp hxta
            refine Finset.mem_erase.mpr ⟨?_, Finset.mem_erase.mpr ⟨?_, hcl x hxt⟩⟩
            · intro hh
              exact hxa (calc x = σ (σ x) := (hinv x).symm
                     _ = σ b := congrArg σ hh
                     _ = σ (σ a) := congrArg σ hb_def
                     _ = a := hinv a)
            · intro hh
              exact hxb (calc x = σ (σ x) := (hinv x).symm
                     _ = σ a := congrArg σ hh
                     _ = b := hb_def.symm)
          have hne2 : ∀ x ∈ (t.erase a).erase b, σ x ≠ x := by
            intro x hx
            exact hne x (Finset.mem_erase.mp (Finset.mem_erase.mp hx).2).2
          have hle : ((t.erase a).erase b).card ≤ n := by omega
          obtain ⟨k, hk⟩ := ih ((t.erase a).erase b) σ hinv hcl2 hne2 hle
          exact ⟨k + 1, by omega⟩
    intro t σ h1 h2 h3
    exact key t.card t σ h1 h2 h3 (Nat.le_refl _)
  have gen : ∀ (α : Type) (u : Finset (α × α)) (f : α × α → ℝ),
      (∀ x ∈ u, x.1 ≠ x.2) → (∀ x ∈ u, (x.2, x.1) ∈ u) → (∀ x ∈ u, f (x.2, x.1) = f x) →
      (u.image f).sum (fun d => (u.filter (fun p => f p = d)).card / 2) = u.card / 2 := by
    intro α u f hne hcl hf
    have hne' : ∀ x ∈ u, (x.2, x.1) ≠ x := by
      intro x hx hh
      exact hne x hx (congrArg Prod.snd hh)
    have hSu : 2 ∣ u.card := h_even _ u (fun x => (x.2, x.1)) (fun _ => rfl) hcl hne'
    have hfc : ∀ d ∈ u.image f, 2 ∣ (u.filter (fun p => f p = d)).card := by
      intro d hd
      refine h_even _ _ (fun x => (x.2, x.1)) (fun _ => rfl) ?_ ?_
      · intro x hx
        have hx' := Finset.mem_filter.mp hx
        exact Finset.mem_filter.mpr ⟨hcl x hx'.1, by rw [hf x hx'.1, hx'.2]⟩
      · intro x hx hh
        exact hne x (Finset.mem_filter.mp hx).1 (congrArg Prod.snd hh)
    have hm : Set.MapsTo f (u : Set (α × α)) (u.image f : Set ℝ) :=
      fun _ hx => Finset.mem_image_of_mem f hx
    have hsum : (u.image f).sum (fun d => (u.filter (fun p => f p = d)).card) = u.card :=
      (Finset.card_eq_sum_card_fiberwise (f := f) (s := u) (t := u.image f) hm).symm
    have hmul : 2 * (u.image f).sum (fun d => (u.filter (fun p => f p = d)).card / 2)
        = (u.image f).sum (fun d => (u.filter (fun p => f p = d)).card) := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun d hd => Nat.mul_div_cancel' (hfc d hd))
    refine Nat.eq_of_mul_eq_mul_left (by norm_num : (0 : ℕ) < 2) ?_
    rw [hmul, hsum, Nat.mul_div_cancel' hSu]
  unfold distanceSet distanceMultiplicity
  have hdiag : ∀ x ∈ P.offDiag, x.1 ≠ x.2 := fun x hx => (Finset.mem_offDiag.mp hx).2.2
  have hswapS : ∀ x ∈ P.offDiag, (x.2, x.1) ∈ P.offDiag := by
    intro x hx
    have h := Finset.mem_offDiag.mp hx
    exact Finset.mem_offDiag.mpr ⟨h.2.1, h.1, h.2.2.symm⟩
  have hdistS : ∀ x ∈ P.offDiag,
      (fun pair => dist pair.1 pair.2) (x.2, x.1) = (fun pair => dist pair.1 pair.2) x :=
    fun x _ => dist_comm x.2 x.1
  refine (gen _ P.offDiag (fun pair => dist pair.1 pair.2) hdiag hswapS hdistS).trans ?_
  rw [Nat.choose_two_right, Finset.offDiag_card, Nat.mul_sub_left_distrib, Nat.mul_one]

theorem nat_choose_two_div (n : Nat) : Nat.choose n 2 = n * (n - 1) / 2 := by
  exact Nat.choose_two_right n

theorem multiplicity_square_integer_optimization
    {α : Type _}
    [DecidableEq α]
    (s : Finset α)
    (w : α → Nat)
    (n : Nat)
    (hn : 0 < n)
    (hsum : s.sum w = n * (n - 1) / 2)
    (hb : ∀ a ∈ s, w a ≤ n) :
    s.sum (fun a => (w a : Real) ^ 2) ≤
      ((((n * (n - 1) / 2) / n : Nat) : Real) * (n : Real) ^ 2 +
        (((n * (n - 1) / 2) % n : Nat) : Real) ^ 2) := by
  have subadd : ∀ (T x : ℕ), x ≤ n →
      (x : ℝ) * ((n : ℝ) - (x : ℝ)) + ((T % n : ℕ) : ℝ) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) ≥
        (((T + x) % n : ℕ) : ℝ) * ((n : ℝ) - (((T + x) % n : ℕ) : ℝ)) := by
    intro T x hx
    have hu : T % n < n := Nat.mod_lt T hn
    have hT : T + x = T % n + x + n * (T / n) := by
      calc T + x = (T % n + n * (T / n)) + x := by rw [Nat.mod_add_div]
        _ = T % n + (n * (T / n) + x) := Nat.add_assoc _ _ _
        _ = T % n + (x + n * (T / n)) := by rw [Nat.add_comm (n * (T / n)) x]
        _ = T % n + x + n * (T / n) := (Nat.add_assoc _ _ _).symm
    have hbase : (T + x) % n = (T % n + x) % n := by rw [hT, Nat.add_mul_mod_self_left]
    by_cases hc : T % n + x < n
    · have h1 : (T + x) % n = T % n + x := by rw [hbase, Nat.mod_eq_of_lt hc]
      have H : (x : ℝ) * ((n : ℝ) - (x : ℝ)) + ((T % n : ℕ) : ℝ) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) ≥
          (((T % n : ℕ) : ℝ) + (x : ℝ)) * ((n : ℝ) - (((T % n : ℕ) : ℝ) + (x : ℝ))) := by
        have hid : (x : ℝ) * ((n : ℝ) - (x : ℝ)) + ((T % n : ℕ) : ℝ) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) -
            (((T % n : ℕ) : ℝ) + (x : ℝ)) * ((n : ℝ) - (((T % n : ℕ) : ℝ) + (x : ℝ))) =
            2 * (x : ℝ) * ((T % n : ℕ) : ℝ) := by ring
        have hpos : (0 : ℝ) ≤ 2 * (x : ℝ) * ((T % n : ℕ) : ℝ) := by positivity
        linarith
      rw [h1, Nat.cast_add]
      exact H
    · have hc' : n ≤ T % n + x := by omega
      have hd : T % n + x - n < n := by omega
      have hs' : T % n + x = n + (T % n + x - n) := by omega
      have h2 : (T % n + x) % n = T % n + x - n := by
        conv_lhs => rw [hs']
        rw [Nat.add_mod, Nat.mod_self, Nat.zero_add, Nat.mod_mod, Nat.mod_eq_of_lt hd]
      have h1 : (T + x) % n = T % n + x - n := by rw [hbase, h2]
      have h3 : ((T % n + x - n : ℕ) : ℝ) = ((T % n : ℕ) : ℝ) + (x : ℝ) - (n : ℝ) := by
        rw [Nat.cast_sub hc', Nat.cast_add]
      have H : (x : ℝ) * ((n : ℝ) - (x : ℝ)) + ((T % n : ℕ) : ℝ) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) ≥
          (((T % n : ℕ) : ℝ) + (x : ℝ) - (n : ℝ)) *
            ((n : ℝ) - (((T % n : ℕ) : ℝ) + (x : ℝ) - (n : ℝ))) := by
        have hid : (x : ℝ) * ((n : ℝ) - (x : ℝ)) + ((T % n : ℕ) : ℝ) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) -
            ((((T % n : ℕ) : ℝ) + (x : ℝ) - (n : ℝ)) *
              ((n : ℝ) - (((T % n : ℕ) : ℝ) + (x : ℝ) - (n : ℝ)))) =
            2 * ((n : ℝ) - (x : ℝ)) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) := by ring
        have hx' : (x : ℝ) ≤ (n : ℝ) := by exact_mod_cast hx
        have hu' : ((T % n : ℕ) : ℝ) ≤ (n : ℝ) := by exact_mod_cast Nat.le_of_lt hu
        have hpos : (0 : ℝ) ≤ 2 * ((n : ℝ) - (x : ℝ)) * ((n : ℝ) - ((T % n : ℕ) : ℝ)) := by
          refine mul_nonneg (mul_nonneg ?_ ?_) ?_ <;> linarith
        linarith
      rw [h1, h3]
      exact H
  have key : ∀ (t : Finset α), ∀ f : α → Nat, (∀ a ∈ t, f a ≤ n) →
      ((t.sum f % n : ℕ) : ℝ) * ((n : ℝ) - ((t.sum f % n : ℕ) : ℝ)) ≤
        t.sum (fun a => (f a : ℝ) * ((n : ℝ) - (f a : ℝ))) := by
    intro t
    refine Finset.induction_on t ?_ ?_
    · intro f _
      simp
    · intro a s' has ih f hf
      have ha : f a ≤ n := hf a (Finset.mem_insert_self a s')
      have hrest : ∀ b ∈ s', f b ≤ n := fun b hb => hf b (Finset.mem_insert_of_mem hb)
      have hIH := ih f hrest
      have h1 : (insert a s').sum (fun x => (f x : ℝ) * ((n : ℝ) - (f x : ℝ))) =
          (f a : ℝ) * ((n : ℝ) - (f a : ℝ)) + s'.sum (fun x => (f x : ℝ) * ((n : ℝ) - (f x : ℝ))) :=
        Finset.sum_insert has
      have h2 : (insert a s').sum f = s'.sum f + f a := by
        rw [Finset.sum_insert has]
        ring
      have h3 := subadd (s'.sum f) (f a) ha
      rw [h1, h2]
      linarith
  have hsq : s.sum (fun a => (w a : ℝ)^2) + s.sum (fun a => (w a : ℝ) * ((n : ℝ) - (w a : ℝ))) =
      (n : ℝ) * ((s.sum w : ℕ) : ℝ) := by
    calc s.sum (fun a => (w a : ℝ)^2) + s.sum (fun a => (w a : ℝ) * ((n : ℝ) - (w a : ℝ)))
        = s.sum (fun a => (w a : ℝ)^2 + (w a : ℝ) * ((n : ℝ) - (w a : ℝ))) := (Finset.sum_add_distrib).symm
      _ = s.sum (fun a => (n : ℝ) * (w a : ℝ)) := by
        refine Finset.sum_congr rfl (fun a _ => ?_)
        ring
      _ = (n : ℝ) * s.sum (fun a => (w a : ℝ)) := (Finset.mul_sum s (fun a => (w a : ℝ)) (n : ℝ)).symm
      _ = (n : ℝ) * ((s.sum w : ℕ) : ℝ) := by
        have hc : ((s.sum w : ℕ) : ℝ) = s.sum (fun a => (w a : ℝ)) := by simp
        rw [hc]
  have hdecomp : (n : ℝ) * ((s.sum w : ℕ) : ℝ) =
      ((s.sum w / n : ℕ) : ℝ) * (n : ℝ)^2 + ((s.sum w % n : ℕ) : ℝ) * (n : ℝ) := by
    have h1 : ((s.sum w : ℕ) : ℝ) = ((s.sum w / n : ℕ) : ℝ) * (n : ℝ) + ((s.sum w % n : ℕ) : ℝ) := by
      have hh : ((s.sum w : ℕ) : ℝ) = ((s.sum w % n : ℕ) : ℝ) + (n : ℝ) * ((s.sum w / n : ℕ) : ℝ) := by
        exact_mod_cast (Nat.mod_add_div (s.sum w) n).symm
      rw [hh]
      ring
    calc (n : ℝ) * ((s.sum w : ℕ) : ℝ)
        = (n : ℝ) * (((s.sum w / n : ℕ) : ℝ) * (n : ℝ) + ((s.sum w % n : ℕ) : ℝ)) := by rw [h1]
      _ = ((s.sum w / n : ℕ) : ℝ) * (n : ℝ)^2 + ((s.sum w % n : ℕ) : ℝ) * (n : ℝ) := by ring
  have hrw : ((s.sum w % n : ℕ) : ℝ) * ((n : ℝ) - ((s.sum w % n : ℕ) : ℝ)) =
      ((s.sum w % n : ℕ) : ℝ) * (n : ℝ) - ((s.sum w % n : ℕ) : ℝ)^2 := by ring
  have hmain : s.sum (fun a => (w a : ℝ)^2) ≤
      ((s.sum w / n : ℕ) : ℝ) * (n : ℝ)^2 + ((s.sum w % n : ℕ) : ℝ)^2 := by
    have h4 : s.sum (fun a => (w a : ℝ) * ((n : ℝ) - (w a : ℝ))) ≥
        ((s.sum w % n : ℕ) : ℝ) * (n : ℝ) - ((s.sum w % n : ℕ) : ℝ)^2 := by
      rw [← hrw]
      exact key s w hb
    linarith [hsq, hdecomp, h4]
  have hq : s.sum w / n = n * (n - 1) / 2 / n := by rw [hsum]
  have hr : s.sum w % n = n * (n - 1) / 2 % n := by rw [hsum]
  rw [hq, hr] at hmain
  exact hmain

theorem multiplicitySquareOptimal_rhs_odd
    (n : Nat)
    (hn : 0 < n)
    (hodd : Odd n) :
    (((n * (n - 1) / 2) / n : Nat) : Real) * (n : Real) ^ 2 +
        (((n * (n - 1) / 2) % n : Nat) : Real) ^ 2 =
      ((n / 2 : Nat) : Real) * (n : Real) ^ 2 := by
  obtain ⟨k, rfl⟩ : ∃ k, n = 2 * k + 1 := hodd
  have hn1 : (2 * k + 1) - 1 = 2 * k := by omega
  have h1 : (2 * k + 1) * ((2 * k + 1) - 1) / 2 = (2 * k + 1) * k := by
    rw [hn1]
    rw [show (2 * k + 1) * (2 * k) = ((2 * k + 1) * k) * 2 by ring]
    exact Nat.mul_div_left _ (by norm_num : (0 : ℕ) < 2)
  have h2 : (2 * k + 1) * k / (2 * k + 1) = k :=
    Nat.mul_div_right k (by omega : 0 < 2 * k + 1)
  have h3 : (2 * k + 1) * k % (2 * k + 1) = 0 := Nat.mul_mod_right (2 * k + 1) k
  have h4 : (2 * k + 1) / 2 = k := by omega
  rw [h1, h2, h3, h4]
  simp

theorem multiplicitySquareOptimal_rhs_even
    (n : Nat)
    (hn : 2 ≤ n)
    (heven : Even n) :
    (((n * (n - 1) / 2) / n : Nat) : Real) * (n : Real) ^ 2 +
        (((n * (n - 1) / 2) % n : Nat) : Real) ^ 2 =
      ((n / 2 - 1 : Nat) : Real) * (n : Real) ^ 2 +
        ((n / 2 : Nat) : Real) ^ 2 := by
  obtain ⟨k, hk⟩ := heven
  replace hk : n = 2 * k := by omega
  subst hk
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  -- now n = 2 * (j + 1)
  have hn1 : 2 * (j + 1) - 1 = 2 * j + 1 := by omega
  have hprod : 2 * (j + 1) * (2 * (j + 1) - 1) = 2 * (2 * j * j + 3 * j + 1) := by
    rw [hn1]
    ring
  have hdiv2 : (2 * (j + 1) * (2 * (j + 1) - 1)) / 2 = 2 * j * j + 3 * j + 1 := by
    rw [hprod, Nat.mul_div_cancel_left _ (by norm_num : (0 : ℕ) < 2)]
  have hdecomp : 2 * j * j + 3 * j + 1 = (j + 1) + j * (2 * (j + 1)) := by ring
  have hlt : j + 1 < 2 * (j + 1) := by omega
  have hq : (2 * j * j + 3 * j + 1) / (2 * (j + 1)) = j := by
    rw [hdecomp, Nat.add_mul_div_right _ _ (by omega : (0 : ℕ) < 2 * (j + 1)),
      Nat.div_eq_of_lt hlt]
    omega
  have hr : (2 * j * j + 3 * j + 1) % (2 * (j + 1)) = j + 1 := by
    rw [hdecomp, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hlt]
  have hd : 2 * (j + 1) / 2 = j + 1 := by
    rw [Nat.mul_div_cancel_left _ (by norm_num : (0 : ℕ) < 2)]
  rw [hdiv2, hq, hr, hd]
  rfl

theorem sumsq_constant_of_card_and_eq
    {α : Type _}
    [DecidableEq α]
    (s : Finset α)
    (w : α → Nat)
    (c k : Nat)
    (hcard : s.card = k)
    (hw : ∀ a ∈ s, w a = c) :
    s.sum (fun a => (w a : Real) ^ 2) =
      ((k : Nat) : Real) * (c : Real) ^ 2 := by
  have h1 : s.sum (fun a => (w a : Real) ^ 2) = s.sum (fun _ => (c : Real) ^ 2) :=
    Finset.sum_congr rfl fun a ha => by rw [hw a ha]
  rw [h1, Finset.sum_const, hcard, nsmul_eq_mul]

theorem sumsq_one_diameter_partition
    {α : Type _}
    [DecidableEq α]
    (s : Finset α)
    (s₀ : Finset α)
    (d : α)
    (w : α → Nat)
    (n : Nat)
    (hn : 2 ≤ n)
    (hd : d ∈ s)
    (hdisj : s₀ ∩ ({d} : Finset α) = ∅)
    (hunion : s = s₀ ∪ ({d} : Finset α))
    (hcard₀ : s₀.card = n / 2 - 1)
    (hw₀ : ∀ a ∈ s₀, w a = n)
    (hwd : w d = n / 2) :
    s.sum (fun a => (w a : Real) ^ 2) =
      (((n / 2 - 1 : Nat) : Real) * (n : Real) ^ 2 +
        ((n / 2 : Nat) : Real) ^ 2) := by
  have hdisj' : Disjoint s₀ ({d} : Finset α) :=
    Finset.disjoint_iff_inter_eq_empty.mpr hdisj
  calc s.sum (fun a => (w a : Real) ^ 2)
      = (s₀ ∪ ({d} : Finset α)).sum (fun a => (w a : Real) ^ 2) := by rw [hunion]
    _ = s₀.sum (fun a => (w a : Real) ^ 2) + ({d} : Finset α).sum (fun a => (w a : Real) ^ 2) :=
        Finset.sum_union hdisj'
    _ = ((n / 2 - 1 : Nat) : Real) * (n : Real) ^ 2 + (w d : Real) ^ 2 := by
        rw [sumsq_constant_of_card_and_eq s₀ w n (n / 2 - 1) hcard₀ hw₀, Finset.sum_singleton]
    _ = ((n / 2 - 1 : Nat) : Real) * (n : Real) ^ 2 + ((n / 2 : Nat) : Real) ^ 2 := by
        rw [hwd]

theorem distanceMultiplicity_sum_nat_choose_of_card
    (n : Nat)
    (P : Finset (EuclideanSpace Real (Fin 2)))
    (hcard : P.card = n) :
    (distanceSet P).sum (fun d => distanceMultiplicity P d) =
      n * (n - 1) / 2 := by
  rw [multiplicity_sum_identity, hcard, nat_choose_two_div]

theorem multiplicity_square_sum_optimum_le
    (n : Nat)
    (hn : 0 < n)
    (P : Finset (EuclideanSpace Real (Fin 2)))
    (hsum :
      (distanceSet P).sum (fun d => distanceMultiplicity P d) =
        n * (n - 1) / 2)
    (hcap : ∀ d ∈ distanceSet P, distanceMultiplicity P d ≤ n) :
    (distanceSet P).sum (fun d => (distanceMultiplicity P d : Real) ^ 2) ≤
      (((n * (n - 1) / 2) / n : Nat) : Real) * (n : Real) ^ 2 +
        (((n * (n - 1) / 2) % n : Nat) : Real) ^ 2 := by
  classical
  exact multiplicity_square_integer_optimization (distanceSet P) (fun d => distanceMultiplicity P d) n hn hsum hcap

theorem not_forall_le_nat
    {α : Type _}
    (s : Finset α)
    (f : α → Nat)
    (n : Nat)
    (h : ¬ (∀ a ∈ s, f a ≤ n)) :
    ∃ a ∈ s, n < f a := by
  classical
  by_contra h'
  apply h
  intro a ha
  have hnot : ¬ (n < f a) := fun hn => h' ⟨a, ha, hn⟩
  exact Nat.le_of_not_lt hnot

theorem regularNGon_even_multiplicitySquareSum_closed_form_of_data
    (n : Nat)
    (hn : 3 ≤ n)
    (heven : Even n)
    (hcard :
      (distanceSet (Erdos94.regularNGon n)).card = n / 2)
    (hpart :
      ∃ d ∈ distanceSet (Erdos94.regularNGon n),
        distanceMultiplicity (Erdos94.regularNGon n) d = n / 2 ∧
          ∀ x ∈ distanceSet (Erdos94.regularNGon n),
            x ≠ d → distanceMultiplicity (Erdos94.regularNGon n) x = n) :
    (distanceSet (Erdos94.regularNGon n)).sum
        (fun d => (distanceMultiplicity (Erdos94.regularNGon n) d : Real) ^ 2) =
      ((n / 2 - 1 : Nat) : Real) * (n : Real) ^ 2 +
        ((n / 2 : Nat) : Real) ^ 2 := by
  obtain ⟨d, hd, hmd, hall⟩ := hpart
  have hn2 : 2 ≤ n := by omega
  have hdisj : (distanceSet (Erdos94.regularNGon n)).erase d ∩ ({d} : Finset ℝ) = ∅ := by
    rw [← Finset.disjoint_iff_inter_eq_empty, Finset.disjoint_left]
    intro x hx hx'
    rw [Finset.mem_singleton] at hx'
    rw [Finset.mem_erase] at hx
    exact hx.1 hx'
  have hunion : distanceSet (Erdos94.regularNGon n) =
      (distanceSet (Erdos94.regularNGon n)).erase d ∪ ({d} : Finset ℝ) := by
    rw [Finset.ext_iff]
    intro x
    rw [Finset.mem_union, Finset.mem_singleton, Finset.mem_erase]
    constructor
    · intro hx
      by_cases h : x = d
      · exact Or.inr h
      · exact Or.inl ⟨h, hx⟩
    · rintro (⟨_, hx⟩ | h)
      · exact hx
      · subst h
        exact hd
  have hcard₀ : ((distanceSet (Erdos94.regularNGon n)).erase d).card = n / 2 - 1 := by
    rw [Finset.card_erase_of_mem hd, hcard]
  have hw₀ : ∀ a ∈ (distanceSet (Erdos94.regularNGon n)).erase d,
      distanceMultiplicity (Erdos94.regularNGon n) a = n := by
    intro a ha
    rw [Finset.mem_erase] at ha
    exact hall a ha.2 ha.1
  exact sumsq_one_diameter_partition (distanceSet (Erdos94.regularNGon n))
      ((distanceSet (Erdos94.regularNGon n)).erase d) d
      (distanceMultiplicity (Erdos94.regularNGon n)) n hn2 hd hdisj hunion hcard₀ hw₀ hmd

theorem eventually_of_convex_independent_multiplicity_sum_bound_threshold
    (h :
      ∃ N : Nat,
        ∀ n : Nat,
          N ≤ n →
            ∀ P : Finset (EuclideanSpace Real (Fin 2)),
              P.card = n →
                EuclideanGeometry.ConvexIndep (↑P : Set (EuclideanSpace Real (Fin 2))) →
                  (distanceSet P).sum (fun d => (distanceMultiplicity P d : Real) ^ 2) ≤
                    (distanceSet (Erdos94.regularNGon n)).sum
                      (fun d =>
                        (distanceMultiplicity (Erdos94.regularNGon n) d : Real) ^ 2)) :
    Filter.Eventually
      (fun n =>
        ∀ P : Finset (EuclideanSpace Real (Fin 2)),
          P.card = n →
            EuclideanGeometry.ConvexIndep (↑P : Set (EuclideanSpace Real (Fin 2))) →
              (distanceSet P).sum (fun d => (distanceMultiplicity P d : Real) ^ 2) ≤
                (distanceSet (Erdos94.regularNGon n)).sum
                  (fun d =>
                    (distanceMultiplicity (Erdos94.regularNGon n) d : Real) ^ 2))
      Filter.atTop := by
  exact Filter.eventually_atTop.mpr h

theorem multiplicity_total_even_partition
    (n : Nat)
    (h2 : 2 ≤ n)
    (heven : Even n) :
    n * (n - 1) / 2 = n / 2 + (n / 2 - 1) * n := by
  obtain ⟨k, rfl⟩ : ∃ k, n = 2 * k := by
    obtain ⟨m, hm⟩ := heven
    exact ⟨m, by rw [hm, ← two_mul]⟩
  have hk : 1 ≤ k := by omega
  have hpos : 0 < (2 : ℕ) := by omega
  have hdiv : 2 * k * (2 * k - 1) / 2 = k * (2 * k - 1) := by
    rw [show 2 * k * (2 * k - 1) = 2 * (k * (2 * k - 1)) by ring]
    exact Nat.mul_div_cancel_left _ hpos
  have hdiv2 : 2 * k / 2 = k := Nat.mul_div_cancel_left _ hpos
  rw [hdiv, hdiv2]
  cases k with
  | zero => omega
  | succ j =>
    rw [show 2 * (j + 1) - 1 = 2 * j + 1 by omega, show (j + 1) - 1 = j by omega]
    ring

theorem multiplicity_total_odd
    (n : Nat)
    (hodd : Odd n) :
    n * (n - 1) / 2 = n * (n / 2) := by
  cases' hodd with k hk
  subst hk
  have hsub : 2 * k + 1 - 1 = 2 * k := by omega
  have hdiv : (2 * k + 1) / 2 = k := by omega
  rw [hsub, hdiv]
  exact Nat.div_eq_of_eq_mul_left (by norm_num : (0 : ℕ) < 2)
    (by ring : (2 * k + 1) * (2 * k) = ((2 * k + 1) * k) * 2)

theorem nat_eq_of_sum_eq_mul_card_of_le
    {α : Type _}
    [DecidableEq α]
    (s : Finset α)
    (f : α → Nat)
    (n k : Nat)
    (hcard : s.card = k)
    (hsum : s.sum f = k * n)
    (hle : ∀ a ∈ s, f a ≤ n) :
    ∀ a ∈ s, f a = n := by
  intro a ha
  have hsum_eq : s.sum f = s.sum (fun _ => n) :=
    calc s.sum f = k * n := hsum
      _ = k • n := (nsmul_eq_mul k n).symm
      _ = s.card • n := by rw [hcard]
      _ = s.sum (fun _ => n) := (Finset.sum_const n).symm
  by_contra h
  have hlt : s.sum f < s.sum (fun _ => n) :=
    Finset.sum_lt_sum hle ⟨a, ha, Nat.lt_of_le_of_ne (hle a ha) h⟩
  rw [hsum_eq] at hlt
  exact Nat.lt_irrefl _ hlt

theorem nat_eq_of_sum_one_exceptional
    {α : Type _}
    [DecidableEq α]
    (s : Finset α)
    (f : α → Nat)
    (d : α)
    (k n r : Nat)
    (hd : d ∈ s)
    (hcard : s.card = k)
    (hfd : f d = r)
    (hle : ∀ a ∈ s, a ≠ d → f a ≤ n)
    (hsum : s.sum f = r + (k - 1) * n) :
    ∀ a ∈ s, a ≠ d → f a = n := by
  intro a ha hne
  have hdin : d ∉ s.erase d := by simp
  have hsum_erase : s.sum f = f d + (s.erase d).sum f := by
    have h : (insert d (s.erase d)).sum f = f d + (s.erase d).sum f := Finset.sum_insert hdin
    rw [Finset.insert_erase hd] at h
    exact h
  have h1 : (s.erase d).sum f = (k - 1) * n := by
    rw [hsum_erase, hfd] at hsum
    exact Nat.add_left_cancel hsum
  have hcard_erase : (s.erase d).card = k - 1 := by
    rw [Finset.card_erase_of_mem hd, hcard]
  have hamem : a ∈ s.erase d := Finset.mem_erase.mpr ⟨hne, ha⟩
  have hineq : ∀ x ∈ s.erase d, f x ≤ n := by
    intro x hx
    obtain ⟨hxd, hxs⟩ := Finset.mem_erase.mp hx
    exact hle x hxs hxd
  have hsum_split : (s.erase d).sum f = f a + ((s.erase d).erase a).sum f := by
    have h : (insert a ((s.erase d).erase a)).sum f = f a + ((s.erase d).erase a).sum f := by
      have hna : a ∉ (s.erase d).erase a := by simp
      exact Finset.sum_insert hna
    rw [Finset.insert_erase hamem] at h
    exact h
  have hpos : 1 ≤ (s.erase d).card := Finset.card_pos.mpr ⟨a, hamem⟩
  have hcard_a : (s.erase d).card = ((s.erase d).erase a).card + 1 := by
    rw [Finset.card_erase_of_mem hamem]
    omega
  have h_le : ((s.erase d).erase a).sum f ≤ ((s.erase d).erase a).card * n :=
    calc ((s.erase d).erase a).sum f ≤ ((s.erase d).erase a).sum (fun _ => n) :=
          Finset.sum_le_sum (fun x hx => hineq x (Finset.mem_erase.mp hx).2)
      _ = ((s.erase d).erase a).card • n := Finset.sum_const n
      _ = ((s.erase d).erase a).card * n := Nat.nsmul_eq_mul _ _
  have h_eq : f a + ((s.erase d).erase a).sum f = ((s.erase d).erase a).card * n + n := by
    rw [← hsum_split, h1, ← hcard_erase, hcard_a]
    ring
  have h2 : ((s.erase d).erase a).card * n + n ≤ f a + ((s.erase d).erase a).card * n := by
    rw [← h_eq]
    exact Nat.add_le_add_left h_le (f a)
  have h3 : n ≤ f a :=
    Nat.le_of_add_le_add_left (h2.trans ((Nat.add_comm (f a) _).le))
  exact Nat.le_antisymm (hineq a hamem) h3

theorem regularNGon_card_ge5
    (n : Nat)
    (hn : 5 ≤ n) :
    (Erdos94.regularNGon n).card = n := by
  have hn0 : (0 : ℝ) < (n : ℝ) := Nat.cast_pos.mpr (by omega : 0 < n)
  have hpi : (0 : ℝ) < Real.pi := Real.pi_pos
  have hpi2 : (0 : ℝ) < 2 * Real.pi := mul_pos zero_lt_two hpi
  have h2pi0 : (0 : ℝ) ≤ 2 * Real.pi := le_of_lt hpi2
  have hnne : (n : ℝ) ≠ 0 := ne_of_gt hn0
  unfold Erdos94.regularNGon
  refine Eq.trans (Finset.card_image_of_injOn ?_) ?_
  · intro k hk l hl h
    have hkm : k < n := Finset.mem_range.mp hk
    have hlm : l < n := Finset.mem_range.mp hl
    have hc : Real.cos (((2 * Real.pi) * (k : ℝ)) / (n : ℝ)) =
        Real.cos (((2 * Real.pi) * (l : ℝ)) / (n : ℝ)) :=
      congrArg (fun v : EuclideanSpace ℝ (Fin 2) => v 0) h
    have hs : Real.sin (((2 * Real.pi) * (k : ℝ)) / (n : ℝ)) =
        Real.sin (((2 * Real.pi) * (l : ℝ)) / (n : ℝ)) :=
      congrArg (fun v : EuclideanSpace ℝ (Fin 2) => v 1) h
    have h2 : Real.cos (((2 * Real.pi) * (k : ℝ)) / (n : ℝ) -
        ((2 * Real.pi) * (l : ℝ)) / (n : ℝ)) = 1 := by
      rw [Real.cos_sub, hc, hs]
      have hh := Real.cos_sq_add_sin_sq (((2 * Real.pi) * (l : ℝ)) / (n : ℝ))
      rw [sq, sq] at hh
      exact hh
    obtain ⟨m, hm⟩ := (Real.cos_eq_one_iff
      (((2 * Real.pi) * (k : ℝ)) / (n : ℝ) - ((2 * Real.pi) * (l : ℝ)) / (n : ℝ))).mp h2
    have h1k : ((2 * Real.pi) * (k : ℝ)) / (n : ℝ) = (2 * Real.pi) * ((k : ℝ) * (n : ℝ)⁻¹) := by
      rw [div_eq_mul_inv]
      exact mul_assoc _ _ _
    have h1l : ((2 * Real.pi) * (l : ℝ)) / (n : ℝ) = (2 * Real.pi) * ((l : ℝ) * (n : ℝ)⁻¹) := by
      rw [div_eq_mul_inv]
      exact mul_assoc _ _ _
    have hA0 : 0 ≤ (2 * Real.pi) * ((k : ℝ) * (n : ℝ)⁻¹) :=
      mul_nonneg (le_of_lt hpi2)
        (mul_nonneg (Nat.cast_nonneg k) (inv_nonneg.mpr (le_of_lt hn0)))
    have hB0 : 0 ≤ (2 * Real.pi) * ((l : ℝ) * (n : ℝ)⁻¹) :=
      mul_nonneg (le_of_lt hpi2)
        (mul_nonneg (Nat.cast_nonneg l) (inv_nonneg.mpr (le_of_lt hn0)))
    have hkn : (k : ℝ) * (n : ℝ)⁻¹ < (1 : ℝ) := by
      have h2' : (k : ℝ) * (n : ℝ)⁻¹ < (n : ℝ) * (n : ℝ)⁻¹ :=
        mul_lt_mul_of_pos_right (Nat.cast_lt.mpr hkm) (inv_pos.mpr hn0)
      have h3 : (n : ℝ) * (n : ℝ)⁻¹ = (1 : ℝ) := by
        rw [← div_eq_mul_inv]
        exact div_self hnne
      rw [h3] at h2'
      exact h2'
    have hln : (l : ℝ) * (n : ℝ)⁻¹ < (1 : ℝ) := by
      have h2' : (l : ℝ) * (n : ℝ)⁻¹ < (n : ℝ) * (n : ℝ)⁻¹ :=
        mul_lt_mul_of_pos_right (Nat.cast_lt.mpr hlm) (inv_pos.mpr hn0)
      have h3 : (n : ℝ) * (n : ℝ)⁻¹ = (1 : ℝ) := by
        rw [← div_eq_mul_inv]
        exact div_self hnne
      rw [h3] at h2'
      exact h2'
    have hAkt : (2 * Real.pi) * ((k : ℝ) * (n : ℝ)⁻¹) < 2 * Real.pi := by
      have h4 : (2 * Real.pi) * ((k : ℝ) * (n : ℝ)⁻¹) < (2 * Real.pi) * (1 : ℝ) :=
        mul_lt_mul_of_pos_left hkn hpi2
      have h5 : (2 * Real.pi) * (1 : ℝ) = 2 * Real.pi := mul_one _
      rw [h5] at h4
      exact h4
    have hBlt : (2 * Real.pi) * ((l : ℝ) * (n : ℝ)⁻¹) < 2 * Real.pi := by
      have h4 : (2 * Real.pi) * ((l : ℝ) * (n : ℝ)⁻¹) < (2 * Real.pi) * (1 : ℝ) :=
        mul_lt_mul_of_pos_left hln hpi2
      have h5 : (2 * Real.pi) * (1 : ℝ) = 2 * Real.pi := mul_one _
      rw [h5] at h4
      exact h4
    have hdlt : ((2 * Real.pi) * (k : ℝ)) / (n : ℝ) - ((2 * Real.pi) * (l : ℝ)) / (n : ℝ) <
        2 * Real.pi := by
      rw [h1k, h1l]
      linarith
    have hdgt : -(2 * Real.pi) < ((2 * Real.pi) * (k : ℝ)) / (n : ℝ) -
        ((2 * Real.pi) * (l : ℝ)) / (n : ℝ) := by
      rw [h1k, h1l]
      linarith
    have h5 : (m : ℝ) < 1 := by
      refine not_le.mp ?_
      intro h9
      have h10 : (2 : ℝ) * Real.pi ≤ (m : ℝ) * (2 * Real.pi) := by
        have h11 : (1 : ℝ) * (2 * Real.pi) ≤ (m : ℝ) * (2 * Real.pi) :=
          mul_le_mul_of_nonneg_right h9 h2pi0
        rw [one_mul] at h11
        exact h11
      have h12 : (m : ℝ) * (2 * Real.pi) < 2 * Real.pi := by
        rw [hm]
        exact hdlt
      exact lt_irrefl (2 * Real.pi) (lt_of_le_of_lt h10 h12)
    have hE : 0 < ((m : ℝ) + 1) * (2 * Real.pi) := by
      have h1 : ((m : ℝ) + 1) * (2 * Real.pi) = (m : ℝ) * (2 * Real.pi) + 2 * Real.pi := by
        rw [add_mul, one_mul]
      rw [h1, hm]
      linarith
    have h7 : m = 0 := by
      rcases Int.lt_trichotomy m 0 with hz | hz | hz
      · exfalso
        have h10 : ((m + 1 : ℤ) : ℝ) ≤ ((0 : ℤ) : ℝ) :=
          Int.cast_le.mpr (by omega : (m + 1 : ℤ) ≤ 0)
        rw [Int.cast_zero, Int.cast_add, Int.cast_one] at h10
        have h12 : ((m : ℝ) + 1) * (2 * Real.pi) ≤ (0 : ℝ) * (2 * Real.pi) :=
          mul_le_mul_of_nonneg_right h10 h2pi0
        have h13 : (0 : ℝ) * (2 * Real.pi) = 0 := zero_mul _
        rw [h13] at h12
        linarith
      · exact hz
      · exfalso
        have h10 : ((1 : ℤ) : ℝ) ≤ ((m : ℤ) : ℝ) := Int.cast_le.mpr (by omega : (1 : ℤ) ≤ m)
        have h11 : ((1 : ℤ) : ℝ) = (1 : ℝ) := Int.cast_one
        rw [h11] at h10
        linarith
    have hsub : (m : ℝ) = 0 := Int.cast_eq_zero.mpr h7
    have h7eq : ((2 * Real.pi) * (k : ℝ)) / (n : ℝ) = ((2 * Real.pi) * (l : ℝ)) / (n : ℝ) := by
      have h11 : ((2 * Real.pi) * (k : ℝ)) / (n : ℝ) -
          ((2 * Real.pi) * (l : ℝ)) / (n : ℝ) = 0 := by
        rw [← hm, hsub, zero_mul]
      linarith
    have h8 : (2 * Real.pi) * ((k : ℝ) * (n : ℝ)⁻¹) = (2 * Real.pi) * ((l : ℝ) * (n : ℝ)⁻¹) := by
      rwa [← h1k, ← h1l]
    have h9 : (k : ℝ) * (n : ℝ)⁻¹ = (l : ℝ) * (n : ℝ)⁻¹ :=
      mul_left_cancel₀ (ne_of_gt hpi2) h8
    have h10 : (k : ℝ) = (l : ℝ) := mul_right_cancel₀ (inv_ne_zero hnne) h9
    exact Nat.cast_inj.mp h10
  · exact Finset.card_range n

theorem regularNGon_convexIndep_ge5
    (n : Nat)
    (hn : 5 ≤ n) :
    EuclideanGeometry.ConvexIndep
      (↑(Erdos94.regularNGon n) : Set (EuclideanSpace Real (Fin 2))) := by
  intro a ha
  classical
  have coord0 : ∀ (a b : ℝ), (!₂[a, b] : EuclideanSpace ℝ (Fin 2)) 0 = a := by
    intro a b
    simp
  have coord1 : ∀ (a b : ℝ), (!₂[a, b] : EuclideanSpace ℝ (Fin 2)) 1 = b := by
    intro a b
    simp
  let v : ℕ → EuclideanSpace ℝ (Fin 2) :=
    fun k => !₂[Real.cos (2 * Real.pi * (k : ℝ) / (n : ℝ)),
      Real.sin (2 * Real.pi * (k : ℝ) / (n : ℝ))]
  have hv0 : ∀ k : ℕ, (v k) 0 = Real.cos (2 * Real.pi * (k : ℝ) / (n : ℝ)) := by
    intro k
    exact coord0 _ _
  have hv1 : ∀ k : ℕ, (v k) 1 = Real.sin (2 * Real.pi * (k : ℝ) / (n : ℝ)) := by
    intro k
    exact coord1 _ _
  have hvv : ∀ k : ℕ, (v k) 0 * (v k) 0 + (v k) 1 * (v k) 1 = 1 := by
    intro k
    rw [hv0, hv1]
    rw [← sq, ← sq]
    exact Real.cos_sq_add_sin_sq _
  have hsq : ∀ x ∈ (↑(Erdos94.regularNGon n) : Set (EuclideanSpace ℝ (Fin 2))),
      x 0 * x 0 + x 1 * x 1 = 1 := by
    intro x hx
    have hx' : x ∈ (Finset.range n).image v := hx
    rw [Finset.mem_image] at hx'
    obtain ⟨k, _, hk⟩ := hx'
    rw [← hk]
    exact hvv k
  have ha1 : a 0 * a 0 + a 1 * a 1 = 1 := hsq a ha
  -- The open half-space {y | ⟪y, a⟫ < 1} (written in coordinates) is convex.
  have hHC : Convex ℝ {y : EuclideanSpace ℝ (Fin 2) | y 0 * a 0 + y 1 * a 1 < 1} := by
    refine convex_iff_forall_pos.mpr ?_
    intro x hx y hy c d hc hd hcd
    have hx' : x 0 * a 0 + x 1 * a 1 < 1 := hx
    have hy' : y 0 * a 0 + y 1 * a 1 < 1 := hy
    have hgoal : (c • x + d • y) 0 * a 0 + (c • x + d • y) 1 * a 1
        = c * (x 0 * a 0 + x 1 * a 1) + d * (y 0 * a 0 + y 1 * a 1) := by
      have e0 : (c • x + d • y) 0 = c * x 0 + d * y 0 := by simp
      have e1 : (c • x + d • y) 1 = c * x 1 + d * y 1 := by simp
      rw [e0, e1]
      ring
    have h4 : c * (x 0 * a 0 + x 1 * a 1) < c := by
      calc c * (x 0 * a 0 + x 1 * a 1) < c * 1 := mul_lt_mul_of_pos_left hx' hc
        _ = c := by ring
    have h5 : d * (y 0 * a 0 + y 1 * a 1) < d := by
      calc d * (y 0 * a 0 + y 1 * a 1) < d * 1 := mul_lt_mul_of_pos_left hy' hd
        _ = d := by ring
    show (c • x + d • y) 0 * a 0 + (c • x + d • y) 1 * a 1 < 1
    rw [hgoal]
    linarith [h4, h5, hcd]
  -- Every other vertex lies strictly inside that half-space.
  have hsub : (↑(Erdos94.regularNGon n) : Set (EuclideanSpace ℝ (Fin 2))) \ {a} ⊆
      {y : EuclideanSpace ℝ (Fin 2) | y 0 * a 0 + y 1 * a 1 < 1} := by
    intro x hx
    obtain ⟨hxS, hxa⟩ := hx
    show x 0 * a 0 + x 1 * a 1 < 1
    have hx1 : x 0 * x 0 + x 1 * x 1 = 1 := hsq x hxS
    have hne : ¬(x 0 = a 0 ∧ x 1 = a 1) := by
      rintro ⟨h0, h1⟩
      refine hxa ?_
      ext i
      fin_cases i <;> assumption
    have hid : (x 0 - a 0) * (x 0 - a 0) + (x 1 - a 1) * (x 1 - a 1)
        = 2 - 2 * (x 0 * a 0 + x 1 * a 1) := by
      linear_combination hx1 + ha1
    have hne' : (x 0 - a 0) * (x 0 - a 0) + (x 1 - a 1) * (x 1 - a 1) ≠ 0 := by
      intro h
      have k1 : 0 ≤ (x 0 - a 0) * (x 0 - a 0) := mul_self_nonneg _
      have k2 : 0 ≤ (x 1 - a 1) * (x 1 - a 1) := mul_self_nonneg _
      have z1 : (x 0 - a 0) * (x 0 - a 0) = 0 := by linarith
      have z2 : (x 1 - a 1) * (x 1 - a 1) = 0 := by linarith
      have f1 : x 0 - a 0 = 0 := by
        rcases eq_zero_or_eq_zero_of_mul_eq_zero z1 with w | w <;> linarith
      have f2 : x 1 - a 1 = 0 := by
        rcases eq_zero_or_eq_zero_of_mul_eq_zero z2 with w | w <;> linarith
      exact hne ⟨by linarith, by linarith⟩
    have hpos : 0 < (x 0 - a 0) * (x 0 - a 0) + (x 1 - a 1) * (x 1 - a 1) := by
      by_contra h
      apply hne'
      have k1 : 0 ≤ (x 0 - a 0) * (x 0 - a 0) := mul_self_nonneg _
      have k2 : 0 ≤ (x 1 - a 1) * (x 1 - a 1) := mul_self_nonneg _
      linarith
    linarith [hid, hpos]
  have hfin : convexHull ℝ (↑(Erdos94.regularNGon n) \ {a}) ⊆
      {y : EuclideanSpace ℝ (Fin 2) | y 0 * a 0 + y 1 * a 1 < 1} :=
    convexHull_min hsub hHC
  intro hac
  have h2 : a 0 * a 0 + a 1 * a 1 < 1 := hfin hac
  linarith [ha1]

theorem regularNGon_even_distanceSet_card
    (n : Nat)
    (hn : 5 ≤ n)
    (heven : Even n) :
    (distanceSet (Erdos94.regularNGon n)).card = n / 2 := by
  classical
  have hn0 : (n : ℝ) ≠ 0 := by exact_mod_cast (show n ≠ 0 from by omega)
  have hnpos : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (show 0 < n from by omega)
  simp only [distanceSet, Erdos94.regularNGon]
  set f : ℕ → EuclideanSpace ℝ (Fin 2) :=
    fun k => !₂[Real.cos (2 * Real.pi * (k : ℝ) / n), Real.sin (2 * Real.pi * (k : ℝ) / n)] with hf
  have hdist2 : ∀ (a b c d : ℝ),
      dist (!₂[a, b] : EuclideanSpace ℝ (Fin 2)) (!₂[c, d]) =
        Real.sqrt ((a - c) ^ 2 + (b - d) ^ 2) := by
    intro a b c d
    simp [dist, Real.sqrt_eq_rpow]
  have hsq : ∀ a b : ℝ,
      (Real.cos a - Real.cos b) ^ 2 + (Real.sin a - Real.sin b) ^ 2 =
        4 * Real.sin ((a - b) / 2) ^ 2 := by
    intro a b
    have h1 : (Real.cos a - Real.cos b) ^ 2 + (Real.sin a - Real.sin b) ^ 2 =
        2 - 2 * Real.cos (a - b) := by
      rw [Real.cos_sub]
      linear_combination (norm := ring) (Real.sin_sq_add_cos_sq a) + (Real.sin_sq_add_cos_sq b)
    have h2 : Real.cos (a - b) = 2 * Real.cos ((a - b) / 2) ^ 2 - 1 := by
      have h := Real.cos_two_mul ((a - b) / 2)
      rw [show (2 : ℝ) * ((a - b) / 2) = a - b by ring] at h
      exact h
    have h3 : Real.sin ((a - b) / 2) ^ 2 = 1 - Real.cos ((a - b) / 2) ^ 2 := Real.sin_sq _
    rw [h1, h2, h3]
    ring
  have hsqrtsq : ∀ y : ℝ, Real.sqrt (4 * y ^ 2) = 2 * |y| := by
    intro y
    rw [show (4 : ℝ) * y ^ 2 = (2 * y) ^ 2 by ring, Real.sqrt_sq_eq_abs, abs_mul,
      abs_of_pos (by norm_num : (0 : ℝ) < 2)]
  have hdist : ∀ k l : ℕ,
      dist (f k) (f l) = 2 * |Real.sin (Real.pi * ((k : ℝ) - (l : ℝ)) / n)| := by
    intro k l
    have h1 : dist (f k) (f l) =
        Real.sqrt ((Real.cos (2 * Real.pi * (k : ℝ) / n) - Real.cos (2 * Real.pi * (l : ℝ) / n)) ^ 2 +
          (Real.sin (2 * Real.pi * (k : ℝ) / n) - Real.sin (2 * Real.pi * (l : ℝ) / n)) ^ 2) :=
      hdist2 _ _ _ _
    have h2 : (2 * Real.pi * (k : ℝ) / n - 2 * Real.pi * (l : ℝ) / n) / 2 =
        Real.pi * ((k : ℝ) - (l : ℝ)) / n := by
      field_simp
    rw [h1, hsq, h2, hsqrtsq]
  have hsin_pos : ∀ m : ℕ, 1 ≤ m → m < n → 0 < Real.sin (Real.pi * (m : ℝ) / n) := by
    intro m hm1 hm2
    refine Real.sin_pos_of_pos_of_lt_pi (div_pos (mul_pos Real.pi_pos ?_) hnpos) ?_
    · exact_mod_cast (show 0 < m from by omega)
    · refine (div_lt_iff₀ hnpos).mpr (mul_lt_mul_of_pos_left (by exact_mod_cast hm2) Real.pi_pos)
  have hreduce : ∀ m0 : ℕ, 1 ≤ m0 → m0 < n →
      ∃ m ∈ Finset.Icc 1 (n / 2), Real.sin (Real.pi * (m0 : ℝ) / n) = Real.sin (Real.pi * (m : ℝ) / n) := by
    intro m0 hm1 hm2
    refine ⟨min m0 (n - m0), Finset.mem_Icc.mpr ⟨by omega, ?_⟩, ?_⟩
    · rcases lt_or_ge m0 (n - m0) with h | h
      · rw [min_eq_left (by omega : m0 ≤ n - m0)]
        omega
      · rw [min_eq_right h]
        omega
    · rcases lt_or_ge m0 (n - m0) with h | h
      · rw [min_eq_left (by omega : m0 ≤ n - m0)]
      · rw [min_eq_right h]
        have hangle : Real.pi * ((n - m0 : ℕ) : ℝ) / n = Real.pi - Real.pi * (m0 : ℝ) / n := by
          rw [show ((n - m0 : ℕ) : ℝ) = (n : ℝ) - (m0 : ℝ) from Nat.cast_sub (by omega : m0 ≤ n)]
          field_simp
        rw [hangle, Real.sin_pi_sub]
  have key : ∀ m0 : ℕ, 1 ≤ m0 → m0 < n →
      2 * Real.sin (Real.pi * (m0 : ℝ) / n) ∈
        Finset.image (fun m : ℕ => 2 * Real.sin (Real.pi * (m : ℝ) / n)) (Finset.Icc 1 (n / 2)) := by
    intro m0 hm1 hm2
    obtain ⟨m, hm, hme⟩ := hreduce m0 hm1 hm2
    exact Finset.mem_image.mpr ⟨m, hm, by rw [hme]⟩
  have hmain :
      Finset.image (fun pair : EuclideanSpace ℝ (Fin 2) × EuclideanSpace ℝ (Fin 2) =>
        dist pair.1 pair.2) (Finset.image f (Finset.range n)).offDiag =
        Finset.image (fun m : ℕ => 2 * Real.sin (Real.pi * (m : ℝ) / n)) (Finset.Icc 1 (n / 2)) := by
    apply Finset.ext_iff.mpr
    intro r
    constructor
    · intro hr
      obtain ⟨⟨p1, p2⟩, hpm, rfl⟩ := Finset.mem_image.mp hr
      dsimp only at hpm ⊢
      rw [Finset.mem_offDiag] at hpm
      dsimp only at hpm
      obtain ⟨hp1, hp2, hne⟩ := hpm
      obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hp1
      obtain ⟨l, hl, rfl⟩ := Finset.mem_image.mp hp2
      rw [Finset.mem_range] at hk hl
      have hkne : k ≠ l := fun h => hne (congrArg f h)
      rw [hdist k l]
      rcases lt_trichotomy k l with hkl | hkl | hkl
      · have hm0 : 1 ≤ l - k := by omega
        have hm0n : l - k < n := by omega
        have hc : ((l - k : ℕ) : ℝ) = (l : ℝ) - (k : ℝ) :=
          Nat.cast_sub (by omega : k ≤ l)
        have heq : Real.pi * ((k : ℝ) - (l : ℝ)) / n = -(Real.pi * ((l - k : ℕ) : ℝ) / n) := by
          rw [hc]
          field_simp
          ring
        rw [heq, Real.sin_neg, abs_neg, abs_of_pos (hsin_pos (l - k) hm0 hm0n)]
        exact key (l - k) hm0 hm0n
      · exact (hkne hkl).elim
      · have hm0 : 1 ≤ k - l := by omega
        have hm0n : k - l < n := by omega
        have hc : ((k - l : ℕ) : ℝ) = (k : ℝ) - (l : ℝ) :=
          Nat.cast_sub (by omega : l ≤ k)
        rw [← hc, abs_of_pos (hsin_pos (k - l) hm0 hm0n)]
        exact key (k - l) hm0 hm0n
    · intro hr
      obtain ⟨m, hm, rfl⟩ := Finset.mem_image.mp hr
      rw [Finset.mem_Icc] at hm
      have hmn : m < n := by
        have : n / 2 < n := Nat.div_lt_self (by omega : 0 < n) (by norm_num : 1 < 2)
        omega
      have hd0 : dist (f m) (f 0) = 2 * Real.sin (Real.pi * (m : ℝ) / n) := by
        rw [hdist, Nat.cast_zero, sub_zero, abs_of_pos (hsin_pos m hm.1 hmn)]
      have hne : f m ≠ f 0 := by
        intro h
        rw [h, dist_self] at hd0
        linarith [hsin_pos m hm.1 hmn]
      have hmem : (f m, f 0) ∈ (Finset.image f (Finset.range n)).offDiag :=
        Finset.mem_offDiag.mpr ⟨Finset.mem_image_of_mem f (Finset.mem_range.mpr hmn),
          Finset.mem_image_of_mem f (Finset.mem_range.mpr (by omega : 0 < n)), hne⟩
      exact Finset.mem_image.mpr ⟨(f m, f 0), hmem, hd0⟩
  have hstrict : ∀ a b : ℕ, 1 ≤ a → a < b → b ≤ n / 2 →
      Real.sin (Real.pi * (a : ℝ) / n) < Real.sin (Real.pi * (b : ℝ) / n) := by
    intro a b ha hab hb
    have hc : (0 : ℝ) < Real.pi / n := div_pos Real.pi_pos hnpos
    have ha' : -(Real.pi / 2) ≤ Real.pi * (a : ℝ) / n := by
      have : 0 ≤ Real.pi * (a : ℝ) / n := by positivity
      linarith [Real.pi_pos]
    have hb' : Real.pi * (b : ℝ) / n ≤ Real.pi / 2 := by
      have hb2 : (b : ℝ) ≤ (n : ℝ) / 2 := by
        rw [le_div_iff₀ (by norm_num : (0 : ℝ) < 2)]
        have h2 : (2 : ℝ) * (b : ℝ) ≤ (n : ℝ) := by exact_mod_cast (show 2 * b ≤ n from by omega)
        linarith
      calc Real.pi * (b : ℝ) / n = (Real.pi / n) * (b : ℝ) := by ring
        _ ≤ (Real.pi / n) * ((n : ℝ) / 2) := mul_le_mul_of_nonneg_left hb2 (le_of_lt hc)
        _ = Real.pi / 2 := by field_simp
    have hab' : Real.pi * (a : ℝ) / n < Real.pi * (b : ℝ) / n := by
      calc Real.pi * (a : ℝ) / n = (Real.pi / n) * (a : ℝ) := by ring
        _ < (Real.pi / n) * (b : ℝ) := mul_lt_mul_of_pos_left (by exact_mod_cast hab) hc
        _ = Real.pi * (b : ℝ) / n := by ring
    exact Real.sin_lt_sin_of_lt_of_le_pi_div_two ha' hb' hab'
  have hinj : Set.InjOn (fun m : ℕ => 2 * Real.sin (Real.pi * (m : ℝ) / n))
      (↑(Finset.Icc 1 (n / 2))) := by
    intro a ha b hb hab
    simp only [Finset.mem_coe, Finset.mem_Icc] at ha hb
    dsimp only at hab
    rcases lt_trichotomy a b with h | h | h
    · have := hstrict a b ha.1 h hb.2
      linarith
    · exact h
    · have := hstrict b a hb.1 h ha.2
      linarith
  have hIcccard : (Finset.Icc 1 (n / 2)).card = n / 2 := by
    have h : Finset.Icc 1 (n / 2) = (Finset.range (n / 2)).image (fun i => i + 1) := by
      apply Finset.ext_iff.mpr
      intro x
      constructor
      · intro hx
        have hx' : 1 ≤ x ∧ x ≤ n / 2 := Finset.mem_Icc.mp hx
        refine Finset.mem_image.mpr ⟨x - 1, Finset.mem_range.mpr (by omega), ?_⟩
        show x - 1 + 1 = x
        omega
      · intro hx
        obtain ⟨i, hi, he⟩ := Finset.mem_image.mp hx
        have hhi : i < n / 2 := Finset.mem_range.mp hi
        have h2 : i + 1 = x := he
        exact Finset.mem_Icc.mpr ⟨by omega, by omega⟩
    have hinj2 : Set.InjOn (fun i : ℕ => i + 1) (↑(Finset.range (n / 2))) := by
      intro a _ b _ hab
      have h2 : a + 1 = b + 1 := hab
      omega
    rw [h, Finset.card_image_of_injOn hinj2, Finset.card_range]
  have hcard : (Finset.image (fun m : ℕ => 2 * Real.sin (Real.pi * (m : ℝ) / n))
      (Finset.Icc 1 (n / 2))).card = n / 2 := by
    rw [Finset.card_image_of_injOn hinj, hIcccard]
  rw [hmain]
  exact hcard

theorem regularNGon_even_distanceMultiplicity_chord_bound
    (n : Nat)
    (hn : 5 ≤ n)
    (heven : Even n) :
    ∀ d ∈ distanceSet (Erdos94.regularNGon n),
      distanceMultiplicity (Erdos94.regularNGon n) d ≤ n := by
  intro d hd
  have hn0 : 0 < n := by omega
  have hnR : (0 : ℝ) < (n : ℝ) := by exact_mod_cast hn0
  let f : ℕ → EuclideanSpace ℝ (Fin 2) := fun k =>
    !₂[Real.cos (2 * Real.pi * (k : ℝ) / n), Real.sin (2 * Real.pi * (k : ℝ) / n)]
  have hP : Erdos94.regularNGon n = Finset.image f (Finset.range n) := rfl
  have hc0 (k : ℕ) : f k 0 = Real.cos (2 * Real.pi * (k : ℝ) / n) := rfl
  have hc1 (k : ℕ) : f k 1 = Real.sin (2 * Real.pi * (k : ℝ) / n) := rfl
  have htrig (a b : ℝ) :
      (Real.cos a - Real.cos b) ^ 2 + (Real.sin a - Real.sin b) ^ 2 = 2 - 2 * Real.cos (a - b) := by
    rw [Real.cos_sub]
    nlinarith [Real.cos_sq_add_sin_sq a, Real.cos_sq_add_sin_sq b]
  have hdist (k j : ℕ) :
      dist (f k) (f j) =
        Real.sqrt (2 - 2 * Real.cos (2 * Real.pi * (k : ℝ) / n - 2 * Real.pi * (j : ℝ) / n)) := by
    rw [EuclideanSpace.dist_eq, Fin.sum_univ_two]
    simp only [Real.dist_eq, sq_abs, hc0, hc1]
    rw [htrig]
  have hrot (k m : ℕ) (hk : k < n) (hm : m < n) :
      Real.cos (2 * Real.pi * (k : ℝ) / n - 2 * Real.pi * (((k + m) % n : ℕ) : ℝ) / n) =
        Real.cos (2 * Real.pi * (m : ℝ) / n) := by
    by_cases hlt : k + m < n
    · have h1 : (k + m) % n = k + m := Nat.mod_eq_of_lt hlt
      rw [h1]
      have h2 : 2 * Real.pi * (k : ℝ) / n - 2 * Real.pi * ((k + m : ℕ) : ℝ) / n =
          -(2 * Real.pi * (m : ℝ) / n) := by
        push_cast
        field_simp [hnR.ne']
        ring
      rw [h2, Real.cos_neg]
    · have hge : n ≤ k + m := by omega
      have h1 : (k + m) % n = k + m - n := by
        have h2 : k + m = n + (k + m - n) := by omega
        rw [h2, Nat.add_comm, Nat.add_mod, Nat.mod_self, Nat.add_zero]
        try rw [Nat.mod_eq_of_lt (by omega : k + m - n < n)]
        try rw [Nat.mod_eq_of_lt (by omega : k + m - n < n)]
        try omega
      rw [h1]
      have h2 : ((k + m - n : ℕ) : ℝ) = (k : ℝ) + m - n := by
        rw [Nat.cast_sub hge, Nat.cast_add]
      have h3 : 2 * Real.pi * (k : ℝ) / n - 2 * Real.pi * ((k + m - n : ℕ) : ℝ) / n =
          2 * Real.pi - 2 * Real.pi * (m : ℝ) / n := by
        rw [h2]
        field_simp [hnR.ne']
        ring
      have h4 : Real.cos (2 * Real.pi - 2 * Real.pi * (m : ℝ) / n) =
          Real.cos (2 * Real.pi * (m : ℝ) / n) := by
        rw [Real.cos_sub, Real.cos_two_pi, Real.sin_two_pi]
        ring
      rw [h3, h4]
  have hsqrt (m : ℕ) (hm : m < n) :
      Real.sqrt (2 - 2 * Real.cos (2 * Real.pi * (m : ℝ) / n)) =
        2 * Real.sin (Real.pi * (m : ℝ) / n) := by
    have hx0 : (0 : ℝ) ≤ Real.pi * (m : ℝ) / n :=
      div_nonneg (mul_nonneg (le_of_lt Real.pi_pos) (Nat.cast_nonneg _)) (Nat.cast_nonneg _)
    have hx1 : Real.pi * (m : ℝ) / n ≤ Real.pi := by
      have h1 : (m : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : m ≤ n)
      have h2 : Real.pi * (m : ℝ) ≤ Real.pi * (n : ℝ) :=
        mul_le_mul_of_nonneg_left h1 (le_of_lt Real.pi_pos)
      rw [div_le_iff₀ hnR]
      exact h2
    have hs : 0 ≤ Real.sin (Real.pi * (m : ℝ) / n) := Real.sin_nonneg_of_mem_Icc ⟨hx0, hx1⟩
    have hE : (2 : ℝ) - 2 * Real.cos (2 * Real.pi * (m : ℝ) / n) =
        (2 * Real.sin (Real.pi * (m : ℝ) / n)) ^ 2 := by
      have h1 : 2 * Real.pi * (m : ℝ) / n = 2 * (Real.pi * (m : ℝ) / n) := by ring
      rw [h1, Real.cos_two_mul']
      nlinarith [Real.cos_sq_add_sin_sq (Real.pi * (m : ℝ) / n)]
    rw [hE, Real.sqrt_sq (by linarith : (0 : ℝ) ≤ 2 * Real.sin (Real.pi * (m : ℝ) / n))]
  have hsin_eq (k j : ℕ) (hk : k < n) (hj : j < n) :
      dist (f k) (f ((k + j) % n)) = 2 * Real.sin (Real.pi * (j : ℝ) / n) := by
    rw [hdist, hrot k j hk hj]
    exact hsqrt j hj
  have hadd_mod_cancel (k j : ℕ) (hk : k < n) (hj : j < n) :
      (k + (j + n - k) % n) % n = j := by
    by_cases hle : k ≤ j
    · have h1 : j + n - k = n + (j - k) := by omega
      have h2 : (j + n - k) % n = j - k := by
        rw [h1, Nat.add_comm, Nat.add_mod, Nat.mod_self, Nat.add_zero, Nat.mod_mod]
        exact Nat.mod_eq_of_lt (by omega : j - k < n)
      rw [h2]
      have h3 : k + (j - k) = j := by omega
      rw [h3]
      exact Nat.mod_eq_of_lt hj
    · have h1 : j + n - k < n := by omega
      have h2 : (j + n - k) % n = j + n - k := Nat.mod_eq_of_lt h1
      rw [h2]
      have h3 : k + (j + n - k) = j + n := by omega
      rw [h3, Nat.add_mod, Nat.mod_self, Nat.add_zero, Nat.mod_mod]
      exact Nat.mod_eq_of_lt hj
  have hsin_inj : ∀ x y : ℝ, x ∈ Set.Icc 0 (Real.pi / 2) → y ∈ Set.Icc 0 (Real.pi / 2) →
      Real.sin x = Real.sin y → x = y := by
    intro x y hx hy h
    have h0 : 0 ≤ Real.pi / 2 := by positivity
    rcases lt_trichotomy x y with hxy | rfl | hxy
    · have hlt : Real.sin x < Real.sin y := by
        refine Real.sin_lt_sin_of_lt_of_le_pi_div_two ?_ ?_ hxy
        · linarith [hx.1, h0]
        · linarith [hy.2]
      linarith [h]
    · rfl
    · have hlt : Real.sin y < Real.sin x := by
        refine Real.sin_lt_sin_of_lt_of_le_pi_div_two ?_ ?_ hxy
        · linarith [hy.1, h0]
        · linarith [hx.2]
      linarith [h]
  have hcancel {x y : ℕ} (h : Real.pi * (x : ℝ) / n = Real.pi * (y : ℝ) / n) : x = y := by
    have h1 : (Real.pi / (n : ℝ)) * (x : ℝ) = Real.pi * (x : ℝ) / n := by ring
    have h2 : (Real.pi / (n : ℝ)) * (y : ℝ) = Real.pi * (y : ℝ) / n := by ring
    have h3 : (Real.pi / (n : ℝ)) * (x : ℝ) = (Real.pi / (n : ℝ)) * (y : ℝ) := by
      rw [h1, h2]
      exact h
    have hπ : (Real.pi / (n : ℝ)) ≠ 0 :=
      div_ne_zero Real.pi_ne_zero (by exact_mod_cast (by omega : n ≠ 0))
    exact_mod_cast mul_left_cancel₀ hπ h3
  have hbound1 : ∀ m : ℕ, m < n → 2 * m ≤ n →
      (Real.pi * (m : ℝ) / n) ∈ Set.Icc 0 (Real.pi / 2) := by
    intro m hm hle
    refine ⟨?_, ?_⟩
    · refine div_nonneg (mul_nonneg (le_of_lt Real.pi_pos) (Nat.cast_nonneg _)) (Nat.cast_nonneg _)
    · have h1 : Real.pi * (m : ℝ) * 2 ≤ Real.pi * (n : ℝ) := by
        have h2 : (2 : ℝ) * (m : ℝ) ≤ (n : ℝ) := by exact_mod_cast hle
        nlinarith [Real.pi_pos]
      rw [div_le_div_iff₀ hnR (show (0 : ℝ) < 2 by norm_num)]
      nlinarith [h1]
  have hbound2 : ∀ m : ℕ, m < n → 2 * m > n →
      (Real.pi * (m : ℝ) / n) ∈ Set.Icc (Real.pi / 2) Real.pi := by
    intro m hm hgt
    refine ⟨?_, ?_⟩
    · have h1 : (n : ℝ) ≤ (2 : ℝ) * (m : ℝ) := by exact_mod_cast (by omega : n ≤ 2 * m)
      rw [div_le_div_iff₀ (show (0 : ℝ) < 2 by norm_num) hnR]
      nlinarith [h1, Real.pi_pos]
    · have h1 : (m : ℝ) ≤ (n : ℝ) := by exact_mod_cast (by omega : m ≤ n)
      have h2 : Real.pi * (m : ℝ) ≤ Real.pi * (n : ℝ) :=
        mul_le_mul_of_nonneg_left h1 (le_of_lt Real.pi_pos)
      rw [div_le_iff₀ hnR]
      exact h2
  set T : Finset ℕ :=
    ((Finset.range n).filter (fun m : ℕ => 2 * Real.sin (Real.pi * (m : ℝ) / n) = d)) with hTd
  have hTcard : T.card ≤ 2 := by
    have hne1 : (T.filter (fun m => 2 * m ≤ n)).card ≤ 1 := by
      refine Finset.card_le_one.mpr ?_
      intro x hx y hy
      have hxT : x ∈ T := (Finset.mem_filter.mp hx).1
      have hyT : y ∈ T := (Finset.mem_filter.mp hy).1
      rw [hTd] at hxT hyT
      have hxn : x < n := Finset.mem_range.mp (Finset.mem_filter.mp hxT).1
      have hyn : y < n := Finset.mem_range.mp (Finset.mem_filter.mp hyT).1
      have hxm : 2 * x ≤ n := (Finset.mem_filter.mp hx).2
      have hym : 2 * y ≤ n := (Finset.mem_filter.mp hy).2
      have hs : Real.sin (Real.pi * (x : ℝ) / n) = Real.sin (Real.pi * (y : ℝ) / n) := by
        have hxv : (2 : ℝ) * Real.sin (Real.pi * (x : ℝ) / n) = d := (Finset.mem_filter.mp hxT).2
        have hyv : (2 : ℝ) * Real.sin (Real.pi * (y : ℝ) / n) = d := (Finset.mem_filter.mp hyT).2
        linarith
      have hEq : Real.pi * (x : ℝ) / n = Real.pi * (y : ℝ) / n :=
        hsin_inj _ _ (hbound1 x hxn hxm) (hbound1 y hyn hym) hs
      exact hcancel hEq
    have hne2 : (T.filter (fun m => 2 * m > n)).card ≤ 1 := by
      refine Finset.card_le_one.mpr ?_
      intro x hx y hy
      have hxT : x ∈ T := (Finset.mem_filter.mp hx).1
      have hyT : y ∈ T := (Finset.mem_filter.mp hy).1
      rw [hTd] at hxT hyT
      have hxn : x < n := Finset.mem_range.mp (Finset.mem_filter.mp hxT).1
      have hyn : y < n := Finset.mem_range.mp (Finset.mem_filter.mp hyT).1
      have hxm : 2 * x > n := (Finset.mem_filter.mp hx).2
      have hym : 2 * y > n := (Finset.mem_filter.mp hy).2
      have hs : Real.sin (Real.pi * (x : ℝ) / n) = Real.sin (Real.pi * (y : ℝ) / n) := by
        have hxv : (2 : ℝ) * Real.sin (Real.pi * (x : ℝ) / n) = d := (Finset.mem_filter.mp hxT).2
        have hyv : (2 : ℝ) * Real.sin (Real.pi * (y : ℝ) / n) = d := (Finset.mem_filter.mp hyT).2
        linarith
      have hIx : (Real.pi * (x : ℝ) / n) ∈ Set.Icc (Real.pi / 2) Real.pi := hbound2 x hxn hxm
      have hIy : (Real.pi * (y : ℝ) / n) ∈ Set.Icc (Real.pi / 2) Real.pi := hbound2 y hyn hym
      have h2 : Real.sin (Real.pi - Real.pi * (x : ℝ) / n) =
          Real.sin (Real.pi - Real.pi * (y : ℝ) / n) := by
        rw [Real.sin_pi_sub, Real.sin_pi_sub, hs]
      have hJx : (Real.pi - Real.pi * (x : ℝ) / n) ∈ Set.Icc 0 (Real.pi / 2) := by
        have h1 : Real.pi / 2 ≤ Real.pi * (x : ℝ) / n := (Set.mem_Icc.mp hIx).1
        have h2' : Real.pi * (x : ℝ) / n ≤ Real.pi := (Set.mem_Icc.mp hIx).2
        exact Set.mem_Icc.mpr ⟨by linarith, by linarith⟩
      have hJy : (Real.pi - Real.pi * (y : ℝ) / n) ∈ Set.Icc 0 (Real.pi / 2) := by
        have h1 : Real.pi / 2 ≤ Real.pi * (y : ℝ) / n := (Set.mem_Icc.mp hIy).1
        have h2' : Real.pi * (y : ℝ) / n ≤ Real.pi := (Set.mem_Icc.mp hIy).2
        exact Set.mem_Icc.mpr ⟨by linarith, by linarith⟩
      have hEq : Real.pi - Real.pi * (x : ℝ) / n = Real.pi - Real.pi * (y : ℝ) / n :=
        hsin_inj _ _ hJx hJy h2
      have h4 : Real.pi * (x : ℝ) / n = Real.pi * (y : ℝ) / n := by linarith
      exact hcancel h4
    have hunion : T ⊆ T.filter (fun m => 2 * m ≤ n) ∪ T.filter (fun m => 2 * m > n) := by
      intro m hm
      by_cases hle : 2 * m ≤ n
      · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨hm, hle⟩)
      · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨hm, by omega⟩)
    calc T.card ≤ (T.filter (fun m => 2 * m ≤ n) ∪ T.filter (fun m => 2 * m > n)).card :=
          Finset.card_le_card hunion
      _ ≤ (T.filter (fun m => 2 * m ≤ n)).card + (T.filter (fun m => 2 * m > n)).card :=
          Finset.card_union_le _ _
      _ ≤ 2 := by omega
  have hmain : {pair ∈ (Erdos94.regularNGon n).offDiag | dist pair.1 pair.2 = d}.card ≤ 2 * n := by
    have hsub : {pair ∈ (Erdos94.regularNGon n).offDiag | dist pair.1 pair.2 = d} ⊆
        ((Finset.range n) ×ˢ T).image
          (fun p : ℕ × ℕ => (f p.1, f ((p.1 + p.2) % n))) := by
      intro q hq
      cases q with
      | mk x y =>
        obtain ⟨hqod, hqd⟩ := Finset.mem_filter.mp hq
        have hqd' : dist x y = d := hqd
        obtain ⟨hx, hy, _hne⟩ := Finset.mem_offDiag.mp hqod
        rw [hP] at hx hy
        obtain ⟨k, hk, rfl⟩ := Finset.mem_image.mp hx
        obtain ⟨j, hj, rfl⟩ := Finset.mem_image.mp hy
        have hkn : k < n := Finset.mem_range.mp hk
        have hjn : j < n := Finset.mem_range.mp hj
        have hA : (k + (j + n - k) % n) % n = j := hadd_mod_cancel k j hkn hjn
        have hmT : (j + n - k) % n ∈ T := by
          rw [hTd]
          refine Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (Nat.mod_lt _ (by omega)), ?_⟩
          have h2 : dist (f k) (f ((k + (j + n - k) % n) % n)) =
              2 * Real.sin (Real.pi * (((j + n - k) % n : ℕ) : ℝ) / n) :=
            hsin_eq k ((j + n - k) % n) hkn (Nat.mod_lt _ (by omega))
          rw [hA] at h2
          exact h2.symm.trans hqd'
        have hp2 : (k, (j + n - k) % n) ∈ (Finset.range n) ×ˢ T := by
          simpa using And.intro (Finset.mem_range.mpr hkn) hmT
        have he2 : (f k, f ((k + (j + n - k) % n) % n)) = (f k, f j) := by
          rw [hA]
        exact Finset.mem_image.mpr ⟨(k, (j + n - k) % n), hp2, he2⟩
    calc {pair ∈ (Erdos94.regularNGon n).offDiag | dist pair.1 pair.2 = d}.card
        ≤ (((Finset.range n) ×ˢ T).image
            (fun p : ℕ × ℕ => (f p.1, f ((p.1 + p.2) % n)))).card :=
          Finset.card_le_card hsub
      _ ≤ ((Finset.range n) ×ˢ T).card := Finset.card_image_le
      _ = (Finset.range n).card * T.card := Finset.card_product (Finset.range n) T
      _ = n * T.card := by rw [Finset.card_range]
      _ ≤ n * 2 := Nat.mul_le_mul_left n hTcard
      _ ≤ 2 * n := by omega
  calc distanceMultiplicity (Erdos94.regularNGon n) d
      = {pair ∈ (Erdos94.regularNGon n).offDiag | dist pair.1 pair.2 = d}.card / 2 := rfl
    _ ≤ (2 * n) / 2 := Nat.div_le_div_right hmain
    _ = n := Nat.mul_div_cancel_left n (by norm_num : 0 < 2)

#ga_audit_proof multiplicity_sum_identity
#ga_audit_proof nat_choose_two_div
#ga_audit_proof multiplicity_square_integer_optimization
#ga_audit_proof multiplicitySquareOptimal_rhs_odd
#ga_audit_proof multiplicitySquareOptimal_rhs_even
#ga_audit_proof sumsq_constant_of_card_and_eq
#ga_audit_proof sumsq_one_diameter_partition
#ga_audit_proof distanceMultiplicity_sum_nat_choose_of_card
#ga_audit_proof multiplicity_square_sum_optimum_le
#ga_audit_proof not_forall_le_nat
#ga_audit_proof regularNGon_even_multiplicitySquareSum_closed_form_of_data
#ga_audit_proof eventually_of_convex_independent_multiplicity_sum_bound_threshold
#ga_audit_proof multiplicity_total_even_partition
#ga_audit_proof multiplicity_total_odd
#ga_audit_proof nat_eq_of_sum_eq_mul_card_of_le
#ga_audit_proof nat_eq_of_sum_one_exceptional
#ga_audit_proof regularNGon_card_ge5
#ga_audit_proof regularNGon_convexIndep_ge5
#ga_audit_proof regularNGon_even_distanceSet_card
#ga_audit_proof regularNGon_even_distanceMultiplicity_chord_bound
