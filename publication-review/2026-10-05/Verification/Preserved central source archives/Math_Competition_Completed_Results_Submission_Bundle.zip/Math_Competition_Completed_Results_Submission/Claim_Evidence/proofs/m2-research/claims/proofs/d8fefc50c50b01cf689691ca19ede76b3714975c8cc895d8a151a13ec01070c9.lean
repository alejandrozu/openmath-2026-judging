import Mathlib
import Lean
import FormalConjectures.OEIS.«77408»

set_option google.answer "postpone"

-- Already imported, audited repository definitions (do not redeclare):
-- def OeisA77408.IsBasePalindrome : ℕ → ℕ → Prop := fun b n => n = OeisA77408.revBase b n
-- 
-- def OeisA77408.a : ℕ → ℕ := fun x => Nat.brecOn x OeisA77408.a._f

namespace GAConjectureAudit

-- Keep parser/elaborator namespaces local to these commands. Leaking `open
-- Lean` into generated mathematics makes Lean.Module shadow Mathlib.Module.
open Lean Elab Command Meta

def allowedAxiom (n : Name) : Bool :=
  n == ``propext || n == ``Classical.choice || n == ``Quot.sound

syntax (name := auditProof) "#ga_audit_proof " ident : command
@[command_elab auditProof]
def elabAuditProof : CommandElab := fun stx => do
  let name ← resolveGlobalConstNoOverload stx[1]
  let info ← getConstInfo name
  unless info.isTheorem do throwError "GA audit requires a theorem"
  let axs ← collectAxioms name
  let bad := axs.filter (!allowedAxiom ·)
  unless bad.isEmpty do throwError "Untrusted transitive proof axioms: {bad}"
  logInfo m!"GA_AUDIT_OK {name}: {axs}"

syntax (name := auditTarget) "#ga_audit_target " ident " against " ident : command
@[command_elab auditTarget]
def elabAuditTarget : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Target universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type expected.type do
      throwError "Target type differs from pinned original"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

syntax (name := auditRefutation) "#ga_audit_refutation " ident " against " ident : command
@[command_elab auditRefutation]
def elabAuditRefutation : CommandElab := fun stx => do
  let actual ← getConstInfo (← resolveGlobalConstNoOverload stx[1])
  let expected ← getConstInfo (← resolveGlobalConstNoOverload stx[3])
  unless actual.levelParams == expected.levelParams do
    throwError "Refutation universe parameters changed"
  liftTermElabM do
    unless ← isDefEq actual.type (mkApp (mkConst ``Not) expected.type) do
      throwError "Refutation is not the negation of the entire pinned statement"
  logInfo m!"GA_TARGET_TYPE_OK {actual.name}"

end GAConjectureAudit

theorem ga_ofDigits_digits_three (x : Nat) :
    Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) x) = x := by
  exact Nat.ofDigits_digits 3 x

theorem ga_a_ofDigits_digits (n : Nat) :
    Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) (OeisA77408.a n)) =
      OeisA77408.a n := by
  exact ga_ofDigits_digits_three (OeisA77408.a n)

theorem ga_a_succ_eq :
    ∀ n : Nat,
      OeisA77408.a (n + 1) =
        OeisA77408.a n + OeisA77408.revBase (3 : Nat) (OeisA77408.a n) := by
  intro n
  rfl

theorem ga_a_succ_digits_eq_add_rev (n : Nat) :
    Nat.digits (3 : Nat) (OeisA77408.a (n + 1)) =
      Nat.digits (3 : Nat)
        (OeisA77408.a n + OeisA77408.revBase (3 : Nat) (OeisA77408.a n)) := by
  rw [ga_a_succ_eq]

def ga_addRevBase3_carryFree (d : List Nat) : Prop :=
  ∀ p ∈ d.zip d.reverse, p.1 + p.2 < 3

theorem ga_addRevBase3_carryFree_iff_pair_sums {ds : List Nat} :
    ga_addRevBase3_carryFree ds ↔
      ∀ p ∈ ds.zip ds.reverse, p.1 + p.2 < 3 := by
  simp only [ga_addRevBase3_carryFree]

def ga_dsum3 (d : List Nat) : List Nat :=
  List.zipWith (· + ·) d d.reverse

theorem ga_dsum3_eq_zipWith (d : List Nat) :
    ga_dsum3 d = List.zipWith (· + ·) d d.reverse := by rfl

theorem ga_dsum3_mem_iff (d : List Nat) (a : Nat) :
    a ∈ ga_dsum3 d ↔ ∃ p ∈ d.zip d.reverse, p.1 + p.2 = a := by
  have key : ∀ (l l' : List Nat), List.zipWith (· + ·) l l' = (l.zip l').map (fun p => p.1 + p.2) := by
    intro l
    induction l with
    | nil => intro l'; rfl
    | cons x xs ih =>
      intro l'
      cases l' with
      | nil => rfl
      | cons y ys => simp [List.zipWith_cons_cons, List.zip_cons_cons, ih]
  rw [ga_dsum3_eq_zipWith, key d d.reverse, List.mem_map]

theorem ga_addRevBase3_carryFree_iff_dsum_le_two (d : List Nat) :
    ga_addRevBase3_carryFree d ↔ ∀ e ∈ ga_dsum3 d, e ≤ (2 : Nat) := by
  constructor
  · intro h e he
    obtain ⟨p, hp, rfl⟩ : ∃ p ∈ d.zip d.reverse, p.1 + p.2 = e :=
      (ga_dsum3_mem_iff d e).mp he
    have hlt : p.1 + p.2 < 3 := h p hp
    omega
  · intro h
    show ∀ p ∈ d.zip d.reverse, p.1 + p.2 < 3
    intro p hp
    have hmem : p.1 + p.2 ∈ ga_dsum3 d := (ga_dsum3_mem_iff d _).mpr ⟨p, hp, rfl⟩
    have hle : p.1 + p.2 ≤ 2 := h (p.1 + p.2) hmem
    omega

theorem ga_revBase_digits_reverse (m : Nat) :
    OeisA77408.revBase (3 : Nat) m =
      Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) m).reverse := by
  exact rfl

theorem ga_ofDigits_zipWith_add (as bs : List Nat)
    (h : as.length = bs.length) :
    Nat.ofDigits (3 : Nat) (List.zipWith (· + ·) as bs) =
      Nat.ofDigits (3 : Nat) as + Nat.ofDigits (3 : Nat) bs := by
  induction as generalizing bs with
  | nil =>
      cases bs with
      | nil => rfl
      | cons c t => exact absurd h (by simp)
  | cons a t ih =>
      cases bs with
      | nil => exact absurd h (by simp)
      | cons c t' =>
          have hl : t.length = t'.length := by simpa using h
          simp [Nat.ofDigits, List.zipWith, ih t' hl]
          ring

theorem ga_dsum3_length (d : List Nat) :
    (ga_dsum3 d).length = d.length := by
  unfold ga_dsum3
  rw [List.length_zipWith, List.length_reverse, Nat.min_self]

theorem ga_ofDigits_ga_dsum3 (d : List Nat) :
    Nat.ofDigits (3 : Nat) (ga_dsum3 d) =
      Nat.ofDigits (3 : Nat) d + Nat.ofDigits (3 : Nat) d.reverse := by
  rw [ga_dsum3_eq_zipWith]
  exact ga_ofDigits_zipWith_add d d.reverse List.length_reverse.symm

theorem ga_addRevBase3_dsum_ofDigits (x : Nat) :
    x + OeisA77408.revBase (3 : Nat) x =
      Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x)) := by
  have h3 : Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) x) +
      Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) x).reverse =
      Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x)) :=
    (ga_ofDigits_ga_dsum3 (Nat.digits (3 : Nat) x)).symm
  calc x + OeisA77408.revBase (3 : Nat) x
      = x + Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) x).reverse := by
        rw [ga_revBase_digits_reverse x]
    _ = Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) x) +
        Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) x).reverse := by
        rw [ga_ofDigits_digits_three x]
    _ = Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x)) := h3

theorem ga_digits_getLast_option_ne_zero {x : Nat} (hx : x ≠ 0) :
    List.getLast? (Nat.digits (3 : Nat) x) ≠ some 0 := by
  revert hx
  refine Nat.strongRecOn x ?_
  intro y ih hy
  cases y with
  | zero => exact (hy rfl).elim
  | succ y =>
    have hb : 1 < (3 : Nat) := by decide
    have hpos : 0 < y + 1 := Nat.succ_pos y
    have hd : Nat.digits 3 (y + 1) = (y + 1) % 3 :: Nat.digits 3 ((y + 1) / 3) :=
      Nat.digits_def' hb hpos
    have hlt : (y + 1) / 3 < y + 1 := Nat.div_lt_self hpos (by decide : 1 < 3)
    have hlist : ∀ (d : Nat) (l : List Nat), l ≠ [] → List.getLast? (d :: l) = List.getLast? l := by
      intro d l hl
      cases l with
      | nil => exact (hl rfl).elim
      | cons a as =>
        cases as with
        | nil => first | rfl | simp | trivial
        | cons b bs => first | rfl | simp | trivial
    by_cases hz : (y + 1) / 3 = 0
    · have hlt3 : y + 1 < 3 := by omega
      have hmod : (y + 1) % 3 = y + 1 := Nat.mod_eq_of_lt hlt3
      have hlast : List.getLast? (((y + 1) : Nat) :: []) = some (y + 1) := by
        first | rfl | simp | trivial
      rw [hd, hz, Nat.digits_zero, hmod, hlast]
      intro hc
      exact absurd (Option.some.inj hc) hy
    · rw [hd]
      have hne : Nat.digits 3 ((y + 1) / 3) ≠ [] := Nat.digits_ne_nil_iff_ne_zero.mpr hz
      rw [hlist ((y + 1) % 3) (Nat.digits 3 ((y + 1) / 3)) hne]
      exact ih ((y + 1) / 3) hlt hz

theorem ga_digits_ofDigits_three {xs : List Nat}
    (hlt : ∀ e ∈ xs, e < (3 : Nat))
    (hlast : List.getLast? xs ≠ some 0) :
    Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) xs) = xs := by
  refine Nat.digits_ofDigits (3 : Nat) (by decide) xs hlt ?_
  intro h hz
  have h1 : xs.getLast? = some (xs.getLast h) := by
    cases xs with
    | nil => contradiction
    | cons a l =>
      cases l with
      | nil => rfl
      | cons b m => rfl
  rw [h1] at hlast
  exact hlast (congrArg some hz)

theorem ga_digits_lt_base_three (x : Nat) :
    ∀ d ∈ Nat.digits (3 : Nat) x, d < (3 : Nat) := by
  intro d hd
  exact Nat.digits_lt_base (b := 3) (m := x) (d := d) (by norm_num : 1 < 3) hd

theorem ga_dsum3_reverse (d : List Nat) :
    (ga_dsum3 d).reverse = ga_dsum3 d := by
  have hl : d.length = d.reverse.length := by simp
  have heq : (fun (b a : Nat) => a + b) = (· + ·) := by
    funext x y
    exact add_comm y x
  calc (ga_dsum3 d).reverse
      = List.zipWith (· + ·) d.reverse (d.reverse).reverse := by
          rw [ga_dsum3_eq_zipWith, List.reverse_zipWith hl]
    _ = List.zipWith (· + ·) d.reverse d := by rw [List.reverse_reverse]
    _ = List.zipWith (fun b a => a + b) d d.reverse := by rw [List.zipWith_comm]
    _ = List.zipWith (· + ·) d d.reverse := by rw [heq]
    _ = ga_dsum3 d := (ga_dsum3_eq_zipWith d).symm

theorem ga_dsum3_lt_three_imp_le_four {d : List Nat} (hd : ∀ e ∈ d, e < (3 : Nat)) :
    ∀ e ∈ ga_dsum3 d, e ≤ (4 : Nat) := by
  have key : ∀ (xs ys : List Nat), ∀ z ∈ List.zipWith (· + ·) xs ys, ∃ x ∈ xs, ∃ y ∈ ys, x + y = z := by
    intro xs
    induction xs with
    | nil =>
      intro ys z hz
      have hnil : List.zipWith (· + ·) ([] : List Nat) ys = [] := by rfl
      rw [hnil] at hz
      exact absurd hz List.not_mem_nil
    | cons a as ih =>
      intro ys z hz
      cases ys with
      | nil =>
        have hnil : List.zipWith (· + ·) (a :: as) ([] : List Nat) = [] := by rfl
        rw [hnil] at hz
        exact absurd hz List.not_mem_nil
      | cons b bs =>
        have hc : List.zipWith (· + ·) (a :: as) (b :: bs) = (a + b) :: List.zipWith (· + ·) as bs := by rfl
        rw [hc] at hz
        cases List.mem_cons.mp hz with
        | inl h =>
          subst h
          exact ⟨a, List.mem_cons.mpr (Or.inl rfl), b, List.mem_cons.mpr (Or.inl rfl), rfl⟩
        | inr h =>
          obtain ⟨x, hx, y, hy, rfl⟩ := ih bs z h
          exact ⟨x, List.mem_cons.mpr (Or.inr hx), y, List.mem_cons.mpr (Or.inr hy), rfl⟩
  intro e he
  rw [ga_dsum3_eq_zipWith] at he
  obtain ⟨x, hx, y, hy, rfl⟩ := key d d.reverse e he
  have hx' : x < 3 := hd x hx
  have hy' : y < 3 := hd y (List.mem_reverse.mp hy)
  omega

theorem ga_dsum3_zero_four_to_zip {d : List Nat}
    (h : ∀ e ∈ ga_dsum3 d, e = (0 : Nat) ∨ e = (4 : Nat)) :
    ∀ p ∈ d.zip d.reverse, p.1 + p.2 = (0 : Nat) ∨ p.1 + p.2 = (4 : Nat) := by
  intro p hp
  have hmem : p.1 + p.2 ∈ ga_dsum3 d := (ga_dsum3_mem_iff d _).2 ⟨p, hp, rfl⟩
  exact h _ hmem

theorem ga_digits_last_ne_zero {x : Nat} :
    List.getLast? (Nat.digits (3 : Nat) x) ≠ some 0 := by
  cases Nat.eq_zero_or_pos x with
  | inl h =>
      subst h
      simp
  | inr h =>
      exact ga_digits_getLast_option_ne_zero (Nat.ne_of_gt h)

theorem ga_ofDigits_base3_le_of_entries_le_two {v : List Nat}
    (h : ∀ a ∈ v, a ≤ (2 : Nat)) :
    Nat.ofDigits (3 : Nat) v ≤ (3 : Nat) ^ v.length - 1 := by
  revert h
  induction v with
  | nil =>
      intro _
      simp
  | cons a t ih =>
      intro h
      have ha : a ≤ 2 := h a List.mem_cons_self
      have ht : ∀ b ∈ t, b ≤ 2 := fun b hb => h b (List.mem_cons_of_mem a hb)
      have H : ∀ k : ℕ, 1 ≤ k → 2 + 3 * (k - 1) = k * 3 - 1 := by
        intro k hk
        omega
      have hk : 1 ≤ (3 : ℕ) ^ t.length := by
        have hp : 0 < (3 : ℕ) ^ t.length := pow_pos (by decide : (0 : ℕ) < 3) _
        omega
      simp only [List.length_cons, Nat.ofDigits_cons, pow_succ]
      exact Nat.le_trans (Nat.add_le_add ha (Nat.mul_le_mul_left 3 (ih ht))) (Nat.le_of_eq (H _ hk))

theorem ga_ofDigits_base3_le_of_entries_le_four {u : List Nat}
    (h : ∀ a ∈ u, a ≤ (4 : Nat)) :
    Nat.ofDigits (3 : Nat) u ≤ 2 * ((3 : Nat) ^ u.length - 1) := by
  induction u with
  | nil => simp
  | cons x l ih =>
      have hx : x ≤ 4 := h x (by simp)
      have hl : ∀ a ∈ l, a ≤ 4 := fun a ha => h a (by simp [ha])
      have H := ih hl
      have hpow : 1 ≤ (3 : Nat) ^ l.length := Nat.one_le_pow _ _ (by norm_num)
      obtain ⟨m, hm⟩ := Nat.exists_eq_add_of_le hpow
      rw [Nat.ofDigits_cons, show (x :: l).length = l.length + 1 from rfl, pow_succ, hm]
      rw [hm] at H
      omega

theorem ga_pal_digits_getD_same {E : List Nat} (h : E.reverse = E) {n : Nat}
    (hlen : E.length = n) :
    ∀ i < n, E.getD i 0 = E.getD (n - 1 - i) 0 := by
  intro i hi
  have hlenE : i < E.length := by omega
  have key : E.reverse.getD i 0 = E.getD (E.length - 1 - i) 0 :=
    congrFun (List.getD_reverse i hlenE) 0
  have idx : E.length - 1 - i = n - 1 - i := by omega
  calc E.getD i 0 = E.reverse.getD i 0 := by rw [h]
    _ = E.getD (E.length - 1 - i) 0 := key
    _ = E.getD (n - 1 - i) 0 := by rw [idx]

theorem ga_pal_digits_getD_top {E : List Nat} (h : E.reverse = E) {n : Nat}
    (hlen : E.length = n + 1) :
    ∀ i ≤ n, E.getD i 0 = E.getD (n - i) 0 := by
  intro i hi
  have hlt : i < n + 1 := by omega
  have H := ga_pal_digits_getD_same h hlen i hlt
  have hidx : n + 1 - 1 - i = n - i := by omega
  simpa [hidx] using H

theorem ga_pal_output_dsum_length {d : List Nat}
    (hd : ∀ e ∈ d, e < (3 : Nat))
    (hlast : List.getLast? d ≠ some 0)
    (hpal : (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d))).reverse =
              Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d))) :
    (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d))).length = d.length ∨
      (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d))).length =
        d.length + 1 := by
  -- Summing a list entrywise with another list of the same length cannot decrease `Nat.ofDigits`.
  have h1 : ∀ (l m : List Nat), l.length = m.length →
      Nat.ofDigits (3 : Nat) l ≤ Nat.ofDigits (3 : Nat) (List.zipWith (· + ·) l m) := by
    intro l
    induction l with
    | nil =>
        intro m hm
        cases m with
        | nil => exact Nat.le_refl _
        | cons b bs => exact absurd hm (by simp)
    | cons x xs ih =>
        intro m hm
        cases m with
        | nil => exact absurd hm (by simp)
        | cons y ys =>
            have hlen : xs.length = ys.length := by simpa using hm
            have hrec : Nat.ofDigits (3 : Nat) xs ≤
                Nat.ofDigits (3 : Nat) (List.zipWith (· + ·) xs ys) := ih ys hlen
            calc Nat.ofDigits (3 : Nat) (x :: xs)
                = x + 3 * Nat.ofDigits (3 : Nat) xs := Nat.ofDigits_cons
              _ ≤ x + y + 3 * Nat.ofDigits (3 : Nat) xs :=
                  Nat.add_le_add_right (Nat.le_add_right x y) _
              _ ≤ x + y + 3 * Nat.ofDigits (3 : Nat) (List.zipWith (· + ·) xs ys) :=
                  Nat.add_le_add_left (Nat.mul_le_mul_left (3 : Nat) hrec) _
              _ = Nat.ofDigits (3 : Nat) (List.zipWith (· + ·) (x :: xs) (y :: ys)) := by
                  rw [List.zipWith_cons_cons, Nat.ofDigits_cons]
  -- Every nonempty list is a snoc.
  have h2 : ∀ (l : List Nat), l ≠ [] → ∃ u a, l = u ++ [a] := by
    intro l
    induction l with
    | nil => intro h; exact absurd rfl h
    | cons x xs ih =>
        intro h
        cases xs with
        | nil => exact ⟨[], x, by simp⟩
        | cons y ys =>
            obtain ⟨u, a, hua⟩ := ih (by simp)
            exact ⟨x :: u, a, by simp [hua]⟩
  -- The last element of a snoc.
  have h3 : ∀ (u : List Nat) (a : Nat), (u ++ [a]).getLast? = some a := by
    intro u
    induction u with
    | nil => intro a; simp
    | cons x xs ih =>
        intro a
        rw [List.cons_append, List.getLast?_cons, ih a]
        <;> simp
  by_cases hde : d = []
  · subst hde
    left
    simp [ga_dsum3]
  · obtain ⟨u, a, hud⟩ := h2 d hde
    subst hud
    clear hde
    have ha : 1 ≤ a := by
      rw [h3 u a] at hlast
      have hne : a ≠ 0 := by
        intro hh
        subst hh
        exact hlast rfl
      omega
    set n := Nat.ofDigits (3 : Nat) (ga_dsum3 (u ++ [a]))
    -- lower bound on n
    have hlowD : (3 : Nat) ^ ((u ++ [a]).length - 1) ≤ Nat.ofDigits (3 : Nat) (u ++ [a]) := by
      have hsing : Nat.ofDigits (3 : Nat) [a] = a := by
        rw [Nat.ofDigits_cons]
        simp
      have hApp : Nat.ofDigits (3 : Nat) (u ++ [a]) =
          Nat.ofDigits (3 : Nat) u + (3 : Nat) ^ u.length * a := by
        rw [Nat.ofDigits_append, hsing]
      have hlenS : (u ++ [a]).length = u.length + 1 := by simp
      calc (3 : Nat) ^ ((u ++ [a]).length - 1)
          = (3 : Nat) ^ u.length := by rw [hlenS, Nat.add_sub_cancel]
        _ = (3 : Nat) ^ u.length * 1 := (Nat.mul_one _).symm
        _ ≤ (3 : Nat) ^ u.length * a := Nat.mul_le_mul_left _ ha
        _ ≤ Nat.ofDigits (3 : Nat) u + (3 : Nat) ^ u.length * a := Nat.le_add_left _ _
        _ = Nat.ofDigits (3 : Nat) (u ++ [a]) := hApp.symm
    have hng : (3 : Nat) ^ ((u ++ [a]).length - 1) ≤ n :=
      Nat.le_trans hlowD
        (h1 (u ++ [a]) ((u ++ [a]).reverse) (by rw [List.length_reverse]))
    have hn0 : n ≠ 0 := by
      have hpos : 1 ≤ (3 : Nat) ^ ((u ++ [a]).length - 1) := Nat.one_le_pow _ _ (by norm_num)
      intro h
      omega
    -- upper bound on n
    have hle4 : ∀ e ∈ ga_dsum3 (u ++ [a]), e ≤ (4 : Nat) :=
      ga_dsum3_lt_three_imp_le_four hd
    have hupA : n ≤ (2 : Nat) * ((3 : Nat) ^ (ga_dsum3 (u ++ [a])).length - 1) :=
      ga_ofDigits_base3_le_of_entries_le_four hle4
    have hupB : (2 : Nat) * ((3 : Nat) ^ (ga_dsum3 (u ++ [a])).length - 1) <
        (3 : Nat) ^ ((ga_dsum3 (u ++ [a])).length + 1) := by
      have hp : 0 < (3 : Nat) ^ (ga_dsum3 (u ++ [a])).length :=
        Nat.one_le_pow _ _ (by norm_num)
      calc (2 : Nat) * ((3 : Nat) ^ (ga_dsum3 (u ++ [a])).length - 1)
          ≤ 2 * (3 : Nat) ^ (ga_dsum3 (u ++ [a])).length :=
            Nat.mul_le_mul_left _ (Nat.sub_le _ _)
        _ < 3 * (3 : Nat) ^ (ga_dsum3 (u ++ [a])).length :=
            Nat.mul_lt_mul_of_pos_right (by norm_num) hp
        _ = (3 : Nat) ^ ((ga_dsum3 (u ++ [a])).length + 1) := by
            rw [Nat.pow_succ, Nat.mul_comm]
    have hlenS2 : (ga_dsum3 (u ++ [a])).length = (u ++ [a]).length :=
      ga_dsum3_length (u ++ [a])
    rw [hlenS2] at hupA hupB
    have hup : n < (3 : Nat) ^ ((u ++ [a]).length + 1) := lt_of_le_of_lt hupA hupB
    -- digits length is at most (u ++ [a]).length + 1
    have hlogle : Nat.log (3 : Nat) n ≤ (u ++ [a]).length := by
      apply Nat.le_of_not_lt
      intro hlt
      have hp1 : (3 : Nat) ^ Nat.log (3 : Nat) n ≤ n := Nat.pow_log_le_self (3 : Nat) hn0
      have hp2 : (3 : Nat) ^ ((u ++ [a]).length + 1) ≤ (3 : Nat) ^ Nat.log (3 : Nat) n :=
        Nat.pow_le_pow_right (by norm_num : (3 : Nat) > 0) (by omega)
      omega
    have hdig_le : (Nat.digits (3 : Nat) n).length ≤ (u ++ [a]).length + 1 := by
      rw [Nat.length_digits (3 : Nat) n (by norm_num : 1 < (3 : Nat)) hn0]
      omega
    -- digits length is at least (u ++ [a]).length
    have hdig2 : ∀ e ∈ Nat.digits (3 : Nat) n, e ≤ (2 : Nat) := by
      intro e he
      have := Nat.digits_lt_base (by norm_num : 1 < (3 : Nat)) he
      omega
    have hbdd : Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) n) ≤
        (3 : Nat) ^ (Nat.digits (3 : Nat) n).length - 1 :=
      ga_ofDigits_base3_le_of_entries_le_two hdig2
    have hneq : n = Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) n) :=
      (Nat.ofDigits_digits (3 : Nat) n).symm
    have hlen_ge : (u ++ [a]).length ≤ (Nat.digits (3 : Nat) n).length := by
      by_contra hc
      have hle : (Nat.digits (3 : Nat) n).length + 1 ≤ (u ++ [a]).length := by omega
      have hpow : (3 : Nat) ^ (Nat.digits (3 : Nat) n).length ≤
          (3 : Nat) ^ ((u ++ [a]).length - 1) :=
        Nat.pow_le_pow_right (by norm_num : (3 : Nat) > 0) (by omega)
      have hpos : 1 ≤ (3 : Nat) ^ (Nat.digits (3 : Nat) n).length :=
        Nat.one_le_pow _ _ (by norm_num)
      have h1' : n ≤ (3 : Nat) ^ (Nat.digits (3 : Nat) n).length - 1 := by
        calc n = Nat.ofDigits (3 : Nat) (Nat.digits (3 : Nat) n) := hneq
          _ ≤ (3 : Nat) ^ (Nat.digits (3 : Nat) n).length - 1 := hbdd
      omega
    by_cases hcb : (Nat.digits (3 : Nat) n).length = (u ++ [a]).length
    · exact Or.inl hcb
    · refine' Or.inr _
      omega

theorem ga_pal_output_dsum_succ_len_imp_zero_four {d : List Nat}
    (hd : ∀ e ∈ d, e < (3 : Nat))
    (hlast : List.getLast? d ≠ some 0)
    (hpal : (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d))).reverse =
              Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d)))
    (hlen : (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 d))).length =
              d.length + 1) :
    ∀ e ∈ ga_dsum3 d, e = (0 : Nat) ∨ e = (4 : Nat) := by
  set E := ga_dsum3 d with hEdef
  set N := Nat.ofDigits (3 : Nat) E with hNdef
  set D := Nat.digits (3 : Nat) N with hDdef
  set m := d.length with hmdef
  have hEl : E.length = m := ga_dsum3_length d
  have hDl : D.length = m + 1 := hlen
  have hErev : E.reverse = E := ga_dsum3_reverse d
  have hDrev : D.reverse = D := hpal
  have hE4 : ∀ e ∈ E, e ≤ 4 := ga_dsum3_lt_three_imp_le_four hd
  have hNod : Nat.ofDigits (3 : Nat) D = N := Nat.ofDigits_digits 3 N
  have hget : ∀ (l : List Nat) (n : Nat), n < l.length → l.getD n 0 ∈ l := by
    intro l
    induction l with
    | nil => intro n hn; rw [List.length_nil] at hn; omega
    | cons a l ih =>
      intro n hn
      cases n with
      | zero =>
        have h1 : (a :: l).getD 0 0 = a := rfl
        rw [h1]
        exact List.mem_cons.mpr (Or.inl rfl)
      | succ n =>
        have h1 : (a :: l).getD (n + 1) 0 = l.getD n 0 := rfl
        have hlc : (a :: l).length = l.length + 1 := rfl
        have h2 : n < l.length := by omega
        rw [h1]
        exact List.mem_cons.mpr (Or.inr (ih n h2))
  have hle2 : ∀ (l : List Nat), (∀ x ∈ l, x ≤ 2) → ∀ j, j < l.length → l.getD j 0 ≤ 2 := by
    intro l hl j hj
    exact hl _ (hget l j hj)
  have hle4 : ∀ (l : List Nat), (∀ x ∈ l, x ≤ 4) → ∀ j, j < l.length → l.getD j 0 ≤ 4 := by
    intro l hl j hj
    exact hl _ (hget l j hj)
  have hDlt2 : ∀ x ∈ D, x ≤ 2 := by
    intro x hx
    have := Nat.digits_lt_base (by omega : 1 < (3 : Nat)) hx
    omega
  have hD2 : ∀ j, j ≤ m → D.getD j 0 ≤ 2 := fun j hj => hle2 D hDlt2 j (by omega)
  have hEget : ∀ j, j < m → E.getD j 0 ≤ 4 := fun j hj => hle4 E hE4 j (by omega)
  have hEpal : ∀ i, i < m → E.getD i 0 = E.getD (m - 1 - i) 0 :=
    fun i hi => ga_pal_digits_getD_same hErev hEl i hi
  have hDpal : ∀ i, i ≤ m → D.getD i 0 = D.getD (m - i) 0 :=
    fun i hi => ga_pal_digits_getD_top hDrev hDl i hi
  let c : Nat → Nat := Nat.rec 0 (fun i r => (E.getD i 0 + r) / 3)
  have hc0 : c 0 = 0 := rfl
  have hcS : ∀ i, c (i + 1) = (E.getD i 0 + c i) / 3 := by intro i; exact rfl
  have hdrop : ∀ (l : List Nat) (n : Nat), n < l.length →
      l.drop n = l.getD n 0 :: l.drop (n + 1) := by
    intro l
    induction l with
    | nil => intro n hn; rw [List.length_nil] at hn; omega
    | cons a l ih =>
      intro n hn
      cases n with
      | zero =>
        have h1 : (a :: l).drop 0 = a :: l := rfl
        have h2 : (a :: l).drop 1 = l := rfl
        have h3 : (a :: l).getD 0 0 = a := rfl
        rw [h1, h2, h3]
      | succ n =>
        have hlc : (a :: l).length = l.length + 1 := rfl
        have hlen' : n < l.length := by omega
        have h1 : (a :: l).drop (n + 1) = l.drop n := rfl
        have h2 : (a :: l).drop (n + 2) = l.drop (n + 1) := rfl
        have h3 : (a :: l).getD (n + 1) 0 = l.getD n 0 := rfl
        rw [h1, h2, h3]
        exact ih n hlen'
  have hkey : ∀ i, i ≤ m → c i ≤ 1 ∧
      Nat.ofDigits (3 : Nat) (E.drop i) + c i = Nat.ofDigits (3 : Nat) (D.drop i) := by
    intro i
    induction i with
    | zero =>
      intro _
      constructor
      · omega
      · have h1 : E.drop 0 = E := rfl
        have h2 : D.drop 0 = D := rfl
        have h3 : Nat.ofDigits (3 : Nat) E = N := rfl
        rw [h1, h2, hc0]
        omega
    | succ i ih =>
      intro hi
      have hi' : i ≤ m := by omega
      obtain ⟨hci, hp⟩ := ih hi'
      have hEm : i < m := by omega
      have hED : i < E.length := by omega
      have hDD : i < D.length := by omega
      have h1 : E.drop i = E.getD i 0 :: E.drop (i + 1) := hdrop E i hED
      have h2 : D.drop i = D.getD i 0 :: D.drop (i + 1) := hdrop D i hDD
      have heqE : Nat.ofDigits (3 : Nat) (E.drop i) = E.getD i 0 + 3 * Nat.ofDigits (3 : Nat) (E.drop (i + 1)) := by
        rw [h1]; rfl
      have heqD : Nat.ofDigits (3 : Nat) (D.drop i) = D.getD i 0 + 3 * Nat.ofDigits (3 : Nat) (D.drop (i + 1)) := by
        rw [h2]; rfl
      have hEi : E.getD i 0 ≤ 4 := hEget i hEm
      have hDi : D.getD i 0 ≤ 2 := hD2 i (by omega)
      have hc1 : c (i + 1) = (E.getD i 0 + c i) / 3 := hcS i
      constructor
      · omega
      · omega
  have hcol : ∀ i, i < m → E.getD i 0 + c i = D.getD i 0 + 3 * c (i + 1) := by
    intro i hi
    obtain ⟨hci, hp⟩ := hkey i (by omega)
    obtain ⟨hci', hp'⟩ := hkey (i + 1) (by omega)
    have hED : i < E.length := by omega
    have hDD : i < D.length := by omega
    have h1 : E.drop i = E.getD i 0 :: E.drop (i + 1) := hdrop E i hED
    have h2 : D.drop i = D.getD i 0 :: D.drop (i + 1) := hdrop D i hDD
    have heqE : Nat.ofDigits (3 : Nat) (E.drop i) = E.getD i 0 + 3 * Nat.ofDigits (3 : Nat) (E.drop (i + 1)) := by
      rw [h1]; rfl
    have heqD : Nat.ofDigits (3 : Nat) (D.drop i) = D.getD i 0 + 3 * Nat.ofDigits (3 : Nat) (D.drop (i + 1)) := by
      rw [h2]; rfl
    omega
  have hEdrop : E.drop m = [] := List.drop_of_length_le (by omega : E.length ≤ m)
  have hDdrop : D.drop m = [D.getD m 0] := by
    have hlen : m < D.length := by omega
    have h := hdrop D m hlen
    rw [h]
    have h5 : D.drop (m + 1) = [] := List.drop_of_length_le (by omega : D.length ≤ m + 1)
    rw [h5]
  have hcmD : c m = D.getD m 0 ∧ c m ≤ 1 := by
    obtain ⟨h1, h2⟩ := hkey m (by omega)
    rw [hEdrop] at h2
    rw [hDdrop] at h2
    have h6 : Nat.ofDigits (3 : Nat) ([] : List Nat) = 0 := rfl
    have h7 : Nat.ofDigits (3 : Nat) [D.getD m 0] = D.getD m 0 := rfl
    rw [h6, h7] at h2
    exact ⟨by omega, h1⟩
  have hD0Dm : D.getD 0 0 = D.getD m 0 := by
    have h := hDpal 0 (by omega)
    rw [Nat.sub_zero] at h
    exact h
  have trans : ∀ i, i < m →
      ((c i = 0 ∧ c (m - i) = 1 ∧ D.getD i 0 = 1) ∨
       (c i = 1 ∧ c (m - i) = 0 ∧ D.getD i 0 = 1) ∨
       (c i = 1 ∧ c (m - i) = 1 ∧ D.getD i 0 = 2) ∨
       (c i = 0 ∧ c (m - i) = 0 ∧ D.getD i 0 = 0)) →
      ((c (i + 1) = 0 ∧ c (m - (i + 1)) = 1 ∧ D.getD (i + 1) 0 = 1) ∨
       (c (i + 1) = 1 ∧ c (m - (i + 1)) = 0 ∧ D.getD (i + 1) 0 = 1) ∨
       (c (i + 1) = 1 ∧ c (m - (i + 1)) = 1 ∧ D.getD (i + 1) 0 = 2) ∨
       (c (i + 1) = 0 ∧ c (m - (i + 1)) = 0 ∧ D.getD (i + 1) 0 = 0)) ∧
      (E.getD i 0 = 0 ∨ E.getD i 0 = 4) := by
    intro i him hst
    have hcol1 := hcol i him
    have him2 : m - 1 - i < m := by
      have h1 : m ≥ 1 := by omega
      have h2 : i ≤ m - 1 := by omega
      have h3 : m - 1 - i ≤ m - 1 := by omega
      omega
    have hcol2' := hcol (m - 1 - i) him2
    have h1 : m - 1 - i + 1 = m - i := by omega
    rw [h1] at hcol2'
    have hEp : E.getD (m - 1 - i) 0 = E.getD i 0 := (hEpal i him).symm
    have hDp : D.getD (m - 1 - i) 0 = D.getD (i + 1) 0 := by
      have hj : m - 1 - i ≤ m := by omega
      have h2 := hDpal (m - 1 - i) hj
      have h3 : m - (m - 1 - i) = i + 1 := by omega
      rw [h3] at h2
      exact h2
    rw [hEp, hDp] at hcol2'
    have hcp : c (i + 1) ≤ 1 := (hkey (i + 1) (by omega)).1
    have hcmm : c (m - 1 - i) ≤ 1 := (hkey (m - 1 - i) (by omega)).1
    have hdnext : D.getD (i + 1) 0 ≤ 2 := hD2 (i + 1) (by omega)
    have hEi : E.getD i 0 ≤ 4 := hEget i him
    have hidx : m - (i + 1) = m - 1 - i := by omega
    rw [hidx]
    rcases hst with ⟨h1a, h2a, h3a⟩ | ⟨h1a, h2a, h3a⟩ | ⟨h1a, h2a, h3a⟩ | ⟨h1a, h2a, h3a⟩
    · simp only [h1a, h2a, h3a] at hcol1 hcol2'
      omega
    · simp only [h1a, h2a, h3a] at hcol1 hcol2'
      omega
    · simp only [h1a, h2a, h3a] at hcol1 hcol2'
      omega
    · simp only [h1a, h2a, h3a] at hcol1 hcol2'
      omega
  have hstate : ∀ i, i ≤ m →
      ((c i = 0 ∧ c (m - i) = 1 ∧ D.getD i 0 = 1) ∨
       (c i = 1 ∧ c (m - i) = 0 ∧ D.getD i 0 = 1) ∨
       (c i = 1 ∧ c (m - i) = 1 ∧ D.getD i 0 = 2) ∨
       (c i = 0 ∧ c (m - i) = 0 ∧ D.getD i 0 = 0)) := by
    intro i
    induction i with
    | zero =>
      intro _
      obtain ⟨h1, h2⟩ := hcmD
      rw [Nat.sub_zero]
      have h3 : c 0 = 0 := hc0
      have h4 : D.getD 0 0 = D.getD m 0 := hD0Dm
      omega
    | succ i ih =>
      intro hi
      exact (trans i (by omega) (ih (by omega))).1
  have hEzero : ∀ i, i < m → E.getD i 0 = 0 ∨ E.getD i 0 = 4 := by
    intro i hi
    exact (trans i hi (hstate i (by omega))).2
  have hmem4 : ∀ (l : List Nat), (∀ j, j < l.length → l.getD j 0 = 0 ∨ l.getD j 0 = 4) →
      ∀ e ∈ l, e = 0 ∨ e = 4 := by
    intro l
    induction l with
    | nil => intro _ e he; cases he
    | cons a l ih =>
      intro h e he
      have hlen : (a :: l).length = l.length + 1 := rfl
      rcases List.mem_cons.mp he with heq | hl
      · have h1 := h 0 (by omega)
        have h2 : (a :: l).getD 0 0 = a := rfl
        rw [h2] at h1
        omega
      · have h1 : ∀ j, j < l.length → l.getD j 0 = 0 ∨ l.getD j 0 = 4 := by
          intro j hj
          have h2 := h (j + 1) (by omega)
          have h3 : (a :: l).getD (j + 1) 0 = l.getD j 0 := rfl
          rw [h3] at h2
          exact h2
        exact ih h1 e hl
  intro e he
  have h1 : ∀ j, j < E.length → E.getD j 0 = 0 ∨ E.getD j 0 = 4 := by
    intro j hj
    exact hEzero j (by omega)
  exact hmem4 E h1 e he

theorem ga_addRevBase3_pal_modes {x : Nat}
    (h : (Nat.digits (3 : Nat) (x + OeisA77408.revBase (3 : Nat) x)).reverse =
           Nat.digits (3 : Nat) (x + OeisA77408.revBase (3 : Nat) x)) :
    ga_addRevBase3_carryFree (Nat.digits (3 : Nat) x) ∨
      ∀ p ∈ (Nat.digits (3 : Nat) x).zip (Nat.digits (3 : Nat) x).reverse,
        p.1 + p.2 = 0 ∨ p.1 + p.2 = 4 := by
  classical
  have hdecomp : ∀ (T : List Nat), T ≠ [] → ∃ M b, T = M ++ [b] := by
    intro T
    induction T with
    | nil => intro h; exact absurd rfl h
    | cons x l ih =>
      intro _
      cases l with
      | nil => exact ⟨[], x, rfl⟩
      | cons y m =>
        obtain ⟨M, b, hM⟩ := ih (by simp)
        exact ⟨x :: M, b, by simp [hM]⟩
  have hcancel : ∀ (X Y : List Nat) (z : Nat), X ++ [z] = Y ++ [z] → X = Y := by
    intro X Y z h
    have h3 : ([z] : List Nat) ++ X.reverse = [z] ++ Y.reverse := by
      simpa using congrArg List.reverse h
    exact List.reverse_inj.mp ((List.append_right_inj ([z] : List Nat)).mp h3)
  have key : ∀ n : Nat, ∀ S E : List Nat, S.reverse = S → E.reverse = E → S.length = n → E.length = n →
      (∀ a ∈ S, a ≤ (4 : Nat)) → (∀ a ∈ E, a ≤ (2 : Nat)) →
      Nat.ofDigits (3 : Nat) S = Nat.ofDigits (3 : Nat) E → S = E := by
    intro n
    refine Nat.strongRecOn n ?_
    intro m ih S E hSrev hErev hSlen hElen hS4 hE2 hov
    cases m with
    | zero =>
      have hSnil : S = [] := List.eq_nil_of_length_eq_zero hSlen
      have hEnil : E = [] := List.eq_nil_of_length_eq_zero hElen
      subst hSnil hEnil
      rfl
    | succ m' =>
      cases m' with
      | zero =>
        rcases S with _|⟨s, T⟩
        · rw [List.length_nil] at hSlen; omega
        · rcases E with _|⟨e, U⟩
          · rw [List.length_nil] at hElen; omega
          · have hTlen : T.length = 0 := by rw [List.length_cons] at hSlen; omega
            have hUlen : U.length = 0 := by rw [List.length_cons] at hElen; omega
            have hTnil : T = [] := List.eq_nil_of_length_eq_zero hTlen
            have hUnil : U = [] := List.eq_nil_of_length_eq_zero hUlen
            subst hTnil hUnil
            have hse : s = e := by simpa using hov
            subst hse
            rfl
      | succ k =>
        rcases S with _|⟨a, T⟩
        · rw [List.length_nil] at hSlen; omega
        · have hTne : T ≠ [] := by
            intro hT
            subst hT
            rw [List.length_cons, List.length_nil] at hSlen
            omega
          obtain ⟨M, b, rfl⟩ := hdecomp T hTne
          have hMlen : M.length = k := by
            rw [List.length_cons, List.length_append, List.length_singleton] at hSlen
            omega
          have h1 : b :: (M.reverse ++ [a]) = a :: (M ++ [b]) := by
            rw [← hSrev]
            simp [List.reverse_cons, List.reverse_append]
          obtain ⟨hb, hmid⟩ := List.cons.inj h1
          have hbsym : a = b := hb.symm
          subst hbsym
          have hMrev : M.reverse = M := hcancel M.reverse M a hmid
          rcases E with _|⟨c, U⟩
          · rw [List.length_nil] at hElen; omega
          · have hUne : U ≠ [] := by
              intro hU
              subst hU
              rw [List.length_cons, List.length_nil] at hElen
              omega
            obtain ⟨N, d, rfl⟩ := hdecomp U hUne
            have hNlen : N.length = k := by
              rw [List.length_cons, List.length_append, List.length_singleton] at hElen
              omega
            have h2 : d :: (N.reverse ++ [c]) = c :: (N ++ [d]) := by
              rw [← hErev]
              simp [List.reverse_cons, List.reverse_append]
            obtain ⟨hd, hmid2⟩ := List.cons.inj h2
            have hd2 : c = d := hd.symm
            subst hd2
            have hNrev : N.reverse = N := hcancel N.reverse N c hmid2
            set A := Nat.ofDigits (3 : Nat) M with hAdef
            set B := Nat.ofDigits (3 : Nat) N with hBdef
            set P := (3 : Nat) ^ k with hPdef
            have hM4 : ∀ e ∈ M, e ≤ (4 : Nat) := fun e he => hS4 e (by simp [he])
            have hN2 : ∀ e ∈ N, e ≤ (2 : Nat) := fun e he => hE2 e (by simp [he])
            have hcalc : Nat.ofDigits (3 : Nat) (a :: M ++ [a]) = a + 3 * (A + P * a) := by
              have h2' : Nat.ofDigits (3 : Nat) (M ++ [a]) = A + P * a := by
                rw [Nat.ofDigits_append, hAdef, hMlen, ← hPdef]
                try rfl
              rw [show Nat.ofDigits (3 : Nat) (a :: M ++ [a]) =
                  a + 3 * Nat.ofDigits (3 : Nat) (M ++ [a]) from rfl, h2']
            have hcalcE : Nat.ofDigits (3 : Nat) (c :: N ++ [c]) = c + 3 * (B + P * c) := by
              have h2' : Nat.ofDigits (3 : Nat) (N ++ [c]) = B + P * c := by
                rw [Nat.ofDigits_append, hBdef, hNlen, ← hPdef]
                try rfl
              rw [show Nat.ofDigits (3 : Nat) (c :: N ++ [c]) =
                  c + 3 * Nat.ofDigits (3 : Nat) (N ++ [c]) from rfl, h2']
            have heq : a + 3 * (A + P * a) = c + 3 * (B + P * c) := by
              rw [← hcalc, ← hcalcE]
              exact hov
            have hP : P ≥ 1 := by
              rw [hPdef]
              exact Nat.one_le_pow _ _ (by omega)
            have hA : A ≤ 2 * (P - 1) := by
              have h1 := ga_ofDigits_base3_le_of_entries_le_four hM4
              rw [← hAdef, hMlen, ← hPdef] at h1
              exact h1
            have hB : B ≤ P - 1 := by
              have h1 := ga_ofDigits_base3_le_of_entries_le_two hN2
              rw [← hBdef, hNlen, ← hPdef] at h1
              exact h1
            have ha : a ≤ (4 : Nat) := hS4 a (by simp)
            have hc : c ≤ (2 : Nat) := hE2 c (by simp)
            have hu : (a + 3 * (A + P * a)) % (3 : Nat) = a % 3 := by
              rw [Nat.add_comm, Nat.add_mod, Nat.mul_mod, Nat.mod_self, Nat.zero_mul,
                Nat.zero_mod, Nat.zero_add, Nat.mod_mod]
            have hv : (c + 3 * (B + P * c)) % (3 : Nat) = c % 3 := by
              rw [Nat.add_comm, Nat.add_mod, Nat.mul_mod, Nat.mod_self, Nat.zero_mul,
                Nat.zero_mod, Nat.zero_add, Nat.mod_mod]
            have hmod : a % (3 : Nat) = c % 3 := by
              rw [← hu, ← hv]
              exact congrArg (fun t : Nat => t % 3) heq
            have h_ac : a = c ∧ A = B := by
              interval_cases a <;> interval_cases c <;> omega
            obtain ⟨hac, hab⟩ := h_ac
            subst hac
            have hMN : M = N := ih k (by omega) M N hMrev hNrev hMlen hNlen hM4 hN2 hab
            subst hMN
            rfl
  have hV : x + OeisA77408.revBase (3 : Nat) x =
      Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x)) :=
    ga_addRevBase3_dsum_ofDigits x
  have hEpal : (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x)))).reverse =
      Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x))) := by
    rw [← hV]
    exact h
  have hdlt : ∀ e ∈ Nat.digits (3 : Nat) x, e < (3 : Nat) := ga_digits_lt_base_three x
  have hlast : List.getLast? (Nat.digits (3 : Nat) x) ≠ some (0 : Nat) := ga_digits_last_ne_zero
  obtain hlen | hlen := ga_pal_output_dsum_length hdlt hlast hEpal
  · refine Or.inl ((ga_addRevBase3_carryFree_iff_dsum_le_two (Nat.digits (3 : Nat) x)).mpr ?_)
    have hEq : Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x))) =
        ga_dsum3 (Nat.digits (3 : Nat) x) :=
      (key (Nat.digits (3 : Nat) x).length
        (ga_dsum3 (Nat.digits (3 : Nat) x))
        (Nat.digits (3 : Nat) (Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x))))
        (ga_dsum3_reverse (Nat.digits (3 : Nat) x)) hEpal
        (ga_dsum3_length (Nat.digits (3 : Nat) x)) hlen
        (ga_dsum3_lt_three_imp_le_four hdlt)
        (fun a ha => by have h2 := ga_digits_lt_base_three _ a ha; omega)
        ((ga_ofDigits_digits_three
            (Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x)))).symm)).symm
    intro e he
    rw [← hEq] at he
    have h2 := ga_digits_lt_base_three (Nat.ofDigits (3 : Nat) (ga_dsum3 (Nat.digits (3 : Nat) x))) e he
    omega
  · right
    exact ga_dsum3_zero_four_to_zip (ga_pal_output_dsum_succ_len_imp_zero_four hdlt hlast hEpal hlen)

theorem ga_zero_or_four_mirrored_pairs_imp_pal {ds : List Nat}
    (hds : ∀ d ∈ ds, d < (3 : Nat))
    (h : ∀ p ∈ ds.zip ds.reverse, p.1 + p.2 = 0 ∨ p.1 + p.2 = 4) :
    ds.reverse = ds := by
  have hlen : ∀ (l : List Nat), l.length = l.reverse.length := by
    intro l
    induction l with
    | nil => rfl
    | cons x xs ih => simpa [List.length_cons, List.reverse_cons, List.length_append] using ih
  have zip_fst : ∀ (l m : List Nat) (p : Nat × Nat), p ∈ l.zip m → p.1 ∈ l := by
    intro l
    induction l with
    | nil =>
      intro m p hp
      cases m with
      | nil => exact absurd hp (by simp)
      | cons b bs => exact absurd hp (by simp)
    | cons c cs ih =>
      intro m p hp
      cases m with
      | nil => exact absurd hp (by simp)
      | cons b bs =>
        have he : (c :: cs).zip (b :: bs) = (c, b) :: cs.zip bs := rfl
        rw [he] at hp
        rcases (List.mem_cons (a := p) (b := (c, b)) (l := cs.zip bs)).mp hp with h | h
        · have : p = (c, b) := by simpa using h
          subst this
          simp
        · exact List.mem_cons_of_mem c (ih bs p h)
  have zip_snd : ∀ (m : List Nat) (l : List Nat) (p : Nat × Nat), p ∈ l.zip m → p.2 ∈ m := by
    intro m
    induction m with
    | nil =>
      intro l p hp
      cases l with
      | nil => exact absurd hp (by simp)
      | cons c cs => exact absurd hp (by simp)
    | cons b bs ih =>
      intro l p hp
      cases l with
      | nil => exact absurd hp (by simp)
      | cons c cs =>
        have he : (c :: cs).zip (b :: bs) = (c, b) :: cs.zip bs := rfl
        rw [he] at hp
        rcases (List.mem_cons (a := p) (b := (c, b)) (l := cs.zip bs)).mp hp with h | h
        · have : p = (c, b) := by simpa using h
          subst this
          simp
        · exact List.mem_cons_of_mem b (ih cs p h)
  have aux : ∀ (a b : List Nat), a.length = b.length → (∀ p ∈ a.zip b, p.1 = p.2) → a = b := by
    intro a
    induction a with
    | nil =>
      intro b hb _
      cases b with
      | nil => rfl
      | cons y ys => exact absurd hb (by simp)
    | cons x xs ih =>
      intro b hb hz
      cases b with
      | nil => exact absurd hb (by simp)
      | cons y ys =>
        have he : (x :: xs).zip (y :: ys) = (x, y) :: xs.zip ys := rfl
        have hxy : x = y := by
          have hmem : (x, y) ∈ (x :: xs).zip (y :: ys) := by
            rw [he]
            exact List.mem_cons_self
          have h2 := hz (x, y) hmem
          simpa using h2
        have hrest : ∀ p ∈ xs.zip ys, p.1 = p.2 := by
          intro p hp
          have hmem : p ∈ (x :: xs).zip (y :: ys) := by
            rw [he]
            exact List.mem_cons_of_mem (x, y) hp
          exact hz p hmem
        have hlen' : xs.length = ys.length := by simpa using hb
        subst hxy
        have hab := ih ys hlen' hrest
        subst hab
        rfl
  have hkey : ∀ p ∈ ds.zip ds.reverse, p.1 = p.2 := by
    intro p hp
    obtain ⟨x, y⟩ := p
    have hx : x < 3 := hds x (zip_fst ds ds.reverse (x, y) hp)
    have hy : y < 3 := hds y (List.mem_reverse.mp (zip_snd ds.reverse ds (x, y) hp))
    have hs := h (x, y) hp
    rcases hs with h0 | h4
    · omega
    · omega
  exact ((aux ds ds.reverse (hlen ds) hkey).symm)

theorem ga_addRevBase3_pal_imp_input_pal_or_carryFree {x : Nat}
    (h : (Nat.digits (3 : Nat) (x + OeisA77408.revBase (3 : Nat) x)).reverse =
           Nat.digits (3 : Nat) (x + OeisA77408.revBase (3 : Nat) x)) :
    (Nat.digits (3 : Nat) x).reverse = Nat.digits (3 : Nat) x ∨
      ga_addRevBase3_carryFree (Nat.digits (3 : Nat) x) := by
  have hd : ∀ d ∈ Nat.digits (3 : Nat) x, d < (3 : Nat) := ga_digits_lt_base_three x
  cases ga_addRevBase3_pal_modes h with
  | inl hc => exact Or.inr hc
  | inr h04 =>
      exact Or.inl (ga_zero_or_four_mirrored_pairs_imp_pal hd h04)

#ga_audit_proof ga_ofDigits_digits_three
#ga_audit_proof ga_a_ofDigits_digits
#ga_audit_proof ga_a_succ_eq
#ga_audit_proof ga_a_succ_digits_eq_add_rev
#ga_audit_proof ga_addRevBase3_carryFree_iff_pair_sums
#ga_audit_proof ga_dsum3_eq_zipWith
#ga_audit_proof ga_dsum3_mem_iff
#ga_audit_proof ga_addRevBase3_carryFree_iff_dsum_le_two
#ga_audit_proof ga_revBase_digits_reverse
#ga_audit_proof ga_ofDigits_zipWith_add
#ga_audit_proof ga_dsum3_length
#ga_audit_proof ga_ofDigits_ga_dsum3
#ga_audit_proof ga_addRevBase3_dsum_ofDigits
#ga_audit_proof ga_digits_getLast_option_ne_zero
#ga_audit_proof ga_digits_ofDigits_three
#ga_audit_proof ga_digits_lt_base_three
#ga_audit_proof ga_dsum3_reverse
#ga_audit_proof ga_dsum3_lt_three_imp_le_four
#ga_audit_proof ga_dsum3_zero_four_to_zip
#ga_audit_proof ga_digits_last_ne_zero
#ga_audit_proof ga_ofDigits_base3_le_of_entries_le_two
#ga_audit_proof ga_ofDigits_base3_le_of_entries_le_four
#ga_audit_proof ga_pal_digits_getD_same
#ga_audit_proof ga_pal_digits_getD_top
#ga_audit_proof ga_pal_output_dsum_length
#ga_audit_proof ga_pal_output_dsum_succ_len_imp_zero_four
#ga_audit_proof ga_addRevBase3_pal_modes
#ga_audit_proof ga_zero_or_four_mirrored_pairs_imp_pal
#ga_audit_proof ga_addRevBase3_pal_imp_input_pal_or_carryFree
