import OpHack.PowerFourier.Logarithms

noncomputable section
namespace PowerFourier

/-- A fully quantified form of the leading logarithmic lower-growth constant one. -/
theorem quartic_near_boundary_growth (ε t : ℝ) (n : ℕ)
    (hε : 0 < ε) (ht : 7 ≤ t) (ht8 : t < 8) (hn : 0 < n)
    (hp : PowerSemigroup.CoeffNonneg (PowerSemigroup.quartic t ^ n))
    (hsmall : 8-t ≤ min (4*ε) (Real.exp (-80/ε))) :
    (1-ε)*Real.log (1/(8-t)) ≤ (8-t)*(n : ℝ) := by
  let δ : ℝ := 8-t
  let L : ℝ := Real.log (1/δ)
  have hd : 0 < δ := by dsimp [δ]; linarith
  have hd1 : δ ≤ 1 := by dsimp [δ]; linarith
  have hcoef : 0 ≤ 1-δ/8 := by linarith
  have he := boundary_explicit_log_lower t n ht ht8 hn hp
  have hlog4 : 0 ≤ Real.log (4/3 : ℝ) := (Real.log_pos (by norm_num)).le
  have hlog28 := Real.log_le_sub_one_of_pos (by norm_num : (0 : ℝ) < 28/3)
  have hB : L-40 ≤ L+Real.log (4/3 : ℝ)-4*Real.log (28/3 : ℝ) := by linarith
  have hbasic : (1-δ/8)*(L-40) ≤ δ*(n : ℝ) :=
    (mul_le_mul_of_nonneg_left hB hcoef).trans he
  have hdelta : δ ≤ 4*ε := (le_min_iff.mp hsmall).1
  have hexp : δ ≤ Real.exp (-80/ε) := (le_min_iff.mp hsmall).2
  have hlogδ := Real.log_le_log hd hexp
  rw [Real.log_exp] at hlogδ
  have hL : 80/ε ≤ L := by
    dsimp [L]
    rw [one_div,Real.log_inv]
    simpa only [neg_div,neg_neg] using neg_le_neg hlogδ
  have hL0 : 0 ≤ L := (by positivity : (0 : ℝ) ≤ 80/ε).trans hL
  have hεL : (80 : ℝ) ≤ ε*L := by
    have hh := (div_le_iff₀ hε).mp hL
    nlinarith only [hh]
  have hδL := mul_le_mul_of_nonneg_right hdelta hL0
  have hfinal : (1-ε)*L ≤ (1-δ/8)*(L-40) := by nlinarith only [hεL,hδL,hd.le]
  exact hfinal.trans hbasic

theorem quartic_logarithmic_growth : ∀ ε : ℝ, 0 < ε → ∃ η : ℝ, 0 < η ∧
    ∀ (t : ℝ) (n : ℕ), 7 ≤ t → t < 8 → 0 < n →
      PowerSemigroup.CoeffNonneg (PowerSemigroup.quartic t ^ n) → 8-t < η →
      (1-ε)*Real.log (1/(8-t)) ≤ (8-t)*(n : ℝ) := by
  intro ε hε
  refine ⟨min (4*ε) (Real.exp (-80/ε)),by positivity,?_⟩
  intro t n ht ht8 hn hp hs
  exact quartic_near_boundary_growth ε t n hε ht ht8 hn hp hs.le

theorem function_near_boundary_growth (ε t : ℝ) (n : ℕ)
    (hε : 0 < ε) (ht : 7 ≤ t) (ht8 : t < 8) (hn : 0 < n)
    (h : PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
      (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ)))
    (hsmall : 8-t ≤ min (4*ε) (Real.exp (-80/ε))) :
    (1-ε)*Real.log (1/(8-t)) ≤ (8-t)*(n : ℝ) := by
  apply quartic_near_boundary_growth ε t n hε ht ht8 hn _ hsmall
  apply (PowerSemigroup.diagonal_squaredNorm_iff _).mp
  apply (PowerSemigroup.squaredNorm_iff_function _).mpr
  simpa [PowerSemigroup.evaluate_diagonal,PowerSemigroup.quartic] using h

theorem function_logarithmic_growth : ∀ ε : ℝ, 0 < ε → ∃ η : ℝ, 0 < η ∧
    ∀ (t : ℝ) (n : ℕ), 7 ≤ t → t < 8 → 0 < n →
      PowerSemigroup.FunctionSquaredNorm (fun z : ℂ =>
        (((1+Complex.normSq z)^4-t*(Complex.normSq z)^2)^n : ℝ)) → 8-t < η →
      (1-ε)*Real.log (1/(8-t)) ≤ (8-t)*(n : ℝ) := by
  intro ε hε
  refine ⟨min (4*ε) (Real.exp (-80/ε)),by positivity,?_⟩
  intro t n ht ht8 hn hp hs
  exact function_near_boundary_growth ε t n hε ht ht8 hn hp hs.le

#print axioms function_logarithmic_growth
#print axioms quartic_logarithmic_growth
#print axioms function_near_boundary_growth
end PowerFourier
