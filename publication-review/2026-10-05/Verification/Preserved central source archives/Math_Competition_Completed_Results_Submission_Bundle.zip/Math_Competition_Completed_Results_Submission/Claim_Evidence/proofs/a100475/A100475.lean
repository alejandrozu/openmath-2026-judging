import A100475Conclusion
import A100475Finite

/-!
Candidate negative answer to the positive-start loop question for OEIS A100475.
The definitions are in A100475Dynamics, copied from Formal Conjectures commit
137aec5c7abd3aa61f7a73138a97279acfc79e93, OEIS/100475.lean.
Source: https://oeis.org/A100475

The analytic and finite parts imply that every positive state exceeds its
initial value within three steps. A periodic tail would have a maximum.
Reproduce the complete build and axiom audit with `bash check.sh A100475`.
Mathematical novelty and competition acceptance require separate review.
-/
namespace OeisA100475

theorem not_periodic {x : ℕ} (hx : 0 < x) : ¬ IsUltimatelyPeriodic (aStartAt x) :=
  not_periodic_of_counts A100475Finite.count_100000 A100475Finite.count_1000000 hx

theorem conjecture :
    False ↔ ∃ x : ℕ, 0 < x ∧ x ≠ 1 ∧ IsUltimatelyPeriodic (aStartAt x) := by
  apply iff_of_false False.elim
  rintro ⟨x, hx, _, hp⟩
  exact not_periodic hx hp

#print axioms not_periodic
#print axioms conjecture
end OeisA100475
