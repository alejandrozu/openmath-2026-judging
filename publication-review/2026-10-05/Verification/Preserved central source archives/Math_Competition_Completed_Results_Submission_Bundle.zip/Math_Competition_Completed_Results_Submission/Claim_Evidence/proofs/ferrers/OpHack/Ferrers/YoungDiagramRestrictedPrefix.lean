import OpHack.Ferrers.YoungDiagramBridge
import OpHack.Ferrers.RankPrefixFormula

/-!
# Simultaneous restricted prefixes on the exact Young-diagram graph

The rank formula and the simultaneous independent-set realization are stated
separately. The latter gives actual disjoint finsets of natural-coordinate
`μ.cells` whose ordered prefixes attain the exact copied FC rank.

This uses the copied FC definitions isolated in `FerrersArm.FCCompat`, rather
than the original external declarations. `YoungDiagramBridge` records their
Apache source provenance and proves the natural-coordinate identification
without importing Formal Conjectures. This is a source candidate prepared
without Lean execution.
-/

namespace FerrersArm.YoungDiagramBridge
open Finset

/-- An extremal first drop gives the later ranks of the actual diagram graph. -/
theorem indepNumK_later_ranks (μ : YoungDiagram) (r k : ℕ)
    (hr : 1 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r * k)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r + 1) = (r + 1) * k - r) :
    ∀ h ≤ r, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r + h) = (r + h) * k - h * r := by
  have hR' : FCCompat.indepNumK
      (CellGraphRank.cellGraph (CornerCuts.Allowed (W := width μ) (rowLengths μ))) r =
      r * k := (board_indepNumK_eq μ r).trans hR
  have hNext' : FCCompat.indepNumK
      (CellGraphRank.cellGraph (CornerCuts.Allowed (W := width μ) (rowLengths μ)))
      (r + 1) = (r + 1) * k - r := (board_indepNumK_eq μ (r + 1)).trans hNext
  have hranks := RestrictedPrefix.indepNumK_later_ranks
    (rowLengths μ) (rowLengths_antitone μ) r k hr hk hR' hNext'
  intro h hh
  exact (board_indepNumK_eq μ (r + h)).symm.trans (hranks h hh)

/-- The complete rank formula through `2r`, without asserting a realization. -/
theorem indepNumK_prefix_formula (μ : YoungDiagram) (r k : ℕ)
    (hr : 1 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r * k)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r + 1) = (r + 1) * k - r) :
    ∀ t ≤ 2 * r, FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) t =
      min t r * k + (t - r) * (k - r) := by
  have hR' : CornerCuts.factorRank (W := width μ) (rowLengths μ) r = r * k :=
    (factorRank_eq_indepNumK μ r).trans hR
  have hNext' : CornerCuts.factorRank (W := width μ) (rowLengths μ) (r + 1) =
      (r + 1) * k - r := (factorRank_eq_indepNumK μ (r + 1)).trans hNext
  intro t ht
  exact (factorRank_eq_indepNumK μ t).symm.trans
    (RestrictedPrefix.extremal_drop_rank_formula
      (rowLengths μ) (rowLengths_antitone μ) r k hr hk hR' hNext' t ht)

/-- A board finset viewed as actual natural-coordinate diagram cells.
Any nonallowed input points are discarded; cardinality is preserved for allowed
inputs, as stated in `cellFinset_card`. -/
noncomputable def cellFinset (μ : YoungDiagram)
    (M : Finset (Fin (height μ) × Fin (width μ))) :
    Finset (FCCompat.YoungDiagram.Cell μ) := by
  classical
  exact univ.filter (fun c => ((cellEquiv μ).symm c).val ∈ M)

@[simp] theorem mem_cellFinset (μ : YoungDiagram)
    (M : Finset (Fin (height μ) × Fin (width μ)))
    (c : FCCompat.YoungDiagram.Cell μ) :
    c ∈ cellFinset μ M ↔ ((cellEquiv μ).symm c).val ∈ M := by
  classical
  simp [cellFinset]

/-- Allowed inputs transfer to actual cells with exactly their cardinality. -/
theorem cellFinset_card (μ : YoungDiagram)
    (M : Finset (Fin (height μ) × Fin (width μ)))
    (hM : ∀ p ∈ M, CornerCuts.Allowed (rowLengths μ) p.1 p.2) :
    (cellFinset μ M).card = M.card := by
  classical
  apply card_bij (fun c _ => ((cellEquiv μ).symm c).val)
  · intro c hc
    exact (mem_cellFinset μ M c).mp hc
  · intro c hc d hd hcd
    exact (cellEquiv μ).symm.injective (Subtype.ext hcd)
  · intro p hp
    let a : BoardCell μ := ⟨p, hM p hp⟩
    refine ⟨cellEquiv μ a, ?_, ?_⟩
    · apply (mem_cellFinset μ M _).mpr
      simpa only [Equiv.symm_apply_apply] using hp
    · change ((cellEquiv μ).symm (cellEquiv μ a)).val = p
      simpa only [Equiv.symm_apply_apply] using (show a.val = p from rfl)

/-- A matching becomes an independent set of the natural-coordinate graph. -/
theorem cellFinset_independent (μ : YoungDiagram)
    (M : Finset (Fin (height μ) × Fin (width μ)))
    (hM : MatchingClasses.IsMatching M) :
    (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
      (cellFinset μ M : Set (FCCompat.YoungDiagram.Cell μ)) := by
  intro a ha b hb hne hadj
  have hab : (CellGraphRank.cellGraph
      (CornerCuts.Allowed (W := width μ) (rowLengths μ))).Adj
      ((cellEquiv μ).symm a) ((cellEquiv μ).symm b) := by
    apply (cellEquiv_adj_iff μ _ _).mp
    simpa only [Equiv.apply_symm_apply] using hadj
  have hend := (CellGraphRank.cellGraph_adj_iff _ _ _).mp hab
  have hval := hM _ ((mem_cellFinset μ M a).mp ha)
    _ ((mem_cellFinset μ M b).mp hb) hend.2
  exact hne ((cellEquiv μ).symm.injective (Subtype.ext hval))

/-- Disjoint board finsets remain disjoint as actual natural-coordinate cells. -/
theorem cellFinset_disjoint (μ : YoungDiagram)
    {M N : Finset (Fin (height μ) × Fin (width μ))} (hMN : Disjoint M N) :
    Disjoint (cellFinset μ M) (cellFinset μ N) := by
  classical
  apply disjoint_left.mpr
  intro c hc hd
  exact disjoint_left.mp hMN
    ((mem_cellFinset μ M c).mp hc) ((mem_cellFinset μ N c).mp hd)

/-- The first `h` members of a finite indexed family. -/
noncomputable def firstCells {α : Type*} [DecidableEq α] {r : ℕ}
    (M : Fin r → Finset α) (h : ℕ) : Finset α := by
  classical
  exact ((univ : Finset (Fin r)).filter (fun c => c.val < h)).biUnion M

/-- Disjoint equal-size families have the expected prefix cardinality. -/
theorem firstCells_card {α : Type*} [DecidableEq α] {r h d : ℕ}
    (M : Fin r → Finset α) (hh : h ≤ r)
    (hcard : ∀ c, (M c).card = d)
    (hdis : ∀ c e, c ≠ e → Disjoint (M c) (M e)) :
    (firstCells M h).card = h * d := by
  classical
  let S := (univ : Finset (Fin r)).filter (fun c => c.val < h)
  have hScard : S.card = h := CornerCuts.card_prefix_eq h hh
  change (S.biUnion M).card = h * d
  rw [card_biUnion (fun c hc e he hce => hdis c e hce)]
  calc
    _ = ∑ _c ∈ S, d := sum_congr rfl (fun c _ => hcard c)
    _ = h * d := by simp [hScard]

/-- Prefixes from cross-disjoint families remain disjoint. -/
theorem firstCells_disjoint {α : Type*} [DecidableEq α] {r : ℕ}
    (R G : Fin r → Finset α) (a b : ℕ)
    (hRG : ∀ c d, Disjoint (R c) (G d)) :
    Disjoint (firstCells R a) (firstCells G b) := by
  classical
  apply disjoint_left.mpr
  intro p hpR hpG
  unfold firstCells at hpR hpG
  obtain ⟨c, hc, hpR⟩ := mem_biUnion.mp hpR
  obtain ⟨d, hd, hpG⟩ := mem_biUnion.mp hpG
  exact disjoint_left.mp (hRG c d) hpR hpG

/-- Simultaneous first-`2r` independent-set realization on actual `μ.cells`.
There are `r` disjoint independent sets of size `k`, followed by `r` disjoint
independent sets of size `k-r`. Every ordered prefix through `2r` attains the
exact FC rank. This is stronger than the rank formula alone, but does not assert
an unrestricted CDS coloring or a filling beyond this prefix. -/
theorem first_two_r_independent_sets (μ : YoungDiagram) (r k : ℕ)
    (hr : 1 ≤ r) (hk : r ≤ k)
    (hR : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) r = r * k)
    (hNext : FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ)
      (r + 1) = (r + 1) * k - r) :
    ∃ R G : Fin r → Finset (FCCompat.YoungDiagram.Cell μ),
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (R c : Set (FCCompat.YoungDiagram.Cell μ)) ∧ (R c).card = k) ∧
      (∀ c, (FCCompat.YoungDiagram.toSimpleGraph μ).IsIndepSet
        (G c : Set (FCCompat.YoungDiagram.Cell μ)) ∧ (G c).card = k - r) ∧
      (∀ c d, c ≠ d → Disjoint (R c) (R d)) ∧
      (∀ c d, c ≠ d → Disjoint (G c) (G d)) ∧
      (∀ c d, Disjoint (R c) (G d)) ∧
      (∀ t ≤ 2 * r,
        (firstCells R (min t r) ∪ firstCells G (t - r)).card =
          FCCompat.indepNumK (FCCompat.YoungDiagram.toSimpleGraph μ) t) := by
  classical
  have hR' : CornerCuts.factorRank (W := width μ) (rowLengths μ) r = r * k :=
    (factorRank_eq_indepNumK μ r).trans hR
  have hNext' : CornerCuts.factorRank (W := width μ) (rowLengths μ) (r + 1) =
      (r + 1) * k - r := (factorRank_eq_indepNumK μ (r + 1)).trans hNext
  obtain ⟨R, G, hRed, hGreen, hRR, hGG, hRG, _⟩ :=
    RestrictedPrefix.first_two_r_matchings
      (rowLengths μ) (rowLengths_antitone μ) r k hr hk hR' hNext'
  let R' := fun c => cellFinset μ (R c)
  let G' := fun c => cellFinset μ (G c)
  have hRcard (c : Fin r) : (R' c).card = k :=
    (cellFinset_card μ (R c) (hRed c).2.2).trans (hRed c).2.1
  have hGcard (c : Fin r) : (G' c).card = k - r :=
    (cellFinset_card μ (G c) (hGreen c).2.2).trans (hGreen c).2.1
  have hRR' (c d : Fin r) (hcd : c ≠ d) : Disjoint (R' c) (R' d) :=
    cellFinset_disjoint μ (hRR c d hcd)
  have hGG' (c d : Fin r) (hcd : c ≠ d) : Disjoint (G' c) (G' d) :=
    cellFinset_disjoint μ (hGG c d hcd)
  have hRG' (c d : Fin r) : Disjoint (R' c) (G' d) :=
    cellFinset_disjoint μ (hRG c d)
  refine ⟨R', G', ?_, ?_, hRR', hGG', hRG', ?_⟩
  · intro c
    exact ⟨cellFinset_independent μ (R c) (hRed c).1, hRcard c⟩
  · intro c
    exact ⟨cellFinset_independent μ (G c) (hGreen c).1, hGcard c⟩
  · intro t ht
    have hdiff : t - r ≤ r := by omega
    rw [card_union_of_disjoint (firstCells_disjoint R' G' (min t r) (t - r) hRG'),
      firstCells_card R' (Nat.min_le_right t r) hRcard hRR',
      firstCells_card G' hdiff hGcard hGG']
    exact (indepNumK_prefix_formula μ r k hr hk hR hNext t ht).symm

#print axioms indepNumK_later_ranks
#print axioms indepNumK_prefix_formula
#print axioms first_two_r_independent_sets

end FerrersArm.YoungDiagramBridge
