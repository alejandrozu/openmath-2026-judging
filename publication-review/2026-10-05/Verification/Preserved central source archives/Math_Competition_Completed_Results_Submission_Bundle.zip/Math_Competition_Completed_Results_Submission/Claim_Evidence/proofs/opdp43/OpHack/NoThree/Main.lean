import OpHack.NoThree.GridBalance

namespace NoThreeSymmetry
open Finset

/-- Every full no-three-in-line grid configuration is either exactly half-turn
symmetric, or has at least four points whose half-turn partners are absent. -/
theorem grid_half_turn_gap {n : ℕ} (A : Finset (GridPoint n))
    (h : GridNoThree A) (hcard : A.card = 2*n) :
    (gridDefect A).card = 0 ∨ 4 ≤ (gridDefect A).card := by
  by_cases hn : 3 ≤ n
  · exact grid_half_turn_gap_large hn h hcard
  · have hn' : n < 3 := by omega
    interval_cases n
    · have hA : A = ∅ := Finset.card_eq_zero.mp (by simpa using hcard)
      simp [hA, gridDefect]
    · have hb := Finset.card_le_card (Finset.subset_univ A)
      norm_num at hb
      omega
    · have hA : A = Finset.univ := Finset.eq_univ_of_card A (by simpa using hcard)
      have himage : (Finset.univ : Finset (GridPoint 2)).image rotate = Finset.univ := by
        ext p
        simp only [mem_image, mem_univ, true_and, iff_true]
        exact ⟨rotate p, rotate_rotate p⟩
      simp [hA, gridDefect, himage]

/-- A sharp ten-point example on the five-by-five grid. -/
def witness5 : Finset (GridPoint 5) :=
  {(1,0), (2,0), (0,1), (4,1), (3,2), (4,2), (0,3), (1,3), (2,4), (3,4)}

set_option maxRecDepth 1000000
set_option maxHeartbeats 0
set_option synthInstance.maxSize 100000

theorem witness5_card : witness5.card = 10 := by decide

def integerDet {n : ℕ} (p q r : GridPoint n) : ℤ :=
  ((q.1.val : ℤ) - p.1.val) * ((r.2.val : ℤ) - p.2.val) -
  ((r.1.val : ℤ) - p.1.val) * ((q.2.val : ℤ) - p.2.val)

theorem witness5_integer_check :
    ∀ p ∈ witness5, ∀ q ∈ witness5, ∀ r ∈ witness5,
      p ≠ q → p ≠ r → q ≠ r → integerDet p q r ≠ 0 := by decide

theorem witness5_noThree : GridNoThree witness5 := by
  intro p hp q hq r hr hpq hpr hqr hz
  apply witness5_integer_check p hp q hq r hr hpq hpr hqr
  dsimp [det, raw] at hz
  unfold integerDet
  exact_mod_cast hz

theorem witness5_defect : (gridDefect witness5).card = 4 := by decide

/-- Four is the exact minimum positive half-turn defect over all full grid
configurations, with a five-by-five witness. -/
theorem sharp_half_turn_gap :
    (∀ (n : ℕ) (A : Finset (GridPoint n)), GridNoThree A → A.card = 2*n →
      (gridDefect A).card = 0 ∨ 4 ≤ (gridDefect A).card) ∧
    (∃ A : Finset (GridPoint 5), A.card = 10 ∧ GridNoThree A ∧ (gridDefect A).card = 4) :=
  ⟨fun _ A h hc => grid_half_turn_gap A h hc,
    ⟨witness5, witness5_card, witness5_noThree, witness5_defect⟩⟩

#print axioms grid_half_turn_gap
#print axioms witness5_noThree
#print axioms sharp_half_turn_gap
end NoThreeSymmetry
